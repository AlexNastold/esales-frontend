# esales-frontend

eSales Frontend

## Installation

```bash
  npm install
```

## Development

```bash
  npm run dev
```

## Build for production

```bash
  npm run build:sap
```

## Upgrades

Install global package: [npm-check-updates](https://www.npmjs.com/package/npm-check-updates>)

```bash
  ncu
```

## Set shop-url

File: src\scripts\core\paths.ts

```javascript
  const getServerOrigin = () => {
    const port = location.port ? ':' + location.port : ''
    const origin = `${location.protocol}//${location.hostname}${port}`

    if (/(xed|esr)\.fis-gmbh.de/.test(location.hostname)) {
      return origin
    }

    // Diese Domain wird für Webservice-Requests, zum Auflösen von Bildpfaden usw. verwendet,
    // wenn der Shop unter einer unbekannten Domain (z.B. Localhost) läuft
    return 'https://xed.fis-gmbh.de'
}
```

## Set url for server.js and config for upload

File: technical\config.js

```javascript
  // Diese URL wird zum Einbinden der server.js Datei verwendet, wenn KEIN
  // SAP-Build durchgeführt wird (z.B. wenn das Frontend lokal gehostet wird)
  serverUrl: 'https://xed.fis-gmbh.de/fisesales(====)/shop/',

  // Die hier definierten Systeme können beim Upload ausgewählt werden
  systems: [
    {
      id: 'XED',
      package: '/fis/esi_all',
      syncServiceUrl: 'https://xed.fis-gmbh.de/fis/mime_sync',
      targetBspApplication: '/fis/esi_shop',
    },
  ],
```
