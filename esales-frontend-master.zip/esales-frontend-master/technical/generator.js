const inquirer = require('inquirer')

inquirer.prompt([{
  choices: [
    'Neue Seite',
    'Neues Layout',
  ],
  default: 0,
  message: 'Was willst du generieren?',
  name: 'action',
  type: 'list',
}]).then((answers) => {
  switch (answers.action) {
    case 'Neue Seite':
      require('./generators/new-page')()
      break
    case 'Neues Layout':
      require('./generators/new-layout')()
      break
  }
})
