/* global __dirname module */
/* eslint-disable no-console */
// tslint:disable no-console

const path = require('path')
const fs = require('fs')
const inquirer = require('inquirer')
const chalk = require('chalk')

const replace = require('../_helpers/replacer')
const pagesPath = path.resolve(__dirname, '../../../src/pages')

module.exports = async function () {
  const pageName = await getPageName()
  const pagePath = path.join(pagesPath, pageName)

  fs.mkdirSync(pagePath)
  console.log(`
    ${chalk.green.bold('SUCCESS')}
    Seite "${chalk.green(pageName)}" generiert (${chalk.underline(pagePath)})
  `)

  const filesToCopy = [
    { from: 'index.hbs.tmpl', to: `${pageName}.hbs`, text: 'HTML-Datei' },
    { from: 'index.scss.tmpl', to: `${pageName}.scss`, text: 'SCSS-Datei' },
    { from: 'index.ts.tmpl', to: `${pageName}.ts`, text: 'TS-Einstiegs-Datei' },
    { from: 'index.vue.tmpl', to: `${pageName}.vue`, text: 'Vue-Datei' },
  ]

  filesToCopy.forEach(file => {
    const filePath = path.join(pagePath, file.to)
    let content = fs.readFileSync(path.resolve(__dirname, 'templates', file.from), 'utf-8')
    content = replace(content, { page: pageName })
    fs.writeFileSync(filePath, content)
    console.log(`${chalk.green.bold('SUCCESS')} ${file.text} generiert (${chalk.underline(filePath)})`)
  })
}

async function getPageName () {
  const { page: pageName } = await inquirer.prompt([{
    message: 'Wie soll die Seite heißen? (ohne Endung)',
    name: 'page',
    type: 'input',
    validate: checkName,
  }])

  return pageName
}

function checkName (name) {
  if (!name) {
    return 'Der Name darf nicht leer sein'
  }
  if (name.length > 31) {
    return 'Der Name darf nicht länger als 31 Zeichen sein'
  }
  if (!/^[A-Za-z0-9\-_]+$/.test(name)) {
    return 'Der Name darf nur aus Buchstaben, Zahlen, "-" und "_" bestehen'
  }
  if (/^[0-9]/.test(name)) {
    return 'Der Name darf nicht mit einer Zahl beginnen'
  }
  if (fs.existsSync(path.join(pagesPath, name))) {
    return 'Diese Seite gibt es bereits'
  }
  return true
}
