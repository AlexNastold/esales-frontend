/* global module */

module.exports = function (content, data = {}) {

  // Replace date and time
  const tzoffset = (new Date()).getTimezoneOffset() * 60000
  const now = new Date(Date.now() - tzoffset)
  if (!Object.prototype.hasOwnProperty.call(data, 'date')) {
    data.date = now.toISOString().slice(0, 10)
  }
  if (!Object.prototype.hasOwnProperty.call(data, 'time')) {
    data.time = now.toISOString().slice(11, 19)
  }

  // Replace name
  Object.keys(data).forEach(key => {
    const regex = new RegExp(`{{${key}}}`, 'g')
    content = content.replace(regex, data[key])
  })

  return content
}
