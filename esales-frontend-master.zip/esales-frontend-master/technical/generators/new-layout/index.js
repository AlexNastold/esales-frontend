/* global __dirname module */
/* eslint-disable no-console */
// tslint:disable no-console

const replace = require('../_helpers/replacer')
const path = require('path')
const fs = require('fs')
const inquirer = require('inquirer')
const chalk = require('chalk')

const layoutsPath = path.resolve(__dirname, '../../../src/layouts')

module.exports = async function () {
  const layoutName = await getLayoutName()
  const layoutPath = path.join(layoutsPath, `${layoutName}.hbs`)

  let content = fs.readFileSync(path.resolve(__dirname, 'templates/index.hbs.tmpl'), 'utf-8')
  content = replace(content, { layout: layoutName })
  fs.writeFileSync(layoutPath, content)
  console.log(`
    ${chalk.green.bold('SUCCESS')}
    Layout "${chalk.green(layoutName)}" generiert (${chalk.underline(layoutPath)})
  `)
}

async function getLayoutName () {
  const { layout: layoutName } = await inquirer.prompt([{
    message: 'Wie soll das Layout heißen? (ohne Endung)',
    name: 'layout',
    type: 'input',
    validate: checkName,
  }])

  return layoutName
}

function checkName (name) {
  if (!name) {
    return 'Der Name darf nicht leer sein'
  }
  if (!/^[A-Za-z0-9\-_]+$/.test(name)) {
    return 'Der Name darf nur aus Buchstaben und Zahlen bestehen'
  }
  if (/^[0-9]/.test(name)) {
    return 'Der Name darf nicht mit einer Zahl beginnen'
  }
  if (fs.existsSync(path.join(layoutsPath, `${name}.hbs`))) {
    return 'Das Layout gibt es bereits'
  }
  return true
}
