/* globals __dirname module*/
const path = require('path')

const rootDir = path.resolve(__dirname, '../')

module.exports = {

  // Do not change these paths if you don't know what you're doing
  // (this is not a config)

  dist: path.resolve(rootDir, 'dist'),
  pages: {
    entries: path.resolve(rootDir, 'src/pages/*/*.hbs'),
    helpers: path.resolve(rootDir, 'technical/helpers/**/*.js'),
    layouts: path.resolve(rootDir, 'src/layouts/**/*.hbs'),
    layoutsBase: path.resolve(rootDir, 'src'),
  },
}
