/* globals __dirname module */
/* eslint-disable no-console */
// tslint:disable no-console

const fs = require('fs')
const path = require('path')
const archiver = require('archiver')
const inquirer = require('inquirer')
const request = require('request')
const chalk = require('chalk')
const config = require('../../config')

function zip (output) {
  return new Promise((resolve, reject) => {
    const fileOutput = fs.createWriteStream(output)
    fileOutput.on('close', () => resolve())

    const archive = archiver('zip', { zlib: { level: 9 }})
    archive.pipe(fileOutput)
    archive.glob('**/*', {
      cwd: path.join(__dirname, '../../../dist'),
    })
    archive.on('error', reject)
    archive.finalize()
  })
}

function getSystem () {
  if (config.systems.length === 1) {
    return Promise.resolve(config.systems[0])
  }

  const choices = config.systems.map((system) => {
    return {
      name: system.id,
      value: system.id,
    }
  })

  return inquirer.prompt([{
    choices,
    message: 'System:',
    name: 'system',
    type: 'list',
  }])
    .then((answers) => {
      return config.systems.find((system) => system.id === answers.system)
    })
}

function ensureCorrectBuild () {
  return inquirer.prompt([{
    default: false,
    message: 'Did you build with "build:sap"?',
    name: 'correctBuild',
    type: 'confirm',
  }])
    .then((answers) => answers.correctBuild)
}

function getCredentials () {
  return inquirer.prompt([{
    message: 'Username:',
    name: 'username',
    type: 'input',
  }, {
    message: 'Password:',
    name: 'password',
    type: 'password',
  }])
}

function checkCredentials (system, username, password) {
  return new Promise((resolve, reject) => {
    const formData = {
      task: 'ping',
    }

    request.post({
      auth: {
        pass: password,
        sendImmediately: true,
        user: username,
      },
      formData: formData,
      proxy: 'http://proxy:8080',
      rejectUnauthorized: false,
      timeout: 10000,
      url: system.syncServiceUrl,
    }, function (err, response) {
      if (err) {
        return reject(err)
      }
      if (response.statusCode !== 200) {
        return reject(new Error(`HTTP Status Code "${response.statusCode}", Message "${response.statusMessage}"`))
      }
      return resolve()
    })
  })
}

function getTransport (system, username, password) {
  return getTransports(system, username, password)
    .then((transports) => {
      const choices = [{
        name: 'Manual input',
        value: 'manual',
      }]

      transports.reduce((acc, transport) => {
        if (!acc.some((t) => t.strkorr === transport.strkorr)) {
          acc.push(transport)
        }
        return acc
      }, [])

      transports.forEach((transport) => choices.push({
        name: `${transport.strkorr}: ${transport.name}`,
        value: transport.strkorr,
      }))

      return inquirer.prompt([{
        choices,
        default: 'Manual',
        message: 'Transport:',
        name: 'transport',
        type: 'list',
      }])
        .then((answers) => {
          if (answers.transport !== 'manual') {
            return answers
          }
          return inquirer.prompt([{
            message: 'Transport (manual):',
            name: 'transport',
            type: 'input',
          }])
        })
        .then((answers) => answers.transport)
    })
}

function getTransports (system, username, password) {
  return new Promise((resolve, reject) => {
    const formData = {
      task: 'transports',
    }

    request.post({
      auth: {
        pass: password,
        sendImmediately: true,
        user: username,
      },
      formData: formData,
      proxy: 'http://proxy:8080',
      rejectUnauthorized: false,
      timeout: 10000,
      url: system.syncServiceUrl,
    }, function (err, response, body) {
      if (err) {
        return reject(err)
      }
      if (response.statusCode !== 200) {
        return reject(new Error(`HTTP Status Code "${response.statusCode}", Message "${response.statusMessage}"`))
      }
      return resolve(JSON.parse(body))
    })
  })
}

function upload (system, username, password, transport, dry, zipPath) {
  return new Promise((resolve, reject) => {
    const formData = {
      bsp_application: system.targetBspApplication,
      dry: dry ? 1 : 0,
      fileUpload: fs.createReadStream(zipPath),
      package: system.package,
      task: 'upload',
      transport_req: transport,
    }

    request.post({
      auth: {
        pass: password,
        sendImmediately: true,
        user: username,
      },
      formData: formData,
      proxy: 'http://proxy:8080',
      rejectUnauthorized: false,
      timeout: 180000,
      url: system.syncServiceUrl,
    }, function (err, response, body) {
      if (err) {
        return reject(err)
      }
      if (response.statusCode !== 200) {
        return reject(new Error(
          `HTTP Status Code "${response.statusCode}", ` +
          `Message "${response.statusMessage}", ` +
          `Body "${body}"`))
      }
      resolve(JSON.parse(body))
    })
  })
}

function logUploadResponse (response) {
  const {
    dryRun,
    runtime,
    mimeUrl,
    filesToAdd,
    filesToDelete,
    filesToModify,
    filesToKeep,
    directoriesToDelete,
  } = response

  console.log(chalk.bold.green(
    `Uploaded zip into mime repository ${mimeUrl} ${dryRun ? '(dry run)' : ''} in ${runtime}`,
  ))
  console.log(' ')
  console.log(chalk.underline.blue(`Files added (${filesToAdd.length}):`))
  logFiles(filesToAdd)
  console.log(chalk.underline.blue(`Files modified (${filesToModify.length}):`))
  logFiles(filesToModify)
  console.log(chalk.underline.blue(`Files kept (${filesToKeep.length}):`))
  logFiles(filesToKeep)
  console.log(chalk.underline.blue(`Files deleted (${filesToDelete.length}):`))
  logFiles(filesToDelete)
  console.log(chalk.underline.blue(`Directories deleted (${directoriesToDelete.length}):`))
  logFiles(directoriesToDelete)
}

function logFiles (files) {
  if (!files.length) {
    console.log(chalk.italic.red('  None'))
    console.log(' ')
    return
  }
  files.forEach(file => console.log(chalk.italic.green(`  ${file}`)))
  console.log(' ')
}

function retry () {
  return inquirer.prompt([{
    default: false,
    message: 'Try again?',
    name: 'retry',
    type: 'confirm',
  }])
    .then((answers) => answers.retry)
}

module.exports = {
  checkCredentials,
  ensureCorrectBuild,
  getCredentials,
  getSystem,
  getTransport,
  logUploadResponse,
  retry,
  upload,
  zip,
}
