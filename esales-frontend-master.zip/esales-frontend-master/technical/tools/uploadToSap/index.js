/* globals process __dirname */
/* eslint-disable no-console */
// tslint:disable no-console
// tslint:disable:object-literal-sort-keys

const fs = require('fs')
const path = require('path')
const machina = require('machina')
const chalk = require('chalk')
const {
  checkCredentials,
  ensureCorrectBuild,
  getCredentials,
  getSystem,
  getTransport,
  logUploadResponse,
  retry,
  upload,
  zip,
} = require('./helper.js')
const {
  MAX_LEN_BEFORE_BUILD,
  MAX_LEN_IN_DIST,
  getFilesTooLongBeforeBuild,
  getFilesTooLongInDist,
  outputFiles,
} = require('../uploadCheck/helper')

const state = {
  system: void 0,
  dry: void 0,
  password: void 0,
  transport: void 0,
  username: void 0,
}

const zipDir = path.join(__dirname, '../../../build')
const zipPath = path.join(__dirname, '../../../build/build.zip')

// tslint:disable-next-line:no-unused-expression
new machina.Fsm({
  initialState: 'checkCode',
  namespace: 'upload',
  states: {
    checkCode: {
      _onEnter: function () {
        // Seiten-Namen, welche zu lange sind
        const filesTooLongBeforeBuild = getFilesTooLongBeforeBuild()
        // Dateien, welche zu lang sind
        const filesTooLongInDist = getFilesTooLongInDist()

        if (filesTooLongBeforeBuild.length || filesTooLongInDist.length) {
          outputFiles(
            filesTooLongBeforeBuild,
            `Folgende Seitennamen sind zu lang (maximal ${MAX_LEN_BEFORE_BUILD} Zeichen)`,
          )

          outputFiles(
            filesTooLongInDist,
            `Folgende Dateien im "dist"-Verzeichnis sind zu lang (maximal ${MAX_LEN_IN_DIST} Zeichen)`,
          )
          return
        }
        this.transition('ensureCorrectBuild')
      },
    },
    ensureCorrectBuild: {
      _onEnter: function () {
        ensureCorrectBuild()
          .then((result) => {
            if (!result) {
              console.error(`${chalk.red.bold('Please build the application with "build:sap"')}`)
              return
            }
            this.transition('askForSystem')
          })
      },
    },
    askForSystem: {
      _onEnter: function () {
        getSystem()
          .then((system) => state.system = system)
          .then(() => this.transition('showInfo'))
      },
    },
    showInfo: {
      _onEnter: function () {
        console.log()
        console.log(chalk.bold.cyan('Files will be uploaded'))
        console.log(chalk.bold.cyan(`  to system ${chalk.yellow.bold(state.system.id)}`))
        console.log(chalk.bold.cyan(`  to BSP application ${chalk.yellow.bold(state.system.targetBspApplication)}`))
        console.log(chalk.bold.cyan(`  in package ${chalk.yellow.bold(state.system.package)}`))
        console.log(chalk.bold.cyan(`  via webservice ${chalk.yellow.bold(state.system.syncServiceUrl)}`))
        console.log()
        this.transition('askForCredentials')
      },
    },
    askForCredentials: {
      _onEnter: function () {
        getCredentials()
          .then((credentials) => {
            state.username = credentials.username
            state.password = credentials.password
          })
          .then(() => this.transition('checkCredentials'))
      },
    },
    checkCredentials: {
      _onEnter: function () {
        checkCredentials(state.system, state.username, state.password)
          .then(() => this.transition('askForTransport'))
          .catch((err) => {
            console.error(`${chalk.red.bold('Wrong credentials')} ()${chalk.red(err.message)}`)
            this.transition('askForCredentials')
          })
      },
    },
    askForTransport: {
      _onEnter: function () {
        if (state.system.package.toUpperCase() === '$TMP') {
          console.log(
            chalk.bold.cyan('Skipping transport selection because target application is in local package ') +
            chalk.yellow.bold(state.system.package),
          )
          state.transport = ''
          return this.transition('zip')
        }
        getTransport(state.system, state.username, state.password)
          .then((transport) => state.transport = transport)
          .then(() => this.transition('zip'))
      },
    },
    zip: {
      _onEnter: function () {
        if (!fs.existsSync(zipDir)) {
          fs.mkdirSync(zipDir)
        }
        zip(zipPath)
          .then(() => this.transition('upload'))
      },
    },
    upload: {
      _onEnter: function () {
        upload(
          state.system,
          state.username,
          state.password,
          state.transport,
          state.dry,
          zipPath,
        )
          .then(logUploadResponse)
          .then(() => this.transition('finish'))
          .catch((err) => {
            console.error(`${chalk.red.bold('Upload failed')} (${chalk.red(err)})`)
            this.transition('askForRetry')
          })
      },
    },
    askForRetry: {
      _onEnter: function () {
        retry()
          .then((retryUpload) => {
            if (retryUpload) {
              this.transition('upload')
            } else {
              this.transition('finish')
            }
          })
      },
    },
    finish: {
      _onEnter: function () {
        if (fs.existsSync(zipPath)) {
          fs.unlinkSync(zipPath)
        }
        process.exit()
      },
    },
  },
})
