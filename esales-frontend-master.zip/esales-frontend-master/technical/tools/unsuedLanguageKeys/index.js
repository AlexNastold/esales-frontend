/* global process */
/* eslint-disable no-console */
// tslint:disable no-console

const chalk = require('chalk')
const commandLineArgs = require('command-line-args')
const commandLineUsage = require('command-line-usage')
const {
  failIfNeccessary,
  getLanguageKeysData,
  outputToJson,
  printOutput,
} = require('./helper')

// tslint:disable:max-line-length
const optionDefinitions = [
  { name: 'help', alias: 'h', type: Boolean, description: 'Diese Hilfe anzeigen' },
  { name: 'language', alias: 'l', type: String, description: 'Nur diese Sprache prüfen' },
  { name: 'failOnUnused', alias: 'f', type: Boolean, description: 'Bei nicht benutzten Sprach-Keys mit Exit-Code 1 beenden' },
  { name: 'failOnNotFound', alias: 'n', type: Boolean, description: 'Bei nicht konfigurierten Sprach-Keys mit Exit-Code 1 beenden' },
  { name: 'quiet', alias: 'q', type: Boolean, description: 'Keine Ausgabe erzeugen' },
  { name: 'json', alias: 'j', type: Boolean, description: 'Als JSON ausgeben' },

  { name: 'outputAll', alias: 'a', type: Boolean, description: 'Alles ausgeben' },
  { name: 'outputCritical', alias: 'c', type: Boolean, description: 'Alle Kritischen ausgeben' },
  { name: 'outputAllFromConfig', type: Boolean, description: 'Alle Sprach-Keys ausgeben (aus Konfiguration)' },
  { name: 'outputUsedFromConfig', type: Boolean, description: 'Benutzte Sprach-Keys ausgeben (aus Konfiguration)' },
  { name: 'outputUnusedFromConfig', type: Boolean, description: 'Nicht benutzte Sprach-Keys ausgeben (aus Konfiguration)' },
  { name: 'outputIgnoredFromConfig', type: Boolean, description: 'Ignorierte Sprach-Keys ausgeben (aus Konfiguration)' },
  { name: 'outputIgnoredPluralFromConfig', type: Boolean, description: 'Ignorierte Plural-Sprach-Keys ausgeben (aus Konfiguration)' },
  { name: 'outputRelevantFromConfig', type: Boolean, description: 'Relevante Sprach-Keys ausgeben (aus Konfiguration)' },
  { name: 'outputAllFromSource', type: Boolean, description: 'Alle Sprach-Keys ausgeben (aus Quelltext)' },
  { name: 'outputFoundFromSource', type: Boolean, description: 'Konfigurierte Sprach-Keys ausgeben (aus Quelltext)' },
  { name: 'outputNotFoundFromSource', type: Boolean, description: 'Nicht konfigurierte Sprach-Keys ausgeben (aus Quelltext)' },
]
// tslint:enable:max-line-length

const args = commandLineArgs(optionDefinitions)
if (args.outputAll) {
  args.outputAllFromConfig = true
  args.outputUsedFromConfig = true
  args.outputUnusedFromConfig = true
  args.outputIgnoredFromConfig = true
  args.outputIgnoredPluralFromConfig = true
  args.outputRelevantFromConfig = true
  args.outputAllFromSource = true
  args.outputFoundFromSource = true
  args.outputNotFoundFromSource = true
}
if (args.outputCritical) {
  args.outputUnusedFromConfig = true
  args.outputNotFoundFromSource = true
}

if (args.help) {
  console.log(commandLineUsage([{
    content: 'Ein Tool zum überprüfen von Sprach-Keys',
    header: 'Sprach-Keys',
  }, {
    header: 'Optionen',
    optionList: optionDefinitions,
  }]))
  process.exit()
}

const { result, stats } = getLanguageKeysData(args.language ? [args.language] : void 0)

if (!args.quiet) {
  if (args.json) {
    outputToJson(result, args)
  } else {
    outputStats()

    // Prüfen, ob ein output Argument gesetzt ist
    if (Object.keys(args).filter((arg) => arg.indexOf('output') === 0 && arg).length) {
      let printedLines = 0

      Object.keys(result).forEach((language, index) => {
        const outputData = result[language]
        if (index > 0) {
          console.log()
        }
        console.log(chalk.bold.blue(`Sprache: ${language}`))
        console.log(chalk.bold.blue('--------------------------'))
        printedLines += printOutput(outputData, args)
      })
      console.log()

      if (printedLines > 50) {
        outputStats()
      }
    }
  }
}
failIfNeccessary(result, args)

function outputStats () {
    // tslint:disable:max-line-length
  console.log(chalk.blue.underline('Konfiguration'))
  console.log(`${chalk.grey('Alle:              ')} ${stats.fromConfig.all}`)
  console.log(`${chalk.grey('Relevant:          ')} ${stats.fromConfig.relevant}`)
  console.log(`${chalk.grey('Benutzt:           ')} ${stats.fromConfig.used}`)
  console.log(`${chalk.grey('Unbenutzt:         ')} ${chalk[stats.fromConfig.unused ? 'red' : 'green'](stats.fromConfig.unused)}` + (stats.fromConfig.unused ? ' ⚠️' : ''))
  console.log(`${chalk.grey('Ignoriert:         ')} ${stats.fromConfig.ignored}`)
  console.log(`${chalk.grey('Ignoriert (Plural):')} ${stats.fromConfig.ignoredPlural}`)
  console.log()
  console.log(chalk.blue.underline('Quelltext'))
  console.log(`${chalk.grey('Alle:              ')} ${stats.fromSource.all}`)
  console.log(`${chalk.grey('Konfiguriert:      ')} ${stats.fromSource.found}`)
  console.log(`${chalk.grey('Nicht konfiguriert:')} ${chalk[stats.fromSource.notFound ? 'red' : 'green'](stats.fromSource.notFound)}` + (stats.fromSource.notFound ? ' ⚠️' : ''))
  console.log()
    // tslint:enable:max-line-length
}
