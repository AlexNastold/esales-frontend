/* global module process __dirname */
/* eslint-disable no-console */
// tslint:disable no-console
const fs = require('fs')
const path = require('path')
const chalk = require('chalk')

Array.prototype.unique = function () {
  return this.filter((value, index, self) => {
    return self.indexOf(value) === index
  })
}

function getLanguageKeysData (languages) {
  // Alle ignorierten Sprach-Keys ermitteln
  const ignoredKeysFile = path.join(__dirname, 'ignoredLanguageKeys.ini')
  const keysFromConfigIgnored = getIgnoredKeys(ignoredKeysFile)

  // Alle Sprache-Keys ermitteln
  const languageDir = path.resolve(__dirname, '../../../src/lang')
  let files = fs.readdirSync(languageDir)
    .filter((file) => /\.json$/.test(file))

  if (languages) {
    files = files.filter((file) => {
      const extension = path.extname(file)
      const basename = file.substring(0, file.length - extension.length)
      return languages.includes(basename.toLowerCase())
    })
  }

  const languageKeys = files.reduce((acc, file) => {
    const language = file.match(/(.*)\.json/)[1]
    const filePath = path.resolve(languageDir, file)
    const fileOtrs = require(filePath)
    acc[language] = getObjectKeysFlat(fileOtrs)
    return acc
  }, {})

  // Alle Dateipfade ermitteln, welche durchsucht werden sollen
  const srcFilePaths = getAllFilesInDirectories([
    path.resolve(__dirname, '../../../src/components'),
    path.resolve(__dirname, '../../../src/pages'),
    path.resolve(__dirname, '../../../src/scripts'),
  ], ['.js', '.ts', '.vue'])

  // Alle Quelltexte der Dateien, die durchsucht werden sollen, zusammenhängen
  const allSourcesConcat = getSourceFromFilePaths(srcFilePaths)

  // Alle Sprach-Keys aus dem Quelltext ermitteln
  const keysFromSource = findKeysInText(allSourcesConcat)

  const stats = {
    fromConfig: {
      all: 0,
      ignored: 0,
      ignoredPlural: 0,
      relevant: 0,
      unused: 0,
      used: 0,
    },
    fromSource: {
      all: 0,
      found: 0,
      notFound: 0,
    },
  }

  // Sprache-Keys prüfen
  const result = Object.keys(languageKeys).reduce((acc, language) => {
    const keysFromConfig = languageKeys[language]
    const keysFromConfigFiltered = keysFromConfig
      .filter((key) => !/_plural$/.test(key))
      .filter(removeKeys(keysFromConfigIgnored))

    const keysFromConfigPlural = keysFromConfig
      .filter((key) => /_plural$/.test(key))

    const keysFromConfigUsed = keysFromConfigFiltered.filter((key) => {
      return keysFromSource.includes(key)
    })
    const keysFromConfigUnused = keysFromConfigFiltered.filter((key) => {
      return !keysFromSource.includes(key)
    })
    const keysFromSourceAndInLanguageFile = keysFromSource.filter((key) => {
      return keysFromConfig.includes(key)
    })
    const keysFromSourceButNotInLanguageFile = keysFromSource.filter((key) => {
      return !keysFromConfig.includes(key)
    })

    acc[language] = {
      fromConfig: {
        all: keysFromConfig,
        ignored: keysFromConfigIgnored,
        ignoredPlural: keysFromConfigPlural,
        relevant: keysFromConfigFiltered,
        unused: keysFromConfigUnused,
        used: keysFromConfigUsed,
      },
      fromSource: {
        all: keysFromSource,
        found: keysFromSourceAndInLanguageFile,
        notFound: keysFromSourceButNotInLanguageFile,
      },
    }
    stats.fromConfig.all += keysFromConfig.length
    stats.fromConfig.ignored += keysFromConfigIgnored.length
    stats.fromConfig.ignoredPlural += keysFromConfigPlural.length
    stats.fromConfig.relevant += keysFromConfigFiltered.length
    stats.fromConfig.unused += keysFromConfigUnused.length
    stats.fromConfig.used += keysFromConfigUsed.length
    stats.fromSource.all += keysFromSource.length
    stats.fromSource.found += keysFromSourceAndInLanguageFile.length
    stats.fromSource.notFound += keysFromSourceButNotInLanguageFile.length
    return acc
  }, {})

  return {
    result,
    stats,
  }
}

/**
 * Gibt alle zu ignorierenden Keys aus der Datei ignoredLanguageKeys.ini zurück
 */
function getIgnoredKeys (file) {
  return fs.readFileSync(file)
    .toString()
    .split(/\n\r?/)
    .filter((line) => line.indexOf('#') !== 0 && line.indexOf(';') !== 0)
    .map((line) => line.trim())
    .filter((line) => line)
}

function getAllFilesInDirectories (directories, extensions) {
  let filePaths = directories.reduce((acc, dir) => {
    const dirFiles = readDirR(dir)
    dirFiles.forEach((file) => acc.push(file))
    return acc
  }, [])

  if (extensions) {
    filePaths = filePaths.filter((filePath) => {
      const extName = path.extname(filePath)
      return extensions.includes(extName)
    })
  }

  return filePaths
}

function readDirR (dir) {
  return fs.statSync(dir).isDirectory()
    ? Array.prototype.concat(...fs.readdirSync(dir).map(f => readDirR(path.join(dir, f))))
    : dir
}

function getSourceFromFilePaths (filePaths) {
  return filePaths
    .map(file => fs.readFileSync(file))
    .join(' ')
}

function findKeysInText (text) {
  const regex = /(\$|\.)t\('([A-Za-z0-9.]+)'(\)|,)/gi
  const keys = []
  let match = null

  // tslint:disable-next-line:no-conditional-assignment
  while ((match = regex.exec(text)) != null) {
    if (!keys.includes(match[1])) {
      keys.push(match[2])
    }
  }
  keys.sort()
  return keys.unique()
}

function outputToJson (output, args) {
  const filteredOutput = Object.keys(output).reduce((acc, language) => {
    acc[language] = filterOutput(output[language], args)
    return acc
  }, {})
  console.log(JSON.stringify(filteredOutput))
}

function getObjectKeysFlat (obj, parentKey) {
  return Object.keys(obj).reduce((acc, key) => {
    const newKey = parentKey ? `${parentKey}.${key}` : key
    if (typeof obj[key] === 'string' || Array.isArray(obj[key])) {
      acc.push(newKey)
    } else {
      acc.push(...getObjectKeysFlat(obj[key], newKey))
    }
    return acc
  }, [])
}

function removeKeys (keys) {
  return function (key) {
    return !keys.includes(key)
  }
}

function printSection (title, keys, critical = false) {
  if (critical && keys.length) {
    console.log('⚠️  ' + chalk.red(`${title} (${keys.length}):`))
  } else {
    console.log('✅  ' + chalk.green(`${title} (${keys.length}):`))
  }
  if (keys.length) {
    keys.forEach((key) => console.log('- ' + chalk.white(key)))
  }
  console.log()
}

function printOutput (outputData, args) {
  let lines = 0
  if (args.outputAllFromConfig) {
    printSection('Alle Sprach-Keys aus Konfiguration', outputData.fromConfig.all)
    lines += outputData.fromConfig.all.length
  }
  if (args.outputRelevantFromConfig) {
    printSection('Relevante Sprach-Keys aus Konfiguration', outputData.fromConfig.relevant)
    lines += outputData.fromConfig.relevant.length
  }
  if (args.outputUsedFromConfig) {
    printSection('Benutzte Sprach-Keys aus Konfiguration', outputData.fromConfig.used)
    lines += outputData.fromConfig.used.length
  }
  if (args.outputUnusedFromConfig) {
    printSection('Unbenutzte Sprach-Keys aus Konfiguration', outputData.fromConfig.unused, true)
    lines += outputData.fromConfig.unused.length
  }
  if (args.outputIgnoredFromConfig) {
    printSection('Ignorierte Sprach-Keys aus Konfiguration', outputData.fromConfig.ignored)
    lines += outputData.fromConfig.ignored.length
  }
  if (args.outputIgnoredPluralFromConfig) {
    printSection('Ignorierte Plural-Sprach-Keys aus Konfiguration', outputData.fromConfig.ignoredPlural)
    lines += outputData.fromConfig.ignoredPlural.length
  }
  if (args.outputAllFromSource) {
    printSection('Alle Sprach-Keys aus Quelltext', outputData.fromSource.all)
    lines += outputData.fromSource.all.length
  }
  if (args.outputFoundFromSource) {
    printSection('Konfigurierte Sprach-Keys aus Quelltext', outputData.fromSource.found)
    lines += outputData.fromSource.found.length
  }
  if (args.outputNotFoundFromSource) {
    printSection('Nicht konfigurierte Sprach-Keys aus Quelltext', outputData.fromSource.notFound, true)
    lines += outputData.fromSource.notFound.length
  }
  return lines
}

function filterOutput (outputData, args) {
  const filteredOutput = {}
  if (args.outputAllFromConfig) {
    filteredOutput.fromConfig = filteredOutput.fromConfig ? filteredOutput.fromConfig : {}
    filteredOutput.fromConfig.all = outputData.fromConfig.all
  }
  if (args.outputRelevantFromConfig) {
    filteredOutput.fromConfig = filteredOutput.fromConfig ? filteredOutput.fromConfig : {}
    filteredOutput.fromConfig.relevant = outputData.fromConfig.relevant
  }
  if (args.outputUsedFromConfig) {
    filteredOutput.fromConfig = filteredOutput.fromConfig ? filteredOutput.fromConfig : {}
    filteredOutput.fromConfig.used = outputData.fromConfig.used
  }
  if (args.outputUnusedFromConfig) {
    filteredOutput.fromConfig = filteredOutput.fromConfig ? filteredOutput.fromConfig : {}
    filteredOutput.fromConfig.unused = outputData.fromConfig.unused
  }
  if (args.outputIgnoredFromConfig) {
    filteredOutput.fromConfig = filteredOutput.fromConfig ? filteredOutput.fromConfig : {}
    filteredOutput.fromConfig.ignored = outputData.fromConfig.ignored
  }
  if (args.outputIgnoredPluralFromConfig) {
    filteredOutput.fromConfig = filteredOutput.fromConfig ? filteredOutput.fromConfig : {}
    filteredOutput.fromConfig.ignoredPlural = outputData.fromConfig.ignoredPlural
  }
  if (args.outputAllFromSource) {
    filteredOutput.fromSource = filteredOutput.fromSource ? filteredOutput.fromSource : {}
    filteredOutput.fromSource.all = outputData.fromSource.all
  }
  if (args.outputFoundFromSource) {
    filteredOutput.fromSource = filteredOutput.fromSource ? filteredOutput.fromSource : {}
    filteredOutput.fromSource.found = outputData.fromSource.found
  }
  if (args.outputNotFoundFromSource) {
    filteredOutput.fromSource = filteredOutput.fromSource ? filteredOutput.fromSource : {}
    filteredOutput.fromSource.notFound = outputData.fromSource.notFound
  }
  return filteredOutput
}

function failIfNeccessary (outputData, args) {
  if (args.failOnUnused) {
    if (Object.keys(outputData).some((language) => {
      return outputData[language].fromConfig.unused.length
    })) {
      process.exit(1)
    }
  }
  if (args.failOnNotFound) {
    if (Object.keys(outputData).some((language) => {
      return outputData[language].fromSource.notFound.length
    })) {
      process.exit(1)
    }
  }
}

module.exports = {
  failIfNeccessary,
  findKeysInText,
  getAllFilesInDirectories,
  getIgnoredKeys,
  getLanguageKeysData,
  getObjectKeysFlat,
  getSourceFromFilePaths,
  outputToJson,
  printOutput,
  printSection,
  removeKeys,
}
