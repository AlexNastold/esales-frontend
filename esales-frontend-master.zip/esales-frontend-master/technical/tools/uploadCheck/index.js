
/* global */
// tslint:disable:no-console
/* eslint-disable no-console */

const {
  MAX_LEN_BEFORE_BUILD,
  MAX_LEN_IN_DIST,
  getFilesTooLongBeforeBuild,
  getFilesTooLongInDist,
  outputFiles,
} = require('./helper')

// Seiten-Namen, welche zu lange sind
const filesTooLongBeforeBuild = getFilesTooLongBeforeBuild()
// Dateien, welche zu lang sind
const filesTooLongInDist = getFilesTooLongInDist()

outputFiles(
  filesTooLongBeforeBuild,
  `Folgende Seitennamen sind zu lang (maximal ${MAX_LEN_BEFORE_BUILD} Zeichen)`,
)

outputFiles(
  filesTooLongInDist,
  `Folgende Dateien im "dist"-Verzeichnis sind zu lang (maximal ${MAX_LEN_IN_DIST} Zeichen)`,
)
