/* global module __dirname */
// tslint:disable:no-console
/* eslint-disable no-console */
const chalk = require('chalk')
const glob = require('glob')
const path = require('path')
const fs = require('fs')

const {maxFileNameLength, maxHashLength} = require('./../../config')

// Mimes: 40 Zeichen (ohne Verzeichnisstruktur), siehe config
// - Trennzeichen für Hash: 1 Zeichen (.)
// - Hash: 5 Zeichen (12345), siehe config
// - Endung: 4 Zeichen (.css)
// = 30 Zeichen
const MAX_LEN_BEFORE_BUILD = maxFileNameLength - (1 + maxHashLength) - 4

// Mimes: 40 Zeichen (ohne Verzeichnisstruktur)
const MAX_LEN_IN_DIST = maxFileNameLength

const outputFiles = (files, title) => {
  if (files.length) {
    console.log(chalk.red('-'.repeat(title.length + 4)))
    console.log(chalk.red(`⚠️  ${title}:`))
    console.log(chalk.red('-'.repeat(title.length + 4)))

    const maxTooLongByStrLen = Math.max(...files.map((file) => file.tooLongBy)).toString().length

    files.forEach(({ file, tooLongBy }) => {
      const tooLongByStrLen = tooLongBy.toString().length
      const spacesToFill = ' '.repeat(maxTooLongByStrLen - tooLongByStrLen)
      console.log(`${chalk.grey.bold(`${spacesToFill}${(tooLongBy)} |`)} ${_makeCoolColored(file)}`)
    })
  }
}

/**
 * @param {String} file
 */
const _makeCoolColored = (file) => {
  const parts = file.split('/')
  const filename = parts.pop()
  let pathname = parts.join('/') + (parts.length ? '/' : '')
  if (pathname) {
    pathname = chalk.green.bold(pathname)
  }
  return `${pathname}${filename}`
}

const sortDirectoriesFirst = (a, b) => {
  if (
    (a.indexOf('/') !== -1 && b.indexOf('/') !== -1)
    || (a.indexOf('/') === -1 && b.indexOf('/') === -1)
  ) {
    return a.localeCompare(b)
  }
  return (b.indexOf('/') !== -1) - (a.indexOf('/') !== -1)
}

const overflowMaxLen = (maxLength) => {
  return (str) => str.length > maxLength
}

const getFiles = (pattern, dir) => glob.sync(pattern, {
  cwd: dir,
})

const fillWithAdditionalInfos = ({ maxLen }) => (file) => ({
  file,
  tooLongBy: file.length - maxLen,
})

const getFilesTooLongBeforeBuild = () => {
  return getFiles('*', path.resolve(__dirname, '../../../src/pages/'))
    .filter((directory) => fs.existsSync(path.resolve(__dirname, '../../../src/pages/', directory, `${directory}.ts`)))
    .filter(overflowMaxLen(MAX_LEN_BEFORE_BUILD))
    .map(fillWithAdditionalInfos({ maxLen: MAX_LEN_BEFORE_BUILD}))
}

const getFilesTooLongInDist = () => {
  return getFiles('**/*', path.resolve(__dirname, '../../../dist/'))

    // Dateinamen ohne Pfad prüfen
    // Die Verzeichnisse sind eigene Knoten (Tabelleneinträge) im Mime-Repository
    .map((filePath) => path.basename(filePath))
    .filter(overflowMaxLen(MAX_LEN_IN_DIST))
    .sort(sortDirectoriesFirst)
    .map(fillWithAdditionalInfos({ maxLen: MAX_LEN_IN_DIST}))
}

module.exports = {
  MAX_LEN_BEFORE_BUILD,
  MAX_LEN_IN_DIST,
  fillWithAdditionalInfos,
  getFiles,
  outputFiles,
  overflowMaxLen,
  sortDirectoriesFirst,

  getFilesTooLongBeforeBuild,
  getFilesTooLongInDist,
}
