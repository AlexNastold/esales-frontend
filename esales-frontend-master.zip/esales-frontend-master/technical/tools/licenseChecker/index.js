/* eslint-disable no-console */
// tslint:disable no-console
/* global __dirname process */

const path = require('path')
const fs = require('fs')
const del = require('del')
const config = require('../../config')
const licenseChecker = require('node-license-validator')
const chalk = require('chalk')

const invalidLicensesFile = path.resolve(__dirname, '../../../invalid-licenses.json')
del.sync(invalidLicensesFile)

function checkLicenses () {
  return new Promise((resolve, reject) => {
    licenseChecker(path.resolve(__dirname, '../../..'), {
      licenses: config.allowedLicenses,
      packages: config.allowedPackages,
      production: true,
    }, function (err, result) {

      if (err) {
        return reject(err)
      }

      const invalidPackages = result.invalids.reduce((packages, packageName) => {
        // Erlaubte Lizenzen überspringen
        if (config.allowedLicenses.includes(result.packages[packageName])) {
          return packages
        }
        // Alle anderen sind kritisch
        packages[packageName] = result.packages[packageName]
        return packages
      }, {})



      if (Object.keys(invalidPackages).length) {
        fs.writeFileSync(invalidLicensesFile, JSON.stringify(invalidPackages, undefined, 2))
        return reject(
          new Error(
            `Found ${Object.keys(invalidPackages).length} packages with invalid licenses (see ${invalidLicensesFile})`,
          ),
        )
      }

      resolve()
    })
  })
}

checkLicenses()
  .catch((err) => {
    console.log(chalk.red(err.message))
    process.exit(1)
  })
