/* global module */

module.exports = {
  allowedLicenses: [
    'MIT',
    'MIT OR X11',
    'MIT/X11',
    'BSD',
    'BSD-2-Clause',
    'BSD-3-Clause',
    'ISC',
    'Apache-2.0',
    'CC-BY-4.0',
    'Apache, Apache 2.0',
    'Apache, Apache, Version 2.0',
    'Apache',
    'zlib',
    'Unknown',
    'Unlicense',
    'UNLICENSED',
  ],
  allowedPackages: [
    'lightgallery',
  ],
  gtagSiteVerification: '',
  languages: ['de', 'en-gb', 'fr'],

  // Maximal mögliche Länge eines Dateinamens im Mime-Repository (ohne Verzeichnis)
  maxFileNameLength: 40,
  maxHashLength: 5,

  // Diese URL wird zum Einbinden der server.js Datei verwendet, wenn KEIN
  // SAP-Build durchgeführt wird (z.B. wenn das Frontend lokal gehostet wird)
  serverUrl: 'https://xed.fis-gmbh.de/fisesales(====)/shop/',

  // Die hier definierten Systeme können beim Upload ausgewählt werden
  systems: [
    {
      id: 'XED',
      package: '/fis/esi_all',
      syncServiceUrl: 'https://xed.fis-gmbh.de/fis/mime_sync',
      targetBspApplication: '/fis/esi_shop',
    },
  ],
}
