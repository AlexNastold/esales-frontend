/* global process module */
const parseArgs = require('minimist')

const args = parseArgs(process.argv.slice(2))

module.exports = {
  continueOnError: !!(args['continue-on-error'] || args['ignore-errors']),
  production: !!(args.production || process.env.NODE_ENV === 'production'),
  sapBuild: args['sap-build'] || process.env.SAP_BUILD === 'true',
  showGridBreakpoints: args['show-breakpoints'] || process.env.SHOW_BREAKPOINTS === 'true',
  showGridOutlines: args['show-outlines'] || process.env.SHOW_OUTLINES === 'true',
}
