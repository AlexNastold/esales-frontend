declare module "*.vue" {
  import Vue from 'vue'
  const VueComponent: typeof Vue
  export default VueComponent
}
