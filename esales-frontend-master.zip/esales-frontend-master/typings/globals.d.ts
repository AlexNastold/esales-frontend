declare var $
declare var cookieconsent
// Google Tag Manager
declare var gtag
// TinyEmitter Instance
declare module 'tiny-emitter/instance'
// Loadjs
declare module 'loadjs'
interface Array<T> {
  unique (): Array<T>,
  pluck<T> (key: any, fallback?: any): Array<T>
}
