/* global module */

module.exports = {
  extends: 'stylelint-config-sass-guidelines',
  rules: {
    'max-nesting-depth': 10,
    'selector-max-compound-selectors': null,
    'selector-no-qualifying-type': null,
    'number-leading-zero': null,
    'order/order': null,
    'color-named': null,
    'scss/selector-no-redundant-nesting-selector': null,
    'scss/dollar-variable-colon-space-after': null,
    'scss/at-import-partial-extension-blacklist': null,
    'rule-empty-line-before': null,
    'block-opening-brace-space-before': null,
    'property-no-vendor-prefix': null,
    'order/properties-alphabetical-order': null,
    'value-no-vendor-prefix': null,
  }
}
