/**
 * This configuration will be merged with the configuration from the server (server.js)
 * The server configuration will always overwrite settings from this configuration
 *
 * If something is not yet configurated in server.js but already here,
 * it is easy to implement it in the backend by adding it to server.js
 */

export default {
  applicationSettings: {

  },
  pageSettings: {

  },
  user: {

  },
}
