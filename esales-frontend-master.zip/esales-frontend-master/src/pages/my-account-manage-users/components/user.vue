<template>
  <div class="border rounded bg-light p-3 mb-1">
    <div class="row">
      <!-- Benutzerkennung, Name, Alias -->
      <div class="col-12 col-sm-8 col-lg-4 mb-2 mb-sm-0">
        <a :href="`my-account-manage-users-detail?id=${user.userId}`">
          <strong class="text-dark font-size-lg">
            {{ user.firstName }} {{ user.lastName }}
          </strong><br>
          <small class="text-muted">
            {{ $t('myAccountManageUsers.components.user.username') }}: {{ user.userId }}
          </small><br>
          <small class="text-muted">
            {{ user.emailAddress }}
          </small><br>
          <span class="text-dark">
            {{ user.userAlias }}
          </span>
        </a>
      </div>

      <!-- Sprache, Währung -->
      <div class="col-12 col-sm-4 col-lg-3">
        <div class="row">
          <div class="col-12 col-lg-6 font-weight-bold mb-lg-1">
            {{ $t('myAccountManageUsers.components.user.language') }}
          </div>
          <div class="col-12 col-lg-6 mb-1">
            {{ user.language }}
          </div>

          <div class="col-12 col-lg-6 font-weight-bold">
            {{ $t('myAccountManageUsers.components.user.currency') }}
          </div>
          <div class="col-12 col-lg-6">
            {{ user.currency }}
          </div>
        </div>
      </div>

      <!-- Master, OCI, Gesperrt, Initialpasswort, Aktiviert -->
      <div class="col-12 col-lg-5 mt-2 mt-lg-0">
        <div class="row">
          <!-- Master -->
          <div class="col-12 col-md-6 mb-1">
            <div :class="user.isMaster ? 'text-success' : 'text-muted'">
              <i class="fas fa-user-secret fa-fw" />&nbsp;
              <span v-if="user.isMaster">
                {{ $t('myAccountManageUsers.components.user.master.true') }}
              </span>
              <span v-else>
                {{ $t('myAccountManageUsers.components.user.master.false') }}
              </span>
            </div>
          </div>

          <!-- OCI -->
          <div class="col-12 col-md-6 mb-1">
            <div :class="user.isOciUser ? 'text-success' : 'text-muted'">
              <i class="fas fa-book fa-fw" />&nbsp;
              <span v-if="user.isOciUser">
                {{ $t('myAccountManageUsers.components.user.ociUser.true') }}
              </span>
              <span v-else>
                {{ $t('myAccountManageUsers.components.user.ociUser.false') }}
              </span>
            </div>
          </div>

          <!-- Gesperrt -->
          <div class="col-12 col-md-6 mb-1">
            <div :class="user.isLocked ? 'text-danger' : 'text-muted'">
              <i
                :class="user.isLocked ? 'fa-lock' : 'fa-unlock'"
                class="fas fa-fw" />&nbsp;
              <span v-if="user.isLocked">
                {{ $t('myAccountManageUsers.components.user.locked.true') }}
              </span>
              <span v-else>
                {{ $t('myAccountManageUsers.components.user.locked.false') }}
              </span>
            </div>
          </div>

          <!-- Aktiviert -->
          <div class="col-12 col-md-6 mb-1">
            <div :class="user.isActivated ? 'text-success' : 'text-muted'">
              <i
                :class="user.isActivated ? 'fa-toggle-on' : 'fa-toggle-off'"
                class="fas fa-fw" />&nbsp;
              <span v-if="user.isActivated">
                {{ $t('myAccountManageUsers.components.user.active.true') }}
              </span>
              <span v-else>
                {{ $t('myAccountManageUsers.components.user.active.false') }}
              </span>
            </div>
          </div>

          <!-- Initialpasswort -->
          <div class="col-12 col-md-6">
            <div :class="user.hasInitialPassword ? 'text-success' : 'text-muted'">
              <i class="fas fa-key fa-fw" />&nbsp;
              <span v-if="user.hasInitialPassword">
                {{ $t('myAccountManageUsers.components.user.passwordInitial.true') }}
              </span>
              <span v-else>
                {{ $t('myAccountManageUsers.components.user.passwordInitial.false') }}
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- Aktionen -->
      <div class="col-12 d-flex justify-content-end mt-2">
        <div
          v-if="hasDropdownMenu"
          class="dropdown mr-1">
          <button
            type="button"
            class="btn btn-secondary dropdown-toggle"
            data-toggle="dropdown">
            {{ $t('myAccountManageUsers.components.user.actions') }}
          </button>
          <div class="dropdown-menu dropdown-menu-right">
            <!-- Benutzer sperren/entsperren (Master können sich nicht selbst sperren/entsperren) -->
            <template v-if="!(user.isMaster && user.userId === app.user.userId)">
              <button
                v-if="user.isLocked"
                type="button"
                class="dropdown-item"
                @click="unlockUser">
                <i class="fas fa-unlock fa-fw" />&nbsp;
                {{ $t('myAccountManageUsers.components.user.unlockUser.true.title') }}
              </button>
              <button
                v-else
                type="button"
                class="dropdown-item"
                @click="lockUser">
                <i class="fas fa-lock fa-fw" />&nbsp;
                {{ $t('myAccountManageUsers.components.user.unlockUser.false.title') }}
              </button>
            </template>

            <!-- Benutzer aktivieren -->
            <button
              v-if="!user.isActivated"
              type="button"
              class="dropdown-item"
              @click="activateUser">
              <i class="fas fa-toggle-on fa-fw" />&nbsp;
              {{ $t('myAccountManageUsers.components.user.activateUser.title') }}
            </button>

            <!-- Kundenanschreiben anzeigen/versenden -->
            <template v-if="user.hasInitialPassword && user.isActivated">
              <div class="dropdown-divider" />
              <button
                type="button"
                class="dropdown-item"
                @click="downloadLetter">
                <i class="fas fa-file-pdf fa-fw" />&nbsp;
                {{ $t('myAccountManageUsers.components.user.showUserLetter') }}
              </button>
              <button
                v-if="user.emailAddress"
                type="button"
                class="dropdown-item"
                @click="sendLetter">
                <i class="fas fa-paper-plane fa-fw" />&nbsp;
                {{ $t('myAccountManageUsers.components.user.sendUserLetter.sendTitle') }}
              </button>
            </template>

            <!-- Benutzer löschen -->
            <button
              v-if="!user.isMaster"
              type="button"
              class="dropdown-item"
              @click="deleteUser">
              <i class="fas fa-trash-alt fa-fw" />&nbsp;
              {{ $t('general.delete') }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { redirect } from '@scripts/helper/redirect'
import { confirmDialog, showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { deleteUser, sendLetter, activateUser, lockUser, unlockUser, getLetterDownloadUri } from '@scripts/modules/useradm'

export default {
  props: {
    user: {
      type: Object,
      required: true,
    },
  },

  computed: {
    hasDropdownMenu () {
      return (
        !(this.user.isMaster && this.user.userId === this.app.user.userId)
        || !this.user.isActivated
        || this.user.hasInitialPassword && this.user.isActivated
        || !this.user.isMaster
      )
    },
  },

  methods: {
    async activateUser () {
      if (await confirmDialog(
        this.$t('myAccountManageUsers.components.user.activateUser.title'),
        this.$t('myAccountManageUsers.components.user.activateUser.confirm', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}),
        {
          type: 'warning',
          buttonConfirmText: '<i class="fas fa-toggle-on fa-fw"></i> ' + this.$t('myAccountManageUsers.components.user.activateUser.action'),
          buttonCancelText: '<i class="fas fa-times fa-fw"></i> ' + this.$t('general.cancel'),
        },
      )) {
        try {
          await activateUser(this.user.userId)
          showSuccessMessage(this.$t('myAccountManageUsers.components.user.activateUser.success', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}))
          this.$emit('activate')
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },

    async lockUser () {
      if (await confirmDialog(
        this.$t('myAccountManageUsers.components.user.unlockUser.false.title'),
        this.$t('myAccountManageUsers.components.user.unlockUser.false.confirm', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}),
        {
          type: 'warning',
          buttonConfirmText: '<i class="fas fa-lock fa-fw"></i> ' + this.$t('myAccountManageUsers.components.user.unlockUser.false.action'),
          buttonCancelText: '<i class="fas fa-times fa-fw"></i> ' + this.$t('general.cancel'),
        },
      )) {
        try {
          await lockUser(this.user.userId)
          showSuccessMessage(this.$t('myAccountManageUsers.components.user.unlockUser.false.success', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}))
          this.$emit('lock')
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },

    async unlockUser () {
      if (await confirmDialog(
        this.$t('myAccountManageUsers.components.user.unlockUser.true.title'),
        this.$t('myAccountManageUsers.components.user.unlockUser.true.confirm', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}),
        {
          type: 'warning',
          buttonConfirmText: '<i class="fas fa-unlock fa-fw"></i> ' + this.$t('myAccountManageUsers.components.user.unlockUser.true.action'),
          buttonCancelText: '<i class="fas fa-times fa-fw"></i> ' + this.$t('general.cancel'),
        },
      )) {
        try {
          await unlockUser(this.user.userId)
          showSuccessMessage(this.$t('myAccountManageUsers.components.user.unlockUser.true.success', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}))
          this.$emit('unlock')
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },

    async deleteUser () {
      if (await confirmDialog(
        this.$t('myAccountManageUsers.components.user.deleteUser.title'),
        this.$t('myAccountManageUsers.components.user.deleteUser.confirm', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}),
        {
          type: 'danger',
          buttonConfirmText: '<i class="fas fa-trash-alt fa-fw"></i> ' + this.$t('myAccountManageUsers.components.user.deleteUser.action'),
          buttonCancelText: '<i class="fas fa-times fa-fw"></i> ' + this.$t('general.cancel'),
        },
      )) {
        try {
          await deleteUser(this.user.userId)
          showSuccessMessage(this.$t('myAccountManageUsers.components.user.deleteUser.success', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}))
          this.$emit('delete')
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },

    async sendLetter () {
      if (await confirmDialog(
        this.$t('myAccountManageUsers.components.user.sendUserLetter.sendTitle'),
        this.$t('myAccountManageUsers.components.user.sendUserLetter.confirm', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId, emailAddress: this.user.emailAddress}),
        {
          type: 'info',
          buttonConfirmText: '<i class="fas fa-paper-plane fa-fw"></i> ' + this.$t('myAccountManageUsers.components.user.sendUserLetter.action'),
          buttonCancelText: '<i class="fas fa-times fa-fw"></i> ' + this.$t('general.cancel'),
        },
      )) {
        try {
          await sendLetter(this.user.userId)
          showSuccessMessage(this.$t('myAccountManageUsers.components.user.sendUserLetter.success', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}))
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },

    async downloadLetter () {
      const downloadUri = getLetterDownloadUri(this.user.userId)
      redirect(downloadUri)
    },
  },
}
</script>
