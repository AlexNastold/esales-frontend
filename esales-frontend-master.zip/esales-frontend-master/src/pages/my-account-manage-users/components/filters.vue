<template>
  <div>
    <!-- Filter -->
    <div class="input-group mb-3">
      <input
        ref="queryFilter"
        v-model="filters.query"
        :placeholder="$t('myAccountManageUsers.components.filters.searchUserPlaceholder')"
        type="search"
        class="form-control">
      <div class="input-group-append">
        <button
          type="button"
          class="btn btn-secondary"
          @click="resetFilterByName('query')">
          <i class="fas fa-times fa-fw" />
        </button>
      </div>
    </div>

    <div class="row mb-3">
      <!-- Sprache -->
      <div class="col-12 col-sm-6 col-lg-2">
        <div class="form-group">
          <label for="language">
            {{ $t('myAccountManageUsers.components.filters.language') }}
          </label>
          <select
            id="language"
            v-model="filters.language"
            class="form-control custom-select">
            <option :value="void 0">
              {{ $t('myAccountManageUsers.components.filters.chooseLanguage') }}
            </option>
            <option
              v-for="language in languages"
              :key="language.key"
              :value="language.key">
              {{ language.label }}
            </option>
          </select>
        </div>
      </div>

      <!-- Währung -->
      <div class="col-12 col-sm-6 col-lg-2">
        <div class="form-group">
          <label for="currency">
            {{ $t('myAccountManageUsers.components.filters.currency') }}
          </label>
          <select
            id="currency"
            v-model="filters.currency"
            class="form-control custom-select">
            <option :value="void 0">
              {{ $t('myAccountManageUsers.components.filters.chooseCurrency') }}
            </option>
            <option
              v-for="currency in currencies"
              :key="currency.key"
              :value="currency.key">
              {{ currency.label }}
            </option>
          </select>
        </div>
      </div>

      <div class="col d-flex align-items-center">
        <div class="row">
          <!-- Master -->
          <div class="col-6 col-sm-4 py-1">
            <div class="custom-control custom-checkbox m-0">
              <input
                id="checkbox-useradm-filter-master"
                v-model="filters.flagMaster"
                type="checkbox"
                class="custom-control-input">
              <label
                for="checkbox-useradm-filter-master"
                class="custom-control-label">
                <i class="fas fa-user-secret fa-fw" />&nbsp;
                {{ $t('myAccountManageUsers.components.filters.master') }}
              </label>
            </div>
          </div>

          <!-- OCI -->
          <div class="col-6 col-sm-4 py-1">
            <div class="custom-control custom-checkbox m-0">
              <input
                id="checkbox-useradm-filter-oci"
                v-model="filters.flagOci"
                type="checkbox"
                class="custom-control-input">
              <label
                for="checkbox-useradm-filter-oci"
                class="custom-control-label">
                <i class="fas fa-book fa-fw" />&nbsp;
                {{ $t('myAccountManageUsers.components.filters.oci') }}
              </label>
            </div>
          </div>

          <!-- Gesperrt -->
          <div class="col-6 col-sm-4 py-1">
            <div class="custom-control custom-checkbox m-0">
              <input
                id="checkbox-useradm-filter-locked"
                v-model="filters.flagLocked"
                type="checkbox"
                class="custom-control-input">
              <label
                for="checkbox-useradm-filter-locked"
                class="custom-control-label">
                <i class="fas fa-lock fa-fw" />&nbsp;
                {{ $t('myAccountManageUsers.components.filters.locked') }}
              </label>
            </div>
          </div>

          <!-- Initialpasswort -->
          <div class="col-6 col-sm-4 py-1">
            <div class="custom-control custom-checkbox m-0">
              <input
                id="checkbox-useradm-filter-initialpassword"
                v-model="filters.flagInitialPassword"
                type="checkbox"
                class="custom-control-input">
              <label
                for="checkbox-useradm-filter-initialpassword"
                class="custom-control-label">
                <i class="fas fa-key fa-fw" />&nbsp;
                {{ $t('myAccountManageUsers.components.filters.passwordInitial') }}
              </label>
            </div>
          </div>

          <!-- Aktiviert -->
          <div class="col-6 col-sm-4 py-1">
            <div class="custom-control custom-checkbox m-0">
              <input
                id="checkbox-useradm-filter-activated"
                v-model="filters.flagActivated"
                type="checkbox"
                class="custom-control-input">
              <label
                for="checkbox-useradm-filter-activated"
                class="custom-control-label">
                <i class="fas fa-toggle-on fa-fw" />&nbsp;
                {{ $t('myAccountManageUsers.components.filters.active.true') }}
              </label>
            </div>
          </div>

          <!-- Nicht aktiviert -->
          <div class="col-6 col-sm-4 py-1">
            <div class="custom-control custom-checkbox m-0">
              <input
                id="checkbox-useradm-filter-notactivated"
                v-model="filters.flagNotActivated"
                type="checkbox"
                class="custom-control-input">
              <label
                for="checkbox-useradm-filter-notactivated"
                class="custom-control-label">
                <i class="fas fa-toggle-off fa-fw" />&nbsp;
                {{ $t('myAccountManageUsers.components.filters.active.false') }}
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Aktive Filter -->
    <div
      v-if="Object.keys(activeFilters).length"
      class="d-flex flex-wrap">
      <app-active-filter
        v-for="(value, name) of activeFilters"
        :key="name"
        :label="getFilterLabelByName(name)"
        :value="getFilterValueByName(name, value)"
        type="primary"
        @click="resetFilterByName(name)" />

      <app-active-filter
        :label="$t('myAccountManageUsers.components.filters.resetFilter')"
        type="dark"
        @click="resetFilters" />
    </div>
  </div>
</template>

<script>
import { getQueryParameter } from '@scripts/helper/urlParams'
import { updateUrlQueryString } from '@scripts/helper/urlUpdate'

export default {
  props: {
    languages: {
      type: Array,
      required: true,
    },
    currencies: {
      type: Array,
      required: true,
    },
  },

  data () {
    return {
      // Die Reihenfolge hier sollte genauso wie im DOM sein
      filters: {
        query: getQueryParameter('query') || void 0,
        language: getQueryParameter('language') || void 0,
        currency: getQueryParameter('currency') || void 0,
        flagMaster: !!getQueryParameter('flagMaster') || false,
        flagOci: !!getQueryParameter('flagOci') || false,
        flagLocked: !!getQueryParameter('flagLocked') || false,
        flagInitialPassword: !!getQueryParameter('flagInitialPassword') || false,
        flagActivated: !!getQueryParameter('flagActivated') || false,
        flagNotActivated: !!getQueryParameter('flagNotActivated') || false,
      },
      filterNames: {
        query: this.$t('myAccountManageUsers.components.filters.query'),
        language: this.$t('myAccountManageUsers.components.filters.language'),
        currency: this.$t('myAccountManageUsers.components.filters.currency'),
        flagMaster: this.$t('myAccountManageUsers.components.filters.master'),
        flagOci: this.$t('myAccountManageUsers.components.filters.oci'),
        flagLocked: this.$t('myAccountManageUsers.components.filters.locked'),
        flagInitialPassword: this.$t('myAccountManageUsers.components.filters.passwordInitial'),
        flagActivated: this.$t('myAccountManageUsers.components.filters.active.true'),
        flagNotActivated: this.$t('myAccountManageUsers.components.filters.active.false'),
      },
    }
  },

  computed: {
    activeFilters () {
      const activeFilters = {}
      for (let name in this.filters) {
        if (this.filters[name]) {
          activeFilters[name] = this.filters[name]
        }
      }
      return activeFilters
    },
  },

  watch: {
    filters: {
      handler (filters) {
        this.$emit('change', filters)
        updateUrlQueryString(filters)
      },
      deep: true,
    },
  },

  created () {
    this.$emit('init', this.filters)
  },

  methods: {
    resetFilters () {
      this.filters = {
        query: void 0,
        language: void 0,
        currency: void 0,
        flagMaster: false,
        flagOci: false,
        flagLocked: false,
        flagInitialPassword: false,
        flagActivated: false,
        flagNotActivated: false,
      }

      this.$refs.queryFilter.focus()
    },
    resetFilterByName (name) {
      this.filters[name] = void 0

      if (name === 'query') {
        this.$refs.queryFilter.focus()
      }
    },
    getFilterLabelByName (name) {
      return this.filterNames[name]
    },
    getFilterValueByName (name, value) {
      if (name === 'language') {
        return this.languages.find((language) => language.key === value).label
      }
      if (name === 'currency') {
        return this.currencies.find((currency) => currency.key === value).label
      }
      return typeof value === 'string' ? value : void 0
    },
  },
}
</script>

