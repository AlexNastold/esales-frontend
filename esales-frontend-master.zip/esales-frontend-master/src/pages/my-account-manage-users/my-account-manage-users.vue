<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-manage-users">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountManageUsers.manageUser')"
        page="manage-users" />

      <div class="container">
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountManageUsers.manageUser') }}
          </li>
        </ol>

        <!-- Filter -->
        <filters
          :languages="languages"
          :currencies="currencies"
          class="mb-2"
          @init="onFiltersChange"
          @change="onFiltersChange" />

        <!-- Neuen Benutzer anlegen -->
        <div class="mb-3">
          <div class="d-lg-none">
            <a
              class="btn btn-block btn-primary"
              href="my-account-manage-users-create">
              <span class="mr-1">
                <i class="fas fa-user-plus fa-fw" />
                {{ $t('myAccountManageUsers.createUser') }}
              </span>
            </a>
          </div>
          <div class="d-none d-lg-block">
            <a
              class="btn btn-primary"
              href="my-account-manage-users-create">
              <span class="mr-1">
                <i class="fas fa-user-plus fa-fw" />
                {{ $t('myAccountManageUsers.createUser') }}
              </span>
            </a>
          </div>
        </div>

        <!-- Auflistung Benutzer -->
        <app-loading-box v-if="isLoading" />
        <template v-else>
          <div
            v-if="!filteredUsers.length"
            class="border rounded">
            <app-box-empty-list
              v-if="!users.length"
              :headline="$t('myAccountManageUsers.titleNoUsers')"
              icon="fas fa-users">
              <span v-html="$t('myAccountManageUsers.noUsersCreated')" />
            </app-box-empty-list>
            <app-box-empty-list
              v-if="users.length"
              :headline="$t('myAccountManageUsers.titleNoUsers')"
              icon="fas fa-users">
              <span v-html="$t('myAccountManageUsers.noUsersFound')" />
            </app-box-empty-list>
          </div>

          <user
            v-for="user in filteredUsers"
            :key="user.userId"
            :user="user"
            @activate="loadUsers"
            @lock="loadUsers"
            @unlock="loadUsers"
            @delete="onUserDelete(user)" />
        </template>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { pageSettingsMyAccountManageUsers } from '@scripts/app/settings'
import { matches } from '@scripts/helper/matches'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getList } from '@scripts/modules/useradm'

import MyAccountHeader from '@components/pages/my-account/header.vue'

import Filters from './components/filters.vue'
import User from './components/user.vue'

export default {
  components: {
    'my-account-header': MyAccountHeader,

    filters: Filters,
    user: User,
  },

  data () {
    return {
      filters: {},
      isLoading: true,
      users: [],

      currencies: pageSettingsMyAccountManageUsers.currencies,
      languages: pageSettingsMyAccountManageUsers.languages,
    }
  },

  computed: {
    filteredUsers () {
      return this.users.filter((user) => {
        if (
          (this.filters.query && !matches(this.filters.query, [
            user.userId, user.firstName, user.lastName, user.userAlias,
          ]))
          || (this.filters.language && this.filters.language !== user.language)
          || (this.filters.currency && this.filters.currency !== user.currency)
          || (this.filters.flagMaster && !user.isMaster)
          || (this.filters.flagOci && !user.isOciUser)
          || (this.filters.flagLocked && !user.isLocked)
          || (this.filters.flagInitialPassword && !user.hasInitialPassword)
          || (this.filters.flagActivated && !user.isActivated)
          || (this.filters.flagNotActivated && user.isActivated)
        ) {
          return false
        }
        return true
      })
    },
  },

  created () {
    this.setPageTitle(this.$t('myAccountManageUsers.title'))
    this.loadUsers()
  },

  methods: {
    async loadUsers () {
      try {
        this.users = await getList()
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
    onFiltersChange (filters) {
      this.filters = filters
    },
    onUserDelete (deletedUser) {
      this.users = this.users.filter((user) => user.userId !== deletedUser.userId)
    },
  },
}
</script>

<style lang="scss" src="./my-account-manage-users.scss"></style>
