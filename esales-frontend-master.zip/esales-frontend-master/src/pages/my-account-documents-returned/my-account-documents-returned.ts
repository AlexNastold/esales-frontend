/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/my-account-documents-returned/my-account-documents-returned.vue'
setup(PageComponent)
