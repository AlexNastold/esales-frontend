<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-documents-returned">
      <div class="container">
        <!-- Ladestatus -->
        <app-loading-box v-if="isLoading" />

        <!-- Fehler -->
        <app-box-error v-else-if="!returnDocId">
          <h3>{{ $t('general.unspecifiedErrorMessage') }}</h3>
          {{ $t('general.tryAgainLater') }}
        </app-box-error>

        <!-- Anfrage & Bestellung -->
        <template v-else>
          <h1
            class="headline h2"
            v-html="$t('myAccountDocuments.return.returnCreated')" />

          <app-box-success>
            <h4>{{ $t('myAccountDocuments.return.returnCreatedHeadline') }}</h4>
            {{ $t('myAccountDocuments.return.returnCreatedSubtext') }}
            <p class="text-muted">
              {{ $t('myAccountDocuments.return.returnDocNumber', { returnDocId: returnDocId }) }}
            </p>

            <!-- Desktop Buttons -->
            <div class="d-none d-md-block">
              <a
                :href="`my-account-documents-detail?doctype=${orderDocType}&docid=${orderDocId}`"
                class="btn btn-primary">
                <i class="fas fa-folder-open fa-fw" />
                {{ $t('myAccountDocuments.return.backToOrder') }}
              </a>
            </div>

            <!-- Mobile Buttons -->
            <div class="d-md-none">
              <a
                :href="`my-account-documents-detail?doctype=${orderDocType}&docid=${orderDocId}`"
                class="btn btn-primary btn-block mb-1">
                <i class="fas fa-folder-open fa-fw" />
                {{ $t('myAccountDocuments.return.backToOrder') }}
              </a>
            </div>
          </app-box-success>
        </template>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>

import { getQueryParameter } from '@scripts/helper/urlParams'

export default {
  data () {
    return {
      isLoading: true,
      returnDocId: getQueryParameter('returnDocId') || void 0,
      orderDocId: getQueryParameter('orderDocId') || void 0,
      orderDocType: getQueryParameter('orderDocType') || void 0,
    }
  },
  created () {
    this.setPageTitle(this.$t('myAccountDocuments.return.returnArticles'))
    this.isLoading = false
  },
}
</script>

<style lang="scss" src="./my-account-documents-returned.scss"></style>

<style lang="scss" scoped>
@import '~styles/definitions/all';

</style>
