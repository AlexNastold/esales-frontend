/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/my-account-topsellers/my-account-topsellers.vue'
setup(PageComponent)
