<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-last-articles">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountLastArticles.list.headline')"
        page="last-articles" />

      <div class="container">
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountLastArticles.list.breadcrumb') }}
          </li>
        </ol>

        <app-loading-box v-if="isLoading" />
        <template v-else>
          <!-- Auflistung Zuletzt angesehen Artikel -->
          <template v-if="articles.length">
            <div class="list-group">
              <div
                v-for="(article, index) in articles"
                :key="index"
                class="list-group-item">
                <app-article-item
                  :article="article"
                  pitcher="last" />
              </div>
            </div>
          </template>

          <div
            v-else
            class="border rounded mb-3">
            <app-box-empty-list
              :headline="$t('myAccountLastArticles.list.listEmpty')"
              icon="fas fa-history">
              <span v-html="$t('myAccountLastArticles.list.listEmptyDescription')" />
            </app-box-empty-list>
          </div>
        </template>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getLastSeenArticles } from '@scripts/modules/lastseen'

import MyAccountHeader from '@components/pages/my-account/header.vue'

export default {
  components: {
    'my-account-header': MyAccountHeader,
  },

  data () {
    return {
      articles: void 0,
      isLoading: true,
    }
  },

  async created () {
    this.setPageTitle(this.$t('myAccountLastArticles.list.title'))

    try {
      this.articles = await getLastSeenArticles()
      this.isLoading = false
    } catch (e) {
      console.error(e)
      showTechnicalErrorMessage()
    }
  },
}
</script>

<style lang="scss" src="./my-account-last-articles.scss"></style>
