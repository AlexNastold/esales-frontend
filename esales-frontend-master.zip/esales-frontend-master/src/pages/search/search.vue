<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-search">
      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="index">
              {{ $t('search.index') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('search.title') }}
          </li>
        </ol>

        <div v-if="solrOffline">
          <h1 class="text-center">
            <i class="fab fa-searchengin" /> {{ $t('search.searchEngineIsOffline') }}
          </h1>
        </div>
        <div
          v-else
          class="row">
          <!-- Kategorie -->
          <div class="col-12 col-md-4 col-lg-3">
            <h2>{{ $t('search.categories') }}</h2>
            <category-filter
              v-if="filters.pivots && filters.pivots.length"
              :filter-data="filters.pivots[0]"
              :is-loading="isLoading"
              class="mb-3"
              @activatefilter="activateFilter"
              @togglefilter="toggleFilter"
              @resetcategoryfilters="resetCategoryFilters" />
          </div>

          <!-- Suchergebnisse -->
          <div
            class="col-12 col-md-8 col-lg-9">
            <!-- Überschrift -->
            <div
              v-if="!isLoading"
              class="mb-3">
              <!-- Suchbegriff vorhanden -->
              <div
                v-if="selectedCategory !== '' && selectedCategory !== $store.getters.getActiveCategory.label"
                class="alert alert-warning alert-dismissible fade show"
                role="alert">
                <span v-html="$t('search.categoryFilterRemoved', { selectedCategory })" />
                <button
                  type="button"
                  class="close"
                  data-dismiss="alert"
                  aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <h1
                v-if="lastQuery"
                class="h2">
                <span v-html="$t('search.headline', { count: numberOfHits, query: lastQuery })" />
              </h1>
              <!-- Kein Suchbegriff -->
              <h1
                v-else
                class="h2">
                {{ $t('search.headlineNoQuery', { count: numberOfHits }) }}
              </h1>

              <!-- Angezeigte Treffer -->
              <span
                v-if="searchResults.length"
                v-html="$t('search.amountOfArticles', { from: resultBoundary.from, to: resultBoundary.to })" />
            </div>

            <!-- Filter -->
            <search-filters
              v-if="numberOfHits > 0"
              :filters="filters"
              :is-loading="isLoading"
              @applyfilter="applyFilters"
              @resetallfilters="resetAllFilters" />

            <!-- Aktive Filter -->
            <active-filters
              :filters="filters"
              :ignore-hierachy-filters="true"
              class="mb-3"
              @search="search" />

            <!-- Dropdown Sortierung -->
            <div class="d-flex flex-column flex-sm-row align-items-sm-center justify-content-sm-end mb-3">
              <div class="mr-2">
                {{ $t('search.sortBy.label') }}
              </div>
              <div>
                <select
                  v-model="searchOptions.sort"
                  class="form-control custom-select"
                  @change="search">
                  <option value="score desc">
                    {{ $t('search.relevance') }}
                  </option>
                  <option value="price asc">
                    {{ $t('search.sortBy.price.asc') }}
                  </option>
                  <option value="price desc">
                    {{ $t('search.sortBy.price.desc') }}
                  </option>
                  <option value="maktx1 asc">
                    {{ $t('search.sortBy.alphabet.asc') }}
                  </option>
                  <option value="maktx1 desc">
                    {{ $t('search.sortBy.alphabet.desc') }}
                  </option>
                </select>
              </div>
            </div>

            <div class="mb-4 d-none">
              {{ $t('search.hits') }}: {{ numberOfHits }}
            </div>

            <!-- Auflistung Suchergebnisse -->
            <search-results
              :search-results="searchResults"
              :is-filtered="!!activeFilters.length"
              :is-loading="isLoading"
              pitcher="search"
              class="mb-3"
              @resetfilters="resetAllFilters" />

            <!-- Dropdown Treffer pro Seite -->
            <div class="d-flex flex-column flex-sm-row align-items-sm-center mb-3">
              <div class="mr-2">
                {{ $t('search.hitsPerPage') }}
              </div>
              <div class="options">
                <select
                  v-model="searchOptions.rows"
                  class="form-control custom-select"
                  @change="search">
                  <option value="12">
                    12
                  </option>
                  <option value="24">
                    24
                  </option>
                  <option value="48">
                    48
                  </option>
                </select>
              </div>
            </div>

            <!-- Seitenauswahl -->
            <app-pagination
              v-if="numberOfPages > 1"
              :pages="numberOfPages"
              :current-page="currentPage"
              :disabled="isLoading"
              class="pager d-flex justify-content-center"
              @change="onPageChange" />
          </div>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import {
  activateFilter,
  activateMarkedFilters,
  getActiveFilters,
  getParsedResponse,
  parseFilterString,
  resetAllFilters,
  resetHierarchyFilters,
  serializeActiveFilters,
  toggleFilter,
} from '@scripts/modules/search'
import { setUrlChangeHandler, updateUrlQueryString } from '@scripts/helper/urlUpdate'
import I18n from '@scripts/modules/i18n'
import { applicationSettings } from '@scripts/app/settings'
import { getQueryParameter } from '@scripts/helper/urlParams'

import ActiveFiltersComponent from './components/search-filters-active.vue'
import FilterComponent from './components/search-filters.vue'
import HierarchyFilterComponent from './components/search-filter-type-hierarchy.vue'
import ResultComponent from './components/search-results.vue'

import { redirect } from '@scripts/helper/redirect'

export default {
  components: {
    'active-filters': ActiveFiltersComponent,
    'category-filter': HierarchyFilterComponent,
    'search-filters': FilterComponent,
    'search-results': ResultComponent,
  },

  props: {
    defaultQuery: {
      default: '',
      type: String,
    },
    hasFuzzySearch: {
      default: true,
      type: Boolean,
    },
    hasInitialSearch: {
      default: true,
      type: Boolean,
    },
    hasInstantSearch: { // ToDo: Muss noch eingebaut werden
      default: false,
      type: Boolean,
    },
    searchInputSelector: {
      default: 'input[name=q]',
      type: String,
    },
  },

  data () {
    return {
      currentPage: 1,
      customSearchInput: void 0,
      filters: {},
      isLoading: true,
      numberOfHits: 0,
      numberOfPages: 0,
      query: getQueryParameter('q').trim() || this.defaultQuery,
      lastQuery: '',
      searchOptions: {
        fq: getQueryParameter('fq') || void 0,
        fuzzy: this.hasFuzzySearch,
        rows: getQueryParameter('rows') ? parseInt(getQueryParameter('rows'), 10) : 12,
        sort: getQueryParameter('sort') || 'score desc',
        start: getQueryParameter('start') ? parseInt(getQueryParameter('start'), 10) : 0,
      },
      searchResults: [],
      selectedCategory: '',
      solrOffline: false,
    }
  },

  computed: {
    activeFilters () {

      // Wenn beim Laden der Seite der fq-Parameter übergeben wird,
      // wird dieser für die Suchanfrage verwendet.
      if (!Object.keys(this.filters).length) {
        return parseFilterString(this.searchOptions.fq || '')
      }
      const activeFilters = getActiveFilters(this.filters)
      if (activeFilters.length) {
        return activeFilters
      }

      // Wenn ein Filter per fq-Parameter übergeben wird,
      // der Filterwert aber nicht existiert, trotzdem verwenden
      if (this.searchOptions.fq && this.numberOfHits === 0) {
        return parseFilterString(this.searchOptions.fq)
      }
      return []
    },

    // Computed value that observes multiple data properties
    // for easier watching
    // See https://github.com/vuejs/vue/issues/844#issuecomment-265315349
    urlQueryString () {
      return this.query, this.activeFilters, Date.now()
    },

    resultBoundary () {
      const amountPerPage = this.searchOptions.rows
      return {
        from: (this.currentPage * amountPerPage) + 1,
        to: (this.currentPage * amountPerPage) + this.searchResults.length,
      }
    },
  },

  watch: {
    urlQueryString () {
      this.setPropertiesToUrl(true)
    },
  },

  beforeCreate () {
    if (!getQueryParameter('q')) {
      redirect('catalogue')
    }
  },

  created () {
    this.setPageTitle(this.$t('search.title'))
  },

  async mounted () {
    if (this.searchInputSelector) {
      this.customSearchInput = document.querySelector(this.searchInputSelector)
    }

    if (this.customSearchInput) {

      // Two-Way-Data-Binding simulieren
      this.customSearchInput.value = this.query
      this.$watch(
        function () {
          return this.query
        },
        function (newValue) {
          this.customSearchInput.value = newValue
        },
      )
      this.customSearchInput.addEventListener('input', () => {
        this.query = this.customSearchInput.value
      }, false)

      // Submit-Event abbrechen und Suche ausführen
      if (this.customSearchInput.form) {
        this.customSearchInput.form.addEventListener('submit', (event) => {
          event.preventDefault()
          event.stopImmediatePropagation()
          this.search()
        }, false)
      }

      this.setPropertiesToUrl(false)

      // Beim Navigieren über Browser-Back/-Forward die Suchparameter aus der URL übernehmen
      setUrlChangeHandler(this.updatePropertiesFromUrl)
    }

    if (this.query || this.hasInitialSearch || this.searchOptions.start) {
      const page = this.searchOptions.start ? Math.floor(this.searchOptions.start / this.searchOptions.rows) : 0
      await this.search(page) // @TODO Fehler abfangen
    }
  },

  methods: {
    async search (page = 0) {
      if (!this.query) {
        redirect('catalogue')
      } else {
        this.isLoading = true

        const response = await getParsedResponse(this.query, this.activeFilters, {  // @TODO Fehler abfangen
          fuzzy: this.searchOptions.fuzzy,
          rows: this.searchOptions.rows,
          sort: this.searchOptions.sort,
          start: page * this.searchOptions.rows,
        })
        this.searchResults = response.searchResults
        this.filters = response.filters
        this.numberOfHits = response.numberOfHits
        this.searchOptions.start = response.start
        this.searchOptions.rows = response.rows
        this.numberOfPages = response.numberOfPages
        this.currentPage = response.currentPage
        this.selectedCategory = response.selectedCategory
        this.solrOffline = response.solrOffline

        if (this.query) {
          this.setPageTitle(this.$t('search.titleWithQuery', { query: this.query }))
          this.lastQuery = this.query
        } else {
          this.setPageTitle(this.$t('search.title'))
          this.lastQuery = ''
        }
        this.sendGooglePageView()
        this.isLoading = false
      }
    },
    async sendGooglePageView () {
      if (applicationSettings.gtagActive && applicationSettings.gtagTrackingID) {
        window.gtag(
          'event',
          'page_view',
          {
            page_title: I18n.t('search.title'),
            page_location: window.location.href.replace(/\([^)]+\)\//, '/').toLowerCase(),
            page_path: window.location.pathname.replace(/\([^)]+\)\//, '/').toLowerCase() + '?q=' + this.query,
          },
        )
      }
    },
    onPageChange (page) {
      this.search(page)
    },
    toggleFilter (id) {
      toggleFilter(id, this.filters)
      this.search()
    },
    activateFilter (filter) {
      activateFilter(filter)
      this.search()
    },
    applyFilters () {
      activateMarkedFilters(this.filters)
      this.search()
    },
    resetCategoryFilters () {
      resetHierarchyFilters(this.filters)
      this.search()
    },
    resetAllFilters () {
      resetAllFilters(this.filters)
      this.searchOptions.fq = void 0
      this.search()
    },
    setPropertiesToUrl (push = true) {
      this.searchOptions.fq = this.activeFilters ? serializeActiveFilters(this.activeFilters) : void 0,

      updateUrlQueryString({
        fq: this.searchOptions.fq,
        q: this.query ? this.query : void 0,
        rows: this.searchOptions.rows > 0 ? this.searchOptions.rows : void 0,
        sort: this.searchOptions.sort !== 'score desc' ? this.searchOptions.sort : void 0,
        start: this.searchOptions.start > 0 ? this.searchOptions.start : void 0,
      }, {pushState: push})
    },
    updatePropertiesFromUrl () {
      this.query = getQueryParameter('q') || this.defaultQuery,

      this.searchOptions.fq = getQueryParameter('fq') || void 0
      this.searchOptions.fuzzy = this.hasFuzzySearch
      this.searchOptions.rows = getQueryParameter('rows') ? parseInt(getQueryParameter('rows'), 10) : 12
      this.searchOptions.sort = getQueryParameter('sort') || 'score desc'
      this.searchOptions.start = getQueryParameter('start') ? parseInt(getQueryParameter('start'), 10) : 0

      this.filters = {}
      this.search()
    },
  },
}
</script>
