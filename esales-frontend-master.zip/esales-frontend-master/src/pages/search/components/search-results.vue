<template>
  <div class="results">
    <!-- Ladeanzeige -->
    <div
      v-if="isLoading"
      class="border rounded p-3 text-center">
      <app-loading-spinner />
    </div>

    <template v-else>
      <!-- Auflistung Suchergebnisse -->
      <div
        v-if="searchResults.length > 0"
        class="list-group">
        <div
          v-for="item in searchResults"
          :key="item.id"
          class="list-group-item">
          <app-article-item
            :article="generateArticleFromSearchResult(item)"
            :pitcher="pitcher"
            size="medium" />
        </div>
      </div>

      <!-- Keine Suchergebnisse -->
      <div
        v-else
        class="border rounded p-3">
        <app-box-empty-list
          icon="fas fa-search"
          headline="Keine Treffer">
          {{ $t('search.components.searchResults.noResults') }}
          <div
            v-if="isFiltered"
            class="mt-2">
            <button
              type="button"
              class="btn btn-outline-primary text-uppercase"
              @click="$emit('resetfilters')">
              {{ $t('search.components.searchFilters.resetFilters') }}
            </button>
          </div>
        </app-box-empty-list>
      </div>
    </template>
  </div>
</template>

<script>
import { generateArticleFromSearchResult } from '@scripts/modules/search'

export default {
  props: {
    searchResults: {
      type: Array,
      default: () => [],
    },
    isFiltered: {
      type: Boolean,
      required: true,
    },
    isLoading: {
      type: Boolean,
      default: true,
    },
    pitcher: {
      required: true,
      type: String,
    },
  },

  methods: {
    generateArticleFromSearchResult,
  },
}
</script>
