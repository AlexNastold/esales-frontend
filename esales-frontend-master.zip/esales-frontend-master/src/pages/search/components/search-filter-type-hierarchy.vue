<template>
  <div>
    <div
      v-if="isLoading"
      class="text-center py-5">
      <app-loading-spinner />
    </div>

    <div
      v-else
      :class="{ 'show-categories': categoriesVisible }"
      class="category-parent">
      <!-- Backdrop -->
      <div
        class="backdrop"
        @click="closeSidebar" />

      <!-- Kategorien Mobile -->
      <button
        type="button"
        class="btn btn-block btn-secondary d-flex d-md-none"
        @click="toggleSidebar">
        {{ $t('search.components.searchFilterTypeHierarchy.category') }}
        <i class="fas fa-caret-right fa-fw align-self-center ml-auto" />
      </button>

      <!-- Auflistung Kategorien -->
      <div
        :class="{'px-3 py-2': categoriesVisible}"
        class="category-container">
        <!-- Button Schließen Mobile -->
        <div class="d-md-none mb-2">
          <button
            type="button"
            class="btn btn-secondary"
            @click="toggleSidebar">
            <i class="fas fa-times fa-fw" />
            {{ $t('general.dialogCloseLabel') }}
          </button>
        </div>

        <template v-if="isCategoryFilterActive">
          <!-- Wenn ein Kategoriefilter aktiv ist, hier die übergeordnete Kategorie ausgeben, wenn es eine gibt -->

          <a
            v-if="activeCategory.parent"
            href="#"
            class="parent-category icon-link d-block mb-1"
            @click.prevent="toggleFilter(activeCategory.id)">
            <i class="fas fa-angle-left" />
            <span class="text">
              {{ activeCategory.parent.label }}
            </span>
          </a>

          <!-- Wenn es keine übergeordnete Kategorie gibt, einen Link "Alle Kategorien" -->
          <a
            v-else
            href="#"
            class="base-category icon-link d-block mb-1"
            @click.prevent="resetCategoryFilters()">
            <i class="fas fa-angle-left" />
            <span class="text">
              {{ $t('search.components.searchFilterTypeHierarchy.allCategories') }}
            </span>
          </a>

          <!-- Hier die aktive Kategorie ausgeben, wenn es eine gibt -->
          <a
            href="#"
            class="active-category text-dark font-weight-bold d-block mb-1"
            @click.prevent="activateFilter(activeCategory)">
            {{ activeCategory.label }}
          </a>
        </template>

        <!-- Dann die Liste der untergeordneten Kategorien ausgeben -->
        <ul class="sub-category-list m-0 p-0">
          <li
            v-for="category in categoriesToDisplay"
            :key="category.id"
            class="sub-category-item">
            <category-item
              :hierarchy-node="category"
              @activatefilter="activateFilter" />
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import { getDeepestActiveHierarchyFilterWithSubs } from '@scripts/modules/search'

import CategoryItemComponent from './search-filter-type-hierarchy-item.vue'

export default {
  components: {
    'category-item': CategoryItemComponent,
  },

  props: {
    filterData: {
      type: Object,
      required: true,
    },
    isLoading: {
      type: Boolean,
      default: true,
    },
  },

  data () {
    return {
      categoriesVisible: false,
    }
  },

  computed: {
    activeCategory () {
      let activeCategory
      this.filterData.values.some((filter) => {
        if (filter.isActive) {
          activeCategory = getDeepestActiveHierarchyFilterWithSubs(filter)
          return true
        }
        return false
      })
      return activeCategory
    },
    isCategoryFilterActive () {
      return this.activeCategory !== undefined
    },
    categoriesToDisplay () {
      if (this.isCategoryFilterActive) {
        return this.activeCategory.sub
      }
      return this.filterData.values
    },
  },

  methods: {
    toggleSidebar () {
      this.categoriesVisible = !this.categoriesVisible
    },
    closeSidebar () {
      this.categoriesVisible = false
    },
    activateFilter (filter) {
      if (!filter.isActive) {
        this.closeSidebar()
        this.$emit('activatefilter', filter)
      }
    },
    toggleFilter (id, event) {
      this.closeSidebar()
      this.$emit('togglefilter', id, event)
    },
    resetCategoryFilters () {
      this.closeSidebar()
      // aktive Kategorie initialisieren
      this.$emit('resetcategoryfilters')
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

$category-sidebar-breakpoint: sm;

// .sub-category-list {
//   margin-left: 0;
//   padding-left: .75rem;
//   padding-right: 0;
// }

.sub-category-item {
  list-style-type: none;
}

.category-parent {

  .backdrop {
    background: rgba(0, 0, 0, .5);
    bottom: 0;
    left: -100%;
    opacity: 0;
    position: fixed;
    top: 0;
    transition: opacity .2s ease-in-out, left 0s ease-in-out .2s;
    width: 100%;
    z-index: $zindex-navigation-menu;
  }

  &.show-categories {
    .category-container {
      @include media-breakpoint-down($category-sidebar-breakpoint) {
        width: 50%;
      }
      @include media-breakpoint-down(xs) {
        width: 75%;
      }
    }

    .backdrop {
      left: 0;
      opacity: 1;
      transition: opacity .2s ease-in-out;
    }
  }

  .toggle-category-container {
    display: none;

    @include media-breakpoint-down($category-sidebar-breakpoint) {
      display: flex;
    }
  }

  .category-container {

    @include media-breakpoint-down($category-sidebar-breakpoint) {
      background: white;
      bottom: 0;
      box-shadow: 0 0 5px 0 rgba(0, 0, 0, .5);
      overflow: auto;
      position: fixed;
      right: 0;
      top: 0;
      transition: width .2s ease-in-out;
      width: 0;
      z-index: $zindex-navigation-menu;
    }
  }
}
</style>
