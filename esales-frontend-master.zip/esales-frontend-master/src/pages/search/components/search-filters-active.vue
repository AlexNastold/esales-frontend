<template>
  <!-- Suche Aktive Filter -->
  <div
    v-if="activeFiltersFlat.length"
    class="d-flex">
    <!-- Beschriftung Aktive Filter -->
    <div class="mr-2 font-weight-bold">
      <strong>{{ $t('search.components.searchFiltersActive.activeFilters') }}:</strong>
    </div>

    <!-- Auflistung Aktive Filter -->
    <div class="d-flex flex-wrap">
      <app-active-filter
        v-for="activeFilter in activeFiltersFlat"
        :key="activeFilter.id"
        :label="activeFilter.label"
        :value="activeFilter.valueLabel"
        type="primary"
        @click="resetFilter(activeFilter.field, activeFilter.value)" />

      <app-active-filter
        v-if="activeFiltersFlat.length > 1"
        :label="$t('search.components.searchFiltersActive.placeholder.resetFilters')"
        type="dark"
        @click="resetAllFilters" />
    </div>
  </div>
</template>

<script>
import { FilterType, getActiveFiltersFlat, resetAllFilters, resetFilter } from '@scripts/modules/search'

export default {
  props: {
    filters: {
      type: Object,
      default: () => {
        return {
          fields: [],
          ranges: [],
          pivots: [],
          queries: [],
        }
      },
    },
    ignoreHierachyFilters: {
      type: Boolean,
      default: false,
    },
  },
  data () {
    return {}
  },
  computed: {
    activeFiltersFlat () {

      let activeFilters = getActiveFiltersFlat(this.filters)

      if (this.ignoreHierachyFilters) {
        activeFilters = activeFilters.filter((filter) => {
          return filter.type !== FilterType.PIVOT_FILTER
        })
      }
      return activeFilters
    },
  },
  methods: {
    resetFilter (fieldName, value) {
      resetFilter(fieldName, value, this.filters)
      this.search()
    },
    resetAllFilters () {
      resetAllFilters(this.filters)
      this.search()
    },
    search (event) {
      this.activeFiltersFlat.forEach((filter) => {
        filter.isActive = true
      })
      this.$emit('search', event)
    },
  },
}
</script>
