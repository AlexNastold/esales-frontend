<template>
  <div>
    <a
      :class="{'pl-2': hierarchyNode.level > 0}"
      class="d-flex align-items-center text-dark my-1"
      href="#"
      @click.prevent="activateFilter(hierarchyNode)">
      <span :class="{'active': isActive}">
        {{ hierarchyNode.label }}
      </span>
      <div class="badge badge-pill badge-tertiary ml-auto">
        {{ hierarchyNode.hits }}
      </div>
    </a>
  </div>
</template>

<script>
export default {

  // Explicitely set a name for this component to be able to use
  // it recursively in its own template
  // See https://github.com/vuejs/vue/issues/3039#issuecomment-320508120
  name: 'HierarchyTreeItem',

  props: {
    hierarchyNode: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      isOpen: this.hierarchyNode.isActive,
    }
  },

  computed: {
    hasSub () {
      return this.hierarchyNode.sub.length
    },
    isActive () {
      return this.hierarchyNode.isActive
    },
  },

  watch: {
    isActive () {
      this.isOpen = this.isActive
    },
  },

  methods: {
    activateFilter (filter) {
      this.$emit('activatefilter', filter)
    },
    toggleVisibility () {
      this.isOpen = !this.isOpen
    },
  },
}
</script>

<style lang="scss" scoped>
  .sub-hierarchy-toggle {
    cursor: pointer;
  }

  .active {
    font-weight: bold;
  }
</style>
