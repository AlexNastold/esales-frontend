<template>
  <div
    v-if="isFieldFilter || isQueryFilter"
    ref="dropdown"
    class="btn-group filter-wrapper">
    <button
      :id="filterData.id"
      :title="filterData.label"
      type="button"
      class="btn btn-secondary dropdown-toggle filter-toggle"
      data-toggle="dropdown"
      aria-haspopup="true"
      aria-expanded="false">
      <div class="filter-label-wrapper">
        <span class="filter-label">
          {{ filterData.label }}
        </span>
        <div
          v-if="activeValues"
          class="active-values-wrapper">
          {{ activeValuesString }}
        </div>
      </div>
    </button>
    <div
      :aria-labelledby="filterData.id"
      class="dropdown-menu filter-items-wrapper">
      <div class="input-group mb-2">
        <input
          v-model="query"
          class="form-control"
          type="text"
          aria-describedby="filterSearch"
          @keyup="filterValues()">
        <div class="input-group-append">
          <span
            id="filterSearch"
            class="input-group-text"><i class="fas fa-search" /></span>
        </div>
      </div>
      <div
        ref="filterItems"
        class="filter-items">
        <div
          v-for="filterValue in filterData.values"
          :key="filterValue.id"
          class="filter-item custom-control custom-checkbox my-2">
          <input
            :id="filterValue.id"
            v-model="filterValue.markedForActivation"
            type="checkbox"
            class="custom-control-input"
            value="">
          <label
            :for="filterValue.id"
            class="custom-control-label">
            <template v-if="filterValue.image">
              <img
                :src="filterValue.image"
                :alt="filterValue.label"
                :title="filterValue.label"
                class="filter-value-image">
            </template>
            <template v-else>
              {{ filterValue.label }}
            </template>
            <span class="text-muted">
              ({{ filterValue.hits }})
            </span>
          </label>
        </div>
      </div>
      <button
        type="button"
        class="btn btn-block btn-primary apply-filter-button"
        @click="applyFilter">
        {{ $t('search.components.searchFilterTypeSimple.accept') }}
      </button>
    </div>
  </div>
</template>

<script>
import { FilterType } from '@scripts/modules/search'

import Fuse from 'fuse.js/dist/fuse'

export default {

  props: {
    filterData: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      fuse: void 0,
      query: '',
      filterDataValues: [],
    }
  },

  computed: {
    isFieldFilter () {
      return this.filterData.type === FilterType.FIELD_FILTER
    },
    isQueryFilter () {
      return this.filterData.type === FilterType.QUERY_FILTER
    },
    activeValues () {
      return this.filterData.values.reduce((activeValues, value) => {
        if (value.isActive) {
          activeValues.push(value)
        }
        return activeValues
      }, [])
    },
    activeValuesString () {
      let activeValuesString = ''
      this.activeValues.forEach((value, index) => {
        activeValuesString += (index > 0 ? ', ' : '') + value.label
      })
      return activeValuesString
    },
  },

  mounted () {

    /* Dropdown-Menüs beim Klick auf einen Eintrag nicht automatisch schließen */
    const dropdown = this.$refs.dropdown
    this.filterDataValues = this.filterData.values.slice(0)
    this.fuse = new Fuse(this.filterDataValues, { shouldSort: false, threshold: 0.0, keys: [ 'value' ] })
    $(dropdown).on({
      /* Beim Öffnen eines Filters alle anderen schließen */
      'show.bs.dropdown' () {
        $(this).siblings('.filter-wrapper.show').dropdown('toggle')
      },
    })

    $(dropdown).find('.dropdown-menu').on({click (event) {
      event.stopPropagation()
    }})

  },

  methods: {
    applyFilter () {
      this.$emit('applyfilter')
    },
    filterValues () {
      if (this.query !== '') {
        this.filterData.values = this.fuse.search(this.query).map((result) => (result.item))
      } else {
        this.filterData.values = this.filterDataValues
      }

    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

$filter-sidebar-breakpoint: sm;

.filter-wrapper {
  padding: ($spacer / 4) ($spacer / 4);
  width: (100% / 3);

  @include media-breakpoint-between($filter-sidebar-breakpoint, lg) {
    &:nth-of-type(3n+1) {
      padding-left: 0;
    }

    &:nth-of-type(3n) {
      padding-right: 0;
    }
  }

  @include media-breakpoint-up(xl) {
    width: (100% / 4);

    &:nth-of-type(4n+1) {
      padding-left: 0;
    }

    &:nth-of-type(4n) {
      padding-right: 0;
    }
  }

  @include media-breakpoint-down($filter-sidebar-breakpoint) {
    display: block;
    padding: 0 0;
    width: 100%;
  }

  .filter-toggle {
    display: flex;
    width: 100%;
    text-align: left;

    @include media-breakpoint-down($filter-sidebar-breakpoint) {
      border-radius: 0;
    }

    .filter-label-wrapper,
    .filter-label,
    .active-values-wrapper {
      text-overflow: ellipsis;
      white-space: nowrap;
      overflow: hidden;
      margin-right: ($spacer / 4)
    }

    .active-values-wrapper {
      display: none;
      color: theme-color('primary');

      @include media-breakpoint-down($filter-sidebar-breakpoint) {
        display: block;
      }
    }

    &:after {
      align-self: center;
      margin-left: auto;
    }
  }

  .filter-items-wrapper {
    min-width: ($spacer * 12);
    padding: ($spacer / 2);

    @include media-breakpoint-down($filter-sidebar-breakpoint) {
      width: 100%;
      border-radius: 0;
      border-top: none;
      float: unset;
      position: initial !important;
      transform: none !important;
    }

    .filter-items {
      max-height: 200px;
      overflow-x: hidden;
      overflow-y: auto;

      .filter-item label {
        width: 100%;
      }

      .filter-value-image {
        height: 20px;
        width: auto;
      }
    }

    .apply-filter-button {
      margin-top: ($spacer / 2);
    }
  }
}
</style>
