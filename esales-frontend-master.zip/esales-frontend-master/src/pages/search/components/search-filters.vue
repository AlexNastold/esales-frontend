<template>
  <div>
    <!-- Ladeanzeige -->
    <div
      v-if="isLoading"
      class="p-3 text-center">
      <app-loading-spinner />
    </div>

    <!-- Auflistung Filter -->
    <div
      v-else
      :class="{ 'show-filters': filtersVisible }"
      class="filter-parent mb-3">
      <div
        class="backdrop"
        @click="closeSidebar" />
      <button
        type="button"
        class="btn btn-block btn-secondary mb-3 toggle-filter-container"
        @click="toggleSidebar">
        {{ $t('search.components.searchFilters.filter') }}
        <i class="fas fa-caret-right fa-fw align-self-center ml-auto" />
      </button>

      <div class="filter-container">
        <button
          type="button"
          class="btn btn-secondary d-md-none m-2"
          @click="toggleSidebar">
          <i class="fas fa-times fa-fw" />
          {{ $t('general.dialogCloseLabel') }}
        </button>

        <button
          v-if="activeFilters.length"
          type="button"
          class="btn btn-link text-dark w-100 justify-content-between align-items-center reset-filters"
          @click="resetAllFilters">
          {{ $t('search.components.searchFilters.resetFilters') }}
          <i class="fas fa-times fa-fw" />
        </button>

        <simple-filter
          v-for="filter in combinedFiltersMain"
          :key="filter.id"
          :filter-data="filter"
          @applyfilter="applyFilter" />

        <simple-filter
          v-for="filter in combinedFiltersAdditional"
          v-show="showAdditionalFilters"
          :key="filter.id"
          :filter-data="filter"
          @applyfilter="applyFilter" />
      </div>
      <button
        v-show="combinedFiltersAdditional"
        type="button"
        class="btn btn-link"
        @click="showAdditionalFilters = !showAdditionalFilters">
        <template v-if="showAdditionalFilters">
          <i class="fas fa-angle-up" /> {{ $t('search.components.searchFilters.hideAdditionalFilter') }}
        </template>
        <template v-else>
          <i class="fas fa-angle-down" /> {{ $t('search.components.searchFilters.showAdditionalFilter') }}
        </template>
      </button>
    </div>
  </div>
</template>

<script>
import SimpleFilter from './search-filter-type-simple.vue'

export default {
  components: {
    'simple-filter': SimpleFilter,
  },

  props: {
    filters: {
      type: Object,
      default: () => {
        return {
          fields: [],
          ranges: [],
          pivots: [],
          queries: [],
        }
      },
    },
    isLoading: {
      type: Boolean,
      default: true,
    },
  },

  data () {
    return {
      filtersVisible: false,
      showAdditionalFilters: false,
      numberFiltersMain: 12,
    }
  },

  computed: {
    combinedFilters () {
      let combinedFilters = [].concat(this.filters.queries, this.filters.fields, this.filters.ranges)
      return combinedFilters.filter((filter) => {
        if (typeof filter === 'undefined') {
          return false
        }
        if (!this.app.settings.eek.listIconsActive  && filter.field === 'eek_classes') {
          return false
        }
        return true
      })
    },
    combinedFiltersMain () {
      if (this.combinedFilters.length > this.numberFiltersMain) {
        return this.combinedFilters.slice(0, this.numberFiltersMain)
      } else {
        return this.combinedFilters
      }
    },
    combinedFiltersAdditional () {
      if (this.combinedFilters.length > this.numberFiltersMain) {
        return this.combinedFilters.slice(this.numberFiltersMain)
      } else {
        return null
      }
    },
    activeFilters () {
      return this.combinedFilters.reduce((filterValues, filter) => {
        filter.values.forEach((filterValue) => {
          if (filterValue.isActive) {
            filterValues.push(filterValue)
          }
        })
        return filterValues
      }, [])
    },
  },

  methods: {
    toggleSidebar () {
      this.filtersVisible = !this.filtersVisible
    },
    closeSidebar () {
      this.filtersVisible = false
    },
    toggleFilter () {
      this.closeSidebar()
      this.$emit('togglefilter')
    },
    applyFilter () {
      this.closeSidebar()
      this.$emit('applyfilter')
    },
    resetAllFilters () {
      this.closeSidebar()
      this.$emit('resetallfilters')
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

$filter-sidebar-breakpoint: sm;

.filter-parent {

  .backdrop {
    background: rgba(0, 0, 0, .5);
    bottom: 0;
    left: -100%;
    opacity: 0;
    position: fixed;
    top: 0;
    transition: opacity .2s ease-in-out, left 0s ease-in-out .2s;
    width: 100%;
    z-index: $zindex-navigation-menu;
  }

  &.show-filters {
    .filter-container {
      @include media-breakpoint-down($filter-sidebar-breakpoint) {
        width: 50%;
      }
      @include media-breakpoint-down(xs) {
        width: 75%;
      }
    }

    .backdrop {
      left: 0;
      opacity: 1;
      transition: opacity .2s ease-in-out;
    }
  }

  .toggle-filter-container, .reset-filters {
    display: none;

    @include media-breakpoint-down($filter-sidebar-breakpoint) {
      display: flex;
    }
  }

  .filter-container {
    display: flex;
    flex-flow: row wrap;
    justify-content: flex-start;

    @include media-breakpoint-down($filter-sidebar-breakpoint) {
      background: white;
      bottom: 0;
      box-shadow: 0 0 5px 0 rgba(0, 0, 0, .5);
      display: initial;
      overflow: auto;
      position: fixed;
      right: 0;
      top: 0;
      transition: width .2s ease-in-out;
      width: 0;
      z-index: $zindex-navigation-menu;
      flex-direction: column;
    }
  }
}
</style>
