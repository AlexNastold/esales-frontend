<template>
  <div class="col-12 col-md-6 col-lg-4 mb-3">
    <a
      :href="href"
      :target="target"
      class="service-list-item">
      <div class="icon text-center py-3 mb-3">
        <i :class="`${icon} fa-5x fa-fw`" />
      </div>
      <div class="infos p-2 p-md-3">
        <div class="title font-weight-bold">
          {{ title }}
        </div>
        <div class="description text-truncate">
          {{ description }}
        </div>
      </div>
    </a>
  </div>
</template>

<script>
export default {
  props: {
    href: {
      type: String,
      required: true,
    },
    target: {
      type: String,
      default: '',
    },
    icon: {
      type: String,
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.service-list-item {
  border: 1px solid $service-list-item-text-background;
  transition: border-color .2s ease-in-out;
  color: white;
  display: block;
  height: $service-list-item-height;
  overflow: hidden;
  position: relative;
  text-decoration: none;

  .icon {
    transition: transform 1s ease-in-out;
    color: $service-list-item-text-background;

    &:hover {
      transform: scale(1.2);
    }
  }

  .infos {
    -webkit-backface-visibility: hidden; // sass-lint:disable-line no-vendor-prefixes
    -webkit-font-smoothing: antialiased; // sass-lint:disable-line no-vendor-prefixes
    background: transparentize($service-list-item-text-background, .1);
    bottom: 0;
    left: 0;
    position: absolute;
    right: 0;
    transition: background .2s ease-in-out;

    .title {
      font-family: $font-family-headline;
      font-size: 1.75rem;
      text-transform: uppercase;
    }

    .description {
      font-weight: 500;
    }

    &:hover {
      @if (lightness($service-list-item-text-background-hover) > 50%) {
        color: $font-color;
      } @else {
        color: white;
      }
    }
  }

  &:hover {
    border-color: $service-list-item-text-background-hover;

    .infos {
      background: $service-list-item-text-background-hover;
    }

    .icon {
      transform: scale(1.2);
    }
  }
}
</style>

