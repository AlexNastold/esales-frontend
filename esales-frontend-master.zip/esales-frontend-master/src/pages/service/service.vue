<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-service">
      <div class="container">
        <h1 class="headline">
          {{ $t('service.dashboard.headline') }}
        </h1>

        <div class="row">
          <!-- FAQ -->
          <service-list-item
            v-if="app.user.hasPermission('SERVICE_FAQ')"
            :title="$t('service.dashboard.cards.faqTitle')"
            :description="$t('service.dashboard.cards.faqDescription')"
            href="service-faq"
            icon="fas fa-question-circle" />

          <!-- Downloads -->
          <service-list-item
            v-if="app.user.hasPermission('SERVICE_DOWNLOADS')"
            :title="$t('service.dashboard.cards.downloadsTitle')"
            :description="$t('service.dashboard.cards.downloadsDescription')"
            href="service-downloads"
            icon="fas fa-download" />

          <!-- Nicht gelistete Produkte -->
          <service-list-item
            v-if="app.user.hasPermission('SERVICE_FORM_UNLISTED_ARTICLES')"
            :title="$t('service.dashboard.cards.notListedProductsTitle')"
            :description="$t('service.dashboard.cards.notListedProductsDescription')"
            href="service-not-listed-products"
            icon="fas fa-archive" />

          <!-- PDF Handbuch -->
          <service-list-item
            v-if="app.settings.manualPath"
            :title="$t('service.dashboard.cards.manualTitle')"
            :description="$t('service.dashboard.cards.manualDescription')"
            :href="app.settings.manualPath"
            target="_blank"
            icon="fas fa-book" />

          <!-- Kontakt -->
          <service-list-item
            v-if="app.user.hasPermission('SERVICE_CONTACT')"
            :title="$t('service.dashboard.cards.contactTitle')"
            :description="$t('service.dashboard.cards.contactDescription')"
            href="service-contact"
            icon="fas fa-id-card" />

          <!-- Teamviewer -->
          <service-list-item
            v-if="app.pageSettings.teamViewerLink"
            :title="$t('service.dashboard.cards.teamViewerTitle')"
            :description="$t('service.dashboard.cards.teamViewerDescription')"
            :href="app.pageSettings.teamViewerLink"
            target="_blank"
            icon="fas fa-user-friends" />
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import ServiceListItem from './components/service-list-item.vue'

export default {
  components: {
    'service-list-item': ServiceListItem,
  },

  created () {
    this.setPageTitle(this.$t('service.dashboard.title'))
  },
}
</script>
