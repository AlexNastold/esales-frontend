<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-documents-return">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountDocuments.headline')"
        page="documents" />

      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item">
            <a href="my-account-documents">
              {{ $t('myAccountDocuments.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item">
            <a :href="`my-account-documents?doctype=${encodeURIComponent(doctype)}`">
              {{ doctype | documentTypeTitlePlural }}
            </a>
          </li>
          <li
            v-if="isLoading"
            class="breadcrumb-item">
            <app-loading-spinner class="d-inline-block" />
          </li>
          <li
            v-else-if="!doc"
            class="breadcrumb-item active text-danger">
            Beleg nicht gefunden
          </li>
          <li
            v-else
            class="breadcrumb-item active">
            <a :href="`my-account-documents-detail?docid=${encodeURIComponent(docid)}&doctype=${encodeURIComponent(doctype)}`">
              {{ doc.documentType | documentTypeTitle }} {{ doc.documentIdDisplay }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountDocuments.return.returnArticles') }}
          </li>
        </ol>

        <!-- Seitenüberschrift -->
        <h2 class="mb-3">
          {{ $t('myAccountDocuments.return.returnArticles') }}
        </h2>

        <!-- Error -->
        <div
          v-show="errorMessage"
          class="alert alert-danger"
          role="alert"
          v-html="errorMessage" />

        <!-- Ladeanzeige -->
        <app-loading-box v-if="isLoading" />

        <!-- Formular retoure -->
        <form
          v-else
          @submit.prevent="save">
          <div class="mb-3">
            <!-- Hinweis -->
            <div
              v-if="returnOrderData.redemptionFees > 0 || returnOrderData.manipulationFees > 0"
              class="alert alert-warning mb-3"
              v-html="$t('myAccountDocuments.return.chargesReturn', { redemptionFees : returnOrderData.redemptionFees, manipulationFees: returnOrderData.manipulationFees, redemptionFeesCurrency : returnOrderData.redemptionFeesCurrency, manipulationFeesCurrency: returnOrderData.manipulationFeesCurrency })" />

            <!-- Checkbox Artikel sollen abgeholt werden -->
            <div class="custom-control custom-checkbox mb-3">
              <input
                id="checkboxPickup"
                v-model="pickup"
                type="checkbox"
                class="custom-control-input">
              <label
                for="checkboxPickup"
                class="custom-control-label">
                <strong class="d-block">
                  Artikel sollen abgeholt werden
                </strong>
              </label>
            </div>

            <!-- Wenn Artikel abgeholt werden sollen -->
            <div
              v-if="pickup"
              class="row">
              <!-- Land -->
              <div class="col-12 col-md-6">
                <div class="form-group">
                  <label for="country">
                    {{ $t('myAccountDocuments.return.country') }} <span class="required" />
                  </label>
                  <select
                    v-model="address.country"
                    :class="{ 'is-invalid': formErrors[ReturnsFieldErrors.COUNTRY] }"
                    class="form-control custom-select">
                    <option
                      v-for="country in returnOrderData.countries"
                      :key="country.key"
                      :value="country.key">
                      {{ country.label }}
                    </option>
                  </select>
                  <div
                    v-if="formErrors[ReturnsFieldErrors.COUNTRY]"
                    class="invalid-feedback"
                    v-html="formErrors[ReturnsFieldErrors.COUNTRY]" />
                </div>
              </div>

              <!-- Postleitzahl -->
              <div class="col-12 col-md-6">
                <div class="form-group">
                  <label for="zip-code">
                    {{ $t('myAccountDocuments.return.zipCode') }} <span class="required" />
                  </label>
                  <input
                    v-model="address.zipcode"
                    :placeholder="$t('myAccountDocuments.return.zipCodePlaceholder')"
                    :class="{ 'is-invalid': formErrors[ReturnsFieldErrors.ZIPCODE] }"
                    type="text"
                    class="form-control">
                  <div
                    v-if="formErrors[ReturnsFieldErrors.ZIPCODE]"
                    class="invalid-feedback"
                    v-html="formErrors[ReturnsFieldErrors.ZIPCODE]" />
                </div>
              </div>

              <!-- Ort -->
              <div class="col-12 col-md-6">
                <div class="form-group">
                  <label for="place">
                    {{ $t('myAccountDocuments.return.city') }} <span class="required" />
                  </label>
                  <input
                    v-model="address.city"
                    :placeholder="$t('myAccountDocuments.return.cityPlaceholder')"
                    :class="{ 'is-invalid': formErrors[ReturnsFieldErrors.CITY] }"
                    type="text"
                    class="form-control">
                  <div
                    v-if="formErrors[ReturnsFieldErrors.CITY]"
                    class="invalid-feedback"
                    v-html="formErrors[ReturnsFieldErrors.CITY]" />
                </div>
              </div>

              <!-- Straße, Haus-Nr. -->
              <div class="col-12 col-md-6">
                <div class="form-group">
                  <label for="street-number">
                    {{ $t('myAccountDocuments.return.street') }} <span class="required" />
                  </label>
                  <input
                    v-model="address.street"
                    :placeholder="$t('myAccountDocuments.return.streetPlaceholder')"
                    :class="{ 'is-invalid': formErrors[ReturnsFieldErrors.STREET] }"
                    type="text"
                    class="form-control">
                  <div
                    v-if="formErrors[ReturnsFieldErrors.STREET]"
                    class="invalid-feedback"
                    v-html="formErrors[ReturnsFieldErrors.STREET]" />
                </div>
              </div>

              <!-- Nachname/Firma (Name1) -->
              <div class="col-12 col-md-6">
                <div class="form-group">
                  <label for="place">
                    {{ $t('myAccountDocuments.return.name1') }} <span class="required" />
                  </label>
                  <input
                    v-model="address.name1"
                    :placeholder="$t('myAccountDocuments.return.name1Placeholder')"
                    :class="{ 'is-invalid': formErrors[ReturnsFieldErrors.NAME1] }"
                    type="text"
                    class="form-control">
                  <div
                    v-if="formErrors[ReturnsFieldErrors.NAME1]"
                    class="invalid-feedback"
                    v-html="formErrors[ReturnsFieldErrors.NAME1]" />
                </div>
              </div>

              <!-- Vorname (Name2) -->
              <div class="col-12 col-md-6">
                <div class="form-group">
                  <label for="street-number">
                    {{ $t('myAccountDocuments.return.name2') }}
                  </label>
                  <input
                    v-model="address.name2"
                    :placeholder="$t('myAccountDocuments.return.name2Placeholder')"
                    type="text"
                    class="form-control">
                </div>
              </div>

              <app-form-required-hint class="col-12" />
            </div>
          </div>

          <!-- Bemerkung -->
          <div class="mb-3">
            <label for="notice">
              {{ $t('myAccountDocuments.return.notice') }}
            </label>
            <textarea
              v-model="notice"
              :placeholder="$t('myAccountDocuments.return.noticePlaceholder')"
              class="form-control" />
          </div>

          <!-- Auflistung Positionen -->
          <div class="list-group mb-3">
            <div class="list-group-item p-0">
              <return-position
                :position="firstPosition"
                :return-reasons="returnOrderData.return_reasons"
                :return-statuses="returnOrderData.return_stati" />
            </div>
          </div>

          <template v-if="furtherPositions.length">
            <h4 class="mb-3">
              {{ $t('myAccountDocuments.return.sameOrderPositions') }}
            </h4>
            <div class="list-group mb-3">
              <div
                v-for="position in furtherPositions"
                :key="position.posnr"
                class="list-group-item p-0">
                <return-position
                  :position="position"
                  :is-further-position="true"
                  :return-reasons="returnOrderData.return_reasons"
                  :return-statuses="returnOrderData.return_stati" />
              </div>
            </div>
          </template>

          <!-- Buttons -->
          <div class="d-md-flex justify-content-end">
            <!-- Buttons Mobile -->
            <div class="d-md-none">
              <!-- Button Speichern -->
              <button
                :disabled="isProcessing || isLoading"
                type="button"
                class="btn btn-block btn-primary mb-1"
                @click.prevent="returnArticles()">
                <app-icon-state
                  :is-loading="isProcessing"
                  icon="fas fa-box" />
                {{ $t('myAccountDocuments.return.returnArticles') }}
              </button>
              <!-- Button Abbrechen -->
              <button
                type="button"
                class="btn btn-block btn-secondary"
                @click.prevent="cancel()">
                <i class="fas fa-times fa-fw" />
                {{ $t('general.cancel') }}
              </button>
            </div>

            <!-- Buttons Desktop -->
            <div class="d-none d-md-block">
              <!-- Button Abbrechen -->
              <button
                type="button"
                class="btn btn-secondary"
                @click.prevent="cancel()">
                <i class="fas fa-times fa-fw" />
                {{ $t('general.cancel') }}
              </button>
              <!-- Button Speichern -->
              <button
                :disabled="isProcessing || isLoading"
                type="button"
                class="btn btn-primary"
                @click.prevent="returnArticles()">
                <app-icon-state
                  :is-loading="isProcessing"
                  icon="fas fa-box" />
                {{ $t('myAccountDocuments.return.returnArticles') }}
              </button>
            </div>
          </div>
        </form>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>

import { redirect, RedirectMethod } from '@scripts/helper/redirect'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { getDocumentDetail} from '@scripts/modules/documents'
import { showTechnicalErrorMessage, showErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'
import { getReturnOrderData, ReturnsFieldErrors, returnArticles } from '@scripts/modules/returns'

import MyAccountHeader from '@components/pages/my-account/header.vue'
import ReturnPosition from './components/ReturnPosition.vue'

export default {
  components: {
    'my-account-header': MyAccountHeader,
    'return-position': ReturnPosition,
  },

  data () {
    return {
      isLoading: true,
      isProcessing: false,
      doc: void 0,
      pickup: false,
      errorMessage: '',
      address: {
        name1: void 0,
        name2: void 0,
        street: void 0,
        zipcode: void 0,
        city: void 0,
        country: void 0,
      },
      returnOrderData: {},
      docid: getQueryParameter('docid') || void 0,
      doctype: parseInt(getQueryParameter('doctype'), 10) ? parseInt(getQueryParameter('doctype'), 10) : void 0,
      material: getQueryParameter('material') || void 0,
      pos: getQueryParameter('pos') || void 0,
      formErrors: {},
      ReturnsFieldErrors,
      notice: '',
      positions: [],
    }
  },

  computed: {
    firstPosition () {
      return this.positions[0]
    },
    furtherPositions () {
      return this.positions.slice(1)
    },
  },

  async created () {
    this.setPageTitle(this.$t('myAccountDocuments.return.returnArticles'))
    try {
      this.doc = await getDocumentDetail(this.doctype, this.docid)
      this.returnOrderData = await getReturnOrderData(this.docid, this.material, this.pos)
      this.positions = this.returnOrderData.positions
      this.address.name1 = this.returnOrderData.name1
      this.address.name2 = this.returnOrderData.name2
      this.address.street = this.returnOrderData.street
      this.address.zipcode = this.returnOrderData.zipcode
      this.address.city = this.returnOrderData.city
      this.address.country = this.returnOrderData.country
      this.isLoading = false
    } catch (e) {
      console.error(e)
      showTechnicalErrorMessage()
    }
  },

  methods: {
    cancel () {
      redirect('my-account-documents-detail', { docid: this.doc.documentId, doctype: this.doc.documentType }, RedirectMethod.GET)
    },
    async returnArticles () {
      this.isProcessing = true
      try {
        const data = await returnArticles(this.pickup, this.address.country, this.address.zipcode, this.address.street, this.address.city,
          this.address.name1, this.address.name2, this.notice, this.positions.map((position) => {
            return {
              material: position.material,
              quantity: position.qty,
              sales_unit: position.unit,
              doc_number: position.doc_number,
              itm_number: position.posnr,
              notice: position.notice,
              return_reason: position.return_reason,
              return_status: position.return_status,
            }
          }))
        redirect('my-account-documents-returned', { orderDocId: this.doc.documentId, orderDocType: this.doc.documentType, returnDocId: data.returnDocId }, RedirectMethod.GET)
      } catch (e) {
        if (e.code === ErrorCode.INVALID_FIELDS) {
          showErrorMessage(this.$t('general.invalidFieldsMessage'))
          this.errorMessage = this.$t('general.invalidFieldsMessage')
          this.formErrors = e.fieldErrors
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
      this.isProcessing = false
    },
  },
}
</script>

<style lang="scss" src="./my-account-documents-return.scss"></style>

<style lang="scss" scoped>
@import '~styles/definitions/all';

</style>
