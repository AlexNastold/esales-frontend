<template>
  <div>
    <!-- Positionsnummer -->
    <div class="col-12 text-muted bg-light px-3 py-1">
      {{ $t('myAccountDocuments.detail.tabs.positions.fields.positionNumber') }}
      {{ position.posnrDisplay }}
    </div>

    <!-- Fehlermeldung -->
    <div
      v-if="positionError"
      class="text-danger font-weight-bold mt-2 px-3">
      <i class="fas fa-exclamation-triangle fa-fw" />&nbsp;
      {{ positionError }}
    </div>

    <div class="row p-3">
      <!-- Artikelbild, Artikelname, Artikelnummer, Bestellte Menge -->
      <div class="col-12 col-md-7 col-lg-8">
        <div class="row">
          <!-- Artikelbild -->
          <div class="col-auto d-flex">
            <div class="article-image-wrapper d-flex align-items-center justify-content-center">
              <img
                :src="position.image | articleImage"
                :alt="position.description">
            </div>
          </div>

          <!-- Artikelname, Artikelnummer, Position, Bestellte Menge -->
          <div class="col">
            <!-- Artikelname -->
            <div class="font-weight-bold font-size-lg">
              <span
                class="text-dark">
                {{ position.description }}
              </span>
            </div>

            <!-- Artikelnummer -->
            <div class="text-muted">
              <small>
                {{ $t('general.articleNumberShort') }}
                {{ position.materialDisplay }}
              </small>
            </div>

            <!-- Bestellte Menge -->
            <div>
              <span class="text-muted">
                {{ $t('myAccountDocuments.return.orderedQuantity') }}
              </span>
              {{ position.reqQty }} {{ position.unitFormatted }}
            </div>
          </div>
        </div>
      </div>

      <!-- Menge, Bemerkung, Rückgabegrund, Warenzustand -->
      <div class="col-12 col-md-5 col-lg-4">
        <!-- Menge -->
        <div class="d-flex justify-content-end mb-1">
          <!-- Ausgewählter Artikel -->
          <app-form-input-quantity
            v-if="!isFurtherPosition"
            v-model="position.qty"
            :force-max="true"
            :min="position.stepsize"
            :max="position.open_ret_qty"
            :stepsize="position.stepsize"
            :unit="position.unit" />

          <!-- Anderer Artikel aus Bestellung -->
          <app-form-input-quantity
            v-else
            v-model="position.qty"
            :force-max="true"
            :max="position.open_ret_qty"
            :stepsize="position.stepsize"
            :unit="position.unit" />
        </div>

        <!-- Bemerkung -->
        <div class="d-flex justify-content-end mb-1">
          <input
            v-model="position.notice"
            :placeholder="$t('myAccountDocuments.return.noticePlaceholder')"
            type="text"
            class="form-control">
        </div>

        <!-- Rückgabegrund -->
        <div class="d-flex justify-content-end mb-1">
          <select
            v-model="position.return_reason"
            :disabled="position.qty === 0"
            class="form-control custom-select">
            <option value="">
              {{ $t('myAccountDocuments.return.reason') }}
            </option>
            <option
              v-for="return_reason in returnReasons"
              :key="return_reason.key"
              :value="return_reason.key">
              {{ return_reason.label }}
            </option>
          </select>
        </div>

        <!-- Warenzustand -->
        <div class="d-flex justify-content-end">
          <select
            v-model="position.return_status"
            :disabled="position.qty === 0"
            class="form-control custom-select">
            <option value="">
              {{ $t('myAccountDocuments.return.goodsState') }}
            </option>
            <option
              v-for="return_status in returnStatuses"
              :key="return_status.key"
              :value="return_status.key">
              {{ return_status.label }}
            </option>
          </select>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    position: {
      required: true,
      type: Object,
    },
    isFurtherPosition: {
      default: false,
      type: Boolean,
    },
    positionError: {
      type: String,
      default: '',
    },
    returnReasons: {
      type: Array,
      required: true,
    },
    returnStatuses: {
      type: Array,
      required: true,
    },
  },
}
</script>
