<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-ordering-process-payment-cc">
      <div class="container">
        <h1 class="headline">
          {{ $t('payment.creditcard.headline') }}
        </h1>

        <form
          @submit.prevent="checkCreditcard">
          <div class="row">
            <div class="col-12 col-lg-6 order-2 order-lg-1">
              <!-- Nachname -->
              <div class="form-group">
                <label>
                  {{ $t('payment.creditcard.lastname') }}
                  <span class="required" />
                </label>
                <div>
                  <input
                    v-model="lastname"
                    type="text"
                    placeholder="Nachname"
                    class="form-control">
                </div>
              </div>

              <!-- Vorname -->
              <div class="form-group">
                <label>
                  {{ $t('payment.creditcard.firstname') }}
                  <span class="required" />
                </label>
                <div>
                  <input
                    v-model="firstname"
                    type="text"
                    placeholder="Vorname"
                    class="form-control">
                </div>
              </div>

              <!-- Kreditkartennummer -->
              <div class="form-group">
                <label>
                  {{ $t('payment.creditcard.cardpan') }}
                  <span class="required" />
                </label>
                <span
                  id="cardpan"
                  class="inputIframe" />
              </div>

              <!-- Kreditkartenpruefziffer -->
              <div class="form-group">
                <label>
                  {{ $t('payment.creditcard.cardcvc2') }}
                  <span class="required" />
                </label>
                <div>
                  <span
                    id="cardcvc2"
                    class="inputIframe" />
                </div>
              </div>

              <!-- Kreditkartenpruefziffer -->
              <div class="form-group">
                <label>
                  {{ $t('payment.creditcard.expireDate') }}
                  <span class="required" />
                </label>
                <span
                  id="expireInput"
                  class="inputIframe">
                  <div>
                    <span id="cardexpiremonth" />
                    <span id="cardexpireyear" />
                  </div>
                </span>
              </div>

              <app-form-required-hint />

              <div class="d-flex align-items-center mb-3">
                <small class="safe-connection text-right ml-auto">
                  <i class="fas fa-lock fa-fw" />
                  {{ $t('general.secureConnection') }}
                </small>
              </div>

              <div class="row mt-3">
                <div class="col-12 col-lg-6 order-lg-2 mb-2 mb-lg-0">
                  <button
                    type="button"
                    class="btn btn-block btn-primary"
                    @click="checkCreditcard ">
                    {{ $t('payment.creditcard.submit') }}
                  </button>
                </div>

                <div class="col-12 col-lg-6 order-lg-1">
                  <a
                    href="checkout"
                    class="btn btn-block btn-secondary">
                    {{ $t('payment.creditcard.cancel') }}
                  </a>
                </div>
              </div>
            </div>

            <!-- Hinweis -->
            <div class="col-12 col-lg-6 order-1 order-lg-2 mb-3 mb-lg-0">
              <div class="alert alert-info mb-0">
                {{ $t('payment.creditcard.info') }} <br> <br>
                <div>
                  <img
                    v-for="(icon, iconIndex) in creditcardIcons"
                    :key="`${iconIndex}`"
                    :src="icon"
                    :alt="$t('payment.creditcard.creditcard')"
                    class="payment-icon-creditcard">
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
/* global Payone */

import { RedirectMethod, redirect } from '@scripts/helper/redirect'
import { getPaymentIcons, getPaymentInfo } from '@scripts/modules/payment'
import { showErrorMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  data () {
    return {
      firstname: '',
      lastname: '',
      paymentInfo: void 0,
      payoneIframes: void 0,
      creditcardIcons: [],
      creditcardCheckConfig: {
        request: 'creditcardcheck',
        responsetype: 'JSON',
        mode: '',
        mid: '',
        aid: '',
        portalid: '',
        encoding: 'UTF-8',
        storecarddata: 'yes',
        hash: '',
      },
    }
  },

  async created () {
    this.setPageTitle(this.$t('payment.creditcard.title'))
    await this.loadPaymentInfo()
    window.payoneCallback = this.payoneCallback.bind(this)
    this.creditcardIcons = getPaymentIcons('PAYONE', 'cc')
  },

  methods: {
    async loadPaymentInfo () {
      try {
        this.paymentInfo = await getPaymentInfo()
        this.firstname = this.paymentInfo.firstname
        this.lastname = this.paymentInfo.lastname
        this.creditcardCheckConfig.mode = this.paymentInfo.mode
        this.creditcardCheckConfig.mid = this.paymentInfo.mid
        this.creditcardCheckConfig.aid = this.paymentInfo.aid
        this.creditcardCheckConfig.portalid = this.paymentInfo.portalid
        this.creditcardCheckConfig.hash = this.paymentInfo.hash_cc
        this.createPayoneHostedIFrames()
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },

    payoneCallback (response) {
      if (response.status === 'VALID') {
        this.paymentInfo.pseudocardpan = response.pseudocardpan
        this.paymentInfo.truncatedcardpan = response.truncatedcardpan
        this.paymentInfo.firstname = this.firstname
        this.paymentInfo.lastname = this.lastname
        redirect(this.paymentInfo.clientURL, this.paymentInfo, RedirectMethod.POST)
      } else {
        console.error(response.errorcode && ': ' && response.errormessage)
        showErrorMessage(response.errormessage)
      }
    },
    checkCreditcard () {
      if (this.payoneIframes) {
        if (this.payoneIframes.isComplete() && this.firstname && this.lastname) {
          this.payoneIframes.creditCardCheck('payoneCallback')
        } else {
          showErrorMessage(this.$t('general.requiredFieldsMessage'))
          this.isLoading = false
        }
      }
    },
    createPayoneHostedIFrames () {
      let supportedCardtypes = []
      this.paymentInfo.cc_types.forEach(cc_type => {
        supportedCardtypes.push(cc_type.value)
      })
      let payoneLanguageObject = ''
      if (this.paymentInfo.language === 'fr') {
        payoneLanguageObject = Payone.ClientApi.Language.fr
      } else if (this.paymentInfo.language === 'en') {
        payoneLanguageObject = Payone.ClientApi.Language.en
      } else {
        payoneLanguageObject = Payone.ClientApi.Language.de
      }
      this.payoneIframes = new Payone.ClientApi.HostedIFrames({
        language: payoneLanguageObject,
        autoCardtypeDetection: {
          supportedCardtypes,
        },
        defaultStyle: {
          input: 'display: block;width: 100%;padding: 0.375rem 0.75rem;font-size: 0.875rem;line-height: 1.5;color: #263238;background-color: #fff;background-clip: padding-box;border: 1px solid #d1d9dd;border-radius: 0;-webkit-transition: border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;transition: border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;',
          password: 'display: block;width: 100%;padding: 0.375rem 0.75rem;font-size: 0.875rem;line-height: 1.5;color: #263238;background-color: #fff;background-clip: padding-box;border: 1px solid #d1d9dd;border-radius: 0;-webkit-transition: border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;transition: border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;',
          select: 'display: block;width: 100%;padding: 0.375rem 0.75rem;font-size: 0.875rem;line-height: 1.5;color: #263238;background-color: #fff;background-clip: padding-box;border: 1px solid #d1d9dd;border-radius: 0;-webkit-transition: border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;transition: border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;',
          iframe: {
            height: '50px',
          },
        },
        fields: {
          cardpan: {
            selector: 'cardpan',
            type: 'text',
            iframe: {
              width: '100%',
            },
          },
          cardcvc2: {
            selector: 'cardcvc2',
            type: 'password',
            size: '4',
            maxlength: '4',
            iframe: {
              width: '80px',
            },
          },
          cardexpiremonth: {
            selector: 'cardexpiremonth',
            type: 'select',
            iframe: {
              width: '80px',
            },
          },
          cardexpireyear: {
            selector: 'cardexpireyear',
            type: 'select',
            iframe: {
              width: '180px',
            },
          },
        },
      }, this.creditcardCheckConfig)
    },
  },
}
</script>

<style lang="scss" src="./ordering-process-payment-cc.scss"></style>
