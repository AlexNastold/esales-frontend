/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/my-account-addresses-edit/my-account-addresses-edit.vue'
setup(PageComponent)
