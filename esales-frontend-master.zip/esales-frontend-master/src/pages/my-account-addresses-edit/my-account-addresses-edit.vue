<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-addresses-edit">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountAddressesEdit.addresses')"
        page="addresses" />

      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item">
            <a href="my-account-addresses">
              {{ $t('myAccountAddressesEdit.addresses') }}
            </a>
          </li>
          <li
            v-if="isLoading"
            class="breadcrumb-item">
            <app-loading-spinner class="d-inline-block" />
          </li>
          <li
            v-else-if="!address"
            class="breadcrumb-item text-danger">
            {{ $t('myAccountAddressesEdit.notFoundBreadcrumb') }}
          </li>
          <li
            v-else
            class="breadcrumb-item">
            {{ $t('myAccountAddressesEdit.numberContraction') }}. {{ address.id }}
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountAddressesEdit.edit') }}
          </li>
        </ol>

        <h2 class="mb-3">
          {{ $t('myAccountAddressesEdit.editAddress') }}
        </h2>

        <div
          v-show="errorMessage"
          class="alert alert-danger"
          role="alert"
          v-html="errorMessage" />

        <!-- Ladeanzeige -->
        <app-loading-box v-if="isLoading" />

        <!-- Adresse nicht gefunden -->
        <app-box-oops
          v-else-if="!address"
          link-title="Zurück zur Übersicht"
          link-href="my-account-addresses">
          {{ $t('myAccountAddressesEdit.addressNotFound') }}
        </app-box-oops>

        <!-- Adresse anzeigen -->
        <form
          v-else
          @submit.prevent="editAddress">
          <div class="row">
            <!-- Nachname, Firma -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label for="company">
                  {{ $t('myAccountAddressesEdit.company') }} <span class="required" />
                </label>
                <input
                  id="company"
                  v-model="address.name1"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.LASTNAME]}"
                  :placeholder="$t('myAccountAddressesEdit.companyPlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="35"
                  autofocus>
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.LASTNAME]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.LASTNAME]" />
              </div>
            </div>

            <!-- Vorname -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label for="firstname">
                  {{ $t('myAccountAddressesEdit.firstName') }}
                </label>
                <input
                  id="firstname"
                  v-model="address.name2"
                  :placeholder="$t('myAccountAddressesEdit.firstNamePlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="35">
              </div>
            </div>

            <!-- Straße -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label for="street">
                  {{ $t('myAccountAddressesEdit.street') }} <span class="required" />
                </label>
                <input
                  id="street"
                  v-model="address.street"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.STREET]}"
                  :placeholder="$t('myAccountAddressesEdit.streetPlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="60">
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.STREET]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.STREET]" />
              </div>
            </div>

            <!-- Postleitzahl -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label for="postalCode">
                  {{ $t('myAccountAddressesEdit.plz') }} <span class="required" />
                </label>
                <input
                  id="postalCode"
                  v-model="address.postalCode"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.ZIPCODE]}"
                  :placeholder="$t('myAccountAddressesEdit.plzPlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="10">
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.ZIPCODE]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.ZIPCODE]" />
              </div>
            </div>

            <!-- Ort -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label for="city">
                  {{ $t('myAccountAddressesEdit.city') }} <span class="required" />
                </label>
                <input
                  id="city"
                  v-model="address.city"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.CITY]}"
                  :placeholder="$t('myAccountAddressesEdit.cityPlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="35">
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.CITY]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.CITY]" />
              </div>
            </div>

            <!-- Land -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label for="country">
                  {{ $t('myAccountAddressesEdit.country') }} <span class="required" />
                </label>
                <select
                  id="country"
                  v-model="address.country"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.COUNTRY]}"
                  class="form-control custom-select">
                  <option
                    v-for="country of countries"
                    :key="country.key"
                    :value="country.key">
                    {{ country.label }}
                  </option>
                </select>
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.COUNTRY]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.COUNTRY]" />
              </div>
            </div>

            <div class="col-12 col-lg-6 mb-2 mb-lg-0">
              <app-form-required-hint />
            </div>

            <!-- Buttons -->
            <div class="col-12 col-lg-6 text-lg-right">
              <!-- Buttons Mobile -->
              <div class="d-lg-none">
                <button
                  type="submit"
                  class="btn btn-block btn-primary mb-1">
                  <app-icon-state
                    :is-loading="isInProcess"
                    icon="fas fa-save" />
                  {{ $t('myAccountAddressesEdit.save') }}
                </button>
                <a
                  href="my-account-addresses"
                  class="btn btn-block btn-secondary">
                  <i class="fas fa-times fa-fw" />
                  {{ $t('general.cancel') }}
                </a>
              </div>

              <!-- Buttons Desktop -->
              <div class="d-none d-lg-block">
                <a
                  href="my-account-addresses"
                  class="btn btn-secondary">
                  <i class="fas fa-times fa-fw" />
                  {{ $t('general.cancel') }}
                </a>
                <button
                  type="submit"
                  class="btn btn-primary">
                  <app-icon-state
                    :is-loading="isInProcess"
                    icon="fas fa-save" />
                  {{ $t('myAccountAddressesEdit.save') }}
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { pageSettingsMyAccountAddressesCreate as pageSettings } from '@scripts/app/settings'
import { createFlashMessage } from '@scripts/helper/flash-messages'
import { redirect } from '@scripts/helper/redirect'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { DeliveryAddressFieldErrors, editDeliveryAddress, getDeliveryAddress } from '@scripts/modules/delivery-addresses'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'

import MyAccountHeader from '@components/pages/my-account/header.vue'

export default {
  components: {
    'my-account-header': MyAccountHeader,
  },

  data () {
    return {
      isInProcess: false,
      isLoading: true,

      address: void 0,
      addressId: getQueryParameter('id'),

      countries: pageSettings.countries,

      errorMessage: '',
      formErrors: {},

      DeliveryAddressFieldErrors,

    }
  },

  created () {
    this.setPageTitle(this.$t('myAccountAddressesEdit.title'))

    this.loadDeliveryAddress()
  },

  methods: {
    async loadDeliveryAddress () {
      this.isLoading = true

      try {
        this.address = await getDeliveryAddress(this.addressId)
        this.isLoading = false
      } catch (e) {
        if (e.code === ErrorCode.NOT_FOUND) {
          // Ist okay, nur nicht "this.address" setzen
          this.isLoading = false
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },
    async editAddress () {

      this.isInProcess = true
      this.errorMessage = ''
      this.formErrors = {}
      try {
        await editDeliveryAddress(
          this.address.id,
          this.address.name1,
          this.address.name2,
          this.address.street,
          this.address.postalCode,
          this.address.city,
          this.address.country,
        )
        createFlashMessage(
          this.$t('myAccountAddressesEdit.confirmAddressEdit'),
          'success',
        )
        redirect('my-account-addresses')
      } catch (e) {
        if (e.code === ErrorCode.INVALID_FIELDS) {
          this.errorMessage = this.$t('general.invalidFieldsMessage')
          this.formErrors = e.fieldErrors
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
        this.isInProcess = false
      }
    },
  },
}
</script>

<style lang="scss" src="./my-account-addresses-edit.scss"></style>
