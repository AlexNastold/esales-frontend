/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/service-not-listed-products/service-not-listed-products.vue'
setup(PageComponent)
