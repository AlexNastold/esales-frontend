<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main>
      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="service">
              {{ $t('service.dashboard.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('serviceNotListedProducts.page.breadcrumb') }}
          </li>
        </ol>

        <!-- Seitenüberschrift -->
        <h1 class="headline">
          {{ $t('serviceNotListedProducts.page.headline') }}
        </h1>

        <app-box-success v-if="isSent">
          <h2>{{ $t('serviceNotListedProducts.page.success.headline') }}</h2>
          {{ $t('serviceNotListedProducts.page.success.message') }}<br>

          <a
            href="service"
            class="btn btn-secondary mt-3">
            {{ $t('serviceNotListedProducts.page.success.buttonBack') }}
          </a>
        </app-box-success>

        <!-- Formular -->
        <form
          v-else
          @submit.prevent="send">
          <!-- Fehlermeldung -->
          <div
            v-show="errorMessage"
            class="alert alert-danger"
            role="alert"
            v-html="errorMessage" />

          <!-- Bestellinformationen -->
          <h3>{{ $t('serviceNotListedProducts.page.orderHeadline') }}</h3>

          <!-- Bestellnummer -->
          <div class="form-group">
            <label>
              {{ $t('serviceNotListedProducts.page.fields.orderNumber') }}
              <span class="required" />
            </label>
            <input
              v-model="formOrderNumber"
              :class="{'is-invalid': formErrors[NotListedProductsFieldErrors.ORDERNUMBER]}"
              :placeholder="$t('serviceNotListedProducts.page.fields.orderNumberPlaceholder')"
              type="text"
              class="form-control"
              autofocus>
            <div
              v-if="formErrors[NotListedProductsFieldErrors.ORDERNUMBER]"
              class="invalid-feedback"
              v-html="formErrors[NotListedProductsFieldErrors.ORDERNUMBER]" />
          </div>

          <!-- Bemerkung -->
          <div class="form-group">
            <label>
              {{ $t('serviceNotListedProducts.page.fields.message') }}
              <span class="required" />
            </label>
            <textarea
              v-model="formText"
              :class="{'is-invalid': formErrors[NotListedProductsFieldErrors.MESSAGE]}"
              :placeholder="$t('serviceNotListedProducts.page.fields.messagePlaceholder')"
              class="form-control"
              rows="5" />
            <div
              v-if="formErrors[NotListedProductsFieldErrors.MESSAGE]"
              class="invalid-feedback"
              v-html="formErrors[NotListedProductsFieldErrors.MESSAGE]" />
          </div>

          <!-- Positionsdaten -->
          <h3>{{ $t('serviceNotListedProducts.page.positionsHeadline') }}</h3>

          <div class="position bg-light p-3 mb-2">
            <div
              v-for="(article, index) in articles"
              :key="index"
              :class="{
                'mb-0': index === articles.length - 1,
                'mb-3': index !== articles.length - 1,
              }"
              class="row mb-lg-0">
              <!-- Herstellernummer -->
              <div class="col-12 col-lg-3 mb-1">
                <input
                  v-model="article.matnr"
                  :placeholder="$t('serviceNotListedProducts.page.fields.articleNumberPlaceholder')"
                  type="text"
                  class="form-control">
              </div>

              <!-- Hersteller -->
              <div class="col-12 col-lg-3 mb-1">
                <input
                  v-model="article.supplier"
                  :placeholder="$t('serviceNotListedProducts.page.fields.supplierIdPlaceholder')"
                  type="text"
                  class="form-control">
              </div>

              <!-- Produktbezeichnung -->
              <div class="col-12 col-lg-3 mb-1">
                <input
                  v-model="article.supplierName"
                  :placeholder="$t('serviceNotListedProducts.page.fields.supplierNamePlaceholder')"
                  type="text"
                  class="form-control">
              </div>

              <!-- Menge -->
              <div class="col-12 col-lg-2 mb-1">
                <app-form-input-quantity
                  v-model="article.amount"
                  :unit="$t('components.formInputQuantity.unitDefault')"
                  width="auto" />
              </div>
              <!-- Knopf Position entfernen -->
              <div
                class="col-12 col-lg-1 mb-1">
                <template
                  v-if="index>0">
                  <button
                    class="d-block d-lg-none btn btn-block btn-secondary"
                    @click.prevent="removePosition(index)">
                    <i class="fas fa-trash-alt fa-fw" />
                  </button>
                  <button
                    class="d-none d-lg-block btn btn-secondary"
                    @click.prevent="removePosition(index)">
                    <i class="fas fa-trash-alt fa-fw" />
                  </button>
                </template>
              </div>
            </div>
          </div>

          <div class="d-flex justify-content-end">
            <button
              type="button"
              class="btn btn-secondary"
              @click.prevent="addArticle">
              <i class="fas fa-plus fa-fw" />
              {{ $t('serviceNotListedProducts.page.actions.addPosition') }}
            </button>
          </div>

          <!-- Anhang -->
          <div class="form-group">
            <label>
              {{ $t('serviceNotListedProducts.page.fields.file') }}
            </label>
            <b-form-file
              ref="formFileInput"
              v-model="formFile"
              :lang="language"
              :placeholder="$t('serviceNotListedProducts.page.fields.filePlaceholder')" />
          </div>

          <div class="d-flex justify-content-end">
            <button
              :disabled="!formFile"
              type="button"
              class="btn btn-secondary"
              @click.prevent="clearFileInput">
              {{ $t('general.attachmentDelete') }}
            </button>
          </div>


          <app-form-required-hint class="mb-2" />

          <!-- Buttons -->
          <div class="d-md-flex justify-content-end">
            <!-- Buttons Mobile -->
            <div class="d-md-none">
              <button
                :disabled="isProcessing"
                type="submit"
                class="btn btn-block btn-primary">
                <app-icon-state
                  :is-loading="isProcessing"
                  icon="fas fa-paper-plane" />
                {{ $t('serviceNotListedProducts.page.actions.send') }}
              </button>
            </div>

            <!-- Buttons Desktop -->
            <div class="d-none d-md-block">
              <button
                :disabled="isProcessing"
                type="submit"
                class="btn btn-primary">
                <app-icon-state
                  :is-loading="isProcessing"
                  icon="fas fa-paper-plane" />
                {{ $t('serviceNotListedProducts.page.actions.send') }}
              </button>
            </div>
          </div>
        </form>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { NotListedProductsFieldErrors, sendMailUnlistedArticles } from '@scripts/modules/service'
import { showErrorMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'
import I18n from '@scripts/modules/i18n'

export default {

  model: {
    prop: 'checked',
    avent: 'change',
  },

  data () {
    return {
      articles: [{
        amount: 1,
        matnr: '',
        supplier: '',
        supplierName: '',
      }],
      formFile: void 0,
      formOrderNumber: '',
      formText: '',
      isProcessing: false,
      errorMessage: '',
      isSent: false,
      formErrors: {},

      NotListedProductsFieldErrors,
      language: I18n.language,
    }
  },

  created () {
    this.setPageTitle(this.$t('serviceNotListedProducts.page.title'))
  },

  methods: {
    clearFileInput () {
      this.$refs.formFileInput.reset()
    },
    addArticle () {
      this.articles.push({
        amount: 1,
        matnr: '',
        supplier: '',
        supplierName: '',
      })
    },

    async send () {
      if (this.isProcessing) {
        return
      }

      this.isProcessing = true
      this.formErrors = ''
      try {
        await sendMailUnlistedArticles(
          this.formOrderNumber,
          this.formText,
          this.articles,
          this.formFile,
        )
        this.isSent = true
      } catch (e) {
        if (e.code === ErrorCode.NO_DATA) {
          showErrorMessage(this.$t('serviceNotListedProducts.page.actions.sendErrorNoData'))
        } else if (e.code === ErrorCode.INVALID_FIELDS) {
          this.errorMessage = this.$t('general.invalidFieldsMessage')
          this.formErrors = e.fieldErrors
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }

      this.isProcessing = false
    },
    removePosition (index) {
      this.articles.splice(index, 1)
    },
  },
}
</script>
