<template>
  <div>
    <app-loading-box v-if="isLoading" />
    <div v-else>
      <!-- Auswahl Ordermatrix -->
      <select
        v-model="selectedOrdermatrixId"
        class="custom-select mb-2">
        <!-- Bitte Ordermatrix auswählen -->
        <option
          v-if="!isDirty"
          :value="void 0">
          {{ $t('ordermatrix.detail.ordermatrixDummyEntry') }}
        </option>

        <!-- Ordermatrizen ohne Kategorie -->
        <option
          v-for="ordermatrix in ordermatricesWithoutCategory"
          :key="ordermatrix.id"
          :value="ordermatrix.id">
          {{ ordermatrix.name | maxlength(50) }}
        </option>

        <!-- Ordermatrizen mit Kategorie gruppiert nach Kategorie -->
        <optgroup
          v-for="category in categories"
          :key="category.name"
          :label="`${category.name} (${category.ordermatrices.length})`">
          <option
            v-for="ordermatrix in category.ordermatrices"
            :key="ordermatrix.id"
            :value="ordermatrix.id">
            {{ ordermatrix.name | maxlength(50) }}
          </option>
        </optgroup>
      </select>
    </div>
  </div>
</template>

<script>
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getList } from '@scripts/modules/ordermatrix'

export default {
  props: {
    value: {
      type: String,
      default: void 0,
    },
  },

  data () {
    return {
      isDirty: !!this.value,
      isLoading: true,
      ordermatrices: [],
      selectedOrdermatrixId: this.value,
    }
  },

  computed: {
    categories () {
      return this.ordermatrices
        .pluck('category')
        .unique()
        .filter((category) => category)
        .map((category) => ({
          name: category,
          ordermatrices: this.ordermatrices
            .filter((ordermatrix) => ordermatrix.category === category)
            .sort((a, b) => a.name.localeCompare(b.name)),
        }))
        .sort((a, b) => a.name.localeCompare(b.name))
    },
    ordermatricesWithoutCategory () {
      return this.ordermatrices
        .filter((ordermatrix) => !ordermatrix.category)
        .sort((a, b) => a.name.localeCompare(b.name))
    },
  },

  watch: {
    value () {
      this.selectedOrdermatrixId = this.value
    },
    selectedOrdermatrixId () {
      if (this.selectedOrdermatrixId) {
        this.$emit('input', this.selectedOrdermatrixId)
      }
      // Sobald eine Bestellmatrix ausgewählt wurde, wird die Option "Bestellmatrix auswählen" entfernt
      this.isDirty = true
    },
  },

  created () {
    this.loadOrdermatrices()
  },

  methods: {
    async loadOrdermatrices () {
      try {
        this.ordermatrices = (await getList()).ordermatrices
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
