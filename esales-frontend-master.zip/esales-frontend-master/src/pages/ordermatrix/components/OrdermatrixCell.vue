<template>
  <td
    :class="{'ordermatrix-cell-selected': isSelected, 'ordermatrix-cell-has-error': hasError}"
    class="p-2 odermatrix-cell">
    <div
      v-if="column.matnr && column.matnr !== 'INITIAL'"
      class="d-flex align-items-start flex-column">
      <!-- Checkbox Artikelnummer -->
      <div class="d-flex justify-content-between align-items-baseline w-100">
        <div class="custom-control custom-checkbox mb-1">
          <input
            :id="`ordermatrix-cell-article-number-${colIndex}-${rowIndex}`"
            v-model="isSelected"
            :disabled="hasError"
            type="checkbox"
            class="custom-control-input">
          <label
            :for="`ordermatrix-cell-article-number-${colIndex}-${rowIndex}`"
            class="custom-control-label">
            <span class="text-muted">
              {{ $t('general.articleNumberShort') }}:
            </span>
            {{ column.matnrDisplay }}
          </label>
        </div>
        <a
          v-if="!hasError"
          :href="detailLink(column.matnr,column.maktx,column.maktx2)"
          :title="$t('article.articleDetails.articleDetails')"
          class="fas fa-external-link-alt icon-link" />
      </div>

      <template v-if="app.user.hasPermission('SHOW_AVAILABILITY') && !hasError">
        <!-- Verfügbarkeit -->
        <app-article-atom-availability
          :is-loading="isAdditionalDataLoading"
          :availability="additionalData && additionalData.availability"
          class="mb-1" />
      </template>

      <!-- Fehlermeldung -->
      <div
        v-if="hasError"
        class="text-danger font-size-xs mt-1"
        :title="errorMessage">
        <i class="fas fa-exclamation-triangle fa-fw" />
        {{ errorMessage }}
      </div>

      <!-- Mengenfeld -->
      <div class="mt-auto text-right">
        <app-form-input-quantity
          v-model="amount"
          :unit="column.article.unitFormatted"
          :stepsize="column.article.stepsize"
          :disabled="hasError"
          :btn-sm="true" />
      </div>
    </div>
  </td>
</template>

<script>
import { getSingleAdditionalArticleData } from '@scripts/modules/additional-article-data'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { detailLink } from '@scripts/helper/generateLink'

export default {
  props: {
    column: {
      required: true,
      type: Object,
    },
    rowIndex: {
      required: true,
      type: Number,
    },
    colIndex: {
      required: true,
      type: Number,
    },
  },

  data () {
    return {
      amount: this.column.amount,
      isSelected: this.column.checked,
      additionalData: void 0,
      errorMessage: '',
      hasError: false,
      isAdditionalDataLoading: true,
      detailLink,
    }
  },

  computed: {
    columnAmount () {
      return this.column.amount
    },
    columnChecked () {
      return this.column.checked
    },
  },

  watch: {
    columnAmount (val) {
      this.amount = val
    },
    columnChecked (val) {
      this.isSelected = val
    },
    amount () {
      this.isSelected = !!this.amount
      this.$emit('amountChange', this.amount)
    },
    isSelected () {
      if (this.isSelected && !this.amount) {
        this.amount = 1
      }
      this.$emit(this.isSelected ? 'select' : 'unselect')
    },
  },

  async created () {
    try {
      if (this.column.matnr !== 'INITIAL') {
        this.additionalData = await getSingleAdditionalArticleData(this.column.matnr)
        this.hasError = this.additionalData.hasError
        this.errorMessage = this.additionalData.error
      }
      this.isAdditionalDataLoading = false
    } catch (e) {
      console.error(e)
      showTechnicalErrorMessage()
    }
  },
}
</script>
