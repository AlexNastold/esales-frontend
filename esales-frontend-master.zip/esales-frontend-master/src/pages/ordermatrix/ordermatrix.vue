<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-ordermatrix">
      <div class="container">
        <h1 class="headline">
          {{ $t('ordermatrix.detail.headline') }}
        </h1>

        <!-- Bestellmatrix auswählen -->
        <ordermatrix-selection
          v-model="selectedOrdermatrixId"
          class="mb-3" />

        <!-- Bestellmatrix Ladeanzeige -->
        <app-loading-box v-if="isOrdermatrixLoading" />

        <!-- Bestellmatrix -->
        <div v-else-if="ordermatrix">
          <!-- Name, Oben Buttons -->
          <div class="row">
            <!-- Name -->
            <div class="col-12 col-md text-truncate-wrapper mb-3">
              <h3 class="mb-0 text-truncate">
                {{ ordermatrix.name }}
              </h3>
            </div>

            <!-- Oben Button in den Warenkorb -->
            <div class="col-12 col-md-auto d-md-flex justify-content-md-end mb-3">
              <!-- Button Mobile -->
              <div class="d-md-none">
                <app-action-button-basket-multiple
                  :articles="articlesToThrow"
                  :disabled="!articlesToThrow.length"
                  button-class="btn-primary btn-block"
                  pitcher="ordermatrix"
                  @success="resetArticles" />
              </div>

              <!-- Button Desktop -->
              <div class="d-none d-md-block">
                <app-action-button-basket-multiple
                  :articles="articlesToThrow"
                  :disabled="!articlesToThrow.length"
                  pitcher="ordermatrix"
                  @success="resetArticles" />
              </div>
            </div>
          </div>

          <!-- Tabelle Bestellmatrix -->
          <div
            :key="ordermatrix.id"
            class="mb-3">
            <div class="wrapper-table-ordermatrix">
              <vue-scrolling-table
                :scroll-horizontal="true"
                :scroll-vertical="true"
                dead-area-color="#eee">
                <!-- Bestellmatrix Header -->
                <template
                  slot="thead"
                  class="thead-light">
                  <tr>
                    <th class="p-2">
                      <div class="d-flex">
                        <!-- Header-Bild -->
                        <div v-if="ordermatrix.header.picture">
                          <div class="article-image-wrapper d-flex align-items-center justify-content-center mr-3">
                            <img
                              :src="ordermatrix.header.picture | externalImage"
                              :alt="ordermatrix.header.text">
                          </div>
                        </div>

                        <!-- Header-Text -->
                        <div class="font-size-lg d-flex align-items-center">
                          {{ ordermatrix.header.text }}
                        </div>
                      </div>
                    </th>
                    <th
                      v-for="(column, index) in ordermatrix.header.columns"
                      :key="index"
                      class="p-2 font-size-lg align-middle">
                      {{ column }}
                    </th>
                  </tr>
                </template>

                <!-- Bestellmatrix Zeilen -->
                <template slot="tbody">
                  <!-- Bestellmatrix Zeilenbeschreibung -->
                  <tr
                    v-for="(row, rowIndex) in ordermatrix.rows"
                    :key="rowIndex">
                    <th class="p-2">
                      <!-- Zeilenbild, Zeilentext -->
                      <div class="d-flex">
                        <!-- Zeilenbild -->
                        <div v-if="row.picture">
                          <div class="article-image-wrapper d-flex align-items-center justify-content-center mr-3">
                            <img
                              :src="row.picture | externalImage"
                              :alt="row.text">
                          </div>
                        </div>

                        <!-- Zeilentext -->
                        <div class="font-size-lg">
                          {{ row.text }}
                        </div>
                      </div>
                    </th>

                    <!-- Bestellmatrix Zellen -->
                    <ordermatrix-cell
                      v-for="(column, colIndex) in row.columns"
                      :key="colIndex"
                      :column="column"
                      :row-index="rowIndex"
                      :col-index="colIndex"
                      :matrix-index="parseInt(ordermatrix.id)"
                      @select="column.checked = true"
                      @unselect="column.checked = false"
                      @amountChange="column.amount = arguments[0]" />
                  </tr>
                </template>
              </vue-scrolling-table>
            </div>
          </div>

          <!-- Unten Button in den Warenkorb -->
          <div class="d-md-flex justify-content-md-end">
            <!-- Button Mobile -->
            <div class="d-md-none">
              <app-action-button-basket-multiple
                :articles="articlesToThrow"
                :disabled="!articlesToThrow.length"
                pitcher="ordermatrix"
                button-class="btn-primary btn-block"
                @success="resetArticles" />
            </div>

            <!-- Button Desktop -->
            <div class="d-none d-md-block">
              <app-action-button-basket-multiple
                :articles="articlesToThrow"
                :disabled="!articlesToThrow.length"
                pitcher="ordermatrix"
                @success="resetArticles" />
            </div>
          </div>
        </div>

        <!-- Keine Ordermatrix ausgewählt -->
        <div
          v-else
          class="border rounded p-3">
          <app-box-empty-list
            :headline="$t('ordermatrix.detail.noOrdermatrixSelectedHeadline')"
            icon="fas fa-table">
            <span v-html="$t('ordermatrix.detail.noOrdermatrixSelectedText')" />
          </app-box-empty-list>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { getQueryParameter } from '@scripts/helper/urlParams'
import { updateUrlQueryString } from '@scripts/helper/urlUpdate'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getOrdermatrix } from '@scripts/modules/ordermatrix'

import vueScrollingTable from 'vue-scrolling-table'

import OrdermatrixCell from './components/OrdermatrixCell.vue'
import OrdermatrixSelection from './components/OrdermatrixSelection.vue'

export default {
  components: {
    'ordermatrix-cell': OrdermatrixCell,
    'ordermatrix-selection': OrdermatrixSelection,
    'vue-scrolling-table': vueScrollingTable,
  },

  data () {
    return {
      isOrdermatrixLoading: false,
      ordermatrix: void 0,
      selectedArticles: [],
      selectedOrdermatrixId: void 0,
    }
  },

  computed: {
    articlesToThrow () {
      if (this.ordermatrix) {
        return this.ordermatrix.rows.reduce((acc, row) => {
          row.columns
            .filter((column) => column.checked && column.amount)
            .forEach((column) => acc.push({
              amount: column.amount,
              matnr: column.matnr,
            }))
          return acc
        }, [])
      }
      return []
    },
  },

  watch: {
    selectedOrdermatrixId (ordermatrixId) {
      this.loadOrdermatrix(ordermatrixId)
      updateUrlQueryString({
        id: ordermatrixId,
      })
    },
  },

  created () {
    this.setPageTitle(this.$t('ordermatrix.detail.title'))

    const idFromUrl = getQueryParameter('id')
    if (idFromUrl) {
      this.selectedOrdermatrixId = idFromUrl
    }
  },

  methods: {
    async loadOrdermatrix (id) {
      this.isOrdermatrixLoading = true

      try {
        const ordermatrix = await getOrdermatrix(id)

        // checked und amount hinzufügen, damit die Felder reactive sind
        ordermatrix.rows.forEach((row) => {
          row.columns.forEach((column) => {
            column.checked = false
            column.amount = 0
          })
        })

        this.ordermatrix = ordermatrix

        this.setPageTitle(this.$t('ordermatrix.detail.titleWithName', {
          name: this.ordermatrix.name,
        }))

        this.isOrdermatrixLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
    resetArticles () {
      this.ordermatrix.rows.forEach((row) => {
        row.columns.forEach((column) => {
          column.checked = false
          column.amount = 0
        })
      })
    },
  },
}
</script>
<style lang="scss" src="./ordermatrix.scss"></style>
