<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-ordering-process-payment-ok">
      <div class="container">
        <app-loading-box v-if="isLoading" />
        <div
          v-else
          class="alert alert-danger mb-3">
          <i class="fas fa-exclamation-triangle fa-fw" />
          {{ $t('general.unspecifiedErrorMessage') }}
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { redirect } from '@scripts/helper/redirect'
import { order } from '@scripts/modules/basket'
import { createFlashMessage } from '@scripts/helper/flash-messages'

export default {
  data () {
    return {
      isLoading: true,
    }
  },

  async created () {
    this.setPageTitle(this.$t('payment.successpage.title'))
    try {
      await order()
      redirect('ordering-process-ordered')
    } catch (e) {
      this.isLoading = false
      createFlashMessage(
        e.message || this.$t('general.unspecifiedErrorMessage'),
        'error',
      )
      redirect('checkout')
    }
  },
}
</script>
