/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/ordering-process-payment-ok/ordering-process-payment-ok.vue'
setup(PageComponent)
