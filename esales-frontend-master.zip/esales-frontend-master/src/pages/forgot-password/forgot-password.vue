<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-forgot-password">
      <div class="container">
        <h1 class="headline">
          {{ $t('forgotPassword.headline') }}
        </h1>
        <div
          v-show="errorMessage"
          class="alert alert-danger"
          role="alert"
          v-html="errorMessage" />
        <div
          v-if="!isPasswordResetSuccessful"
          class="row">
          <div class="col-12 col-lg-6">
            <div
              v-if="infoMessage"
              class="d-block d-lg-none alert alert-info alert-icon"
              role="alert"
              v-html="infoMessage" />
            <div class="card">
              <div class="card-header">
                {{ $t('forgotPassword.userdata') }}
              </div>
              <div class="card-body">
                <form
                  novalidate
                  @submit.prevent="onSubmit">
                  <div class="form-group">
                    <label for="username-alias">
                      {{ $t('forgotPassword.username') }}
                      <span class="required" />
                    </label>
                    <input
                      id="username-alias"
                      v-model="userid"
                      :class="{'is-invalid': formErrors[ResetPasswordFieldErrors.USERNAME_ALIAS]}"
                      :placeholder="$t('forgotPassword.usernamePlaceholder')"
                      type="text"
                      class="form-control">
                    <div
                      v-if="formErrors[ResetPasswordFieldErrors.USERNAME_ALIAS]"
                      class="invalid-feedback"
                      v-html="formErrors[ResetPasswordFieldErrors.USERNAME_ALIAS]" />
                  </div>
                  <div class="form-group">
                    <label for="customer-number">
                      {{ $t('forgotPassword.costumerId') }}
                      <span class="required" />
                    </label>
                    <input
                      id="customer-number"
                      v-model="kunnr"
                      :class="{'is-invalid': formErrors[ResetPasswordFieldErrors.CUSTOMER_NUMBER]}"
                      :placeholder="$t('forgotPassword.costumerIdPlaceholder')"
                      type="text"
                      class="form-control">
                    <div
                      v-if="formErrors[ResetPasswordFieldErrors.CUSTOMER_NUMBER]"
                      class="invalid-feedback"
                      v-html="formErrors[ResetPasswordFieldErrors.CUSTOMER_NUMBER]" />
                  </div>
                  <div class="form-group">
                    <label for="email">
                      {{ $t('forgotPassword.mailaddress') }}
                      <span class="required" />
                    </label>
                    <input
                      id="email"
                      v-model="emailAddress"
                      :class="{'is-invalid': formErrors[ResetPasswordFieldErrors.EMAIL]}"
                      :placeholder="$t('forgotPassword.mailaddressPlaceholder')"
                      type="email"
                      class="form-control">
                    <div
                      v-if="formErrors[ResetPasswordFieldErrors.EMAIL]"
                      class="invalid-feedback"
                      v-html="formErrors[ResetPasswordFieldErrors.EMAIL]" />
                  </div>
                  <vue-recaptcha
                    v-if="shouldDisplayCaptcha"
                    ref="recaptcha"
                    :sitekey="captchaKey"
                    class="mb-3"
                    @verify="onCaptchaVerify" />
                  <div class="d-block d-lg-none">
                    <button
                      :disabled="isPasswordResetInProcess"
                      type="submit"
                      class="btn btn-block btn-primary">
                      <app-icon-state
                        :is-loading="isPasswordResetInProcess"
                        icon="fas fa-lock" />
                      {{ $t('forgotPassword.resetPassword') }}
                    </button>
                    <a
                      :disabled="isPasswordResetInProcess"
                      href="login"
                      class="btn btn-block btn-link">
                      {{ $t('forgotPassword.returnToLogin') }}
                    </a>
                  </div>
                  <div class="d-none d-lg-block text-right">
                    <a
                      :disabled="isPasswordResetInProcess"
                      href="login"
                      class="btn btn-link">
                      {{ $t('forgotPassword.returnToLogin') }}
                    </a>
                    <button
                      :disabled="isPasswordResetInProcess"
                      type="submit"
                      class="btn btn-primary">
                      <app-icon-state
                        :is-loading="isPasswordResetInProcess"
                        icon="fas fa-lock" />
                      {{ $t('forgotPassword.resetPassword') }}
                    </button>
                  </div>
                </form>
              </div>
            </div>

            <app-form-required-hint />
          </div>
          <div class="d-none d-lg-block col-12 col-lg-6">
            <div
              v-if="infoMessage"
              class="alert alert-info alert-icon"
              role="alert"
              v-html="infoMessage" />
          </div>
        </div>

        <app-box-success v-if="isPasswordResetSuccessful">
          <h3>{{ $t('forgotPassword.mailSentHint') }}</h3>
          {{ $t('forgotPassword.mailSentHintDescription') }}.<br>

          <a
            href="login"
            class="btn btn-secondary mt-3">
            {{ $t('forgotPassword.returnToLogin') }}
          </a>
        </app-box-success>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { pageSettingsForgotPassword } from '@scripts/app/settings'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'
import { ResetPasswordFieldErrors, resetPassword } from '@scripts/modules/reset-password'
import { getHtmlContent, PageId } from '@scripts/modules/html-content'

import VueRecaptcha from 'vue-recaptcha'

export default {
  components: {
    'vue-recaptcha': VueRecaptcha,
  },

  data () {
    return {
      captchaKey: pageSettingsForgotPassword.captchaKey,
      shouldDisplayCaptcha: pageSettingsForgotPassword.captchaActive,

      errorMessage: '',
      infoMessage: '',
      isPasswordResetInProcess: false,
      isPasswordResetSuccessful: false,

      formErrors: {},

      emailAddress: '',
      kunnr: '',
      userid: '',
      formCaptchaResponse: '',
      ResetPasswordFieldErrors,
    }
  },

  async created () {
    this.setPageTitle(this.$t('forgotPassword.headline'))
    this.infoMessage = (await getHtmlContent(PageId.FORGOT_PASSWORD)).html
  },

  methods: {
    /**
     * Form submit handler
     */
    onSubmit () {
      this.tryPasswordReset()
    },

    /**
     * Store the RECAPTCHA response
     *
     * @param {string} response - The RECAPTCHA response
     */
    onCaptchaVerify (response) {
      this.formCaptchaResponse = response
    },

    resetCaptcha () {
      this.formCaptchaResponse = ''
      this.$refs.recaptcha.reset()
    },

    /**
     * Try to reset passwort
     */
    async tryPasswordReset () {
      this.isPasswordResetInProcess = true
      this.errorMessage = ''
      this.formErrors = {}
      try {
        await resetPassword(this.userid, this.kunnr, this.emailAddress, this.formCaptchaResponse)
        this.isPasswordResetSuccessful = true
      } catch (e) {
        if (e.code === ErrorCode.SHOP_LOCKED) {
          this.errorMessage = this.$t('forgotPassword.shopLocked')
        } else if (e.code === ErrorCode.CAPTCHA_INVALID) {
          this.errorMessage = this.$t('forgotPassword.invalidCaptcha')
        } else if (e.code === ErrorCode.INVALID_FIELDS) {
          this.errorMessage = this.$t('general.invalidFieldsMessage')
          this.formErrors = e.fieldErrors
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
        if (this.$refs.recaptcha) {
          this.resetCaptcha()
        }
      }

      this.isPasswordResetInProcess = false
    },
  },
}
</script>
