<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main>
      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="service">
              {{ $t('service.dashboard.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('serviceFaq.page.breadcrumb') }}
          </li>
        </ol>

        <!-- Überschrift -->
        <h1 class="headline">
          {{ $t('serviceFaq.page.headline') }}
        </h1>

        <p
          class="mb-3"
          v-html="$t('serviceFaq.page.description', { contactLink: descriptionContactLink, joinArrays: ' ' })" />

        <!-- Fragen durchsuchen -->
        <div class="rounded bg-light p-3 mb-3">
          <h2 class="text-center mb-3">
            {{ $t('serviceFaq.page.filter.headline') }}
          </h2>

          <!-- Eingabefelder Mobile -->
          <div class="d-md-none">
            <select
              v-model="activeCategoryId"
              class="custom-select form-control mb-1">
              <option :value="void 0">
                {{ $t('serviceFaq.page.filter.allCategories') }}
              </option>
              <option
                v-for="faqCategory in faqCategories"
                :key="faqCategory.id"
                :value="faqCategory.id">
                {{ faqCategory.name }}
              </option>
            </select>
            <input
              v-model="query"
              :placeholder="$t('serviceFaq.page.filter.queryPlaceholder')"
              type="text"
              class="form-control form-control">
          </div>

          <!-- Eingabefelder Desktop -->
          <div class="input-group d-none d-md-flex">
            <select
              v-model="activeCategoryId"
              class="custom-select form-control w-25">
              <option :value="void 0">
                {{ $t('serviceFaq.page.filter.allCategories') }}
              </option>
              <option
                v-for="faqCategory in faqCategories"
                :key="faqCategory.id"
                :value="faqCategory.id">
                {{ faqCategory.name }}
              </option>
            </select>
            <input
              v-model="query"
              :placeholder="$t('serviceFaq.page.filter.queryPlaceholder')"
              type="text"
              class="form-control form-control w-75">
          </div>
        </div>

        <!-- Keine FAQs gefunden -->
        <app-box-empty-list
          v-if="!faqCategoriesToShow.length"
          :headline="$t('serviceFaq.page.listEmpty')"
          icon="fas fa-question">
          <span
            v-if="activeCategoryId"
            v-html="$t('serviceFaq.page.listEmptyDescriptionWithCategory')" />
          <span
            v-else
            v-html="$t('serviceFaq.page.listEmptyDescription')" />
        </app-box-empty-list>

        <!-- Kategorien / FAQs -->
        <div
          v-else
          id="faq-categories">
          <!-- Kategorien -->
          <div
            v-for="(faqCategory, categoryIndex) of faqCategoriesToShow"
            :key="categoryIndex"
            class="mb-4">
            <h2 class="mb-3">
              {{ faqCategory.name }}
            </h2>

            <!-- FAQs -->
            <div
              v-for="(faq, faqIndex) of faqCategory.faqs"
              :key="faqIndex"
              class="card mb-1">
              <!-- Frage -->
              <div
                :id="`heading-frage-${categoryIndex}-${faqIndex}`"
                :data-target="`#collapse-frage-${categoryIndex}-${faqIndex}`"
                class="card-header cursor-pointer px-3 py-2"
                data-toggle="collapse">
                {{ faq.question }}
              </div>

              <!-- Antwort -->
              <div
                :id="`collapse-frage-${categoryIndex}-${faqIndex}`"
                :class="{'show': query}"
                class="collapse"
                data-parent="#faq-categories">
                <div
                  class="card-body"
                  v-html="faq.answer" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import Fuse from 'fuse.js/dist/fuse'

import { getFAQs } from '@scripts/modules/faq'
import { rewriteUrlsInText } from '@scripts/helper/rewriteUrlsInText'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  data () {
    return {
      activeCategoryId: void 0,
      faqCategories: [],
      query: '',

      fuseOptions: {
        distance: 1000,
        keys: ['question', 'answer'],
        location: 0,
        maxPatternLength: 50,
        minMatchCharLength: 1,
        shouldSort: false,
        threshold: 0.3,
      },
    }
  },

  computed: {
    faqCategoriesToShow () {
      let faqCategoriesToDisplay = []

      if (this.activeCategoryId) {
        faqCategoriesToDisplay = this.faqCategories.filter((faqCategory) => faqCategory.id === this.activeCategoryId)
      } else {
        faqCategoriesToDisplay = this.faqCategories
      }

      if (!this.query) {
        return faqCategoriesToDisplay
      }

      const searchEngineResults = this.faqSearchEngine.search(this.query).map((result) => result.item.id)

      // Kopie des Array machen und die FAQs filtern
      faqCategoriesToDisplay = faqCategoriesToDisplay
        .map((category) => ({
          ...category,
          faqs: category.faqs.filter((faq) => searchEngineResults.includes(faq.id)),
        }))
        .filter((category) => category.faqs.length)

      return faqCategoriesToDisplay
    },

    descriptionContactLink () {
      const label = this.$t('serviceFaq.page.descriptionContactLinkLabel')
      return `<a href="service-contact">${label}</a>`
    },
  },

  created () {
    this.setPageTitle(this.$t('serviceFaq.page.title'))
    this.loadFaqs()
  },

  methods: {
    async loadFaqs () {
      try {
        this.faqCategories = (await getFAQs()).map((category) => ({
          ...category,
          faqs: category.faqs.map((faq) => ({
            ...faq,
            answer: faq.answer = rewriteUrlsInText(faq.answer),
          })),
        }))

        const faqsToSearch = this.faqCategories.reduce((faqs, category) => {
          faqs.push(...category.faqs)
          return faqs
        }, [])

        this.faqSearchEngine = new Fuse(faqsToSearch, this.fuseOptions)
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
