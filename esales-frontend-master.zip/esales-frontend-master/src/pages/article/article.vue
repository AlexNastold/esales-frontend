<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-article">
      <!-- Ladgeanzeige -->
      <app-loading-box v-if="isLoading" />

      <!-- Artikel nicht gefunden -->
      <app-box-oops
        v-else-if="!article"
        link-title="Zur Startseite"
        link-href="index">
        {{ $t('article.articleNotFound') }}
      </app-box-oops>

      <!-- Artikel hat Fehlermeldungen -->
      <app-box-error v-else-if="article.errors">
        <h3>{{ $t('general.unspecifiedErrorMessage') }}</h3>
        <div
          v-for="(error, index) in article.errors"
          :key="index"
          v-text="error" />
      </app-box-error>

      <!-- Artikel anzeigen -->
      <div v-else>
        <div class="container">
          <!-- Breadcrumb -->
          <ol
            v-if="app.user.hasPermission('CATALOGUE') && article.cataloguePath.length"
            class="breadcrumb">
            <li
              v-for="(category, index) in article.cataloguePath"
              :key="index"
              class="breadcrumb-item">
              <a :href="`catalogue?fq=${encodeURIComponent(category.filterQuery)}`">
                {{ category.label }}
              </a>
            </li>
          </ol>

          <!-- Artikel zuletzt gekauft am -->
          <div
            v-if="article.lastPurchase"
            class="border rounded bg-light text-center p-2 mb-3">
            <i class="fas fa-box-open" />
            {{ $t('article.lastPurchase', { date: $options.filters.date(article.lastPurchase.date) }) }}
            <a :href="`my-account-documents-detail?doctype=${DocumentType.AUFTRAG}&docid=${encodeURIComponent(article.lastPurchase.documentId)}`">
              <span class="text">
                {{ $t('article.showDocumentLink', { docType: $options.filters.documentTypeTitle(DocumentType.AUFTRAG) }) }}
              </span>
            </a>
          </div>

          <div class="d-block d-lg-none mb-3">
            <!-- Artikelname Mobile -->
            <h1 class="text-break h3">
              {{ article.maktx }} {{ article.maktx2 }}
            </h1>

            <!-- Artikelnummer Desktop -->
            <div class="small text-muted d-lg-none mb-2">
              {{ $t('general.articleNumberShort') }}
              {{ article.matnrDisplay }}
            </div>

            <!-- Referenz-Beleg -->
            <div
              v-if="article.documentInformations"
              class="d-lg-none">
              {{ $t('article.articleDetails.outOf') }}
              <a
                :href="`my-account-documents-detail?doctype=${encodeURIComponent(article.documentInformations.documentType)}&docid=${encodeURIComponent(article.documentInformations.documentId)}`"
                class="icon-link">
                <i class="fas fa-file fa-fw" />
                <span class="text">
                  {{ article.documentInformations.documentType | documentTypeTitle }}
                  {{ article.documentInformations.documentIdDisplay }}
                </span>
              </a>
              {{ $t('article.positionNumber') }} {{ article.documentInformations.documentPosnrDisplay }}
            </div>
          </div>

          <!-- Artikelbilder, Artikeldetail, Artikel Sidebar -->
          <div class="row mb-4">
            <div class="col-12 col-lg-3 col-xl-4">
              <article-images
                :images="article.images"
                :alt="`${article.maktx} ${article.maktx2}`" />
            </div>
            <div class="col-12 col-lg-5">
              <article-details
                :article="article"
                :technical-informations="technicalInformations" />
            </div>
            <div class="col-12 col-lg-4 col-xl-3">
              <article-sidebar :article="article" />
            </div>
          </div>

          <!-- Zusätzliche Informationen -->
          <description
            v-if="article.description"
            :text="article.description"
            class="mb-5" />

          <technical-details
            v-if="technicalInformations.length"
            :technical-informations="technicalInformations"
            class="mb-5" />

          <factory-availability
            v-if="app.user.hasPermission('SHOW_AVAILABILITY') && app.user.isLoggedIn && app.state.oltpAvailable"
            :article="article"
            class="mb-5" />

          <scaled-prices
            v-if="article.retailScalePrices.length > 1"
            id="scaled-prices"
            :retail="article.retailScalePrices"
            :net="article.netScalePrices"
            class="mb-5" />

          <documents
            v-if="article.documents.length"
            :documents="article.documents"
            class="mb-5" />

          <conversion-factors
            v-if="article.conversionFactors.length"
            :conversion-factors="article.conversionFactors"
            class="mb-5" />

          <article-lists
            v-if="article.additionalMaterials.length"
            :additional-materials="article.additionalMaterials"
            class="mb-5"
            open-tab="Z" />

          <template v-if="article.oxomi">
            <oxomi-masterdata
              :masterdata="article.oxomi.masterdata"
              class="mb-5" />

            <oxomi-videos
              :videos="article.oxomi.videos"
              class="mb-5" />

            <oxomi-catalogue-pages
              :catalogue-pages="article.oxomi.cataloguePages"
              class="mb-5" />
          </template>
        </div>

        <div
          v-if="article.suggestedMaterials.length"
          class="bg-light p-3 mb-5">
          <div class="container">
            <customers-also-bought :articles="article.suggestedMaterials" />
          </div>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { getQueryParameter } from '@scripts/helper/urlParams'
import { getArticleDetails } from '@scripts/modules/article-details'
import { ErrorCode } from '@scripts/modules/errors'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { DocumentType } from '@scripts/modules/documents'
import { setOxomiConfiguration, addOxomiDataToArticle, OxomiType } from '@scripts/modules/oxomi'

import ArticleDetails from './components/article-details.vue'
import ArticleImages from './components/article-images.vue'
import ArticleSidebar from './components/article-sidebar.vue'

import AdditionalInformationArticleLists from './components/additional-information/article-lists.vue'
import AdditionalInformationConversionFactors from './components/additional-information/conversion-factors.vue'
import AdditionalInformationCustomersAlsoBought from './components/additional-information/customers-also-bought.vue'
import AdditionalInformationDescription from './components/additional-information/description.vue'
import AdditionalInformationDocuments from './components/additional-information/documents.vue'
import AdditionalInformationFactoryAvailability from './components/additional-information/factory-availability.vue'
import AdditionalInformationScaledPrices from './components/additional-information/scaled-prices.vue'
import AdditionalInformationTechnicalDetails from './components/additional-information/technical-details.vue'
import AdditionalInformationOxomiMasterdata from './components/additional-information/oxomi-masterdata.vue'
import AdditionalInformationOxomiVideos from './components/additional-information/oxomi-videos.vue'
import AdditionalInformationOxomiCataloguePages from './components/additional-information/oxomi-catalogue-pages.vue'

import { applicationSettings } from '@scripts/app/settings'
import { gtagTrackViewItem } from '@scripts/modules/gtag'

export default {
  components: {
    'article-details': ArticleDetails,
    'article-images': ArticleImages,
    'article-lists': AdditionalInformationArticleLists,
    'article-sidebar': ArticleSidebar,
    'conversion-factors': AdditionalInformationConversionFactors,
    'customers-also-bought': AdditionalInformationCustomersAlsoBought,
    description: AdditionalInformationDescription,
    documents: AdditionalInformationDocuments,
    'factory-availability': AdditionalInformationFactoryAvailability,
    'scaled-prices': AdditionalInformationScaledPrices,
    'technical-details': AdditionalInformationTechnicalDetails,
    'oxomi-masterdata': AdditionalInformationOxomiMasterdata,
    'oxomi-videos': AdditionalInformationOxomiVideos,
    'oxomi-catalogue-pages': AdditionalInformationOxomiCataloguePages,
  },

  data () {
    return {
      DocumentType,

      amount: parseInt(getQueryParameter('amount'), 10) ? parseInt(getQueryParameter('amount'), 10) : 1,
      documentId: getQueryParameter('docid'),
      documentPosnr: getQueryParameter('docposnr'),
      documentType: parseInt(getQueryParameter('doctype'), 10) ? parseInt(getQueryParameter('doctype'), 10) : void 0,
      matnr: getQueryParameter('matnr') !== void 0 ? getQueryParameter('matnr') : this.getMatnrFromURL(),

      article: void 0,
      isLoading: true,
    }
  },

  computed: {
    technicalInformations () {
      const technicalInformations = []
      if (this.article) {
        if (this.article.weightGross) {
          technicalInformations.push({
            label: this.$t('article.components.additionalInformation.technicalDetails.grossWeight'),
            value: `${this.article.weightGross} ${this.article.weightUnit}`,
          })
        }
        if (this.article.weightNet) {
          technicalInformations.push({
            label: this.$t('article.components.additionalInformation.technicalDetails.netWeight'),
            value: `${this.article.weightNet} ${this.article.weightUnit}`,
          })
        }
      }
      return technicalInformations
    },
  },

  created () {
    this.setPageTitle('Artikel')
    this.loadArticle()
  },

  methods: {
    getMatnrFromURL () {
      let matnr
      try {
        matnr = location.href.match(/^([^?#]+)/)[1].match(/^(.+)-(.+)/)[2]
      } catch (e) {
        matnr = ''
      }
      return matnr
    },
    async loadArticle () {
      // Keine Materialnummer übergeben -> "Artikel nicht gefunden" anzeigen
      if (!this.matnr) {
        this.setPageTitle(this.$t('article.articleNotFoundTitle'))
        this.isLoading = false
        return
      }

      // Versuchen Artikel zu laden
      try {
        this.article = await getArticleDetails(
          this.matnr,
          this.amount,
          this.documentType,
          this.documentId,
          this.documentPosnr,
        )

        this.setPageTitle(`${this.article.maktx} ${this.article.maktx2}`.trim())
        let description = ''
        if (this.article.description !== '') {
          description = this.article.description.trim().substring(0, 120)
        } else {
          description = `${this.article.maktx} ${this.article.maktx2}`.trim()
        }
        $('meta[name=description]').attr('content', description)
        this.isLoading = false
        if (applicationSettings.gtagActive) {
          let categories = []
          this.article.cataloguePath.forEach((category) => {
            categories.push(category.label)
          })
          gtagTrackViewItem({
            partno: this.article.bismt,
            quantity: this.amount,
            texts: `${this.article.maktx} ${this.article.maktx2}`.trim(),
            category: categories.join('/'),
          })
        }
        // Optional Oxomi-Daten holen
        if (this.app.settings.oxomi.active && this.app.settings.oxomi.options.detail) {
          const oxomiSettings = this.app.settings.oxomi
          oxomiSettings.render = oxomiSettings.render || [OxomiType.MASTERDATA]
          setOxomiConfiguration(oxomiSettings)
          addOxomiDataToArticle(this.article)

          // Reactive machen
          this.$set(this.article, 'oxomi', this.article.oxomi)
        }
      } catch (e) {
        if (e.code === ErrorCode.NOT_FOUND) {
          // Ist okay, nur nicht "this.article" setzen
          this.setPageTitle(this.$t('article.articleNotFoundTitle'))
          this.isLoading = false
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },
  },
}
</script>

<style lang="scss" src="./article.scss"></style>
