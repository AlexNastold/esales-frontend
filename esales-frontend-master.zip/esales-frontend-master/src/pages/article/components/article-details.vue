<template>
  <div class="article-details">
    <!-- Artikelname Desktop -->
    <h3 class="d-none d-lg-block text-break">
      {{ article.maktx }} {{ article.maktx2 }}
    </h3>

    <!-- Artikelnummer Desktop -->
    <div class="small text-muted d-none d-lg-block mb-2">
      {{ $t('general.articleNumberShort') }}
      {{ article.matnrDisplay }}
    </div>

    <!-- Referenz-Beleg -->
    <div
      v-if="article.documentInformations"
      class="d-none d-lg-block mb-2">
      {{ $t('article.articleDetails.outOf') }}
      <a
        :href="`my-account-documents-detail?doctype=${encodeURIComponent(article.documentInformations.documentType)}&docid=${encodeURIComponent(article.documentInformations.documentId)}`"
        class="icon-link">
        <i class="fas fa-file fa-fw" />
        <span class="text">
          {{ article.documentInformations.documentType | documentTypeTitle }}
          {{ article.documentInformations.documentIdDisplay }}
        </span>
      </a>
      {{ $t('article.positionNumber') }} {{ article.documentInformations.documentPosnrDisplay }}
    </div>

    <!-- Herstellerlogo -->
    <div
      v-if="article.supplierLogo"
      class="supplier-logo-wrapper mb-3">
      <img
        :src="article.supplierLogo | externalImage"
        :alt="$t('article.articleDetails.supplierLogo')">
    </div>

    <div class="mb-3">
      <!-- Verfügbarkeit -->
      <div class="mb-1">
        <!-- Verfügbarkeit (bei Fehler ausblenden) -->
        <app-article-atom-availability
          v-if="app.user.hasPermission('SHOW_AVAILABILITY')"
          :availability="article.availability" />
      </div>

      <!-- Links -->
      <div class="mt-3 font-weight-bold">
        {{ $t('article.articleDetails.jumpDirectTo') }}
      </div>
      <div class="container">
        <div class="row row-cols-1 row-cols-sm-2">
          <div
            v-if="article.description"
            class="col mt-2">
            <a
              href="#article-description"
              class="icon-link text-nowrap">
              <i class="fas fa-file-alt" />
              {{ $t('article.components.additionalInformation.description.description') }}
            </a>
          </div>
          <div
            v-if="technicalInformations.length"
            class="col mt-2">
            <a
              href="#technical-details"
              class="icon-link text-nowrap">
              <i class="fas fa-cog" />
              {{ $t('article.components.additionalInformation.technicalDetails.technicalInformation') }}
            </a>
          </div>
          <div
            v-if="app.user.hasPermission('SHOW_AVAILABILITY') && app.user.isLoggedIn"
            class="col mt-2">
            <a
              href="#factory-availability"
              class="icon-link text-nowrap">
              <i class="fas fa-truck-loading" />
              {{ $t('article.articleDetails.plantAvailability') }}
            </a>
          </div>
          <div
            v-if="article.retailScalePrices.length > 1"
            class="col mt-2">
            <a
              href="#article-scale-prices"
              class="icon-link text-nowrap">
              <i class="fas fa-dollar-sign" />
              {{ $t('article.components.additionalInformation.scaledPrices.scaledPrices') }}
            </a>
          </div>
          <div
            v-if="article.conversionFactors.length"
            class="col mt-2">
            <a
              href="#article-conversion-factors"
              class="icon-link text-nowrap">
              <i class="fas fa-calculator" />
              {{ $t('article.components.additionalInformation.conversionFactors.conversionFactors') }}
            </a>
          </div>
          <div
            v-if="article.documents.length"
            class="col mt-2">
            <a
              href="#article-documents"
              class="icon-link text-nowrap">
              <i class="fas fa-book" />
              {{ $t('article.components.additionalInformation.documents.documents') }}
            </a>
          </div>
          <div
            v-if="article.additionalMaterials.length"
            class="col mt-2">
            <a
              href="#article-additional-material"
              class="icon-link text-nowrap">
              <i class="fas fa-cogs" />
              {{ $t('article.components.additionalInformation.articleLists.related') }}
            </a>
          </div>
          <div
            v-if="article.oxomi && article.oxomi.masterdata"
            class="col mt-2">
            <a
              href="#article-oxomi-masterdata"
              class="icon-link text-nowrap">
              <i class="fas fa-cogs" />
              {{ $t('article.dataSheet') }}
            </a>
          </div>
          <div
            v-if="article.oxomi && article.oxomi.videos"
            class="col mt-2">
            <a
              href="#article-oxomi-videos"
              class="icon-link text-nowrap">
              <i class="fas fa-photo-video" />
              {{ $t('article.videos') }}
            </a>
          </div>
          <div
            v-if="article.oxomi && article.oxomi.cataloguePages"
            class="col mt-2">
            <a
              href="#article-oxomi-catalogue-pages"
              class="icon-link text-nowrap">
              <i class="fas fa-book-open fa-fw" />
              {{ $t('article.cataloguePages') }}
            </a>
          </div>
          <div
            v-if="article.suggestedMaterials.length"
            class="col mt-2">
            <a
              href="#article-also-bought"
              class="icon-link text-nowrap">
              <i class="fas fa-shopping-basket" />
              {{ $t('article.components.additionalInformation.costumersAlsoBought.costumersAlsoBought') }}
            </a>
          </div>
        </div>
      </div>
    </div>

    <!-- Artikeldetails -->
    <div class="border-bottom pb-1 mb-2">
      <div class="row">
        <!-- Kundenmaterialnummer -->
        <template v-if="article.customerMatnr">
          <div class="col-12 col-sm-5 font-weight-bold mb-sm-1">
            {{ $t('article.articleDetails.costumerMatnr') }}
          </div>
          <div class="col-12 col-sm-7 mb-1">
            {{ article.customerMatnr }}
          </div>
        </template>

        <!-- Werksartikelnummer -->
        <template v-if="article.factoryNumbers.length">
          <div class="col-12 col-sm-5 font-weight-bold mb-sm-1">
            {{ $t('article.articleDetails.factoryNumber') }}
          </div>
          <div class="col-12 col-sm-7 mb-1">
            <div
              v-for="factoryNumber in article.factoryNumbers"
              :key="`${factoryNumber.supplierNumber}-${factoryNumber.supplierMatnr}`">
              {{ factoryNumber.supplierMatnr }} ({{ factoryNumber.supplierName }})
            </div>
          </div>
        </template>

        <!-- Energieeffizienzklassen EEK-Labels -->
        <template v-if="article.eek && article.eek.classes.length">
          <div class="col-12 col-sm-5 col-lg-12 col-xl-5 font-weight-bold mb-1">
            {{ $t('article.articleDetails.eek') }}
          </div>
          <div class="col-12 col-sm-7 col-lg-12 col-xl-7 mb-1">
            <app-article-atom-eek-labels :classes="article.eek.classes" />

            <!-- Energieeffizienzklassen Dokumente -->
            <template v-if="article.eek.detailLabelsEnabled && article.eek.hasSupplierData">
              <!-- Energieeffizienzklassen Dokumente generieren -->
              <div v-if="article.eek.labels.length === 0">
                <button
                  :disabled="isEEKDocumentGenerationInProcess"
                  class="btn btn-secondary btn-small"
                  @click.prevent="generateEEKDocuments">
                  <app-icon-state
                    :is-loading="isEEKDocumentGenerationInProcess"
                    icon="fas fa-file-pdf" />
                  EEK-Dokumente Generieren
                </button>
              </div>

              <!-- Energieeffizienzklassen Dokumente anzeigen -->
              <div
                v-for="(label, index) in article.eek.labels"
                :key="index">
                <a
                  v-if="label.hasData"
                  :href="getEEKDocumentDownloadUrl(article.eek.supplierId, article.eek.supplierMatnr, index + 1)">
                  <i class="fas fa-file-pdf fa-fw" /> {{ label.name }}
                </a>
                <span v-else>
                  <i class="fas fa-file-pdf fa-fw" /> {{ label.name }}
                </span>
              </div>
            </template>
          </div>
        </template>
      </div>
    </div>

    <!-- Zusätzliche Informationen -->
    <div
      v-if="hasExtendedInformation"
      class="border-bottom mb-2 pb-1">
      <!-- Mindestbestellmenge -->
      <div
        v-if="article.minimumOrderQuantity"
        class="row">
        <div class="col-12 col-sm-5 b-1 mb-lg-0">
          <strong>{{ $t('article.articleDetails.minimumOrderQuantity') }}</strong>
        </div>
        <div class="col-12 col-sm-7">
          {{ article.minimumOrderQuantity.quantity }} {{ article.minimumOrderQuantity.unit }}
        </div>
      </div>
    </div>

    <!-- Andere Artikel aus übergeordneter Kategorie -->
    <div
      v-if="app.user.hasPermission('CATALOGUE') && article.cataloguePath.length"
      class="mb-3">
      <div
        v-for="(category, index) in article.cataloguePath"
        :key="index">
        {{ $t('article.articleDetails.otherArticlesFrom') }} <a :href="`catalogue?fq=${encodeURIComponent(category.filterQuery)}`">
          {{ category.label }}
        </a>
      </div>
    </div>
  </div>
</template>

<script>
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { generateEEKDocuments,  getEEKDocumentDownloadUrl } from '@scripts/modules/eek'

export default {
  props: {
    article: {
      type: Object,
      required: true,
    },
    technicalInformations: {
      type: Array,
      default () {
        return []
      },
    },
  },

  data () {
    return {
      getEEKDocumentDownloadUrl,
      isEEKDocumentGenerationInProcess: false,
    }
  },

  computed: {
    hasExtendedInformation () {
      return !!this.article.minimumOrderQuantity
    },
  },

  methods: {
    async generateEEKDocuments () {
      this.isEEKDocumentGenerationInProcess = true
      try {
        const eekLabels = await generateEEKDocuments(this.article.eek.supplierId, this.article.eek.supplierMatnr)
        this.article.eek.labels = eekLabels
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
      this.isEEKDocumentGenerationInProcess = false
    },
  },
}
</script>
