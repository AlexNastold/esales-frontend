<template>
  <section class="additional-information">
    <!-- Überschrift -->
    <h4 class="text-uppercase border-bottom pb-2 mb-3">
      <a name="article-documents">
        <i class="fas fa-book" />
        {{ $t('article.components.additionalInformation.documents.documents') }}
      </a>
    </h4>

    <div class="row">
      <!-- Auflistung Links -->
      <div
        v-if="documentLinks.length"
        class="col-12 col-lg">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th class="td-inline pr-3 border-top-0">
                {{ $t('article.components.additionalInformation.documents.links') }}
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="(document, index) in documentLinks"
              :key="index">
              <td>
                <a
                  :href="document.url"
                  :title="document.label"
                  target="_blank"
                  class="icon-link">
                  <i
                    v-if="document.type === 'PDF'"
                    class="fas fa-file-pdf fa-fw text-dark" />
                  <i
                    v-else
                    class="fas fa-external-link-alt fa-fw text-dark" />
                  <span class="text">
                    {{ document.label }}
                  </span>
                </a>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Auflistung PDFs -->
      <div
        v-if="documentPdfs.length"
        class="col-12 col-lg">
        <table class="table table-striped table-sm">
          <thead class="">
            <tr>
              <th class="td-inline pr-3 border-top-0">
                {{ $t('article.components.additionalInformation.documents.pdfs') }}
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="(document, index) in documentPdfs"
              :key="index">
              <td>
                <a
                  :href="document.url"
                  :title="document.label"
                  target="_blank"
                  class="icon-link">
                  <i
                    v-if="document.type === 'PDF'"
                    class="fas fa-file-pdf fa-fw text-dark" />
                  <i
                    v-else
                    class="fas fa-external-link-alt fa-fw text-dark" />
                  <span class="text">
                    {{ document.label }}
                  </span>
                </a>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  props: {
    documents: {
      type: Array,
      required: true,
    },
  },

  computed: {
    documentLinks () {
      return this.documents.filter((document) => document.type !== 'PDF')
    },
    documentPdfs () {
      return this.documents.filter((document) => document.type === 'PDF')
    },
  },
}
</script>

