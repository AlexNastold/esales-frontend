<template>
  <div class="bg-light p-2 mb-3">
    <!-- Beschreibung -->
    <label
      class="mb-1 pl-1"
      for="form-input-distance">{{ $t('article.components.additionalInformation.factoryAvailabilityFilter.description') }}</label>
    <b-form-input
      id="form-input-distance"
      v-model="value"
      type="range"
      min="0"
      :max="max"
      @change="change" />
    <!-- Label for Range Slider- -->
    <div class="text-center">
      <strong>{{ $t('article.components.additionalInformation.factoryAvailabilityFilter.radius') }}</strong> {{ filterLabel(value) }}
    </div>
  </div>
</template>

<script>

export default {

  props: {
    max: {
      default: 200,
      type: Number,
    },
  },

  data () {
    return {
      value: this.max,
    }
  },

  methods: {
    change () {
      this.$emit('change', Number(this.value) === this.max ? Infinity : Number(this.value))
    },
    filterLabel (v) {
      if (Number(v) === this.max) {
        return '∞'
      } else {
        return `${v} km`
      }
    },
  },
}
</script>
