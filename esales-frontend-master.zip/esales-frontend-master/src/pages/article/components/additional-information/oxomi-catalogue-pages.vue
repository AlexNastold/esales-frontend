<template>
  <section
    v-if="cataloguePages"
    class="additional-information">
    <h4 class="text-uppercase border-bottom pb-2 mb-3">
      <a name="article-oxomi-catalogue-pages">
        <i class="fas fa-book-open fa-fw" />
        {{ $t('article.cataloguePages') }}
      </a>
    </h4>
    <div class="row">
      <div
        v-for="(cataloguePage, index) in cataloguePages.items"
        :key="`cataloguePage-${index}`"
        class="col-6 col-sm-4 col-md-3 col-lg-2 h-100 mb-3">
        <a
          href="#"
          @click.prevent="openOxomiCatalogue(cataloguePage.id, cataloguePage.page, cataloguePage.query)">
          <div class="catalogue-image-wrapper border rounded p-1 d-flex align-items-center justify-content-center mb-1">
            <img
              :src="cataloguePage.previewUrl"
              :alt="cataloguePage.name"
              class="figure-img img-fluid rounded">
            <div class="catalogue-view-icon">
              <i class="fas fa-search-plus fa-2x fa-fw" />
            </div>
          </div>
          <div class="text-dark font-weight-bold">
            {{ cataloguePage.name }}
          </div>
        </a>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  props: {
    cataloguePages: {
      type: Object,
      default: void 0,
    },
  },

  methods: {
    openOxomiCatalogue (id, page, query) {
      window.oxomi.openCatalog({
        catalog: id,
        page,
        query,
      })
    },
  },
}
</script>
