<template>
  <section
    v-if="videos"
    class="additional-information">
    <h4 class="text-uppercase border-bottom pb-2 mb-3">
      <a name="article-oxomi-videos">
        <i class="fas fa-photo-video" />
        {{ $t('article.videos') }}
      </a>
    </h4>
    <div class="row">
      <div
        v-for="(video, index) in videos.items"
        :key="`video-${index}`"
        class="col-sm-6 col-lg-4 mb-3">
        <div
          :id="`video-${index}`"
          class="video-wrapper">
          <a
            href="#"
            @click.prevent="embedOxomiVideo(video.id, `#video-${index}`, video.width, video.height)">
            <div class="video-preview-container mb-1">
              <img
                :src="video.previewUrl"
                :alt="video.name"
                class="img-fluid w-100">
              <div class="play-icon">
                <i class="far fa-play-circle fa-5x fa-fw" />
              </div>
              <div class="duration-wrapper">
                <div class="duration">
                  {{ video.durationShort }}
                </div>
              </div>
            </div>
          </a>
        </div>
        <div class="text-dark font-weight-bold">
          {{ video.name }}
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  props: {
    videos: {
      type: Object,
      default: void 0,
    },
  },

  methods: {
    embedOxomiVideo (id, targetSelector, width, height) {
      window.oxomi.embedVideo({
        autoplay: true,
        mode: 'embed',
        size: 'medium',
        target: targetSelector,
        video: id,
        width,
        height,
      })
    },
  },
}
</script>
