<template>
  <div
    :class="{'rounded bg-light': additionalInformationOpen}"
    class="factory-availability-list-item d-flex align-items-stretch align-items-end flex-column h-100 p-2">
    <!-- Indicator, Werksname -->
    <div
      :class="{'mb-2': additionalInformationOpen && !factoryAvailability.factoryAddress}"
      class="d-flex align-items-center">
      <div
        :class="className"
        class="indicator rounded" />
      <span
        class="toggle-additional-information"
        @click="toggleAdditionalInformation">
        {{ factoryAvailability.factoryName }}
      </span>
      <small
        v-if="typeof factoryAvailability.distance !== 'undefined'"
        class="ml-auto text-muted">
        {{ $t('article.components.additionalInformation.factoryAvailability.distanceInKilometers', { distance: factoryAvailability.distance }) }}
        <i class="fas fa-map-pin" />
      </small>
    </div>

    <!-- Werk Adresse -->
    <div
      v-if="factoryAvailability.factoryAddress"
      v-show="additionalInformationOpen"
      class="text-muted mb-2">
      <div v-if="factoryAvailability.factoryAddress.street">
        <small>{{ factoryAvailability.factoryAddress.street }}</small>
      </div>
      <div v-if="factoryAvailability.factoryAddress.poBox">
        <small>{{ factoryAvailability.factoryAddress.poBox }}</small>
      </div>
      <div>
        <small>{{ factoryAvailability.factoryAddress.country }}-{{ factoryAvailability.factoryAddress.postalCode }} {{ factoryAvailability.factoryAddress.city }}</small>
      </div>
    </div>

    <!-- Zusätzliche Informationen -->
    <div
      v-show="additionalInformationOpen"
      class="additional-information mt-auto">
      <!-- Artikel nicht verfügbar -->
      <div v-if="!factoryAvailability.availability.directly && !factoryAvailability.availability.shortly">
        <div class="d-flex mt-auto align-items-center">
          <strong>{{ $t('general.availabilityTexts.notAvailable') }}</strong>
        </div>
      </div>

      <div v-else>
        <!-- Sofort verfügbar -->
        <div class="d-flex mt-auto align-items-center mb-1">
          <div class="indicator secondary in-stock rounded" />
          {{ $t('general.availabilityTexts.isAvailable') }}
          <div class="ml-auto">
            <strong>
              {{ factoryAvailability.availability.directly | sapNumber(omitUnnecessaryDecimals = true) }} {{ factoryAvailability.availability.unit }}
            </strong>
          </div>
        </div>

        <!-- Kurzfristig lieferbar -->
        <div class="d-flex align-items-center">
          <div class="indicator secondary deliverable rounded" />
          {{ $t('general.availabilityTexts.shortlyAvailable') }}
          <div class="ml-auto">
            <strong>
              {{ factoryAvailability.availability.shortly | sapNumber(omitUnnecessaryDecimals = true) }} {{ factoryAvailability.availability.unit }}
            </strong>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { AvailabilityFlag } from '@scripts/modules/article-details'

export default {
  props: {
    factoryAvailability: {
      required: true,
      type: Object,
    },
  },

  data () {
    return {
      additionalInformationOpen: false,
    }
  },

  computed: {
    className () {
      switch (this.factoryAvailability.availability.availabilityFlag) {
        case AvailabilityFlag.AVAILABLE:
          return 'in-stock'
        case AvailabilityFlag.SHORTLY_AVAILABLE:
          return 'deliverable'
        case AvailabilityFlag.NOT_AVAILABLE:
          return 'not-available'
      }
      return ''
    },
  },

  methods: {
    toggleAdditionalInformation () {
      this.additionalInformationOpen = !this.additionalInformationOpen
    },
  },
}
</script>

