<template>
  <section class="additional-information">
    <!-- Überschrift -->
    <h4 class="text-uppercase my-3">
      <a name="article-also-bought">
        <i class="fas fa-shopping-basket" />
        {{ $t('article.components.additionalInformation.costumersAlsoBought.costumersAlsoBought') }}
      </a>
    </h4>

    <!-- Artikel-Slider -->
    <app-article-slider :articles="articles" />
  </section>
</template>

<script>
export default {
  props: {
    articles: {
      type: Array,
      required: true,
    },
  },
}
</script>

