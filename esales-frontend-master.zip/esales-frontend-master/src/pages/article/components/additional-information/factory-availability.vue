<template>
  <section
    v-if="factoryAvailabilitiesToDisplay"
    class="additional-information">
    <!-- Überschrift -->
    <h4 class="text-uppercase border-bottom pb-2 mb-3">
      <a name="factory-availability">
        <i class="fas fa-truck-loading" />
        {{ $t('article.components.additionalInformation.factoryAvailability.plantAvailability') }}
      </a>
    </h4>

    <app-loading-spinner
      v-if="loading"
      class="mt-5 mb-5 text-center" />
    <div v-else>
      <!-- Filter -->
      <factory-availabililty-filter
        v-if="clientLocation"
        :max="maxFilterDistance"
        class="factory-availability-filter"
        @change="(v) => maxDistance = v" />

      <div
        v-else-if="isGeolocationSupported"
        :class="isClientLocationNotPossible ? 'alert-danger' : 'alert-info'"
        class="alert">
        <i class="fas fa-info-circle fa-fw" />
        <template v-if="!isClientLocationNotPossible">
          {{ $t('article.components.additionalInformation.factoryAvailability.geoLocationDescription') }}
        </template>
        <template v-else>
          {{ $t('article.components.additionalInformation.factoryAvailability.geoLocationError') }}
        </template>
        <div class="mt-2 text-center">
          <button
            class="btn btn-secondary"
            type="button"
            @click.prevent="calculateDistances">
            <app-icon-state
              :is-loading="isClientLocationLoading"
              icon="fas fa-location-arrow" />
            <template v-if="!isClientLocationNotPossible">
              {{ $t('article.components.additionalInformation.factoryAvailability.calculateDistanceButton') }}
            </template>
            <template v-else>
              {{ $t('article.components.additionalInformation.factoryAvailability.calculateDistanceRetryButton') }}
            </template>
          </button>
        </div>
      </div>

      <!-- Auflistung Werke -->
      <div class="row">
        <template v-for="(factoryAvailability, index) in factoryAvailabilitiesToDisplay">
          <div
            v-show="factoryAvailability.show"
            :key="index"
            class="col-12 col-sm-6 col-lg-4 mb-1">
            <factory-availability-list-item :factory-availability="factoryAvailability" />
          </div>
        </template>
      </div>
    </div>
  </section>
</template>

<script>
import { getFactoryAvailability } from '@scripts/modules/article-details'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getLocation, isGeolocationSupported } from '@scripts/modules/location'
import { getDistanceFromLatLonInKm } from '@scripts/helper/distance'

import FactoryAvailabilityFilter from './factory-availability-filter.vue'
import FactoryAvailabilityListItem from './factory-availability-list-item.vue'

export default {
  components: {
    'factory-availabililty-filter': FactoryAvailabilityFilter,
    'factory-availability-list-item': FactoryAvailabilityListItem,
  },

  props: {
    article: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      factoryAvailabilities: [],
      loading: true,

      clientLocation: void 0,
      isClientLocationLoading: false,
      isClientLocationNotPossible: false,

      maxDistance: Infinity,
      maxFilterDistance: 200,
    }
  },

  computed: {
    factoryAvailabilitiesToDisplay () {
      return this.factoryAvailabilities
        // Show-Attribut setzen
        .map((factoryAvailability) => ({
          ...factoryAvailability,
          show: factoryAvailability.distance <= this.maxDistance || typeof factoryAvailability.distance === 'undefined',
        }))
        // Nach Entfernung und Name sortieren
        .sort((a, b) => {
          return (a.distance === b.distance)
            ? a.factoryName.localeCompare(b.factoryName)
            : ((a.distance || 0) - (b.distance || 0))
        })
    },

    isGeolocationSupported () {
      return isGeolocationSupported()
    },
  },

  created () {
    this.loadFactoryAvailabilities()
  },

  methods: {
    async loadFactoryAvailabilities () {
      try {
        this.factoryAvailabilities = await getFactoryAvailability(this.article.matnr, this.article.unit)
        this.loading = false
      } catch (e) {
        console.error()
        showTechnicalErrorMessage()
      }
    },

    calculateDistance (clientLocation, factoryAvailability) {
      if (factoryAvailability.lat && factoryAvailability.lon) {
        const distance = getDistanceFromLatLonInKm(
          clientLocation.coords.latitude,
          clientLocation.coords.longitude,
          factoryAvailability.lat,
          factoryAvailability.lon,
        )
        return Math.round(distance * 100) / 100
      }
    },

    async calculateDistances () {
      try {
        this.isClientLocationLoading = true
        this.clientLocation = await getLocation()
        this.factoryAvailabilities = this.factoryAvailabilities.map((factoryAvailability) => ({
          ...factoryAvailability,
          distance: this.calculateDistance(this.clientLocation, factoryAvailability),
        }))
      } catch (e) {
        this.isClientLocationNotPossible = true
        console.error(e)
      }
      this.isClientLocationLoading = false
    },
  },
}
</script>

