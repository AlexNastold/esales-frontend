<template>
  <section class="additional-information">
    <!-- Überschrift -->
    <h4 class="text-uppercase border-bottom pb-2 mb-3">
      <a name="article-scale-prices">
        <i class="fas fa-dollar-sign" />
        {{ $t('article.components.additionalInformation.scaledPrices.scaledPrices') }}
      </a>
    </h4>

    <div class="row">
      <!-- Menge, UVP  -->
      <div class="col-12 col-lg-6">
        <app-scale-prices
          :prices="retail"
          :price-label="retailPriceLabel" />
      </div>

      <!-- Menge, Preis -->
      <div class="col-12 col-lg-6">
        <app-scale-prices
          v-if="app.user.hasPermission('SHOW_NET_PRICE') && net.length"
          :prices="net"
          :price-label="$t('article.components.additionalInformation.scaledPrices.price')" />
      </div>
    </div>
  </section>
</template>

<script>
import user from '@scripts/app/user'

export default {
  props: {
    retail: {
      type: Array,
      required: true,
    },
    net: {
      type: Array,
      default () {
        return []
      },
    },
  },

  data () {
    return {
      retailPriceLabel: user.hasPermission('SHOW_NET_PRICE')
        ? this.$t('article.components.additionalInformation.scaledPrices.uvp')
        : this.$t('article.components.additionalInformation.scaledPrices.price'),
    }
  },
}
</script>

