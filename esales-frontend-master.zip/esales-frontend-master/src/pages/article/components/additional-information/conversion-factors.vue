<template>
  <section class="additional-information">
    <!-- Überschrift -->
    <h4 class="text-uppercase border-bottom pb-2 mb-3">
      <a name="article-conversion-factors">
        <i class="fas fa-calculator" />
        {{ $t('article.components.additionalInformation.conversionFactors.conversionFactors') }}
      </a>
    </h4>

    <!-- Tabelle Umrechnungsfaktoren -->
    <table class="table table-sm table-striped">
      <thead>
        <tr>
          <th class="td-inline pr-3 border-top-0">
            {{ $t('article.components.additionalInformation.conversionFactors.from') }}
          </th>
          <th class="border-top-0">
            {{ $t('article.components.additionalInformation.conversionFactors.to') }}
          </th>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="(conversionFactor, index) in conversionFactors"
          :key="index">
          <td class="td-inline pr-3">
            {{ conversionFactor.from.quantity | sapNumber(omitUnnecessaryDecimals = conversionFactor.from.quantity % 1 === 0) }} {{ conversionFactor.from.unit }}
          </td>
          <td>
            {{ conversionFactor.to.quantity | sapNumber(omitUnnecessaryDecimals = conversionFactor.to.quantity % 1 === 0) }} {{ conversionFactor.to.unit }}
          </td>
        </tr>
      </tbody>
    </table>
  </section>
</template>

<script>
export default {
  props: {
    conversionFactors: {
      type: Array,
      required: true,
    },
  },
}
</script>
