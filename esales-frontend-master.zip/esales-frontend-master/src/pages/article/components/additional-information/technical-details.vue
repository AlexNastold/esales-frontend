<template>
  <section class="additional-information">
    <!-- Überschrift -->
    <h4 class="text-uppercase border-bottom pb-2 mb-3">
      <a name="technical-details">
        <i class="fas fa-cog" />
        {{ $t('article.components.additionalInformation.technicalDetails.technicalInformation') }}
      </a>
    </h4>

    <!-- Auflistung technische Details -->
    <table class="table table-sm table-striped">
      <tbody>
        <tr
          v-for="(technicalInformation, index) in technicalInformations"
          :key="index">
          <td class="td-inline pr-3">
            <strong>{{ technicalInformation.label }}</strong>
          </td>
          <td>
            {{ technicalInformation.value }}
          </td>
        </tr>
      </tbody>
    </table>
  </section>
</template>

<script>
export default {
  props: {
    technicalInformations: {
      type: Array,
      required: true,
    },
  },
}
</script>
