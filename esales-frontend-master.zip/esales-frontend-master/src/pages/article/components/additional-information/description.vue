<template>
  <section class="additional-information">
    <!-- Überschrift -->
    <h4 class="text-uppercase border-bottom pb-2 mb-3">
      <a name="article-description">
        <i class="fas fa-file-alt" />
        {{ $t('article.components.additionalInformation.description.description') }}
      </a>
    </h4>

    <!-- Text -->
    <p v-html="text" />
  </section>
</template>

<script>
export default {
  props: {
    text: {
      type: String,
      required: true,
    },
  },
}
</script>

