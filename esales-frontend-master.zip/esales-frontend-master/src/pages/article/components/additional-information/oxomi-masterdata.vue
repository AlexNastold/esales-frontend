<template>
  <section
    v-if="masterdata"
    class="additional-information">
    <h4 class="text-uppercase border-bottom pb-2 mb-3">
      <a name="article-oxomi-masterdata">
        <i class="fas fa-cog" />
        {{ $t('article.dataSheet') }}
      </a>
    </h4>
    <div v-html="masterdata.rendered" />
  </section>
</template>

<script>
export default {
  props: {
    masterdata: {
      type: Object,
      default: void 0,
    },
  },

  mounted () {
    $(this.$el).on('click', '#datasheet-deeplink', function () {
      const datasheetUrl = $(this).closest('.oxomi-masterdata-fields').find('a.oxomi-download-datasheet-icon').first().attr('href')
      if (datasheetUrl) {
        window.oxomi.copyToClipboard(datasheetUrl, $(this))
      }
    })
  },
}
</script>
