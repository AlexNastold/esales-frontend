<template>
  <section class="additional-information">
    <!-- Übeschrift -->
    <h4 class="text-uppercase border-bottom pb-2 mb-3">
      <a name="article-additional-material">
        <i class="fas fa-cogs" />
        {{ $t('article.components.additionalInformation.articleLists.related') }}
      </a>
    </h4>

    <!-- Tab-Navigation Mobile -->
    <select
      class="custom-select w-100 d-lg-none mb-3"
      @change="onSelectChange">
      <option
        v-for="additionalMaterial in additionalMaterials"
        :key="additionalMaterial.type"
        :selected="additionalMaterial.type === activeListType"
        :value="additionalMaterial.type">
        {{ additionalMaterial.label }}
      </option>
    </select>

    <!-- Tab-Navigation Desktop -->
    <div class="d-none d-lg-block">
      <nav
        id="additionalMaterials"
        ref="tabNav"
        role="tablist"
        class="nav nav-tabs border-bottom-0">
        <a
          v-for="additionalMaterial in additionalMaterials"
          :id="`nav-${additionalMaterial.type}-tab`"
          :key="additionalMaterial.type"
          :data-type="additionalMaterial.type"
          :href="`#nav-${additionalMaterial.type}`"
          :class="{'active': additionalMaterial.type === activeListType}"
          data-toggle="tab"
          role="tab"
          class="nav-item nav-link">
          {{ additionalMaterial.label }}
        </a>
      </nav>
    </div>

    <!-- Tabs -->
    <div class="tab-content">
      <div
        v-for="additionalMaterial in additionalMaterials"
        :id="`nav-${additionalMaterial.type}`"
        :key="additionalMaterial.type"
        :class="{'show active': additionalMaterial.type === activeListType}"
        class="tab-pane fade"
        role="tabpanel">
        <div class="article-list-col-12 mb-3 list-group">
          <div
            v-for="(article, index) in additionalMaterial.articles"
            :key="index"
            class="list-group-item">
            <app-article-item
              :key="index"
              :article="article"
              pitcher="detail" />
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  props: {
    additionalMaterials: {
      type: Array,
      default () {
        return []
      },
    },
    openTab: {
      type: String,
      default: void 0,
    },
  },

  data () {
    return {
      activeListType: this.getInitialTab(),
    }
  },

  mounted () {
    $(this.$refs.tabNav).children().on('shown.bs.tab', (e) => {
      this.activeListType = $(e.target).data('type')
    })
  },

  methods: {
    getInitialTab () {
      const types = this.additionalMaterials.map((t) => t.type)
      if (types.includes(this.openTab)) {
        return this.openTab
      }
      return types[0]
    },
    onSelectChange (e) {
      this.activeListType = e.target.value
    },
  },
}
</script>

