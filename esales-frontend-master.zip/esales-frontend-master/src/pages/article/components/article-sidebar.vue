<template>
  <aside class="sidebar">
    <div class="border rounded bg-light p-3 mb-2">
      <!-- Preise -->
      <div class="prices text-right mb-2">
        <div
          v-if="app.user.hasPermission('SHOW_NET_PRICE')"
          class="secondary-price text-muted">
          <div v-if="article.retailPrice.price">
            <span class="uvp">
              {{ $t('article.articleSidebar.uvp') }}
            </span>
            <span class="price">
              {{ article.retailPrice.price | price }} {{ article.retailPrice.currency | replaceCurrencyWithSign }}
            </span>
            <span class="unit">
              / {{ article.retailPrice.costUnit | sapNumber }} {{ article.retailPrice.volumeUnit }}
            </span>
          </div>
          <div v-else>
            <span class="price">
              {{ $t('article.articleSidebar.priceOnRequest') }}
            </span>
          </div>
        </div>
        <div
          v-if="app.user.hasPermission('SHOW_NET_PRICE')"
          class="primary-price">
          <!-- Angebotspreis -->
          <div v-if="article.documentInformations && article.documentInformations.price">
            <!-- <span class="text-muted mr-1">Angebotspreis: </span> -->
            <span class="price">
              {{ article.documentInformations.price.price | price }} {{ article.documentInformations.price.currency | replaceCurrencyWithSign }}
            </span>
            <span class="unit text-muted">
              / {{ article.documentInformations.price.costUnit | sapNumber }} {{ article.documentInformations.price.volumeUnit }}
            </span>
            <div class="document-note text-muted">
              Preis aus Angebot {{ article.documentInformations.documentIdDisplay }}
            </div>
          </div>
          <!-- Nettopreis -->
          <div v-else-if="article.netPrice.price">
            <span class="price">
              {{ article.netPrice.price | price }} {{ article.netPrice.currency | replaceCurrencyWithSign }}
            </span>
            <span class="unit text-muted">
              / {{ article.netPrice.costUnit | sapNumber }} {{ article.netPrice.volumeUnit }}
            </span>
          </div>
          <div v-else>
            <span class="price">
              {{ $t('article.articleSidebar.priceOnRequest') }}
            </span>
          </div>
        </div>
        <div
          v-if="!app.user.hasPermission('SHOW_NET_PRICE')"
          class="primary-price">
          <div v-if="article.retailPrice.price">
            <span class="price">
              {{ article.retailPrice.price | price }} {{ article.retailPrice.currency | replaceCurrencyWithSign }}
            </span>
            <span class="unit text-muted">
              / {{ article.retailPrice.costUnit | sapNumber }} {{ article.retailPrice.volumeUnit }}
            </span>
          </div>
          <div v-else>
            <span class="price">
              {{ $t('article.articleSidebar.priceOnRequest') }}
            </span>
          </div>
        </div>
      </div>

      <!-- Staffelpreise -->
      <div
        v-if="article.retailScalePrices.length > 1"
        class="mb-2">
        <a
          href="#scaled-prices"
          class="icon-link">
          <i class="fas fa-angle-right fa-fw" />
          <span class="text">
            {{ $t('article.articleSidebar.scaledPrices') }}
          </span>
        </a>
      </div>

      <!-- Artikel schon im Warenkorb -->
      <div
        v-if="app.user.hasPermission('BASKET_ADD_ARTICLES')"
        class="text-muted text-center mb-1">
        <small v-if="!article.quantityInBasket">
          {{ $t('article.articleSidebar.quantityInBasket.equal0') }}
        </small>
        <small v-if="article.quantityInBasket">
          {{ $t('article.articleSidebar.quantityInBasket.greater0', { count: article.quantityInBasket }) }}
        </small>
      </div>

      <!-- Menge, Werfen -->
      <app-form-input-quantity
        v-if="app.user.hasPermission(['BASKET_ADD_ARTICLES', 'LISTS', 'COMPARISON', 'LABELS'])"
        v-model="amount"
        :unit="article.unitFormatted"
        :stepsize="article.stepsize"
        class="mb-1"
        width="auto"
        btn-type="btn-tertiary" />

      <app-action-button-basket
        v-if="app.user.hasPermission('BASKET_ADD_ARTICLES')"
        :matnr="article.matnr"
        :amount="amount"
        :document-id="documentId"
        :document-posnr="documentPosnr"
        :document-type="documentType"
        pitcher="article"
        button-class="btn-primary btn-block"
        @success="reloadArticleAmountInBasket" />
    </div>

    <!-- Action Buttons -->
    <div
      v-if="app.user.hasPermission(['LISTS', 'COMPARISON', 'LABELS'])"
      class="border rounded bg-light p-3">
      <app-action-button-list
        v-if="app.user.hasPermission('LISTS')"
        :button-class="'btn-tertiary btn-block mb-1'"
        :matnr="article.matnr"
        :amount="amount" />

      <app-action-button-comparison
        v-if="app.user.hasPermission('COMPARISON')"
        :button-class="'btn-tertiary btn-block mb-1'"
        :matnr="article.matnr" />

      <app-action-button-label
        v-if="app.user.hasPermission('LABELS')"
        :button-class="'btn-tertiary btn-block'"
        :matnr="article.matnr"
        :amount="amount" />
    </div>
  </aside>
</template>

<script>
import { getArticleQuantityInBasket } from '@scripts/modules/basket'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  props: {
    article: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      amount: this.article.quantity,
      documentId: this.article.documentInformations ? this.article.documentInformations.documentId : '',
      documentPosnr: this.article.documentInformations ? this.article.documentInformations.documentPosnr : '',
      documentType: this.article.documentInformations ? this.article.documentInformations.documentType : 0,
    }
  },

  methods: {
    async reloadArticleAmountInBasket () {
      try {
        this.article.quantityInBasket = await getArticleQuantityInBasket(this.article.matnr)
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
