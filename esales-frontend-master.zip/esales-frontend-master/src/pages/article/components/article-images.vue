<template>
  <div>
    <!-- Artikelbilder Mobile -->
    <div class="d-block d-lg-none article-images-md-slider">
      <!-- Artikelbilder Slider -->
      <slick-slider
        v-if="images.length"
        ref="slider"
        :options="articleImagesMdSliderOptions"
        @afterChange="afterSlideChange">
        <div
          v-for="image in imagePaths"
          :key="image.Key"
          class="slider-image-wrapper d-flex align-items-center justify-content-center"
          @click="openGallery">
          <img
            :src="image"
            :alt="alt">
        </div>
      </slick-slider>

      <!-- Kein Artikelbild -->
      <div
        v-else
        class="slider-image-wrapper d-flex align-items-center justify-content-center">
        <img
          :src="getNoImageUrl()"
          :alt="$t('general.noImage')">
      </div>
    </div>

    <!-- Artikelbilder Desktop -->
    <div class="d-none d-lg-block article-images-lg">
      <div
        :class="{'cursor-pointer' : imagePaths.length}"
        class="image-wrapper d-flex align-items-center justify-content-center mb-2"
        @click="openGallery">
        <img
          v-if="imagePaths.length"
          :src="activeImage"
          :alt="alt">
        <img
          v-else
          :src="getNoImageUrl()"
          :alt="$t('general.noImage')">
      </div>

      <!-- Vorschaubilder Desktop -->
      <div
        v-if="imagePaths.length"
        class="preview-article-images-lg">
        <div class="row no-gutters">
          <div
            v-for="(image, index) in imagePaths"
            :key="index"
            class="col-auto m-1">
            <div
              :class="{'border-primary': index === activeImageIndex}"
              class="preview-image-wrapper border d-flex align-items-center justify-content-center p-1"
              @click="onPreviewSelected(index)">
              <img
                :src="image"
                :alt="alt">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { getNoImageUrl } from '@scripts/modules/images'
import SlickSlider from 'vue-slick'

export default {
  components: {
    'slick-slider': SlickSlider,
  },

  props: {
    images: {
      type: Array,
      default () {
        return []
      },
    },
    alt: {
      type: String,
      required: false,
      default () {
        return ''
      },
    },
  },

  data () {
    return {
      articleImagesMdSliderOptions: {
        slidesToScroll: 1,
        slidesToShow: 1,
        dots: true,
        arrows: false,
        speed: 200,
      },
      activeImageIndex: 0,
    }
  },

  computed: {
    imagePaths () {
      return this.images.map(this.$options.filters.articleImage)
    },
    activeImage () {
      return this.imagePaths[this.activeImageIndex]
    },
  },

  watch: {

    // Reinitialize slider when images change
    imagePaths () {
      this.reInitSlider()
    },
  },

  methods: {
    getNoImageUrl,
    openGallery () {
      if (!this.images.length) {
        return
      }
      $(document)
        .lightGallery({
          dynamic: true,
          dynamicEl: this.imagePaths.map((image) => ({ src: image, thumb: image })),
          index: this.activeImageIndex,
          zoom: true,
          download: false,
          url: false,
          hash: false,
        })
        .on('onCloseAfter.lg', function () {
          try {
            $(this).data('lightGallery').destroy(true)
          } catch (e) {
            // Nothing to do
          }
        })
    },

    afterSlideChange (event, slick, currentSlide) {
      this.activeImageIndex = currentSlide
    },

    onPreviewSelected (index) {
      this.activeImageIndex = index

      // Also set active slide in mobile slider
      // (slider doesnt recognize changed to activeImageIndex)
      this.$refs.slider.goTo(index, false)
    },

    reInitSlider () {
      try {
        this.$refs.slider.destroy()
        this.$nextTick(() => {
          this.$refs.slider.create()
          this.$refs.slider.goTo(this.activeImageIndex, true)
        })
      } catch (e) {
        // Nothing to do
      }
    },
  },
}
</script>
