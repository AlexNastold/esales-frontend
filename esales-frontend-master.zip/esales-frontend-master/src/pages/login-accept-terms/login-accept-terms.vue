<!--
Diese Seite dient nur zum Aktzeptieren der AGBs (die normale Anzeige der AGBs ist auf der Seite terms)

Wenn die AGBs akzeptiert werden, wird auf die Seite navigiert, welche als GET-Paramter 'redirecturl' übergeben wird.
Falls keine Seite übergeben wird, wird auf 'index' navigiert.

Wenn die AGBs nicht akzeptiert werden, wird der Benutzer ausgeloggt und auf die 'login' navigiert.
-->
<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-login-accept-terms">
      <div class="container">
        <h1 class="headline">
          {{ $t('terms.headline') }}
        </h1>

        <app-loading-box v-if="isLoading" />
        <template v-else>
          <!-- Infobox -->
          <div class="alert alert-info">
            <i class="fas fa-info-circle fa-fw" />
            {{ $t('terms.acceptTerms.message') }}
          </div>

          <!-- AGBs -->
          <p v-html="agbText" />

          <!-- Buttons -->
          <div class="text-right">
            <button
              :disabled="isAcceptInProcess || isDenyInProcess"
              type="button"
              class="btn btn-secondary d-none d-md-inline-block"
              @click="denyTerms">
              <app-icon-state
                :is-loading="isDenyInProcess"
                icon="fas fa-times" />
              {{ $t('terms.acceptTerms.buttonDeny') }}
            </button>

            <button
              :disabled="isAcceptInProcess || isDenyInProcess"
              type="button"
              class="btn btn-primary d-none d-md-inline-block"
              @click="acceptTerms">
              <app-icon-state
                :is-loading="isAcceptInProcess"
                icon="fas fa-check" />
              {{ $t('terms.acceptTerms.buttonAccept') }}
            </button>

            <button
              :disabled="isAcceptInProcess || isDenyInProcess"
              type="button"
              class="btn btn-primary btn-block d-md-none"
              @click="acceptTerms">
              <app-icon-state
                :is-loading="isAcceptInProcess"
                icon="fas fa-check" />
              {{ $t('terms.acceptTerms.buttonAccept') }}
            </button>

            <button
              :disabled="isAcceptInProcess || isDenyInProcess"
              type="button"
              class="btn btn-secondary btn-block d-md-none"
              @click="denyTerms">
              <app-icon-state
                :is-loading="isDenyInProcess"
                icon="fas fa-times" />
              {{ $t('terms.acceptTerms.buttonDeny') }}
            </button>
          </div>
        </template>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { getNextShopPageAfterLogin } from '@scripts/helper/nextPageAfterLogin'
import { redirect } from '@scripts/helper/redirect'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { acceptTerms, denyTerms } from '@scripts/modules/auth'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getHtmlContent, PageId } from '@scripts/modules/html-content'

export default {
  data () {
    return {
      agbText: void 0,
      isAcceptInProcess: false,
      isDenyInProcess: false,
      isLoading: true,
      redirectUrl: getQueryParameter('redirecturl'),
    }
  },

  async created () {
    this.setPageTitle(this.$t('terms.title'))

    try {
      this.agbText = (await getHtmlContent(PageId.TERMS_AND_CONDITIONS)).html
      this.isLoading = false
    } catch (e) {
      console.error(e)
      showTechnicalErrorMessage()
    }
  },

  methods: {
    async acceptTerms () {
      this.isAcceptInProcess = true
      try {
        await acceptTerms()
        redirect(getNextShopPageAfterLogin(this.redirectUrl))
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
        this.isAcceptInProcess = false
      }
    },
    async denyTerms () {
      this.isDenyInProcess = true
      try {
        await denyTerms()
        redirect('login', {
          redirecturl: this.redirectUrl,
        })
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
        this.isDenyInProcess = false
      }
    },
  },
}
</script>
