/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/login-accept-terms/login-accept-terms.vue'
setup(PageComponent)
