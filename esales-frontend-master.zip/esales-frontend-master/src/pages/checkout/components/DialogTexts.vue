<template>
  <b-modal
    ref="modal"
    :ok-disabled="isProcessing || isLoading"
    :title="$t('checkout.components.dialogTexts.title')"
    header-bg-variant="primary"
    header-text-variant="white"
    size="lg"
    @ok.prevent="save">
    <app-loading-box v-if="isLoading" />
    <template v-else>
      <form @submit.prevent="save">
        <!-- Texte -->
        <div
          v-for="text in texts"
          :key="text.id"
          class="form-group">
          <label>{{ text.label }}</label>
          <textarea
            v-model="text.text"
            :placeholder="$t('checkout.components.dialogTexts.textPlaceholder')"
            class="form-control"
            rows="2" />
        </div>

        <!-- Ausgeblendeter Submit-Button (zum Abschicken des Formulars mit Enter) -->
        <button
          class="d-none"
          tabindex="-1"
          type="submit" />
      </form>
    </template>

    <template slot="modal-cancel">
      <i class="fas fa-times fa-fw" />
      {{ $t('general.cancel') }}
    </template>

    <template slot="modal-ok">
      <app-icon-state
        :is-loading="isProcessing"
        icon="fas fa-save" />
      {{ $t('general.save') }}
    </template>
  </b-modal>
</template>

<script>
import { getTexts, saveTexts } from '@scripts/modules/basket'
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  data () {
    return {
      isLoading: true,
      isProcessing: false,
      texts: [],
    }
  },

  methods: {
    show () {
      this.loadTexts()
      this.$refs.modal.show()
    },

    hideDialog () {
      this.$refs.modal.hide()
    },

    async loadTexts () {
      this.isLoading = true
      try {
        this.texts = await getTexts()
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },

    async save () {
      if (this.isProcessing || this.isLoading) {
        return
      }

      this.isProcessing = true

      try {
        await saveTexts(this.texts.map((text) => ({ id: text.id, text: text.text })))
        showSuccessMessage(this.$t('basket.components.texts.textsSaved'))
        this.$emit('change')
        this.hideDialog()
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.isProcessing = false
    },
  },
}
</script>
