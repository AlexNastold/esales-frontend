<template>
  <div>
    <h4 class="m-0 mb-3 border-bottom p-1">
      {{ $t('checkout.components.positions.position', { count: positions.length }) }}
    </h4>

    <!-- Hinweis Warenkorb leer -->
    <div
      v-if="!positions.length"
      class="alert alert-warning mb-3">
      <i class="fas fa-exclamation-triangle fa-fw" />
      <span v-html="$t('checkout.components.positions.emptyBasketNote')" />
    </div>

    <div class="list-group">
      <!-- Keine Positionen -->
      <div
        v-if="!positions.length"
        class="list-group-item p-3">
        <app-box-empty-list
          :headline="$t('checkout.components.positions.listEmpty')"
          icon="fas fa-shopping-cart">
          <span v-html="$t('checkout.components.positions.listEmptyDescription')" />
        </app-box-empty-list>
      </div>

      <!-- Auflistung Positionen -->
      <template v-if="positions.length">
        <template v-for="position in positions">
          <div
            v-if="!position.position.partList.isPartListArticle || position.position.partList.isHead || app.settings.showPartsListItems"
            :key="position.position.posnr"
            class="list-group-item">
            <position-item :position="position" />
          </div>
        </template>
      </template>
    </div>
  </div>
</template>

<script>
import ArticleListItem from './position-item.vue'

export default {
  components: {
    'position-item': ArticleListItem,
  },

  props: {
    positions: {
      type: Array,
      required: true,
    },
  },
}
</script>

