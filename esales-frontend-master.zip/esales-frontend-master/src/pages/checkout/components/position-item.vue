<template>
  <div>
    <!-- Fehlermeldung -->
    <div
      v-if="position.hasError"
      class="text-danger font-weight-bold mb-2">
      <i class="fas fa-exclamation-triangle fa-fw" />&nbsp;
      {{ position.error }}
    </div>

    <div class="row">
      <!-- Artikelbild,  Artikelname, EEK-Label, Artikelnummer, Verfügbarkeit -->
      <div class="col-12 col-md-7 col-xl-9 mb-2">
        <div
          :class="{'ml-1 ml-xl-2' : position.position.partList && position.position.partList.headPosnr}"
          class="row">
          <!-- Stücklistenartikel, Artikelbild -->
          <div class="col-auto d-flex">
            <!-- Anzeige Stücklistenartikel -->
            <div
              v-if="position.position.partList.isPartListArticle && app.settings.showPartsListItems"
              class="d-flex align-items-center pr-1">
              <i
                v-if="position.position.partList.isHead"
                class="fas fa-angle-down fa-lg fa-fw" />
              <i
                v-else
                class="fas fa-level-up fa-rotate-90 fa-lg fa-fw" />
            </div>

            <!-- Artikelbild -->
            <template v-if="!position.flags.isVariousOrTextPosition">
              <a :href="detailLink(position.article.matnr, position.article.maktx, position.article.maktx2)">
                <div class="article-image-wrapper d-flex align-items-center justify-content-center">
                  <img
                    :src="position.article.image | articleImage"
                    :alt="position.article.maktx">
                </div>
              </a>
            </template>
            <template v-else>
              <div class="article-image-wrapper d-flex align-items-center justify-content-center">
                <img
                  :src="position.article.image | articleImage"
                  :alt="position.article.maktx">
              </div>
            </template>
          </div>

          <!-- Artikelname, EEK-Label, Artikelnummer, Verfügbarkeit -->
          <div class="col">
            <!-- EEK-Label -->
            <app-article-atom-eek-label
              v-if="position.article.eek"
              :classes="position.article.eek"
              class="float-right pl-1" />

            <!-- Artikelname -->
            <div class="font-weight-bold font-size-lg">
              <template v-if="!position.flags.isVariousOrTextPosition">
                <a
                  :href="detailLink(position.article.matnr, position.article.maktx, position.article.maktx2)"
                  class="text-dark text-break">
                  {{ position.article.maktx }}
                  {{ position.article.maktx2 }}
                </a>
              </template>
              <template v-else>
                <span class="text-break">
                  {{ position.article.maktx }}
                  {{ position.article.maktx2 }}
                </span>
              </template>
            </div>

            <!-- Artikelnummer -->
            <div class="text-muted mb-2">
              <small>{{ $t('general.articleNumberShort') }} {{ position.article.matnrDisplay }}</small>
            </div>

            <!-- Verfügbarkeit -->
            <app-article-atom-availability
              v-if="app.user.hasPermission('SHOW_AVAILABILITY') && !position.hasError && position.flags.canHaveAvailablity"
              :is-loading="isAdditionalDataLoading"
              :availability="additionalData && additionalData.availability"
              class="mt-2" />
          </div>
        </div>
      </div>

      <!-- Menge -->
      <div class="col-5 col-sm-8 col-md-2 col-xl-1 d-flex align-items-center align-items-md-start justify-content-end mb-2">
        {{ position.position.amount | sapNumber }} {{ position.article.unitFormatted }}
      </div>

      <!-- Preise -->
      <div class="col-7 col-sm-4 col-md-3 col-xl-2 mb-2">
        <app-article-atom-prices-basket
          v-if="position.flags.canHavePrices"
          :retail-price="additionalData && additionalData.retailPrice"
          :retail-price-single="additionalData && additionalData.retailPriceSingle"
          :net-price="additionalData && additionalData.netPrice"
          :is-price-loading="isAdditionalDataLoading" />
      </div>
    </div>

    <!-- Zusatzinformationen -->
    <position-item-info
      :position="position.position"
      :flags="position.flags" />
  </div>
</template>

<script>
import { numberToSapNumber } from '@scripts/helper/sapFormat'
import { getSingleAdditionalPositionData } from '@scripts/modules/basket'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

import PositionItemInfo from '@components/pages/ordering-process/position-item-info.vue'
import { detailLink } from '@scripts/helper/generateLink'
export default {
  components: {
    'position-item-info': PositionItemInfo,
  },

  props: {
    position: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      additionalData: void 0,
      isAdditionalDataLoading: true,
      detailLink,
    }
  },

  computed: {
    amount () {
      return typeof this.position.amount !== 'undefined' ? numberToSapNumber(this.position.position.amount) : void 0
    },
  },

  created () {
    if (!this.position.hasError) {
      this.loadAdditionalPositionData()
    }
  },

  methods: {
    async loadAdditionalPositionData () {
      try {
        this.additionalData = await getSingleAdditionalPositionData(this.position.position.posnr)
        this.isAdditionalDataLoading = false
      } catch (e) {
        console.error()
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
