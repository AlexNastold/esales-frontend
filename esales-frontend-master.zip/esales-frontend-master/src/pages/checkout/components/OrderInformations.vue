<template>
  <div>
    <ul class="list-group">
      <!-- Bestellinformationen (Belegart, Ersteller, Erstelldatum) -->
      <li class="list-group-item">
        <div class="row">
          <div class="col-12 col-md-3">
            <h5>
              1. {{ $t('checkout.components.orderInformations.order') }}
            </h5>
          </div>
          <div class="col-12 col-md-9">
            <strong>{{ $t('checkout.components.orderInformations.documentType') }}</strong>: {{ order.typeText }}<br>
            <strong>{{ $t('checkout.components.orderInformations.createdBy') }}</strong>: {{ order.createdBy }}<br>
            <strong>{{ $t('checkout.components.orderInformations.createdAt') }}</strong>: {{ order.createdAt | datetime }}
          </div>
        </div>
      </li>

      <!-- Lieferdaten -->
      <li class="list-group-item">
        <div class="row">
          <div class="col col-md-3 order-1">
            <h5>
              2. {{ $t('checkout.components.orderInformations.shipmentData') }}
            </h5>
          </div>

          <div class="col-12 col-md-7 order-3 order-md-2">
            {{ shipment.typeText }}

            <template v-if="shipment.condition === ShipmentCondition.PICKUP">
              <br><strong>{{ $t('checkout.components.orderInformations.pickUpDate') }}</strong>: {{ shipment.date | date }}
              <br><strong>{{ $t('checkout.components.orderInformations.pickUpFrom') }}</strong>: {{ shipment.place }}
            </template>

            <template v-if="shipment.condition === ShipmentCondition.DELIVERY">
              <br><strong>{{ $t('checkout.components.orderInformations.desiredDeliveryDate') }}</strong>: {{ shipment.date | date }}
            </template>

            <template v-if="shipment.condition === ShipmentCondition.DELIVERY_IMMEDIATE">
              <br><strong>{{ $t('checkout.components.orderInformations.deliverWhenComplete') }}</strong>:
              <i
                class="far fa-fw"
                :class="shipment.deliverWhenComplete ? 'fa-check-square' : 'fa-square'" />
            </template>

            <template v-if="shipment.type === ShipmentType.DELIVERY">
              <br><strong>{{ $t('checkout.components.orderInformations.deliveryAddress') }}</strong>:
              {{ shipment.address.name1 }} {{ shipment.address.name2 }},
              {{ shipment.address.street }},
              {{ shipment.address.country }}-{{ shipment.address.postalCode }} {{ shipment.address.city }}
            </template>
          </div>

          <div class="col-auto col-md-2 text-md-right order-2 order-md-3">
            <button
              class="btn btn-sm btn-secondary d-print-none"
              @click="$refs.dialogDelivery.show()">
              <i class="fas fa-edit fa-fw" />
              {{ $t('checkout.components.orderInformations.edit') }}
            </button>
          </div>
        </div>
      </li>

      <!-- Zusatzinformationen (Bestellnummer, Projektbezeichnungen) -->
      <li class="list-group-item">
        <div class="row">
          <div class="col col-md-3 order-1">
            <h5>
              3. {{ $t('checkout.components.orderInformations.additionalOrderData') }}
            </h5>
          </div>

          <div class="col-12 col-md-7 order-3 order-md-2">
            <strong>{{ $t('checkout.components.orderInformations.orderNumber') }}</strong>: {{ additionalInformations.customOrderNumber }}<br>
            <strong>{{ $t('checkout.components.orderInformations.projectDescription1') }}</strong>: {{ additionalInformations.projectLabel1 }}<br>
            <strong>{{ $t('checkout.components.orderInformations.projectDescription2') }}</strong>: {{ additionalInformations.projectLabel2 }}
          </div>

          <div class="col-auto col-md-2 text-md-right order-2 order-md-3">
            <button
              class="btn btn-sm btn-secondary d-print-none"
              @click="$refs.dialogAdditionalData.show()">
              <i class="fas fa-edit fa-fw" />
              {{ $t('checkout.components.orderInformations.edit') }}
            </button>
          </div>
        </div>
      </li>

      <!-- Texte -->
      <li class="list-group-item">
        <div class="row">
          <div class="col col-md-3 order-1">
            <h5>
              4. {{ $t('checkout.components.orderInformations.texts') }}
            </h5>
          </div>

          <div class="col-12 col-md-7 order-3 order-md-2">
            <div
              v-for="text in textsWithContent"
              :key="text.id">
              <strong>{{ text.label }}</strong>:
              <br
                v-if="text.text"
                class="d-md-none">
              <span class="text-break">{{ text.text }}</span>
            </div>
            <div
              v-if="!textsWithContent.length"
              class="text-muted">
              {{ $t('checkout.components.orderInformations.noTexts') }}
            </div>
          </div>

          <div class="col-auto col-md-2 text-md-right order-2 order-md-3">
            <button
              class="btn btn-sm btn-secondary d-print-none"
              @click.prevent="$refs.dialogTexts.show()">
              <i class="fas fa-edit fa-fw" />
              {{ $t('checkout.components.orderInformations.edit') }}
            </button>
          </div>
        </div>
      </li>

      <!-- Zahlungsart -->
      <li
        v-if="paymentActive"
        class="list-group-item">
        <div class="row">
          <div class="col col-md-3 order-1">
            <h5>
              5. {{ $t('checkout.components.orderInformations.payment') }}
            </h5>
          </div>

          <div class="col-12 col-md-7 order-3 order-md-2">
            {{ payment.paymentMethodLabel }}
            <img
              v-for="(paymentIcon, index) in paymentIcons"
              :key="index"
              :src="paymentIcon"
              :title="payment.paymentMethodLabel"
              :alt="payment.paymentMethodLabel"
              class="payment-icon d-inline-block">
          </div>

          <div class="col-auto col-md-2 text-md-right order-2 order-md-3">
            <button
              class="btn btn-sm btn-secondary d-print-none"
              @click.prevent="$refs.dialogPayment.show()">
              <i class="fas fa-edit fa-fw" />
              {{ $t('checkout.components.orderInformations.edit') }}
            </button>
          </div>
        </div>
      </li>
    </ul>

    <dialog-delivery
      ref="dialogDelivery"
      @change="onChange" />

    <dialog-additional-data
      ref="dialogAdditionalData"
      @change="onChange" />

    <dialog-payment
      v-if="paymentActive"
      ref="dialogPayment"
      @change="onChange" />

    <dialog-texts
      ref="dialogTexts"
      @change="onChange" />
  </div>
</template>

<script>
import { ShipmentCondition, ShipmentType } from '@scripts/modules/basket'
import { getPaymentIcons } from '@scripts/modules/payment'

import DialogDelivery from '@components/dialogs/DialogDelivery.vue'
import DialogAdditionalData from './DialogAdditionalOrderData'
import DialogPayment from './DialogPayment.vue'
import DialogTexts from './DialogTexts.vue'

export default {
  components: {
    'dialog-additional-data': DialogAdditionalData,
    'dialog-delivery': DialogDelivery,
    'dialog-payment': DialogPayment,
    'dialog-texts': DialogTexts,
  },

  props: {
    additionalInformations: {
      type: Object,
      required: true,
    },
    shipment: {
      type: Object,
      required: true,
    },
    order: {
      type: Object,
      required: true,
    },
    payment: {
      type: Object,
      required: true,
    },
    texts: {
      type: Array,
      required: true,
    },
  },

  data () {
    return {
      ShipmentCondition,
      ShipmentType,
    }
  },

  computed: {
    textsWithContent () {
      return this.texts.filter((text) => text.text)
    },
    paymentActive () {
      return this.app.settings.payment.active
    },
    paymentIcons () {
      return getPaymentIcons(this.app.settings.payment.provider, this.payment.paymentMethod)
    },
  },

  methods: {
    onChange () {
      this.$emit('change')
    },
  },
}
</script>

<style lang="scss" scoped>
.payment-icon {
  height: 30px;
  margin-right: 5px;
  width: auto;
}
</style>

