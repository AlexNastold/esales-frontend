<template>
  <b-modal
    ref="modal"
    :ok-disabled="isProcessing || isLoading"
    :title="$t('checkout.components.dialogPayment.title')"
    header-bg-variant="primary"
    header-text-variant="white"
    @ok.prevent="save">
    <!-- Hinweis -->
    <div class="alert alert-info">
      {{ $t('checkout.components.dialogPayment.note') }}
    </div>

    <!-- Zahlungsarten Auswahl -->
    <div
      v-for="paymentType in paymentMethods"
      :key="paymentType.key"
      class="d-flex align-items-center mb-2">
      <div class="custom-control custom-radio d-block">
        <input
          :id="`payment-method-${paymentType.key}`"
          v-model="selectedPaymentMethod"
          :value="paymentType.key"
          name="payment-method"
          type="radio"
          class="custom-control-input">
        <label
          :for="`payment-method-${paymentType.key}`"
          class="custom-control-label">
          {{ paymentType.label }}
        </label>
      </div>
      <div class="ml-auto">
        <img
          v-for="(icon, index) in paymentType.icons"
          :key="index"
          :src="icon"
          :title="paymentType.label"
          :alt="paymentType.label"
          class="payment-icon">
      </div>
    </div>

    <template slot="modal-cancel">
      <i class="fas fa-times fa-fw" />
      {{ $t('general.cancel') }}
    </template>

    <template slot="modal-ok">
      <app-icon-state
        :is-loading="isProcessing"
        icon="fas fa-save" />
      {{ $t('general.save') }}
    </template>
  </b-modal>
</template>

<script>
import { applicationSettings } from '@scripts/app/settings'
import { getOrderPaymentMethod, setOrderPaymentMethod } from '@scripts/modules/basket'
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getPaymentIcons } from '@scripts/modules/payment'

export default {
  data () {
    return {
      isLoading: true,
      isProcessing: false,

      paymentMethods: applicationSettings.payment.paymentMethods.map((paymentMethod) => ({
        ...paymentMethod,
        icons: getPaymentIcons(applicationSettings.payment.provider, paymentMethod.key),
      })),

      selectedPaymentMethod: void 0,
    }
  },

  methods: {
    show () {
      this.loadPaymentMethod()
      this.$refs.modal.show()
    },

    hideDialog () {
      this.$refs.modal.hide()
    },

    async loadPaymentMethod () {
      try {
        this.selectedPaymentMethod = (await getOrderPaymentMethod()).paymentMethod
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },

    async save () {
      if (this.isProcessing || this.isLoading) {
        return
      }

      this.isProcessing = true

      try {
        await setOrderPaymentMethod(this.selectedPaymentMethod)
        showSuccessMessage(this.$t('payment.paymentSaved'))
        this.$emit('change')
        this.hideDialog()
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.isProcessing = false
    },
  },
}
</script>

<style lang="scss" scoped>
.payment-icon {
  height: 30px;
  margin-left: 5px;
  width: auto;
}
</style>

