<template>
  <div>
    <ul class="list-group">
      <!-- Bestellinformationen (Belegart, Erstelldatum) -->
      <li class="list-group-item">
        <div class="row">
          <div class="col-12 col-md-3">
            <h5>
              1. {{ $t('checkout.components.orderInformations.order') }}
            </h5>
          </div>
          <div class="col-12 col-md-9">
            <strong>{{ $t('checkout.components.orderInformations.documentType') }}</strong>: {{ order.typeText }}<br>
            <strong>{{ $t('checkout.components.orderInformations.createdAt') }}</strong>: {{ order.createdAt | datetime }}
          </div>
        </div>
      </li>

      <!-- Kontaktdaten -->
      <li class="list-group-item">
        <div class="row">
          <div class="col-12 col-md-3">
            <h5>
              3. {{ $t('checkout.components.orderInformations.contact') }}
            </h5>
          </div>
          <div class="col-12 col-md-9">
            <strong>{{ $t('checkout.components.orderInformations.email') }}</strong>: {{ contact.email }}<br>
            <strong>{{ $t('checkout.components.orderInformations.phoneNumber') }}</strong>: {{ contact.phone }}
          </div>
        </div>
      </li>

      <!-- Firmenanschrift -->
      <li class="list-group-item">
        <div class="row">
          <div class="col-12 col-md-3">
            <h5>
              4. {{ $t('checkout.components.orderInformations.companyAddress') }}
            </h5>
          </div>
          <div class="col-12 col-md-9">
            {{ companyAddress.title }} {{ companyAddress.firstname }} {{ companyAddress.lastname }}<br>
            {{ companyAddress.street }}<br>
            {{ companyAddress.country }}-{{ companyAddress.zipcode }} {{ companyAddress.city }}
          </div>
        </div>
      </li>

      <!-- Lieferanschrift -->
      <li class="list-group-item">
        <div class="row">
          <div class="col-12 col-md-3">
            <h5>
              5. {{ $t('checkout.components.orderInformations.deliveryAddress') }}
            </h5>
          </div>
          <div class="col-12 col-md-9">
            <template v-if="deviantDeliveryAddress">
              {{ deliveryAddress.title }} {{ deliveryAddress.firstname }} {{ deliveryAddress.lastname }}<br>
              {{ deliveryAddress.street }}<br>
              {{ deliveryAddress.country }}-{{ deliveryAddress.zipcode }} {{ deliveryAddress.city }}
            </template>
            <template v-else>
              {{ companyAddress.title }} {{ companyAddress.firstname }} {{ companyAddress.lastname }}<br>
              {{ companyAddress.street }}<br>
              {{ companyAddress.country }}-{{ companyAddress.zipcode }} {{ companyAddress.city }}
            </template>
          </div>
        </div>
      </li>

      <!-- Texte -->
      <li class="list-group-item">
        <div class="row">
          <div class="col col-md-3 order-1">
            <h5>
              6. {{ $t('checkout.components.orderInformations.texts') }}
            </h5>
          </div>

          <div class="col-12 col-md-7 order-3 order-md-2">
            <div
              v-for="text in textsWithContent"
              :key="text.id">
              <strong>{{ text.label }}</strong>:
              <br
                v-if="text.text"
                class="d-md-none">
              {{ text.text }}
            </div>
            <div
              v-if="!textsWithContent.length"
              class="text-muted">
              {{ $t('checkout.components.orderInformations.noTexts') }}
            </div>
          </div>

          <div class="col-auto col-md-2 text-md-right order-2 order-md-3">
            <button
              class="btn btn-sm btn-secondary d-print-none"
              @click.prevent="$refs.dialogTexts.show()">
              <i class="fas fa-edit fa-fw" />
              {{ $t('checkout.components.orderInformations.edit') }}
            </button>
          </div>
        </div>
      </li>

      <!-- Zahlungsart -->
      <li
        v-if="paymentActive"
        class="list-group-item">
        <div class="row">
          <div class="col col-md-3 order-1">
            <h5>
              7. {{ $t('checkout.components.orderInformations.payment') }}
            </h5>
          </div>

          <div class="col-12 col-md-7 order-3 order-md-2">
            {{ payment.paymentMethodLabel }}
            <img
              v-for="(paymentIcon, index) in paymentIcons"
              :key="index"
              :src="paymentIcon"
              :title="payment.paymentMethodLabel"
              :alt="payment.paymentMethodLabel"
              class="payment-icon d-inline-block">
          </div>

          <div class="col-auto col-md-2 text-md-right order-2 order-md-3">
            <button
              class="btn btn-sm btn-secondary d-print-none"
              @click.prevent="$refs.dialogPayment.show()">
              <i class="fas fa-edit fa-fw" />
              {{ $t('checkout.components.orderInformations.edit') }}
            </button>
          </div>
        </div>
      </li>
    </ul>

    <dialog-payment
      v-if="paymentActive"
      ref="dialogPayment"
      @change="onChange" />

    <dialog-texts
      ref="dialogTexts"
      @change="onChange" />
  </div>
</template>

<script>
import { getPaymentIcons } from '@scripts/modules/payment'

import DialogPayment from './DialogPayment.vue'
import DialogTexts from './DialogTexts.vue'

export default {
  components: {
    'dialog-payment': DialogPayment,
    'dialog-texts': DialogTexts,
  },

  props: {
    companyAddress: {
      type: Object,
      required: true,
    },
    contact: {
      type: Object,
      required: true,
    },
    deliveryAddress: {
      type: Object,
      required: true,
    },
    deviantDeliveryAddress: {
      type: Boolean,
      required: true,
    },
    order: {
      type: Object,
      required: true,
    },
    payment: {
      type: Object,
      required: true,
    },
    texts: {
      type: Array,
      required: true,
    },
  },

  computed: {
    paymentActive () {
      return this.app.settings.payment.active
    },
    paymentIcons () {
      return getPaymentIcons(this.app.settings.payment.provider, this.payment.paymentMethod)
    },
    textsWithContent () {
      return this.texts.filter((text) => text.text)
    },
  },

  methods: {
    onChange () {
      this.$emit('change')
    },
  },
}
</script>

<style lang="scss" scoped>
.payment-icon {
  height: 30px;
  margin-right: 5px;
  width: auto;
}
</style>
