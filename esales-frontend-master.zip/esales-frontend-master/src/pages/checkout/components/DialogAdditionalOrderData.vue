<template>
  <b-modal
    ref="modal"
    :ok-disabled="isProcessing || isLoading"
    :title="$t('checkout.components.dialogAdditionalOrderData.title')"
    header-bg-variant="primary"
    header-text-variant="white"
    size="lg"
    @ok.prevent="save">
    <app-loading-box v-if="isLoading" />
    <template v-else>
      <form @submit.prevent="save">
        <!-- Bestellnummer -->
        <div class="form-group">
          <label for="order-number">
            {{ $t('checkout.components.dialogAdditionalOrderData.orderNumber') }}
          </label>
          <input
            id="order-number"
            v-model="formCustomOrderNumber"
            :placeholder="$t('checkout.components.dialogAdditionalOrderData.orderNumberPlaceholder')"
            type="text"
            class="form-control"
            maxlength="35">
        </div>

        <!-- Projektbezeichnung 1 -->
        <div class="form-group">
          <label for="project-description-1">
            {{ $t('checkout.components.dialogAdditionalOrderData.projectDescription1') }}
          </label>
          <input
            id="project-description-1"
            v-model="formProjectLabel1"
            :placeholder="$t('checkout.components.dialogAdditionalOrderData.projectDescription1Placeholder')"
            type="text"
            class="form-control"
            maxlength="55">
        </div>

        <!-- Projektbezeichnung 2 -->
        <div class="form-group">
          <label for="project-description-2">
            {{ $t('checkout.components.dialogAdditionalOrderData.projectDescription2') }}
          </label>
          <input
            id="project-description-2"
            v-model="formProjectLabel2"
            :placeholder="$t('checkout.components.dialogAdditionalOrderData.projectDescription2Placeholder')"
            type="text"
            class="form-control"
            maxlength="55">
        </div>

        <!-- Ausgeblendeted Submit-Button (zum Abschicken des Formulars mit Enter) -->
        <button
          class="d-none"
          tabindex="-1"
          type="submit" />
      </form>
    </template>

    <template slot="modal-cancel">
      <i class="fas fa-times fa-fw" />
      {{ $t('general.cancel') }}
    </template>

    <template slot="modal-ok">
      <i class="fas fa-save fa-fw" />
      {{ $t('general.save') }}
    </template>
  </b-modal>
</template>

<script>
import { getShipmentData, saveAdditionalOrderData, ShipmentCondition } from '@scripts/modules/basket'
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {

  data () {
    return {
      isLoading: true,
      isProcessing: false,

      shipmentData: void 0,
      formCustomOrderNumber: void 0,
      formProjectLabel1: void 0,
      formProjectLabel2: void 0,

      formErrors: {
        formCustomOrderNumber: void 0,
      },

      ShipmentCondition,
    }
  },

  methods: {
    show () {
      this.loadShipmentData()
      this.$refs.modal.show()
    },

    hideDialog () {
      this.$refs.modal.hide()
    },

    /**
     * Lieferdaten laden und anzeigen
     */
    async loadShipmentData () {
      this.isLoading = true

      try {
        this.shipmentData = await getShipmentData()

        this.formCustomOrderNumber = this.shipmentData.additionalInfos.customOrderNumber
        this.formProjectLabel1 = this.shipmentData.additionalInfos.projectLabel1
        this.formProjectLabel2 = this.shipmentData.additionalInfos.projectLabel2

        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },

    async save () {
      if (this.isProcessing || this.isLoading) {
        return
      }

      this.isProcessing = true

      try {
        await saveAdditionalOrderData(
          this.formCustomOrderNumber,
          this.formProjectLabel1,
          this.formProjectLabel2,
        )

        // Alles okay
        showSuccessMessage(this.$t('checkout.components.dialogAdditionalOrderData.saved'))
        this.$emit('change')
        this.hideDialog()
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.isProcessing = false
    },
  },
}
</script>

