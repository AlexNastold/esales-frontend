import { RedirectMethod, redirect } from '@scripts/helper/redirect'
import { generateParamsForOciOrSap, getIdsData, getOciData, orderIds } from '@scripts/modules/basket'
import I18n from '@scripts/modules/i18n'
import { logout } from '@scripts/modules/auth'

/**
 * Beendet die Sitzung und sendet die Daten zurück and die Hookurl
 */
export async function idsBack () {
  const idsData = await getIdsData()
  await logout({ saveBasket: false })
  sendIdsData(idsData.hookurl, idsData.target, idsData.filecontent)
}

/**
 * Erstellt die Bestellung und sendet die Daten zurück and die Hookurl
 */
export async function idsOrderAndBack () {

  const idsData = await getIdsData()

  const orderData = await orderIds()

  if (orderData.vbeln !== '') {

    let xml = idsData.filecontent

    xml = xmlReplace(xml, 'RueckgabeKZ', I18n.t('basket.idsXmlReturnText'))
    xml = xmlReplace(xml, 'DeliveryDate', orderData.ldat)
    xml = xmlInsertAt(xml, '<OrderInfo>', `<OfferNo>${orderData.vbeln}</OfferNo>`)
    xml = xmlInsertAt(xml, '<OrderInfo>', `<OrderConfNo>${orderData.vbeln}</OrderConfNo>`)

    sendIdsData(idsData.hookurl, idsData.target, xml)
  }
}

function sendIdsData (hookurl: string, target: string, idsData: string) {
  redirect(
    hookurl,
    {
      hookurl,
      warenkorb: idsData,
    },
    RedirectMethod.POST,
    {
      enctype: 'multipart/form-data; charset=utf-8',
      target,
    },
  )
}

function xmlReplace (xml, key, value) {
  const startVal = '<' + key + '>'
  const endVal  = '</' + key + '>'
  const startLen = startVal.length
  const startIdx = xml.indexOf(startVal)
  if (startIdx !== -1) {
    const endIdx = xml.indexOf(endVal)
    if (endIdx !== -1 && endIdx > startIdx) {
      const teil1 = xml.substring(0, startIdx + startLen)
      const teil2 = xml.substring(endIdx)
      xml = teil1 + value + teil2
    }
  }
  return xml
}

function xmlInsertAt (xml, at, value) {
  return xml.replace(at, at + value)
}

/**
 * Sendet die Daten an das SAP zurück
 */
export async function sendDataSap () {
  const ociData = await getOciData()
  const params = generateParamsForOciOrSap(ociData)

  redirect(
    'SAPEVENT:BUTTON_CLICK',
    params.fields,
    RedirectMethod.POST,
    {
      target: '_top',
    },
  )
}

/**
 * Navigiert auf die OCI-URI mit den Parametern
 */
export async function sendDataOci () {
  const ociData = await getOciData()
  const params = generateParamsForOciOrSap(ociData)

  redirect(
    params.action,
    params.fields,
    RedirectMethod.POST,
    {
      target: params.target,
    },
  )
}
