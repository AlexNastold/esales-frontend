import { Permission, default as user } from '@scripts/app/user'
import { checkBudget, getBudgetText } from '@scripts/modules/budget'
import { confirmDialog, infoDialog, showErrorMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'
import I18n from '@scripts/modules/i18n'
import { checkOrderData } from '@scripts/modules/ordering-process-guestdata'
import { getCurrencySign } from '@scripts/helper/currencySign'
import { numberToSapCurrency } from '@scripts/helper/sapFormat'

export async function checkOrder () {
  if (!user.isLoggedIn) {
    try {
      await checkOrderData()
      return await confirmOrder()
    } catch (e) {
      if (e.code === ErrorCode.INVALID_OR_MISSING_PARAMS) {
        showErrorMessage(I18n.t('checkout.checkOrderDialog.guestOrder.errorMissingData'))
      } else {
        console.error(e)
        showTechnicalErrorMessage()
      }
      return false
    }
  }

  const budgetInformations = await checkBudget()

  // Budget nicht aktiv
  if (!budgetInformations.budgetActive) {
    return await confirmOrder()
  }

  // OLTP nicht verfügbar
  if (!budgetInformations.oltp.available) {
    if (budgetInformations.oltp.cancelIfNotAvailable) {
      //  Budgetuser dürfen ohne OLTP nicht bestellen -> Fehler anzeigen
      await infoDialog(
        I18n.t('checkout.checkOrderDialog.budget.title'),
        I18n.t('checkout.checkOrderDialog.budget.messageNoOltpAndStop'),
        {
          buttonText: I18n.t('general.ok'),
          type: 'danger',
        },
      )
      return false
    }

    //  Budgetuser dürfen ohne OLTP bestellen -> Meldung anzeigen
    return await confirmDialog(
      I18n.t('checkout.checkOrderDialog.budget.title'),
      I18n.t('checkout.checkOrderDialog.budget.messageNoOltp'),
      {
        buttonCancelText: `<i class="fas fa-times fa-fw"></i> ${I18n.t('general.cancel')}`,
        // tslint:disable-next-line:max-line-length
        buttonConfirmText: `<i class="fas fa-check fa-fw"></i> ${I18n.t('checkout.checkOrderDialog.budget.buttonOkLabel')}`,
        type: 'danger',
      },
    )
  }

  // Benutzer hat Budget nicht überschritten
  if (!budgetInformations.budgetExceeded) {
    return await confirmOrder()
  }

  let question = ''
  let budgetMessage = ''

  if (budgetInformations.budgetsExceeded.length) {
    if (user.hasPermission(Permission.SHOW_NET_PRICE)) {
      budgetMessage = `
        ${I18n.t('checkout.checkOrderDialog.budget.budgetTableHeadline')}<br>
        <table class="table table-sm">
          <thead>
            <tr>
              <th>${I18n.t('checkout.checkOrderDialog.budget.budgetType')}</th>
              <th class="text-right">${I18n.t('checkout.checkOrderDialog.budget.budgetAmount')}</th>
            </tr>
          </thead>
          <tbody>
          ${budgetInformations.budgetsExceeded.reduce((acc, budget) => acc + `
            <tr>
              <td>${getBudgetText(budget.type)}</td>
              <td class="text-right">${numberToSapCurrency(budget.amount)} ${getCurrencySign(budget.currency)}</td>
            </tr>
          `, '')}
          </tbody>
        </table>
      `
    } else {
      budgetMessage = `
        ${I18n.t('checkout.checkOrderDialog.budget.budgetTableHeadline')}<br>
        <table class="table table-sm">
          <thead>
            <tr>
              <th>${I18n.t('checkout.checkOrderDialog.budget.budgetType')}</th>
            </tr>
          </thead>
          <tbody>
          ${budgetInformations.budgetsExceeded.reduce((acc, budget) => acc + `
            <tr>
              <td>${getBudgetText(budget.type)}</td>
            </tr>
          `, '')}
          </tbody>
        </table>
      `
    }
  }

  if (budgetInformations.cancelIfBudgetExceeded) {
    // Bestellung darf nicht angelegt werden
    question =
      I18n.t('checkout.checkOrderDialog.budget.infoBudgetResponsivePerson', {
        name: budgetInformations.responsivePerson.fullName,
        userId: budgetInformations.responsivePerson.userId,
      }) + ' ' +
      I18n.t('checkout.checkOrderDialog.budget.question')
  } else {
    // Bestellung darf trotzdem angelegt werden
    question = I18n.t('checkout.checkOrderDialog.budget.question')
  }

  return await confirmDialog(
    I18n.t('checkout.checkOrderDialog.budget.title'),
    `${budgetMessage}${question}`,
    {
      buttonCancelText: `<i class="fas fa-times fa-fw"></i> ${I18n.t('general.cancel')}`,
      // tslint:disable-next-line:max-line-length
      buttonConfirmText: `<i class="fas fa-check fa-fw"></i> ${I18n.t('checkout.checkOrderDialog.budget.buttonOkLabel')}`,
      type: 'warning',
    },
  )
}

function confirmOrder () {
  return confirmDialog(
    I18n.t('checkout.checkOrderDialog.normal.title'),
    I18n.t('checkout.checkOrderDialog.normal.message'),
    {
      buttonCancelText: `<i class="fas fa-times fa-fw"></i> ${I18n.t('general.cancel')}`,
      // tslint:disable-next-line:max-line-length
      buttonConfirmText: `<i class="fas fa-check fa-fw"></i> ${I18n.t('checkout.checkOrderDialog.normal.buttonOkLabel')}`,
      type: 'info',
    },
  )
}
