<template>
  <div>
    <!-- Header -->
    <app-layout-header class="d-print-none" />

    <!-- Navigation -->
    <app-layout-navigation class="d-print-none" />

    <main class="page-checkout">
      <div class="container">
        <app-loading-box v-if="isLoading" />
        <template v-else>
          <!-- Process-Bar -->
          <process-bar
            :disable-next-steps="orderSummary && (basketIsEmpty || orderSummary.hasErrors)"
            step="checkout"
            class="d-print-none" />

          <div class="row">
            <!-- Überschrift -->
            <div class="col-lg">
              <h1 class="headline">
                {{ $t('checkout.headline') }}
              </h1>
            </div>

            <!-- Button PDF herunterladen Desktop -->
            <div class="col-lg-auto d-none d-lg-block d-print-none">
              <a
                v-if="canDownloadAsPdf"
                :href="downloadUriPdf"
                target="_blank"
                class="btn btn-secondary">
                <i class="fas fa-file-pdf fa-fw" />
                {{ $t('checkout.PDFDownloadButton') }}
              </a>
              <button
                v-else
                disabled
                class="btn btn-secondary">
                <i class="fas fa-file-pdf fa-fw" />
                {{ $t('checkout.PDFDownloadButton') }}
              </button>
            </div>
          </div>
          <!-- Button PDF herunterladen Mobile -->
          <div class="mb-3 d-lg-none">
            <a
              v-if="canDownloadAsPdf"
              :href="downloadUriPdf"
              target="_blank"
              class="btn btn-block btn-secondary">
              <i class="fas fa-file-pdf fa-fw" />
              {{ $t('checkout.PDFDownloadButton') }}
            </a>
            <button
              v-else
              disabled
              class="btn btn-block btn-secondary">
              <i class="fas fa-file-pdf fa-fw" />
              {{ $t('checkout.PDFDownloadButton') }}
            </button>
          </div>

          <!-- Fehlerhafte Positionen -->
          <div
            v-if="!basketIsEmpty && orderSummary.hasErrors"
            class="alert alert-danger mb-3">
            <i class="fas fa-exclamation-triangle fa-fw" />
            <span v-html="$t('checkout.faultyPositions')" />
          </div>

          <!-- Hinweis AGB -->
          <div
            v-else
            class="alert alert-info mb-3">
            <span v-html="$t('checkout.hintTerms')" />
          </div>

          <!-- Bestelldaten angemeldeter User -->
          <template v-if="app.user.isLoggedIn">
            <order-informations
              :order="orderSummary.order"
              :shipment="orderSummary.shipment"
              :payment="orderSummary.payment"
              :additional-informations="orderSummary.additionalInfos"
              :texts="orderSummary.texts"
              class="mb-4"
              @change="loadOrderSummary" />
          </template>

          <!-- Bestelldaten Gastuser -->
          <template v-else>
            <order-informations-guest
              :company-address="orderSummary.orderDataGuest.companyAddress"
              :contact="orderSummary.orderDataGuest.contact"
              :delivery-address="orderSummary.orderDataGuest.deliveryAddress"
              :deviant-delivery-address="orderSummary.orderDataGuest.deviantDeliveryAddress"
              :order="orderSummary.order"
              :payment="orderSummary.payment"
              :texts="orderSummary.texts"
              class="mb-4"
              @change="loadOrderSummary" />
          </template>

          <!-- Positionen -->
          <positions
            :positions="orderSummary.positions"
            class="mb-3" />

          <!-- Summe -->
          <app-article-list-sum
            :sum="orderSummary.sum"
            class="mb-3" />

          <!-- Buttons Bestellen -->
          <div class="d-md-flex justify-content-end">
            <!-- Buttons Mobile -->
            <div class="d-md-none">
              <!-- Normalbestellung-->
              <button
                v-if="app.state.orderVariant === OrderVariant.NORMAL"
                :disabled="orderButtonDisabled"
                type="button"
                class="btn btn-block btn-primary py-3"
                @click="order">
                <app-icon-state
                  :is-loading="isOrderInProcess"
                  icon="fas fa-check" />
                {{ $t('checkout.normalOrderButton') }}
              </button>

              <template v-else>
                <!-- Bestellung aufgeben und Daten per IDS übernehmen -->
                <button
                  v-if="app.state.orderVariant === OrderVariant.IDS"
                  :disabled="orderButtonDisabled"
                  type="button"
                  class="btn btn-block btn-primary"
                  @click="idsOrderAndBack">
                  <app-icon-state
                    :is-loading="isOrderInProcess"
                    icon="fas fa-check" />
                  {{ $t('checkout.idsOrderButton') }}
                </button>

                <!-- Daten per IDS/OCI/SAP übernehmen -->
                <send-data-button
                  :disabled="orderButtonDisabled"
                  class="btn-block mt-1" />
              </template>

              <!-- Abbrechen -->
              <a
                :href="cancelButtonUrl"
                class="btn btn-block btn-secondary mt-1">
                <i class="fas fa-arrow-left fa-fw" />
                {{ $t('checkout.cancelButton') }}
              </a>
            </div>

            <!-- Buttons -->
            <div class="d-none d-md-block d-print-none">
              <!-- Abbrechen -->
              <a
                :href="cancelButtonUrl"
                class="btn btn-secondary">
                <i class="fas fa-arrow-left fa-fw" />
                {{ $t('checkout.cancelButton') }}
              </a>

              <!-- Normalbestellung -->
              <button
                v-if="app.state.orderVariant === OrderVariant.NORMAL"
                :disabled="orderButtonDisabled"
                type="button"
                class="btn btn-primary px-3"
                @click="order">
                <app-icon-state
                  :is-loading="isOrderInProcess"
                  icon="fas fa-check" />
                {{ $t('checkout.normalOrderButton') }}
              </button>

              <template v-else>
                <!-- Bestellung aufgeben und Daten per IDS übernehmen -->
                <button
                  v-if="app.state.orderVariant === OrderVariant.IDS"
                  :disabled="orderButtonDisabled"
                  type="button"
                  class="btn btn-primary px-3"
                  @click="idsOrderAndBack">
                  <app-icon-state
                    :is-loading="isOrderInProcess"
                    icon="fas fa-check" />
                  {{ $t('checkout.idsOrderButton') }}
                </button>
                <!-- Daten per IDS/OCI/SAP übernehmen -->
                <send-data-button
                  :disabled="orderButtonDisabled"
                  class="btn-block mt-1" />
              </template>
            </div>
          </div>
        </template>
      </div>
      <div
        v-show="isOrderProcessedInBackend"
        class="in-progress-overlay">
        <app-loading-box />
        <div class="text-light text-center">
          <h3>
            {{ $t('checkout.waitingHeadline') }}
          </h3>
          {{ $t('checkout.waitingMessage') }}
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer class="d-print-none" />
  </div>
</template>

<script>
import { OrderVariant, getDownloadUri, getOrderPaymentMethod, getOrderSummary, order } from '@scripts/modules/basket'
import { RedirectMethod, redirect } from '@scripts/helper/redirect'
import { showErrorMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import browserStore from '@scripts/core/browserStore'
import { checkOrder } from './scripts/checkOrder'
import { getPaymentInfo } from '@scripts/modules/payment'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { idsOrderAndBack } from './scripts/order'

import ProcessBar from '@components/pages/ordering-process/process-bar.vue'
import SendDataButton from '@src/pages/basket/components/send-data-button.vue'

import OrderInformations from './components/OrderInformations.vue'
import OrderInformationsGuest from './components/order-informations-guest.vue'
import Positions from './components/positions.vue'

export default {
  components: {
    'order-informations': OrderInformations,
    'order-informations-guest': OrderInformationsGuest,
    positions: Positions,
    'process-bar': ProcessBar,
    'send-data-button': SendDataButton,
  },

  data () {
    return {
      OrderVariant,

      isLoading: true,
      isOrderInProcess: false,
      isOrderProcessedInBackend: false,
      orderSummary: void 0,
    }
  },

  computed: {
    basketIsEmpty () {
      if (!this.orderSummary || !this.orderSummary.positions) {
        return true
      }
      return this.orderSummary.positions.length === 0
    },
    canDownloadAsPdf () {
      return browserStore.get('InAppBrowser') === true ? false : !this.basketIsEmpty && !this.orderSummary.hasErrors
    },
    cancelButtonUrl () {
      if (this.app.user.isGuest && this.app.state.orderVariant !== OrderVariant.NONE) {
        return 'ordering-process-guestdata'
      } else {
        return 'basket'
      }
    },
    downloadUriPdf () {
      return getDownloadUri('BASKETPDF')
    },
    orderButtonDisabled () {
      return this.basketIsEmpty || this.orderSummary.hasErrors || this.isOrderInProcess
    },
  },

  created () {
    this.setPageTitle(this.$t('checkout.title'))
    this.loadOrderSummary()

    // Fehler von Payone ausgeben
    if (getQueryParameter('status') === 'ERROR') {
      console.error(getQueryParameter('errorcode') && ': ' && getQueryParameter('errormessage'))
      showErrorMessage(getQueryParameter('customermessage') || this.$t('general.unspecifiedErrorMessage'))
    }
  },

  methods: {

    async idsOrderAndBack () {
      this.isOrderInProcess = true
      if (await checkOrder()) {
        try {
          await idsOrderAndBack()
        } catch (e) {
          console.error(e)
          showErrorMessage(e.message || this.$t('general.unspecifiedErrorMessage'))
        }
      }
      this.loadOrderSummary()
      this.isOrderInProcess = false
    },

    async loadOrderSummary () {
      try {
        if (this.orderSummary) {
          this.orderSummary.positions = []
        }
        this.orderSummary = await getOrderSummary()
        this.isLoading = false
      } catch (e) {
        console.error()
        showTechnicalErrorMessage()
      }
    },

    async order () {
      this.isOrderInProcess = true
      if (await checkOrder()) {
        try {
          const paymentMethod = await getOrderPaymentMethod()

          if (paymentMethod.paymentMethod == 'cc') {
            redirect('ordering-process-payment-cc')
          } else if (paymentMethod.paymentMethod == 'wlt') {
            const paymentInfo = await getPaymentInfo()
            redirect(paymentInfo.clientURL, paymentInfo, RedirectMethod.POST)
          } else {
            this.isOrderProcessedInBackend = true
            await order()
            redirect('ordering-process-ordered')
          }
        } catch (e) {
          this.isOrderProcessedInBackend = false
          console.error(e)
          showErrorMessage(e.message || this.$t('general.unspecifiedErrorMessage'))
        }
      }
      this.loadOrderSummary()
      this.isOrderInProcess = false
    },


  },
}
</script>

<style lang="scss" scoped>
.in-progress-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(35, 35, 35, 0.9);
  z-index: 5000000;
  box-sizing: border-box;
}
</style>
