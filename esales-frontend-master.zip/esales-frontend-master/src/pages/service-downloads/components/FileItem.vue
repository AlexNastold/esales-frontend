<template>
  <a
    :href="file.url | externalUrl"
    target="_blank"
    class="list-group-item list-group-item-action d-flex">
    <div class="d-flex align-items-center">
      <i :class="icon" />&nbsp;
      <div class="filename">
        {{ file.name }}<span class="text-muted">
          .{{ file.ext }}
        </span>
      </div>
    </div>
  </a>
</template>

<script>
export default {
  props: {
    file: {
      required: true,
      type: Object,
    },
  },

  computed: {
    icon () {
      switch (this.file.ext) {
        case 'pdf':
          return 'fas fa-file-pdf fa-fw'
        case 'png':
        case 'jpg':
        case 'jpeg':
        case 'bmp':
        case 'gif':
        case 'tiff':
          return 'fas fa-image fa-fw'
        case 'zip':
        case 'rar':
        case 'tar':
          return 'fas fa-archive fa-fw'
        case 'doc':
        case 'docx':
          return 'fas fa-word fa-fw'
        case 'xls':
        case 'xlsx':
          return 'fas fa-excel fa-fw'
        case 'ppt':
        case 'pptx':
          return 'fas fa-powerpoint fa-fw'
        case 'txt':
          return 'fas fa-file-alt fa-fw'
        case 'mp4':
        case 'avi':
        case 'mov':
        case 'mkv':
          return 'fas fa-film fa-fw'
        case 'wav':
        case 'mp3':
        case 'wma':
        case 'ogg':
          return 'fas fa-file-audio fa-fw'
        default:
          return 'fas fa-file fa-fw'
      }
    },
  },
}
</script>
