<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-service-downloads">
      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="service">
              {{ $t('service.dashboard.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('serviceDownloads.page.breadcrumb') }}
          </li>
        </ol>

        <h1 class="headline">
          {{ $t('serviceDownloads.page.headline') }}
        </h1>

        <app-loading-box v-if="isLoading" />

        <!-- Keine Dateien -->
        <div
          v-else-if="!filelist.length"
          class="border rounded mb-3">
          <app-box-empty-list
            :headline="$t('serviceDownloads.page.listEmpty')"
            icon="fas fa-download">
            <span v-html="$t('serviceDownloads.page.listEmptyDescription')" />
          </app-box-empty-list>
        </div>

        <!-- Auflistung Dateien -->
        <div
          v-else
          class="list-group">
          <file-item
            v-for="(file, index) in filelist"
            :key="index"
            :file="file" />
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { getDownloads } from '@scripts/modules/service'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

import FileItem from './components/FileItem.vue'

export default {
  components: {
    'file-item': FileItem,
  },

  data () {
    return {
      filelist: [],
      isLoading: true,
    }
  },

  created () {
    this.setPageTitle(this.$t('serviceDownloads.page.title'))
    this.loadDownloads()
  },

  methods: {
    async loadDownloads () {
      try {
        this.filelist = await getDownloads()
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
