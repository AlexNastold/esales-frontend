<template>
  <div>
    <div class="card">
      <div class="card-header">
        {{ $t('resetPassword.components.resetPasswordForm.header') }}
      </div>
      <div class="card-body">
        <p>
          <strong>{{ $t('resetPassword.components.resetPasswordForm.costumerId') }}:</strong> {{ kunnr }}<br>
          <strong>{{ $t('resetPassword.components.resetPasswordForm.username') }}:</strong>
          <span v-if="userAlias">
            {{ userAlias }} ({{ userId }})
          </span>
          <span v-else>
            {{ userId }}
          </span>
        </p>
        <p>
          {{ $t('resetPassword.components.resetPasswordForm.description') }}.
        </p>
        <div
          v-show="errorMessage"
          class="alert alert-danger"
          role="alert"
          v-html="errorMessage" />
        <form
          novalidate
          @submit.prevent="resetPassword">
          <div class="row">
            <div class="col-12 col-lg-6">
              <div class="form-group">
                <label for="password">
                  {{ $t('resetPassword.components.resetPasswordForm.password') }} <span class="required" />
                </label>
                <input
                  id="password"
                  v-model="passwordNew"
                  :class="{ 'is-invalid': passwordHasError }"
                  :placeholder="$t('resetPassword.components.resetPasswordForm.passwordPlaceholder')"
                  type="password"
                  class="form-control">
              </div>
            </div>
            <div class="col-12 col-lg-6">
              <div class="form-group">
                <label for="password-confirmation">
                  {{ $t('resetPassword.components.resetPasswordForm.confirmPassword') }} <span class="required" />
                </label>
                <input
                  id="password-confirmation"
                  v-model="passwordNewConfirm"
                  :class="{ 'is-invalid': passwordHasError }"
                  :placeholder="$t('resetPassword.components.resetPasswordForm.confirmPasswordPlaceholder')"
                  type="password"
                  class="form-control">
              </div>
            </div>
          </div>
          <div class="d-block d-lg-none">
            <button
              :disabled="passwordResetInProcess"
              type="button"
              class="btn btn-block btn-primary"
              @click="tryPasswordReset">
              <app-icon-state
                :is-loading="passwordResetInProcess"
                icon="fas fa-lock" />
              {{ $t('resetPassword.components.resetPasswordForm.setPassword') }}
            </button>
          </div>
          <div class="d-none d-lg-block text-right">
            <button
              :disabled="passwordResetInProcess"
              type="button"
              class="btn btn-primary"
              @click="tryPasswordReset">
              <app-icon-state
                :is-loading="passwordResetInProcess"
                icon="fas fa-lock" />
              {{ $t('resetPassword.components.resetPasswordForm.setPassword') }}
            </button>
          </div>
        </form>
      </div>
    </div>
    <app-form-required-hint />
  </div>
</template>

<script>
import { setNewPassword } from '@scripts/modules/reset-password'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'

export default {
  props: {
    kunnr: {
      type: String,
      required: true,
    },
    userId: {
      type: String,
      required: true,
    },
    userAlias: {
      type: String,
      required: true,
    },
    token: {
      type: String,
      required: true,
    },
  },
  data () {
    return {
      passwordResetInProcess: false,
      errorMessage: '',

      passwordNew: '',
      passwordNewConfirm: '',

      passwordHasError: false,
    }
  },
  methods: {
    /**
     * Try to reset passwort
     */
    async tryPasswordReset () {
      this.passwordResetInProcess = true

      try {
        await setNewPassword(this.token, this.passwordNew, this.passwordNewConfirm)
        this.$emit('success')
      } catch (e) {
        this.errorMessage = ''
        this.passwordHasError = false

        if (e.code === ErrorCode.SHOP_LOCKED) {
          this.errorMessage = this.$t('resetPassword.components.resetPasswordForm.errorMessage.shopLocked')
        } else if (e.code === ErrorCode.RESET_PASSWORD_INVALID_TOKEN) {
          this.errorMessage = this.$t('resetPassword.components.resetPasswordForm.errorMessage.invalidToken')
        } else if (e.code === ErrorCode.USER_INITIAL) {
          this.errorMessage = this.$t('resetPassword.components.resetPasswordForm.errorMessage.initialUser')
        } else if (e.code === ErrorCode.RESET_PASSWORD_INVALID_PASSWORD) {
          this.errorMessage = e.message
          this.passwordHasError = true
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }

      this.passwordResetInProcess = false
    },
  },
}
</script>
