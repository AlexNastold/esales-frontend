<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-reset-password">
      <div class="container">
        <h1 class="headline">
          {{ $t('resetPassword.header') }}
        </h1>

        <app-loading-box v-if="isLoading" />

        <div v-if="!isLoading">
          <div v-if="!passwordResetSuccessful">
            <reset-password-form
              v-if="isTokenUseable"
              :token="token"
              :kunnr="kunnr"
              :user-id="userId"
              :user-alias="userAlias"
              @success="onSuccess" />

            <app-box-error v-if="errorMessage">
              <h3>{{ errorHeadline }}</h3>
              {{ errorMessage }}<br>

              <a
                v-if="shouldDisplayLinkToPasswordReset"
                href="forgot-password"
                class="btn btn-secondary mt-3">
                {{ $t('resetPassword.retry') }}
              </a>
            </app-box-error>
          </div>

          <app-box-success v-if="passwordResetSuccessful">
            <h3>{{ $t('resetPassword.successHeader') }}</h3>
            {{ $t('resetPassword.successMessage') }}<br>

            <a
              href="login"
              class="btn btn-secondary mt-3">
              {{ $t('resetPassword.backToLogin') }}
            </a>
          </app-box-success>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { ErrorCode } from '@scripts/modules/errors'
import { checkToken } from '@scripts/modules/reset-password'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

import ResetPasswordFormComponent from './components/reset-password-form.vue'

export default {
  components: {
    'reset-password-form': ResetPasswordFormComponent,
  },

  data () {
    return {
      isLoading: true,
      isTokenUseable: false,
      passwordResetSuccessful: false,

      kunnr: '',
      userAlias: '',
      userId: '',

      errorHeadline: '',
      errorMessage: '',
      shouldDisplayLinkToPasswordReset: false,
      token: getQueryParameter('token'),
    }
  },

  created () {
    this.setPageTitle(this.$t('resetPassword.title'))

    this.checkToken()
  },

  methods: {
    onSuccess () {
      this.passwordResetSuccessful = true
    },

    async checkToken () {
      // Kein Token übergeben
      if (!this.token) {
        this.errorHeadline = this.$t('resetPassword.errorHeader.missingToken')
        this.errorMessage = this.$t('resetPassword.errorMessage.missingToken')
        this.shouldDisplayLinkToPasswordReset = true
        this.isLoading = false
        return
      }

      try {
        const tokenInfo = await checkToken(this.token)

        // Token nicht gültig oder nicht benutzbar
        if (!tokenInfo.isValidToken) {
          if (!tokenInfo.doesTokenExist) {
            this.errorHeadline = this.$t('resetPassword.errorHeader.tokenNotFound')
            this.errorMessage = this.$t('resetPassword.errorMessage.tokenNotFound')
            this.shouldDisplayLinkToPasswordReset = true
          } else if (tokenInfo.isTokenExpired) {
            this.errorHeadline = this.$t('resetPassword.errorHeader.expiredToken')
            this.errorMessage = this.$t('resetPassword.errorMessage.expiredToken')
            this.shouldDisplayLinkToPasswordReset = true
          } else {
            this.errorHeadline = this.$t('resetPassword.errorHeader.other')
            this.errorMessage = this.$t('resetPassword.errorMessage.other')
            this.shouldDisplayLinkToPasswordReset = true
          }
          this.isLoading = false
          return
        }

        // Token gültig und benutzbar
        this.isTokenUseable = true
        this.kunnr = tokenInfo.user.kunnr
        this.userId = tokenInfo.user.userId
        this.userAlias = tokenInfo.user.userAlias
        this.isLoading = false
      } catch (e) {
        if (e.code === ErrorCode.USER_INITIAL) {
          this.errorHeadline = this.$t('resetPassword.errorHeader.initialUser')
          this.errorMessage = this.$t('resetPassword.errorMessage.initialUser')
          this.shouldDisplayLinkToPasswordReset = false
          this.isLoading = false
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },
  },
}
</script>
