<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-imprint">
      <div class="container">
        <h1 class="headline">
          {{ $t('imprint.headline') }}
        </h1>

        <app-loading-box v-if="isLoading" />
        <p
          v-else
          v-html="content" />
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getHtmlContent, PageId } from '@scripts/modules/html-content'

export default {
  data () {
    return {
      content: '',
      isLoading: true,
    }
  },

  async created () {
    this.setPageTitle(this.$t('imprint.title'))

    try {
      this.content = (await getHtmlContent(PageId.IMPRINT)).html
      this.isLoading = false
    } catch (e) {
      console.error(e)
      showTechnicalErrorMessage()
    }
  },
}
</script>
