<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-topsellers">
      <div class="container">
        <h1 class="headline">
          {{ $t('topseller.list.headline') }}
        </h1>

        <app-loading-box v-if="isLoading" />
        <div
          v-else
          class="row">
          <div
            v-for="article in articles"
            :key="article.matnr"
            class="col-12 col-sm-6 col-md-6 col-lg-4 col-xl-3 mb-4">
            <app-article-item
              :article="article"
              pitcher="topseller"
              type="tile" />
          </div>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { TopsellerType, getTopsellers  } from '@scripts/modules/topseller'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  data () {
    return {
      articles: [],
      isLoading: true,
    }
  },

  created () {
    this.setPageTitle(this.$t('topseller.list.title'))
    this.loadTopsellers()
  },

  methods: {
    async loadTopsellers () {
      try {
        this.articles = (await getTopsellers(TopsellerType.SHOP, { amount: 999999 })).topsellers
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
