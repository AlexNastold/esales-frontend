<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-consent-declaration">
      <div class="container">
        <h1 class="headline">
          {{ $t('consentDeclaration.headline') }}
        </h1>

        <app-loading-box v-if="isLoading" />
        <p
          v-else
          v-html="content" />
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getHtmlContent, PageId } from '@scripts/modules/html-content'

export default {
  data () {
    return {
      content: '',
      isLoading: true,
    }
  },

  async created () {
    this.setPageTitle(this.$t('consentDeclaration.title'))

    try {
      this.content = (await getHtmlContent(PageId.CONSENTDECLARATION)).html
      this.isLoading = false
    } catch (e) {
      console.error(e)
      showTechnicalErrorMessage()
    }
  },
}
</script>
