<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-registration">
      <div class="container">
        <h1 class="headline">
          {{ $t('registration.header') }}
        </h1>

        <form
          v-if="!isRegistrationSuccessful"
          novalidate
          @submit.prevent="register">
          <div
            v-show="errorMessage"
            class="alert alert-danger"
            role="alert"
            v-html="errorMessage" />
          <div class="row">
            <div class="col-12 col-lg-6 mb-4 mb-lg-none">
              <div class="card">
                <div class="card-header">
                  {{ $t('registration.userData.header') }}
                </div>
                <div class="card-body">
                  <div class="form-group">
                    <label for="customer-number">
                      {{ $t('registration.userData.userId') }} <span class="required" />
                    </label>
                    <input
                      id="customer-number"
                      v-model="formKunnr"
                      :class="{ 'is-invalid': formKunnrError }"
                      :placeholder="$t('registration.userData.userIdPlaceholder')"
                      type="text"
                      class="form-control">
                    <div
                      v-if="formKunnrError"
                      class="invalid-feedback"
                      v-html="formKunnrError" />
                  </div>
                  <div class="form-group">
                    <label for="salutation">
                      {{ $t('registration.userData.title') }} <span class="required" />
                    </label>
                    <select
                      id="salutation"
                      v-model="formTitle"
                      :class="{ 'is-invalid': formTitleError }"
                      class="form-control custom-select">
                      <option
                        v-for="title in titles"
                        :key="title.key"
                        :value="title.key"
                        v-text="title.label" />
                    </select>
                    <div
                      v-if="formTitleError"
                      class="invalid-feedback"
                      v-html="formTitleError" />
                  </div>
                  <div class="form-group">
                    <label for="lastname-company">
                      {{ $t('registration.userData.company') }} <span class="required" />
                    </label>
                    <input
                      id="lastname-company"
                      v-model="formLastname"
                      :class="{ 'is-invalid': formLastnameError }"
                      :placeholder="$t('registration.userData.companyPlaceholder')"
                      type="text"
                      class="form-control">
                    <div
                      v-if="formLastnameError"
                      class="invalid-feedback"
                      v-html="formLastnameError" />
                  </div>
                  <div class="form-group">
                    <label for="firstname">
                      {{ $t('registration.userData.firstName') }}
                    </label>
                    <input
                      id="firstname"
                      v-model="formFirstname"
                      :placeholder="$t('registration.userData.firstNamePlaceholder')"
                      type="text"
                      class="form-control">
                  </div>
                  <div class="form-group">
                    <label for="alias">
                      {{ $t('registration.userData.alias') }}
                    </label>
                    <input
                      id="alias"
                      v-model="formAlias"
                      :class="{ 'is-invalid': formAliasError }"
                      :placeholder="$t('registration.userData.aliasPlaceholder')"
                      type="text"
                      class="form-control">
                    <div
                      v-if="formAliasError"
                      class="invalid-feedback"
                      v-html="formAliasError" />
                  </div>
                  <div class="form-group">
                    <label for="email">
                      {{ $t('registration.userData.mail') }}
                    </label>
                    <input
                      id="email"
                      v-model="formEmailAddress"
                      :class="{ 'is-invalid': formEmailAddressError }"
                      :placeholder="$t('registration.userData.mailPlaceholder')"
                      type="email"
                      class="form-control">
                    <div
                      v-if="formEmailAddressError"
                      class="invalid-feedback"
                      v-html="formEmailAddressError" />
                  </div>
                  <div class="form-group">
                    <label for="telephone">
                      {{ $t('registration.userData.phone') }}
                    </label>
                    <input
                      id="telephone"
                      v-model="formPhone"
                      :class="{ 'is-invalid': formPhoneError }"
                      :placeholder="$t('registration.userData.phonePlaceholder')"
                      type="text"
                      class="form-control">
                    <div
                      v-if="formPhoneError"
                      class="invalid-feedback"
                      v-html="formPhoneError" />
                  </div>
                  <div class="form-group">
                    <label for="fax">
                      {{ $t('registration.userData.fax') }}
                    </label>
                    <input
                      id="fax"
                      v-model="formFax"
                      :class="{ 'is-invalid': formFaxError }"
                      :placeholder="$t('registration.userData.faxPlaceholder')"
                      class="form-control"
                      type="text">
                    <div
                      v-if="formFaxError"
                      class="invalid-feedback"
                      v-html="formFaxError" />
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-lg-6">
              <div
                v-if="showSettingscard"
                class="card">
                <div class="card-header">
                  {{ $t('registration.settings.header') }}
                </div>
                <div class="card-body">
                  <div
                    v-if="languages.length > 1"
                    class="form-group">
                    <label for="language">
                      {{ $t('registration.settings.language') }} <span class="required" />
                    </label>
                    <select
                      id="language"
                      v-model="formLanguage"
                      :class="{ 'is-invalid': formLanguageError }"
                      class="form-control custom-select">
                      <option
                        v-for="language in languages"
                        :key="language.key"
                        :value="language.key"
                        v-text="language.label" />
                    </select>
                    <div
                      v-if="formLanguageError"
                      class="invalid-feedback"
                      v-html="formLanguageError" />
                  </div>
                  <div
                    v-if="currencies.length > 1"
                    class="form-group">
                    <label for="currency">
                      {{ $t('registration.settings.currency') }} <span class="required" />
                    </label>
                    <select
                      id="currency"
                      v-model="formCurrency"
                      :class="{ 'is-invalid': formCurrencyError }"
                      class="form-control custom-select">
                      <option
                        v-for="currency in currencies"
                        :key="currency.key"
                        :value="currency.key"
                        v-text="currency.label" />
                    </select>
                    <div
                      v-if="formCurrencyError"
                      class="invalid-feedback"
                      v-html="formCurrencyError" />
                  </div>
                  <div
                    v-if="salesOrganisations.length > 1"
                    class="form-group">
                    <label for="sales-data">
                      {{ $t('registration.settings.salesData') }} <span class="required" />
                    </label>
                    <select
                      id="sales-data"
                      v-model="formSalesOrganisation"
                      :class="{ 'is-invalid': formSalesOrganisationError }"
                      class="form-control custom-select">
                      <option
                        v-for="salesOrganisation in salesOrganisations"
                        :key="salesOrganisation.key"
                        :value="salesOrganisation.key"
                        v-text="salesOrganisation.label" />
                    </select>
                    <div
                      v-if="formSalesOrganisationError"
                      class="invalid-feedback"
                      v-html="formSalesOrganisationError" />
                  </div>
                  <vue-recaptcha
                    v-if="captchaActive"
                    ref="recaptcha"
                    :sitekey="captchaKey"
                    class="mb-3"
                    @verify="onCaptchaVerify" />
                </div>
              </div>
              <app-form-required-hint />

              <div class="d-block d-lg-none">
                <button
                  :disabled="isRegistrationInProcess"
                  type="submit"
                  class="btn btn-block btn-primary mt-3">
                  <app-icon-state
                    :is-loading="isRegistrationInProcess"
                    icon="fas fa-user-plus" />
                  {{ $t('registration.register') }}
                </button>
                <a
                  href="login"
                  class="btn btn-block btn-secondary mt-3">
                  <i class="fas fa-times fa-fw" />
                  {{ $t('general.cancel') }}
                </a>
              </div>
              <div class="d-none d-lg-block text-right">
                <a
                  href="login"
                  class="btn btn-secondary">
                  <i class="fas fa-times fa-fw" />
                  {{ $t('general.cancel') }}
                </a>
                <button
                  :disabled="isRegistrationInProcess"
                  type="submit"
                  class="btn btn-primary">
                  <app-icon-state
                    :is-loading="isRegistrationInProcess"
                    icon="fas fa-user-plus" />
                  {{ $t('registration.register') }}
                </button>
              </div>
            </div>
          </div>
        </form>

        <app-box-success v-if="isRegistrationSuccessful">
          <h3>{{ $t('registration.registrationSuccess') }}</h3>
          {{ $t('registration.successMessage') }}<br>

          <a
            href="login"
            class="btn btn-secondary mt-3">
            {{ $t('registration.backToLogin') }}
          </a>
        </app-box-success>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import VueRecaptcha from 'vue-recaptcha'

import { RegistrationErrorFields, register } from '@scripts/modules/registration'
import { ErrorCode } from '@scripts/modules/errors'
import { pageSettingsRegistration } from '@scripts/app/settings'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  components: {
    'vue-recaptcha': VueRecaptcha,
  },

  data () {
    return {
      captchaActive: pageSettingsRegistration.captchaActive,
      captchaKey: pageSettingsRegistration.captchaKey,
      currencies: pageSettingsRegistration.currencies,
      languages: pageSettingsRegistration.languages,
      salesOrganisations: pageSettingsRegistration.salesOrganisations.map((salesOrganisation) => {
        salesOrganisation.key = `${salesOrganisation.vkorg}|${salesOrganisation.vtweg}`
        salesOrganisation.label = `${salesOrganisation.vkorgText} | ${salesOrganisation.vtwegText}`
        return salesOrganisation
      }),
      titles: pageSettingsRegistration.titles,

      errorMessage: '',
      isRegistrationInProcess: false,
      isRegistrationSuccessful: false,
      newUserId: '',

      formAlias: '',
      formCaptchaResponse: '',
      formCurrency: pageSettingsRegistration.currencies[0] ? pageSettingsRegistration.currencies[0].key : '',
      formEmailAddress: '',
      formFax: '',
      formFirstname: '',
      formKunnr: '',
      formLanguage: pageSettingsRegistration.languages[0] ? pageSettingsRegistration.languages[0].key : '',
      formLastname: '',
      formPhone: '',
      formSalesOrganisation: pageSettingsRegistration.salesOrganisations[0]
        ? `${pageSettingsRegistration.salesOrganisations[0].vkorg}|${pageSettingsRegistration.salesOrganisations[0].vtweg}`
        : '',
      formSaveIpConfirm: '',
      formTitle: pageSettingsRegistration.titles[0] ? pageSettingsRegistration.titles[0].key : '',

      formAliasError: '',
      formCurrencyError: '',
      formEmailAddressError: '',
      formFaxError: '',
      formKunnrError: '',
      formLanguageError: '',
      formLastnameError: '',
      formPhoneError: '',
      formSalesOrganisationError: '',
      formSaveIpConfirmError: '',
      formTitleError: '',
    }
  },

  computed: {
    formVkorg () {
      return this.formSalesOrganisation.split('|')[0]
    },
    formVtweg () {
      return this.formSalesOrganisation.split('|')[1]
    },
    showSettingscard () {
      return this.languages.length > 1
        || this.currencies.length > 1
        || this.salesOrganisations.length > 1
        || this.captchaActive
    },
  },

  created () {
    this.setPageTitle(this.$t('registration.title'))
  },

  methods: {
    /**
     * Store the RECAPTCHA response
     *
     * @param {string} response - The RECAPTCHA response
     */
    onCaptchaVerify (response) {
      this.formCaptchaResponse = response
    },

    resetCaptcha () {
      this.formCaptchaResponse = ''
      this.$refs.recaptcha.reset()
    },

    /**
     * Register
     */
    async register () {
      if (this.isRegistrationInProcess) {
        return
      }

      this.isRegistrationInProcess = true
      this.errorMessage = ''
      this.resetFieldErrors()

      try {
        this.newUserId = await register({
          alias: this.formAlias,
          captcha: this.formCaptchaResponse,
          currency: this.formCurrency,
          emailAddress: this.formEmailAddress,
          fax: this.formFax,
          firstname: this.formFirstname,
          kunnr: this.formKunnr,
          language: this.formLanguage,
          lastname: this.formLastname,
          phone: this.formPhone,
          saveIpAccepted: this.formSaveIpConfirm,
          title: this.formTitle,
          vkorg: this.formVkorg,
          vtweg: this.formVtweg,
        })
        this.isRegistrationSuccessful = true
      } catch (e) {
        if (e.code === ErrorCode.CAPTCHA_INVALID) {
          this.errorMessage = this.$t('registration.errorCaptcha')
        } else if (e.code === ErrorCode.INVALID_FIELDS) {
          this.errorMessage = this.$t('general.invalidFieldsMessage')
          this.showFieldErrors(e.fieldErrors)
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
        if (this.$refs.recaptcha) {
          this.resetCaptcha()
        }
      }

      this.isRegistrationInProcess = false
    },

    /**
     * Show the field errors
     *
     * @param {any} [fieldErrors] - Field errors
     */
    showFieldErrors (fieldErrors) {
      this.resetFieldErrors()
      for (const fieldname in fieldErrors) {
        if (Object.prototype.hasOwnProperty.call(fieldErrors, fieldname)) {
          const message = fieldErrors[fieldname].join('<br>')
          if (fieldname === RegistrationErrorFields.ALIAS) {
            this.formAliasError = message
          } else if (fieldname === RegistrationErrorFields.CURRENCY) {
            this.formCurrencyError = message
          } else if (fieldname === RegistrationErrorFields.EMAIL_ADDRESS) {
            this.formEmailAddressError = message
          } else if (fieldname === RegistrationErrorFields.FAX) {
            this.formFaxError = message
          } else if (fieldname === RegistrationErrorFields.KUNNR) {
            this.formKunnrError = message
          } else if (fieldname === RegistrationErrorFields.LANGUAGE) {
            this.formLanguageError = message
          } else if (fieldname === RegistrationErrorFields.LASTNAME) {
            this.formLastnameError = message
          } else if (fieldname === RegistrationErrorFields.PHONE) {
            this.formPhoneError = message
          } else if (fieldname === RegistrationErrorFields.SALES_ORG) {
            this.formSalesOrganisationError = message
          } else if (fieldname === RegistrationErrorFields.SAVE_IP_CONFIRM) {
            this.formSaveIpConfirmError = message
          } else if (fieldname === RegistrationErrorFields.TITLE) {
            this.formTitleError = message
          }
        }
      }
    },

    /**
     * Reset the field errors
     */
    resetFieldErrors () {
      this.formAliasError = ''
      this.formCurrencyError = ''
      this.formEmailAddressError = ''
      this.formFaxError = ''
      this.formKunnrError = ''
      this.formLanguageError = ''
      this.formLastnameError = ''
      this.formPhoneError = ''
      this.formSalesOrganisationError = ''
      this.formSaveIpConfirmError = ''
      this.formTitleError = ''
    },
  },
}
</script>
