<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-campaign mt-0">
      <!-- Ladeanzeige -->
      <app-loading-box v-if="isLoading" />

      <!-- Aktion nicht gefunden -->
      <app-box-oops
        v-else-if="!campaign"
        link-title="Zurück zur Übersicht"
        link-href="campaigns">
        {{ $t('campaign.notFoundMessage') }}
      </app-box-oops>

      <template v-else>
        <!-- Banner -->
        <div
          v-if="campaign.banner"
          :style="`background-image: url(${$options.filters.externalImage(campaign.banner)})`"
          class="banner-image">
          <div class="campaign-caption p-2 p-md-4">
            <div class="container">
              <h1 class="text-uppercase mb-1">
                {{ campaign.name }}
              </h1>
              <div class="slogan">
                {{ campaign.slogan }}
              </div>
              <small class="valid-to">
                {{ $t('campaign.validTo', { date: campaign.validTo }) }}
              </small>
            </div>
          </div>
        </div>

        <div class="container mt-3">
          <!-- Aktions-Zeilen -->
          <div
            v-for="row in campaign.rows"
            :key="row.row"
            class="row">
            <!-- Aktions-Element -->
            <campaign-element
              v-for="element in row.elements"
              :key="element.id"
              :element="element" />
          </div>

          <!-- Zurück zur Übersicht -->
          <div class="text-center mt-3">
            <a
              class="btn btn-outline-primary text-uppercase font-weight-bold px-3 py-2"
              href="campaigns">
              {{ $t('campaign.gotoList') }}
            </a>
          </div>
        </div>
      </template>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { ErrorCode } from '@scripts/modules/errors'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { getCampaign } from '@scripts/modules/campaigns'

import CampaignElement from './components/campaign-element.vue'

import { gtagTrackViewItem } from '@scripts/modules/gtag'

export default {
  components: {
    'campaign-element': CampaignElement,
  },

  data () {
    return {
      campaign: void 0,
      isLoading: true,
    }
  },

  created () {
    this.loadCampaign()
  },

  methods: {
    async loadCampaign () {
      try {
        const campaignIdFromUrl = getQueryParameter('id')
        this.campaign = await getCampaign(campaignIdFromUrl)
        this.setPageTitle(this.$t('campaign.title', {
          campaignName: this.campaign.name,
        }))
        gtagTrackViewItem({ id: this.campaign.id, name: this.campaign.name })
        this.isLoading = false
      } catch (e) {
        if (e.code === ErrorCode.NOT_FOUND) {
          // Ist okay, nur nicht "this.campaign" setzen
          this.setPageTitle(this.$t('campaign.notFoundTitle'))
          this.isLoading = false
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },

    getElementColClass (width) {
      switch (width) {
        case 1: return 'col-12 col-md-6 col-xl-3'
        case 2: return 'col-12 col-md-6'
        default: return 'col'
      }
    },
  },
}
</script>

<style lang="scss" src="./campaign.scss"></style>
