<template>
  <div
    :class="colClass"
    class="mb-3">
    <campaign-element-banner
      v-if="element.type === CampaignElementType.BANNER"
      :banner="element.banner" />
    <campaign-element-headline
      v-else-if="element.type === CampaignElementType.HEADLINE"
      :text="element.text" />
    <campaign-element-article
      v-else-if="element.type === CampaignElementType.ARTICLE"
      :article="element.article"
      :width="element.width" />
    <campaign-element-text
      v-else-if="element.type === CampaignElementType.TEXT"
      :text="element.text" />
  </div>
</template>

<script>
import { CampaignElementType } from '@scripts/modules/campaigns'

import CampaignElementArticle from './campaign-element-article'
import CampaignElementBanner from './campaign-element-banner'
import CampaignElementHeadline from './campaign-element-headline'
import CampaignElementText from './campaign-element-text'

export default {
  components: {
    'campaign-element-banner': CampaignElementBanner,
    'campaign-element-headline': CampaignElementHeadline,
    'campaign-element-article': CampaignElementArticle,
    'campaign-element-text': CampaignElementText,
  },
  props: {
    element: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      CampaignElementType,
    }
  },

  computed: {
    colClass () {
      if (this.element.width === 1) {
        return 'col-12 col-md-6 col-xl-3'
      }
      if (this.element.width === 2) {
        return 'col-12 col-md-6'
      }
      return 'col'
    },
  },
}
</script>
