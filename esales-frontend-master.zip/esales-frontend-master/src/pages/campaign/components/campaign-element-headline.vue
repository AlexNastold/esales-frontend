<template>
  <div class="campaign-element-headline rounded text-white text-uppercase p-3">
    <h3 class="m-0">
      {{ text }}
    </h3>
  </div>
</template>

<script>
export default {
  props: {
    text: {
      type: String,
      required: true,
    },
  },
}
</script>

