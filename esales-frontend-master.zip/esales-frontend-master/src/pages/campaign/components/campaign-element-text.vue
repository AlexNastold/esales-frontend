<template>
  <div
    class="rounded bg-light text-dark h-100 p-3 mb-3"
    v-html="text" />
</template>

<script>
export default {
  props: {
    text: {
      type: String,
      required: true,
    },
  },
}
</script>

