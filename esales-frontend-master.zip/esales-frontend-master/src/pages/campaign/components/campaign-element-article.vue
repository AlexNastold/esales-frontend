<template>
  <div class="campaign-element-article bg-light d-flex align-items-stretch flex-column h-100 p-3">
    <!-- Wenn Element-Breite 25% -->
    <div v-if="width === 1">
      <!-- Artikelbild -->
      <!-- Ohne Fehler: Bild verlinken -->
      <a
        v-if="!hasError"
        :href="detailLink(article.matnr, article.maktx, article.maktx2)">
        <div class="image-wrapper d-flex align-items-center align-self-stretch justify-content-center mb-2">
          <img
            :src="article.image | articleImage"
            :alt="article.maktx">
        </div>
      </a>
      <!-- Mit Fehler: Bild nicht verlinken -->
      <div
        v-else
        class="image-wrapper d-flex align-items-center align-self-stretch justify-content-center mb-2">
        <img
          :src="article.image | articleImage"
          :alt="article.maktx">
      </div>

      <!-- Artikelinformationen -->
      <div class="mb-2">
        <!-- EEK-Label -->
        <app-article-atom-eek-label
          v-if="article.eek"
          :classes="article.eek"
          class="float-right pl-1" />

        <!-- Artikelname -->
        <div class="font-weight-bold font-size-lg">
          <!-- Ohne Fehler: Artikelname verlinken -->
          <a
            v-if="!hasError"
            :href="detailLink(article.matnr, article.maktx, article.maktx2)"
            class="text-dark text-break">
            {{ article.maktx }}
            {{ article.maktx2 }}
          </a>
          <!-- Mit Fehler: Artikelname nicht verlinken -->
          <span
            v-else
            class="text-dark text-break">
            {{ article.maktx }}
            {{ article.maktx2 }}
          </span>
        </div>

        <!-- Artikelnummer -->
        <div class="text-muted">
          <small>{{ $t('general.articleNumberShort') }}: {{ article.matnrDisplay }}</small>
        </div>

        <!-- Verfügbarkeit (bei Fehler ausblenden) -->
        <app-article-atom-availability
          v-if="app.user.hasPermission('SHOW_AVAILABILITY') && !hasError"
          :is-loading="isAdditionalDataLoading"
          :availability="additionalData && additionalData.availability"
          class="mt-2" />

        <!-- Artikel-Badges -->
        <app-article-badges
          :is-loading="isAdditionalDataLoading"
          :already-purchased="additionalData && additionalData.alreadyPurchased"
          :additional-material-categories="article.additionalMaterialCategories"
          class="mt-1" />

        <!-- Fehlermeldung -->
        <div
          v-if="hasError"
          class="text-danger">
          <i class="fas fa-exclamation-triangle" />
          {{ errorMessage }}
        </div>
      </div>
    </div>

    <!-- Wenn Element-Breite 50% -->
    <div
      v-if="width === 2"
      class="row">
      <!-- Artikelbild -->
      <div class="col-12 col-lg-auto mb-2">
        <!-- Ohne Fehler: Bild verlinken -->
        <a
          v-if="!hasError"
          :href="detailLink(article.matnr, article.maktx, article.maktx2)">
          <div class="image-wrapper d-flex justify-content-center align-items-start">
            <img
              :src="article.image | articleImage"
              :alt="article.maktx">
          </div>
        </a>
        <!-- Mit Fehler: Bild nicht verlinken -->
        <div
          v-else
          class="image-wrapper d-flex justify-content-center align-items-start">
          <img
            :src="article.image | articleImage"
            :alt="article.maktx">
        </div>
      </div>

      <!-- Artikelinformationen -->
      <div class="col-12 col-lg mb-2">
        <!-- EEK-Label -->
        <app-article-atom-eek-label
          v-if="article.eek"
          :classes="article.eek"
          class="float-right pl-1" />

        <!-- Artikelname -->
        <div class="font-weight-bold font-size-lg">
          <!-- Ohne Fehler: Artikelname verlinken -->
          <a
            v-if="!hasError"
            :href="detailLink(article.matnr, article.maktx, article.maktx2)"
            class="text-dark text-break">
            {{ article.maktx }}
            {{ article.maktx2 }}
          </a>
          <!-- Mit Fehler: Artikelname nicht verlinken -->
          <span
            v-else
            class="text-dark text-break">
            {{ article.maktx }}
            {{ article.maktx2 }}
          </span>
        </div>

        <!-- Artikelnummer -->
        <div class="text-muted">
          <small>{{ $t('general.articleNumberShort') }}: {{ article.matnrDisplay }}</small>
        </div>

        <!-- Artikel-Badges -->
        <app-article-badges
          :is-loading="isAdditionalDataLoading"
          :additional-material-categories="article.additionalMaterialCategories"
          class="mt-2" />

        <!-- Verfügbarkeit (bei Fehler ausblenden) -->
        <app-article-atom-availability
          v-if="app.user.hasPermission('SHOW_AVAILABILITY') && !hasError"
          :is-loading="isAdditionalDataLoading"
          :availability="additionalData && additionalData.availability"
          class="mt-2" />

        <!-- Fehlermeldung -->
        <div
          v-if="hasError"
          class="text-danger">
          <i class="fas fa-exclamation-triangle" />
          {{ errorMessage }}
        </div>
      </div>
    </div>

    <!-- Preise (bei Fehler ausblenden)  -->
    <app-article-atom-prices
      v-if="!hasError"
      :retail-price="additionalData && additionalData.retailPrice"
      :net-price="additionalData && additionalData.netPrice"
      :is-price-loading="isAdditionalDataLoading"
      class="mt-auto ml-auto text-right" />

    <!-- Menge, Werfen (bei Fehler deaktivieren) -->
    <div
      v-if="app.user.hasPermission('BASKET_ADD_ARTICLES')"
      class="d-flex justify-content-end mt-2">
      <!-- Wenn Element-Breite 25% -->
      <app-form-input-quantity
        v-if="width === 1"
        v-model="amount"
        :disabled="hasError"
        :unit="article.unitFormatted"
        :stepsize="article.stepsize"
        width="auto"
        class="d-flex d-sm-none d-md-flex d-lg-none d-xl-flex"
        btn-type="btn-tertiary" />

      <app-form-input-quantity
        v-if="width === 1"
        v-model="amount"
        :disabled="hasError"
        :unit="article.unitFormatted"
        :stepsize="article.stepsize"
        class="d-none d-sm-flex d-md-none d-lg-flex d-xl-none"
        btn-type="btn-tertiary" />

      <!-- Wenn Element-Breite 50% -->
      <app-form-input-quantity
        v-if="width === 2"
        v-model="amount"
        :disabled="hasError"
        :unit="article.unitFormatted"
        :stepsize="article.stepsize"
        class="d-flex d-sm-none d-md-flex d-lg-none"
        width="auto"
        btn-type="btn-tertiary" />

      <app-form-input-quantity
        v-if="width === 2"
        v-model="amount"
        :disabled="hasError"
        :unit="article.unitFormatted"
        :stepsize="article.stepsize"
        class="d-none d-sm-flex d-md-none d-lg-flex"
        btn-type="btn-tertiary" />

      <!-- Werfen -->
      <app-action-button-basket
        :disabled="hasError"
        :is-icon-only="true"
        :matnr="article.matnr"
        :amount="amount"
        pitcher="campaign"
        class="ml-1" />
    </div>
  </div>
</template>

<script>
import { getSingleAdditionalArticleData } from '@scripts/modules/additional-article-data'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { detailLink } from '@scripts/helper/generateLink'
export default {
  props: {
    article: {
      type: Object,
      required: true,
    },
    width: {
      type: Number,
      default: 1,
    },
  },

  data () {
    return {
      amount: this.article.amount?this.article.amount:void 0,
      additionalData: void 0,
      detailLink,
      hasError: false,
      errorMessage: '',
      isAdditionalDataLoading: true,
    }
  },

  created () {
    this.loadAdditionalArticleData()
  },

  methods: {
    async loadAdditionalArticleData () {
      try {
        this.additionalData = await getSingleAdditionalArticleData(this.article.matnr)
        this.hasError = this.additionalData.hasError
        this.errorMessage = this.additionalData.error
        this.isAdditionalDataLoading = false
      } catch (e) {
        console.error()
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>

