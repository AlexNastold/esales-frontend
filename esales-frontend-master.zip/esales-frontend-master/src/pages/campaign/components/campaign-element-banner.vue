<template>
  <div class="campaign-element-banner">
    <div
      :style="`background-image: url(${$options.filters.externalImage(banner)})`"
      class="image" />
  </div>
</template>

<script>
export default {
  props: {
    banner: {
      type: String,
      required: true,
    },
  },
}
</script>

