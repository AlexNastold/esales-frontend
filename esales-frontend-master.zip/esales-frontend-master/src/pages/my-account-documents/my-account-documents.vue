<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-documents">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountDocuments.headline')"
        page="documents" />

      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountDocuments.breadcrumb') }}
          </li>
        </ol>

        <div class="row">
          <!-- Vergleichsliste -->
          <div class="col-lg-3">
            <compare-list :documents="app.state.docComparison.documents" />
          </div>

          <!-- Filter, Belegliste -->
          <div class="col-lg-9">
            <h3>{{ $t('myAccountDocuments.filter') }}</h3>

            <!-- Filter -->
            <filters
              :is-loading="isLoading"
              @init="onFilterInit"
              @submit="onFilterSubmit" />

            <!-- Belege -->
            <app-loading-box v-if="isLoading" />
            <div
              v-else-if="selectDoctypeMessage"
              class="alert alert-warning text-center">
              {{ $t('myAccountDocuments.noDoctypeHint') }}
            </div>
            <template v-else>
              <div class="row mb-3">
                <!-- Anzahl Ergebnisse -->
                <div
                  :class="{'mb-3' : documents.length}"
                  class="col-12 col-sm mb-sm-0 d-flex align-items-center">
                  <h3 class="m-0">
                    {{ $t('myAccountDocuments.resultsHeadline', { count: documents.length }) }}
                  </h3>
                </div>

                <!-- Sortierung -->
                <div
                  v-if="documents.length"
                  class="col-12 col-sm-auto d-flex align-items-center justify-content-sm-end">
                  <div class="mr-2">
                    {{ $t('myAccountDocuments.sortLabel') }}
                  </div>
                  <div class="options">
                    <select
                      v-model="sort"
                      class="form-control custom-select">
                      <option :value="1">
                        {{ $t('myAccountDocuments.sort.dateAsc') }}
                      </option>
                      <option :value="2">
                        {{ $t('myAccountDocuments.sort.dateDesc') }}
                      </option>
                      <option :value="3">
                        {{ $t('myAccountDocuments.sort.docNumberAsc') }}
                      </option>
                      <option :value="4">
                        {{ $t('myAccountDocuments.sort.docNumberDesc') }}
                      </option>
                      <template
                        v-if="currentDocumentType === DocumentType.AUFTRAG
                          || currentDocumentType === DocumentType.ANGEBOT
                          || currentDocumentType === DocumentType.HAUPTABRUF
                          || currentDocumentType === DocumentType.ANFRAGE
                          || currentDocumentType === DocumentType.RETURN
                        ">
                        <option :value="5">
                          {{ $t('myAccountDocuments.sort.orderNumberAsc') }}
                        </option>
                        <option :value="6">
                          {{ $t('myAccountDocuments.sort.orderNumberDesc') }}
                        </option>
                        <option :value="7">
                          {{ $t('myAccountDocuments.sort.statusAsc') }}
                        </option>
                        <option :value="8">
                          {{ $t('myAccountDocuments.sort.statusDesc') }}
                        </option>
                        <option :value="9">
                          {{ $t('myAccountDocuments.sort.projectNameAsc') }}
                        </option>
                        <option :value="10">
                          {{ $t('myAccountDocuments.sort.projectNameDesc') }}
                        </option>
                        <option :value="11">
                          {{ $t('myAccountDocuments.sort.creatorNameAsc') }}
                        </option>
                        <option :value="12">
                          {{ $t('myAccountDocuments.sort.creatorNameDesc') }}
                        </option>
                        <option :value="13">
                          {{ $t('myAccountDocuments.sort.validFromAsc') }}
                        </option>
                        <option :value="14">
                          {{ $t('myAccountDocuments.sort.validFromDesc') }}
                        </option>
                        <option :value="15">
                          {{ $t('myAccountDocuments.sort.validToAsc') }}
                        </option>
                        <option :value="16">
                          {{ $t('myAccountDocuments.sort.validToDesc') }}
                        </option>
                      </template>
                      <template
                        v-if="currentDocumentType === DocumentType.RECHNUNG
                          || currentDocumentType === DocumentType.OFFENE_POSTEN
                          || currentDocumentType === DocumentType.GUTSCHRIFT
                        ">
                        <option :value="17">
                          {{ $t('myAccountDocuments.sort.dueDateAsc') }}
                        </option>
                        <option :value="18">
                          {{ $t('myAccountDocuments.sort.dueDateDesc') }}
                        </option>
                        <option :value="19">
                          {{ $t('myAccountDocuments.sort.sumAsc') }}
                        </option>
                        <option :value="20">
                          {{ $t('myAccountDocuments.sort.sumDesc') }}
                        </option>
                      </template>
                      <template
                        v-if="currentDocumentType === DocumentType.RECHNUNG
                          || currentDocumentType === DocumentType.GUTSCHRIFT
                        ">
                        <option :value="21">
                          {{ $t('myAccountDocuments.sort.commissionAsc') }}
                        </option>
                        <option :value="22">
                          {{ $t('myAccountDocuments.sort.commissionDesc') }}
                        </option>
                      </template>
                    </select>
                  </div>
                </div>
              </div>

              <!-- Belegliste -->
              <document-list
                :documents="documents"
                :has-sum="hasSum"
                :sum="sum"
                :sum-currency="sumCurrency" />
            </template>
          </div>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import moment from 'moment'

import { getQueryParameter } from '@scripts/helper/urlParams'
import { updateUrlQueryString } from '@scripts/helper/urlUpdate'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import {
  DocumentListSortDirection,
  DocumentListSortField,
  DocumentTimespan,
  DocumentType,
  getDocumentList,
} from '@scripts/modules/documents'

import MyAccountHeader from '@components/pages/my-account/header.vue'

import CompareList from './components/compare-list.vue'
import DocumentList from './components/document-list.vue'
import Filters from './components/filters.vue'

export default {
  components: {
    'compare-list': CompareList,
    'document-list': DocumentList,
    filters: Filters,
    'my-account-header': MyAccountHeader,
  },

  data () {
    return {
      DocumentType,

      currentDocumentType: void 0,
      isLoading: false,
      selectDoctypeMessage: false,

      documents: [],
      hasSum: void 0,
      sum: void 0,
      sumCurrency: void 0,

      filters: void 0,
      sort: parseInt(getQueryParameter('sort'), 10) || 1,
    }
  },

  computed: {
    sortField () {
      switch (this.sort) {
        case 3:
        case 4:
          return DocumentListSortField.DOCUMENT_NUMBER
        case 5:
        case 6:
          return DocumentListSortField.ORDER_NUMBER
        case 7:
        case 8:
          return DocumentListSortField.STATUS
        case 9:
        case 10:
          return DocumentListSortField.PROJECT_NAME
        case 11:
        case 12:
          return DocumentListSortField.CREATED_BY
        case 13:
        case 14:
          return DocumentListSortField.VALID_FROM
        case 15:
        case 16:
          return DocumentListSortField.VALID_TO
        case 17:
        case 18:
          return DocumentListSortField.DUE_DATE
        case 19:
        case 20:
          return DocumentListSortField.BRUTTO_SUM
        case 21:
        case 22:
          return DocumentListSortField.COMMISSION
        default: return DocumentListSortField.CREATE_DATE
      }
    },
    sortDirection () {
      switch (this.sort) {
        case 2:
        case 3:
        case 5:
        case 7:
        case 9:
        case 11:
        case 13:
        case 15:
        case 17:
        case 19:
          return DocumentListSortDirection.ASC
        default: return DocumentListSortDirection.DESC
      }
    },
  },

  watch: {
    sort () {
      this.loadDocuments()
    },
  },

  created () {
    this.setPageTitle(this.$t('myAccountDocuments.title'))
  },

  methods: {
    onFilterInit (filters) {
      this.filters = filters
      this.loadDocuments()
    },

    onFilterSubmit (filters) {

      this.filters = filters
      // Wenn sich der Belegtyp geändert hat, wird die Sortierung auf Datum absteigend gesetzt
      if (this.currentDocumentType !== filters.doctype) {
        this.sort = 1
      }

      this.loadDocuments()
    },

    async loadDocuments () {
      this.updateUrl()

      if (!this.filters.doctype) {
        this.selectDoctypeMessage = true
        return
      }

      this.isLoading = true

      try {
        const documentsInfo = await getDocumentList(this.filters.doctype, {
          customFilterQuery: this.filters.customFilterValue,
          customFilterType: this.filters.customFilter,
          dateFrom: this.filters.dateFrom,
          dateTo: this.filters.dateTo,
          documentStatus: this.filters.status,
          sortDirection: this.sortDirection,
          sortField: this.sortField,
          timespan: this.filters.timespan,
        })
        this.documents = documentsInfo.documents
        this.hasSum = documentsInfo.hasSum
        this.sum = documentsInfo.sum
        this.sumCurrency = documentsInfo.sumCurrency

        this.selectDoctypeMessage = false
        this.currentDocumentType = this.filters.doctype
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.isLoading = false
    },

    updateUrl () {
      const dateFrom = this.filters.timespan === DocumentTimespan.CUSTOM && this.filters.dateFrom
        ? moment(this.filters.dateFrom).format('YYYY-MM-DD')
        : void 0
      const dateTo = this.filters.timespan === DocumentTimespan.CUSTOM && this.filters.dateTo
        ? moment(this.filters.dateTo).format('YYYY-MM-DD')
        : void 0

      updateUrlQueryString({
        ...this.filters,
        dateFrom,
        dateTo,
        sort: this.filters.doctype ? this.sort : void 0,
      })
    },
  },
}
</script>

<style lang="scss" src="./my-account-documents.scss"></style>
