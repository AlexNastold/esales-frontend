<template>
  <div
    :class="{ 'show-list': listVisible }"
    class="parent">
    <!-- Backdrop -->
    <div
      class="backdrop"
      @click="closeSidebar" />

    <!-- Mobile Button Vergleichsliste ein-/ausblenden -->
    <button
      v-if="!listVisible"
      type="button"
      class="btn btn-secondary d-flex d-lg-none mobile-show-hide-compare-list-btn"
      @click="toggleSidebar">
      <i class="fas fa-clipboard-list fa-fw fa-2x p-1" />
      <span class="badge badge-pill badge-primary small py-1 amount-documents">
        {{ documents.length }}
      </span>
      <!-- {{ $t('myAccountDocuments.components.compareList.headline') }} ({{ documents.length }}) bla
      <i class="fas fa-caret-right fa-fw align-self-center ml-auto" /> -->
    </button>

    <!-- Auflistung Dokumente in Vergleichsliste -->
    <div
      :class="{'px-3 py-2': listVisible}"
      class="list-container">
      <!-- Mobile Button Vergleichsliste ausblenden -->
      <div class="d-lg-none mb-2">
        <button
          type="button"
          class="btn btn-secondary"
          @click="closeSidebar">
          <i class="fas fa-times fa-fw" />
          {{ $t('general.dialogCloseLabel') }}
        </button>
      </div>

      <h3>{{ $t('myAccountDocuments.components.compareList.headline') }}</h3>

      <!-- Dokument Listeneintrag -->
      <compare-list-item
        v-for="doc in documents"
        :key="`${doc.documentType}-${doc.documentId}`"
        :doc="doc"
        :active="activeDoc && doc.documentId === activeDoc.documentId"
        @removedoc="removeDocument" />

      <!-- Button Liste leeren -->
      <button
        :disabled="documents.length === 0"
        type="button"
        class="btn btn-link m-0 mt-2  p-0 d-flex align-items-center"
        @click="clearList">
        <i class="fas fa-trash-alt fa-fw mr-1" />
        {{ $t('myAccountDocuments.components.compareList.clearList') }}
      </button>
    </div>
  </div>
</template>

<script>
import { showSuccessMessage, showErrorMessage } from '@scripts/modules/dialogs'
import { removeFromDocCompareList, clearDocCompareList } from '@scripts/modules/document-comparison-list'

import CompareListItem from './compare-list-item.vue'

export default {
  components: {
    'compare-list-item': CompareListItem,
  },

  props: {
    documents: {
      type: Array,
      default () {
        return []
      },
    },
    activeDoc: {
      type: Object,
      default () {
        return void 0
      },
    },
  },

  data () {
    return {
      listVisible: false,
    }
  },

  methods: {
    removeDocument (doc) {
      try {
        removeFromDocCompareList(this.documents, doc)
        showSuccessMessage(this.$t('myAccountDocuments.components.compareList.removeDocSuccessMessage', {
          document: `${this.$options.filters.documentTypeTitle(doc.documentType)} ${doc.documentIdDisplay}`,
        }))
      } catch (e) {
        console.error(e)
        showErrorMessage(e.message)
      }
    },
    clearList () {
      try {
        clearDocCompareList(this.documents)
        showSuccessMessage(this.$t('myAccountDocuments.components.compareList.clearListSuccessMessage'))
      } catch (e) {
        console.error(e)
        showErrorMessage(e.message)
      }
    },
    toggleSidebar () {
      this.listVisible = !this.listVisible
    },
    closeSidebar () {
      this.listVisible = false
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

$sidebar-breakpoint: md;

.parent {

  .mobile-show-hide-compare-list-btn {
    position: fixed;
    right: 0;
    top: 200px;
    z-index: 100;

    .amount-documents {
      position: absolute;
      right: 5px;
      top: 5px;
    }
  }

  .backdrop {
    background: rgba(0, 0, 0, .5);
    bottom: 0;
    left: -100%;
    opacity: 0;
    position: fixed;
    top: 0;
    transition: opacity .2s ease-in-out, left 0s ease-in-out .2s;
    width: 100%;
    z-index: $zindex-navigation-menu;
  }

  &.show-list {
    .list-container {
      @include media-breakpoint-down($sidebar-breakpoint) {
        width: 50%;
      }
      @include media-breakpoint-down(xs) {
        width: 75%;
      }
    }

    .backdrop {
      left: 0;
      opacity: 1;
      transition: opacity .2s ease-in-out;
    }
  }

  .list-container {

    @include media-breakpoint-down($sidebar-breakpoint) {
      background: white;
      bottom: 0;
      box-shadow: 0 0 5px 0 rgba(0, 0, 0, .5);
      overflow: auto;
      position: fixed;
      right: 0;
      top: 0;
      transition: width .2s ease-in-out;
      width: 0;
      z-index: $zindex-navigation-menu;
    }
  }
}
</style>
