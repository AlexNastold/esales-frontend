<template>
  <div class="row">
    <!-- Belegname, Nummer Datum -->
    <div class="col-12 col-lg-3 col-xl-4 mb-2 mb-lg-0">
      <a :href="link">
        <strong class="text-dark font-size-lg">
          {{ doc.documentType | documentTypeTitle }} {{ doc.documentIdDisplay }}
        </strong><br>
        <span class="text-muted">
          {{ doc.createDate | date }}
        </span>
      </a>
    </div>

    <!-- Bestellnunmer, Projektbezeichnung -->
    <div class="col-12 col-lg-3 col-xl-3 mb-2 mb-lg-0">
      <div class="row">
        <div class="col-12 text-muted">
          {{ $t('myAccountDocuments.components.documentTypes.orderNumber') }}
        </div>
        <div class="col-12 mb-1">
          {{ doc.orderNumber }}
        </div>

        <div class="col-12 text-muted">
          {{ $t('myAccountDocuments.components.documentTypes.projectName') }}
        </div>
        <div class="col-12">
          {{ doc.projectName }}
        </div>
      </div>
    </div>

    <!-- Nettobetrag -->
    <div class="col-12 col-md-6 col-lg-3 col-xl-2 text-right mb-2 mb-md-0">
      <div class="text-muted">
        {{ $t('myAccountDocuments.components.documentTypes.netPrice') }}
      </div>
      <strong>{{ doc.netPrice | price }} {{ doc.currency | currency }}</strong>
    </div>

    <!-- Ersteller -->
    <div class="col-12 col-md-6 col-lg-3">
      <div class="text-muted">
        {{ $t('myAccountDocuments.components.documentTypes.creatorName') }}
      </div>
      {{ doc.createdBy }}
    </div>

    <!-- Zur Vergleichliste hinzufügen -->
    <div class="col-12 d-md-flex justify-content-md-end mt-2">
      <add-to-compare-list-btn @click.native="$emit('addtocomparelist', doc)" />
    </div>
  </div>
</template>

<script>
import AddToCompareListBtn from '@components/pages/documents/add-to-compare-list.vue'

export default {
  components: {
    'add-to-compare-list-btn': AddToCompareListBtn,
  },

  props: {
    doc: {
      type: Object,
      required: true,
    },
    link: {
      type: String,
      required: true,
    },
  },
}
</script>
