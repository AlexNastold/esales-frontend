<template>
  <div class="row">
    <!-- Belegname, Nummer Datum -->
    <div class="col-12 col-lg-3 col-xl-4 mb-2 mb-lg-0">
      <strong class="text-dark font-size-lg">
        {{ doc.documentType | documentTypeTitle }} {{ doc.documentIdDisplay }}
      </strong><br>
      <span class="text-muted">
        {{ $t('myAccountDocuments.components.documentTypes.createDate') }}: {{ doc.createDate | date }}
      </span><br>
      <span
        v-if="datesDiffer"
        class="text-muted">
        {{ $t('myAccountDocuments.components.documentTypes.dueDate') }}: {{ doc.dueDate | date }}
      </span>
    </div>

    <!-- Summe -->
    <div class="col-12 col-lg-2 offset-lg-7 offset-xl-6 text-right">
      <div class="text-muted">
        {{ $t('myAccountDocuments.components.documentTypes.retailPrice') }}
      </div>
      <strong>{{ doc.retailPrice | price }} {{ doc.currency | currency }}</strong>
    </div>

    <!-- Referenzbeleg anzeigen -->
    <div class="col-12 d-md-flex justify-content-md-end mt-2">
      <a
        :href="link"
        class="btn btn-tertiary"
        :class="{'disabled': !link}">
        <i class="fas fa-eye" />
        {{ $t('myAccountDocuments.components.documentTypes.showDocumentButton') }}
      </a>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    doc: {
      type: Object,
      required: true,
    },
    link: {
      type: String,
      required: true,
    },
  },

  computed: {
    datesDiffer () {
      return this.doc.createDate === this.doc.dueDate
    },
  },
}
</script>
