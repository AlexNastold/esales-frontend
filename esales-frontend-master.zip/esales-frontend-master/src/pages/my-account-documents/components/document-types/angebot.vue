<template>
  <div class="row">
    <!-- Belegname, Nummer Datum -->
    <div class="col-12 col-md-6 col-lg-3 mb-2 mb-lg-0">
      <a :href="link">
        <strong class="text-dark font-size-lg">
          {{ doc.documentType | documentTypeTitle }} {{ doc.documentIdDisplay }}
        </strong><br>
        <span class="text-muted">
          {{ doc.createDate | date }}
        </span>
      </a>
    </div>

    <!-- Status -->
    <div class="col-12 col-md-6 col-lg-2 mb-2 mb-lg-0">
      <span class="text-muted">
        {{ $t('myAccountDocuments.components.documentTypes.status') }}
      </span><br>
      <document-status-badge :status="doc.status" />
    </div>

    <!-- Gültig von, Gültig bis -->
    <div class="col-12 col-md-6 col-lg-2 mb-2 mb-lg-0">
      <div class="row">
        <div class="col-4 col-lg-12 text-muted mb-1 mb-lg-0">
          {{ $t('myAccountDocuments.components.documentTypes.validFrom') }}
        </div>
        <div class="col-8 col-lg-12 mb-1">
          {{ doc.validFrom | date }}
        </div>

        <div class="col-4 col-lg-12 text-muted">
          {{ $t('myAccountDocuments.components.documentTypes.validTo') }}
        </div>
        <div class="col-8 col-lg-12">
          {{ doc.validTo | date }}
        </div>
      </div>
    </div>

    <!-- Bestellnummer, Projektbezeichnung -->
    <div class="col-md-6 col-lg-3">
      <div class="row">
        <div class="col-12 text-muted">
          {{ $t('myAccountDocuments.components.documentTypes.orderNumber') }}
        </div>
        <div class="col-12 mb-1">
          {{ doc.orderNumber }}
        </div>

        <div class="col-12 text-muted">
          {{ $t('myAccountDocuments.components.documentTypes.projectName') }}
        </div>
        <div class="col-12">
          {{ doc.projectName }}
        </div>
      </div>
    </div>

    <!-- Ersteller -->
    <div class="col-12 col-lg-2 mt-2 mt-lg-0">
      <div class="text-muted">
        {{ $t('myAccountDocuments.components.documentTypes.creatorName') }}
      </div>
      {{ doc.createdBy }}
    </div>

    <!-- Zur Vergleichliste hinzufügen -->
    <div class="col-12 d-md-flex justify-content-md-end mt-2">
      <add-to-compare-list-btn @click.native="$emit('addtocomparelist', doc)" />
    </div>
  </div>
</template>

<script>
import DocumentStatusBadge from '@components/pages/documents/status.vue'
import AddToCompareListBtn from '@components/pages/documents/add-to-compare-list.vue'

export default {
  components: {
    'document-status-badge': DocumentStatusBadge,
    'add-to-compare-list-btn': AddToCompareListBtn,
  },

  props: {
    doc: {
      type: Object,
      required: true,
    },
    link: {
      type: String,
      required: true,
    },
  },
}
</script>

