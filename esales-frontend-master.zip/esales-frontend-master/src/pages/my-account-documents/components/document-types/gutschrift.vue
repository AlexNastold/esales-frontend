<template>
  <div class="row">
    <!-- Belegname, Nummer Datum -->
    <div class="col-12 col-lg-3 mb-2 mb-lg-0">
      <a :href="link">
        <strong class="text-dark font-size-lg">
          {{ doc.documentType | documentTypeTitle }} {{ doc.documentIdDisplay }}
        </strong><br>
        <span class="text-muted">
          {{ doc.createDate | date }}
        </span>
      </a>
    </div>

    <!-- Bestellnummer, Fällig am -->
    <div class="col-12 col-lg-6 mb-2 mb-lg-0">
      <div class="row">
        <div class="col-12 col-lg-4 text-muted mb-lg-1">
          {{ $t('myAccountDocuments.components.documentTypes.orderNumber') }}
        </div>
        <div class="col-12 col-lg-8 mb-1">
          {{ doc.orderNumber }}
        </div>

        <div class="col-12 col-lg-4 text-muted">
          {{ $t('myAccountDocuments.components.documentTypes.dueDate') }}
        </div>
        <div class="col-12 col-lg-8">
          {{ doc.billDate | date }}
        </div>
      </div>
    </div>

    <!-- Bruttobetrag -->
    <div class="col-2 col-lg-3 col-xl-2 offset-xl-1 text-right">
      <div class="text-muted">
        {{ $t('myAccountDocuments.components.documentTypes.retailPrice') }}
      </div>
      <strong>{{ doc.retailPrice | price }} {{ doc.currency | currency }}</strong>
    </div>

    <!-- Zur Vergleichliste hinzufügen -->
    <div class="col-12 d-md-flex justify-content-md-end mt-2">
      <add-to-compare-list-btn @click.native="$emit('addtocomparelist', doc)" />
    </div>
  </div>
</template>

<script>
import AddToCompareListBtn from '@components/pages/documents/add-to-compare-list.vue'

export default {
  components: {
    'add-to-compare-list-btn': AddToCompareListBtn,
  },

  props: {
    doc: {
      type: Object,
      required: true,
    },
    link: {
      type: String,
      required: true,
    },
  },
}
</script>
