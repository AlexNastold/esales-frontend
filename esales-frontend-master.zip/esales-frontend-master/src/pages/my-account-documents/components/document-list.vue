<template>
  <div>
    <!-- Keine Belege -->
    <div
      v-if="!documents.length"
      class="border rounded mb-3">
      <app-box-empty-list
        :headline="$t('myAccountDocuments.listEmpty')"
        icon="fas fa-file">
        <span v-html="$t('myAccountDocuments.components.documentList.listEmptyDescription')" />
      </app-box-empty-list>
    </div>

    <!-- Belege vorhanden -->
    <div
      v-if="documents.length"
      class="documents">
      <div
        v-if="hasSum"
        class="border rounded p-3 font-size-lg text-right mb-1">
        {{ $t('myAccountDocuments.components.documentList.sum') }}
        <strong> {{ sum | price }} {{ sumCurrency | currency }}</strong>
      </div>

      <document-list-item
        v-for="doc in documents"
        :key="doc.docId"
        :doc="doc" />

      <div
        v-if="hasSum"
        class="border rounded p-3 font-size-lg text-right">
        {{ $t('myAccountDocuments.components.documentList.sum') }}
        <strong> {{ sum | price }} {{ sumCurrency | currency }}</strong>
      </div>
    </div>
  </div>
</template>

<script>
import Document from './document-list-item.vue'

export default {
  components: {
    'document-list-item': Document,
  },

  props: {
    documents: {
      type: Array,
      default () {
        return []
      },
    },
    hasSum: {
      type: Boolean,
      default: false,
    },
    sum: {
      type: Number,
      default: 0,
    },
    sumCurrency: {
      type: String,
      default: '',
    },
  },
}
</script>

