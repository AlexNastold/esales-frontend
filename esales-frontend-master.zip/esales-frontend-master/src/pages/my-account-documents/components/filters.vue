<template>
  <form @submit.prevent="onFormSubmit">
    <!-- Filter -->
    <div class="row mb-2 mb-md-1">
      <!-- Belegart -->
      <div class="col-12 col-md-6 col-lg-3 mb-2 mb-md-1 mb-lg-0">
        <div class="from-group">
          <select
            v-model.number="filters.doctype"
            class="form-control custom-select">
            <option :value="void 0">
              {{ $t('myAccountDocuments.components.filters.doctypeSelectionDummy') }}
            </option>
            <template v-for="doctype in doctypes">
              <option
                v-if="isDocumentTypeAllowed(doctype.key)"
                :key="doctype.key"
                :value="doctype.key">
                {{ doctype.label }}
              </option>
            </template>
          </select>
        </div>
      </div>

      <!-- Status -->
      <div class="col-12 col-md-6 col-lg-3 mb-2 mb-md-1 mb-lg-0">
        <div class="from-group">
          <select
            v-model.number="filters.status"
            :disabled="isStatusFilterDisabledForDoctype(filters.doctype)"
            class="form-control custom-select">
            <option :value="void 0">
              {{ $t('myAccountDocuments.components.filters.statusSelectionDummy') }}
            </option>
            <option
              v-for="status in statuses"
              :key="status.key"
              :value="status.key">
              {{ status.filterLabel }}
            </option>
          </select>
        </div>
      </div>

      <!-- Zeitraum -->
      <div class="col-12 col-md-6 col-lg-3 mb-2 mb-lg-0">
        <div
          :class="{'mb-1' : filters.timespan === DocumentTimespan.CUSTOM}"
          class="from-group mb-1">
          <select
            v-model.number="filters.timespan"
            :disabled="isTimespanFilterDisabledForDoctype(filters.doctype)"
            class="form-control custom-select">
            <option :value="void 0">
              {{ $t('myAccountDocuments.components.filters.timespanSelectionDummy') }}
            </option>
            <option
              v-for="timespan in timespans"
              :key="timespan.key"
              :value="timespan.key">
              {{ timespan.label }}
            </option>
          </select>
        </div>

        <!-- Von, Bis -->
        <div
          v-show="filters.timespan === DocumentTimespan.CUSTOM"
          class="row no-gutters">
          <div class="col-3 font-weight-bold d-flex align-items-center mb-1">
            {{ $t('myAccountDocuments.components.filters.timespanCustomFrom') }}
          </div>
          <div class="col-9 mb-1">
            <app-form-input-datepicker v-model="filters.dateFrom" />
          </div>

          <div class="col-3 font-weight-bold d-flex align-items-center">
            {{ $t('myAccountDocuments.components.filters.timespanCustomTo') }}
          </div>
          <div class="col-9">
            <app-form-input-datepicker v-model="filters.dateTo" />
          </div>
        </div>
      </div>

      <!-- Suche nach  -->
      <div class="col-12 col-md-6 col-lg-3">
        <div class="from-group mb-1">
          <select
            v-model.number="filters.customFilter"
            :disabled="isCustomFilterDisabledForDoctype(filters.doctype)"
            class="form-control custom-select">
            <option
              v-for="option in customFilterOptions"
              :key="option.value"
              :value="option.value">
              {{ option.label }}
            </option>
          </select>
        </div>

        <!-- Suchfeld -->
        <div
          v-if="filters.customFilter"
          class="input-group">
          <input
            v-model="filters.customFilterValue"
            :disabled="isCustomFilterDisabledForDoctype(filters.doctype)"
            :placeholder="$t('myAccountDocuments.components.filters.customFilterPlaceholder')"
            type="text"
            class="form-control">
          <div class="input-group-append">
            <button
              type="button"
              class="btn btn-secondary"
              @click="filters.customFilterValue = ''">
              <i class="fas fa-times fa-fw" />
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Suchen Button -->
    <div class="mb-3">
      <!-- Button Mobile -->
      <div class="d-lg-none">
        <button
          :disabled="!filters.doctype || isLoading"
          type="submit"
          class="btn btn-block btn-primary">
          <app-icon-state
            :is-loading="isLoading"
            icon="fas fa-search" />
          {{ $t('myAccountDocuments.components.filters.search') }}
        </button>
      </div>

      <!-- Button Desktop -->
      <div class="d-none d-lg-flex justify-content-end">
        <button
          :disabled="!filters.doctype || isLoading"
          type="submit"
          class="btn btn-primary">
          <app-icon-state
            :is-loading="isLoading"
            icon="fas fa-search" />
          {{ $t('myAccountDocuments.components.filters.search') }}
        </button>
      </div>
    </div>

    <!-- Aktive Filter -->
    <div
      v-if="Object.keys(activeFilters).length"
      class="d-flex mb-3">
      <!-- Beschriftung Aktive Filter -->
      <div class="mr-2 font-weight-bold">
        <strong>{{ $t('myAccountDocuments.components.filters.activeFilter.title') }}:</strong>
      </div>

      <!-- Auflistung Aktive Filter -->
      <div class="d-flex flex-wrap">
        <app-active-filter
          v-for="(value, name) of activeFilters"
          :key="name"
          :label="getFilterLabelByName(name)"
          :value="getFilterValueByName(name, value)"
          type="primary"
          @click="resetFilterByName(name)" />

        <app-active-filter
          :label="$t('myAccountDocuments.components.filters.resetFilters')"
          type="dark"
          @click="resetFilters" />
      </div>
    </div>
  </form>
</template>

<script>
import moment from 'moment'

import { pageSettingsMyAccountDocuments } from '@scripts/app/settings'
import { DocumentType, DocumentStatus, DocumentTimespan, getDocumentStatusTitle, getDocumentStatusFilterTitle, getDocumentTimespanTitle, getDocumentTypeTitle } from '@scripts/modules/documents'

import { getQueryParameter } from '@scripts/helper/urlParams'
import { dateToSapDate } from '@scripts/helper/sapFormat'

export default {
  props: {
    isLoading: {
      type: Boolean,
      default: false,
    },
  },

  data () {
    let documentTypeFromUri = getQueryParameter('doctype') ? parseInt(getQueryParameter('doctype')) : void 0
    if (documentTypeFromUri && !this.isDocumentTypeAllowed(documentTypeFromUri)) {
      documentTypeFromUri = void 0
    }

    return {
      DocumentType,
      DocumentTimespan,

      // Die Reihenfolge hier sollte genauso wie im DOM sein
      filters: {
        doctype: documentTypeFromUri || void 0,
        status: getQueryParameter('status') || void 0,
        timespan: getQueryParameter('timespan') ? parseInt(getQueryParameter('timespan')) : DocumentTimespan.LAST_30_DAYS,
        dateFrom: getQueryParameter('dateFrom') ? new Date(getQueryParameter('dateFrom')) : new Date(),
        dateTo: getQueryParameter('dateTo') ? new Date(getQueryParameter('dateTo')) : new Date(),
        customFilter: getQueryParameter('customFilter') ? parseInt(getQueryParameter('customFilter')) : void 0,
        customFilterValue: getQueryParameter('customFilterValue') || '',
      },
      filterNames: {
        doctype: this.$t('myAccountDocuments.components.filters.activeFilter.doctypeLabel'),
        status: this.$t('myAccountDocuments.components.filters.activeFilter.statusLabel'),
        timespan: this.$t('myAccountDocuments.components.filters.activeFilter.timespanLabel'),
      },
      doctypes: [
        { key: DocumentType.AUFTRAG, label: getDocumentTypeTitle(DocumentType.AUFTRAG, true) },
        { key: DocumentType.ANGEBOT, label: getDocumentTypeTitle(DocumentType.ANGEBOT, true) },
        { key: DocumentType.ANFRAGE, label: getDocumentTypeTitle(DocumentType.ANFRAGE, true) },
        { key: DocumentType.BELEG_UNTER_VORBEHALT, label: getDocumentTypeTitle(DocumentType.BELEG_UNTER_VORBEHALT, true) },
        { key: DocumentType.HAUPTABRUF, label: getDocumentTypeTitle(DocumentType.HAUPTABRUF, true) },
        { key: DocumentType.RECHNUNG, label: getDocumentTypeTitle(DocumentType.RECHNUNG, true) },
        { key: DocumentType.GUTSCHRIFT, label: getDocumentTypeTitle(DocumentType.GUTSCHRIFT, true) },
        { key: DocumentType.BUDGETAUFTRAG, label: getDocumentTypeTitle(DocumentType.BUDGETAUFTRAG, true) },
        { key: DocumentType.OFFENE_POSTEN, label: getDocumentTypeTitle(DocumentType.OFFENE_POSTEN, true) },
        { key: DocumentType.RETURN, label: getDocumentTypeTitle(DocumentType.RETURN, true) },
      ],
      statuses: [
        {
          key: DocumentStatus.OPEN,
          label: getDocumentStatusTitle(DocumentStatus.OPEN),
          filterLabel: getDocumentStatusFilterTitle(DocumentStatus.OPEN),
        },
        {
          key: DocumentStatus.PARTLY_COMPLETED,
          label: getDocumentStatusTitle(DocumentStatus.PARTLY_COMPLETED),
          filterLabel: getDocumentStatusFilterTitle(DocumentStatus.PARTLY_COMPLETED),
        },
        {
          key: DocumentStatus.COMPLETED,
          label: getDocumentStatusTitle(DocumentStatus.COMPLETED),
          filterLabel: getDocumentStatusFilterTitle(DocumentStatus.COMPLETED),
        },
      ],
      timespans: [
        { key: DocumentTimespan.LAST_WEEK, label: getDocumentTimespanTitle(DocumentTimespan.LAST_WEEK) },
        { key: DocumentTimespan.LAST_30_DAYS, label: getDocumentTimespanTitle(DocumentTimespan.LAST_30_DAYS) },
        { key: DocumentTimespan.LAST_QUARTER, label: getDocumentTimespanTitle(DocumentTimespan.LAST_QUARTER) },
        { key: DocumentTimespan.LAST_HALF_YEAR, label: getDocumentTimespanTitle(DocumentTimespan.LAST_HALF_YEAR) },
        { key: DocumentTimespan.LAST_YEAR, label: getDocumentTimespanTitle(DocumentTimespan.LAST_YEAR) },
        { key: DocumentTimespan.CUSTOM, label: getDocumentTimespanTitle(DocumentTimespan.CUSTOM) },
      ],
    }
  },

  computed: {
    activeFilters () {
      const activeFilters = {}
      for (let name in this.filters) {
        if (name === 'customFilterValue' || name === 'dateFrom' || name === 'dateTo') {
          continue
        }

        if (
          (name === 'status' && this.isStatusFilterDisabledForDoctype(this.filters.doctype))
          || (name === 'timespan' && this.isTimespanFilterDisabledForDoctype(this.filters.doctype))
          || (name === 'customFilter' && this.isCustomFilterDisabledForDoctype(this.filters.doctype))
        ) {
          continue
        }

        if (name === 'customFilter') {
          if (this.filters.customFilter && this.filters.customFilterValue) {
            activeFilters[name] = this.filters[name]
          }
        } else if (this.filters[name]) {
          activeFilters[name] = this.filters[name]
        }
      }
      return activeFilters
    },
    customFilterOptions () {
      let options = []
      options.push({
        value: void 0,
        label: this.$t('myAccountDocuments.components.filters.customFilterSelectionDummy'),
      })
      options.push({
        value: 2,
        label: this.$t('myAccountDocuments.components.filters.customFilter.docNumber'),
      })
      options.push({
        value: 3,
        label: this.$t('myAccountDocuments.components.filters.customFilter.orderNumber'),
      })
      options.push({
        value: 4,
        label: this.$t('myAccountDocuments.components.filters.customFilter.articleNumber'),
      })
      options.push({
        value: 6,
        label: this.$t('myAccountDocuments.components.filters.customFilter.deliveryReceiptNumber'),
      })
      if (this.filters.doctype !== DocumentType.GUTSCHRIFT && this.filters.doctype !== DocumentType.RECHNUNG) {
        options.push({
          value: 5,
          label: this.$t('myAccountDocuments.components.filters.customFilter.projectName'),
        })
      }
      return options
    },
  },

  watch: {
    filters: {
      handler () {
        this.$emit('change', Object.assign({}, this.filters))
      },
      deep: true,
    },

    'filters.doctype' (doctype) {
      this.clearFilters(doctype)
    },

    'filters.dateTo' (date) {
      if (this.filters.dateFrom) {
        if (moment(this.filters.dateFrom).diff(moment(date), 'days') > 0) {
          this.filters.dateFrom = date
        }
      }
    },

    customFilterOptions (options) {
      if (options.indexOf((option) => option.value === this.filters.customFilter) === -1) {
        this.filters.customFilter = void 0
        this.filters.customFilterValue = ''
      }
    },
  },

  created () {
    this.clearFilters(this.filters.doctype)
    this.$emit('init', Object.assign({}, this.filters))
  },

  methods: {
    onFormSubmit () {
      this.$emit('submit', Object.assign({}, this.filters))
    },

    clearFilters (doctype) {
      if (this.isStatusFilterDisabledForDoctype(doctype)) {
        this.filters.status = void 0
      }

      if (this.isTimespanFilterDisabledForDoctype(doctype)) {
        this.filters.timespan = DocumentTimespan.LAST_30_DAYS
      }

      if (this.isCustomFilterDisabledForDoctype(doctype)) {
        this.filters.customFilter = void 0
        this.filters.customFilterValue = ''
      }

      // Eigenen Filter zurücksetzen, wenn Projektbezeichnung ausgewählt war
      // und die Belegart auf Gutschrift oder Rechnung geändert wird
      if (
        (doctype === DocumentType.GUTSCHRIFT || doctype === DocumentType.RECHNUNG)
        && this.filters.customFilter === 5
      ) {
        this.filters.customFilter = void 0
        this.filters.customFilterValue = ''
      }
    },

    isDocumentTypeAllowed (documentType) {
      return pageSettingsMyAccountDocuments.allowedDocumentTypes.includes(documentType)
    },

    resetFilters () {
      this.filters = {
        doctype: void 0,
        status: void 0,
        timespan: void 0,
        dateFrom: new Date(),
        dateTo: new Date(),
        customFilter: void 0,
        customFilterValue: '',
      }
      this.onFormSubmit()
    },
    resetFilterByName (name) {
      this.filters[name] = void 0

      if (name === 'customFilter') {
        this.filters.customFilterValue = ''
      }
      this.onFormSubmit()
    },
    getFilterLabelByName (name) {
      if (name === 'customFilter') {
        if (this.filters.customFilter === 2) {
          return this.$t('myAccountDocuments.components.filters.customFilter.docNumber')
        }
        if (this.filters.customFilter === 3) {
          return this.$t('myAccountDocuments.components.filters.customFilter.orderNumber')
        }
        if (this.filters.customFilter === 4) {
          return this.$t('myAccountDocuments.components.filters.customFilter.articleNumber')
        }
        if (this.filters.customFilter === 5) {
          return this.$t('myAccountDocuments.components.filters.customFilter.projectName')
        }
        if (this.filters.customFilter === 6) {
          return this.$t('myAccountDocuments.components.filters.customFilter.deliveryReceiptNumber')
        }
      }

      return this.filterNames[name] || name
    },
    getFilterValueByName (name, value) {
      if (name === 'doctype') {
        return this.doctypes.find((doctype) => doctype.key === value).label
      }
      if (name === 'status') {
        return this.statuses.find((status) => status.key === value).label
      }
      if (name === 'timespan') {
        if (this.filters[name] === DocumentTimespan.CUSTOM) {
          const dateFrom = dateToSapDate(this.filters.dateFrom)
          const dateTo = dateToSapDate(this.filters.dateTo)
          return this.$t('myAccountDocuments.components.filters.activeFilter.timespanValueFromTo', { from: dateFrom, to: dateTo })
        }
        return this.timespans.find((timespan) => timespan.key === value).label
      }
      if (name === 'customFilter') {
        return this.filters.customFilterValue
      }
      if (value instanceof Date) {
        return dateToSapDate(value)
      }
      return typeof value === 'string' ? value : void 0
    },

    isStatusFilterDisabledForDoctype (doctype) {
      return doctype === DocumentType.BELEG_UNTER_VORBEHALT
        || doctype === DocumentType.RECHNUNG
        || doctype === DocumentType.OFFENE_POSTEN
        || doctype === DocumentType.BUDGETAUFTRAG
        || !doctype
    },
    isTimespanFilterDisabledForDoctype (doctype) {
      return doctype === DocumentType.BELEG_UNTER_VORBEHALT
        || doctype === DocumentType.OFFENE_POSTEN
        || !doctype
    },
    isCustomFilterDisabledForDoctype (doctype) {
      return doctype === DocumentType.BELEG_UNTER_VORBEHALT
        || doctype === DocumentType.OFFENE_POSTEN
        || !doctype
    },
  },
}
</script>
