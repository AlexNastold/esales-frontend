<template>
  <div
    :class="`doc-type-${doc.documentType}`"
    class="rounded bg-light p-3 mb-1 document">
    <component
      :is="component"
      :doc="doc"
      :link="detailUri"
      @addtocomparelist="addToDocCompareList" />
  </div>
</template>

<script>
import { DocumentType } from '@scripts/modules/documents'
import { getQueryParameters } from '@scripts/helper/urlParams'
import { showSuccessMessage, showWarningMessage, showErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'
import { addToDocCompareList } from '@scripts/modules/document-comparison-list'

import DocumentTypeAnfrage from './document-types/anfrage.vue'
import DocumentTypeAngebot from './document-types/angebot.vue'
import DocumentTypeAuftrag from './document-types/auftrag.vue'
import DocumentTypeGutschrift from './document-types/gutschrift.vue'
import DocumentTypeHauptabruf from './document-types/hauptabruf.vue'
import DocumentTypeOffenePosten from './document-types/offene-posten.vue'
import DocumentTypeRechnung from './document-types/rechnung.vue'
import DocumentTypeBudgetauftrag from './document-types/budgetauftrag.vue'
import DocumentTypeUnterVorbehalt from './document-types/unter-vorbehalt.vue'
import DocumentTypeReturn from './document-types/return.vue'

export default {
  props: {
    doc: {
      type: Object,
      required: true,
    },
  },

  computed: {
    component () {
      switch (this.doc.documentType) {
        case DocumentType.ANFRAGE: return DocumentTypeAnfrage
        case DocumentType.ANGEBOT: return DocumentTypeAngebot
        case DocumentType.AUFTRAG: return DocumentTypeAuftrag
        case DocumentType.GUTSCHRIFT: return DocumentTypeGutschrift
        case DocumentType.HAUPTABRUF: return DocumentTypeHauptabruf
        case DocumentType.OFFENE_POSTEN: return DocumentTypeOffenePosten
        case DocumentType.RECHNUNG: return DocumentTypeRechnung
        case DocumentType.BUDGETAUFTRAG: return DocumentTypeBudgetauftrag
        case DocumentType.BELEG_UNTER_VORBEHALT: return DocumentTypeUnterVorbehalt
        case DocumentType.RETURN: return DocumentTypeReturn
      }
      return ''
    },
    detailUri () {
      let additionalQueryParameters = void 0
      if (this.doc.documentType === DocumentType.OFFENE_POSTEN) {
        if (!this.doc.billDocumentId || !this.doc.billType) {
          return ''
        } else {
          additionalQueryParameters = $.param(getQueryParameters(['docid', 'doctype']))
          return 'my-account-documents-detail' +
            `?docid=${encodeURIComponent(this.doc.billDocumentId)}` +
            `&doctype=${encodeURIComponent(this.doc.billType)}` +
            (additionalQueryParameters ? `&${additionalQueryParameters}` : '')
        }
      } else {
        additionalQueryParameters = $.param(getQueryParameters(['docid']))
        return 'my-account-documents-detail' +
          `?docid=${encodeURIComponent(this.doc.documentId)}` +
          (additionalQueryParameters ? `&${additionalQueryParameters}` : '')
      }
    },
  },

  methods: {
    addToDocCompareList () {
      try {
        addToDocCompareList(this.app.state.docComparison.documents, this.doc)
        showSuccessMessage(this.$t('myAccountDocuments.components.compareList.addDocumentSuccessMessage', {
          document: `${this.$options.filters.documentTypeTitle(this.doc.documentType)} ${this.doc.documentIdDisplay}`,
        }))
      } catch (e) {
        if (e.code === ErrorCode.ALREADY_IN_DOC_COMPARISON) {
          showWarningMessage(this.$t('myAccountDocuments.components.compareList.addDocumentErrorMessageExists', {
            document: `${this.$options.filters.documentTypeTitle(this.doc.documentType)} ${this.doc.documentIdDisplay}`,
          }))
        } else {
          console.error(e)
          showErrorMessage(e.message)
        }
      }
    },
  },
}
</script>

