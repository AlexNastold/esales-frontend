<template>
  <div
    :class="`doc-type-${doc.documentType}`"
    class="bg-light d-flex justify-content-between mb-1 compare-list-item">
    <!-- Dokument, dass gerade angezeigt wird (aktives Dokument) -->
    <div
      v-if="active"
      class="d-flex bg-dark text-white justify-content-start w-100 pl-2 py-2">
      <div class="d-flex flex-column">
        <!-- Belegname, Nummer -->
        <strong class="document-name">
          {{ doc.documentType | documentTypeTitle }} <span class="d-lg-block d-xl-inline">
            {{ doc.documentIdDisplay }}
          </span>
        </strong>

        <!-- Datum -->
        <small class="text-secondary d-block document-date">
          {{ doc.createDate | date }}
        </small>
      </div>
    </div>

    <!-- Dokument, dass gerade NICHT angezeigt wird (nicht aktives Dokument) -->
    <a
      v-else
      :href="detailUri"
      class="text-decoration-none d-flex justify-content-start w-100 pl-2 py-2 document-link">
      <div class="d-flex flex-column">
        <!-- Belegname, Nummer -->
        <strong class="text-dark document-name">
          {{ doc.documentType | documentTypeTitle }} <span class="d-lg-block d-xl-inline">
            {{ doc.documentIdDisplay }}
          </span>
        </strong>

        <!-- Datum -->
        <small class="text-muted d-block document-date">
          {{ doc.createDate | date }}
        </small>
      </div>

      <!-- Icon Detail -->
      <div class="d-flex align-items-center ml-auto angle-detail">
        <i class="fas fa-angle-right fa-2x fa-fw" />
      </div>
    </a>

    <!-- Dokument aus Vergleichsliste entfernen -->
    <div
      class="bg-dark text-white close d-flex align-items-center p-1"
      @click="$emit('removedoc', doc)">
      <i class="fas fa-times fa-fw fa-xs" />
    </div>
  </div>
</template>

<script>
import { getQueryParameters } from '@scripts/helper/urlParams'

export default {
  props: {
    doc: {
      type: Object,
      required: true,
    },
    active: {
      type: Boolean,
      default: false,
    },
  },

  computed: {
    detailUri () {
      const additionalQueryParameters = $.param(getQueryParameters(['doctype', 'docid']))
      return 'my-account-documents-detail' +
        `?doctype=${encodeURIComponent(this.doc.documentType)}` +
        `&docid=${encodeURIComponent(this.doc.documentId)}` +
        (additionalQueryParameters ? `&${additionalQueryParameters}` : '')
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.compare-list-item {
  border: $border-width solid $border-color;
  border-left: 5px solid $my-account-documents-color;

  .document-link {

    &:hover {
      .document-name,
      .document-date {
        text-decoration: underline;
      }

      .angle-detail {
        color: $font-color;
        transition: color .2s ease-in-out;
      }
    }

    .angle-detail {
      color: theme-color('primary');
    }
  }

  // Bestellung (Auftrag)
  &.doc-type-1 {
    border-left-color: $my-account-document-bestellung-color;
  }

  // Rechnung
  &.doc-type-2 {
    border-left-color: $my-account-document-rechnung-color;
  }

  // Offene Posten
  &.doc-type-3 {
    border-left-color: $my-account-document-offene-posten-color;
  }

  // Gutschrift
  &.doc-type-4 {
    border-left-color: $my-account-document-gutschrift-color;
  }

  // Angebot
  &.doc-type-5 {
    border-left-color: $my-account-document-angebot-color;
  }

  // Hauptabruf
  &.doc-type-6 {
    border-left-color: $my-account-document-hauptabruf-color;
  }

  // Anfrage
  &.doc-type-7 {
    border-left-color: $my-account-document-anfrage-color;
  }

  // Budgetauftrag
  &.doc-type-9 {
    border-left-color: $my-account-document-budgetauftrag-color;
  }

  // Beleg unter vorbehalt
  &.doc-type-10 {
    border-left-color: $my-account-document-unter-vorbehalt-color;
  }

  // Retouren
  &.doc-type-12 {
    border-left-color: $my-account-document-return-color;
  }
}

</style>


