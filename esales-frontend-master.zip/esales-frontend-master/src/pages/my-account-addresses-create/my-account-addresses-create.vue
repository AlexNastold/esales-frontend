<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-addresses-create">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountAddressesCreate.addresses')"
        page="addresses" />

      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item">
            <a href="my-account-addresses">
              {{ $t('myAccountAddressesCreate.addresses') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountAddressesCreate.create') }}
          </li>
        </ol>

        <h2 class="mb-3">
          {{ $t('myAccountAddressesCreate.createAddress') }}
        </h2>

        <div
          v-show="errorMessage"
          class="alert alert-danger"
          role="alert"
          v-html="errorMessage" />

        <form @submit.prevent="createAddress">
          <div class="row">
            <!-- Nachname, Firma -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label for="company">
                  {{ $t('myAccountAddressesCreate.company') }} <span class="required" />
                </label>
                <input
                  id="company"
                  v-model="formFieldName1"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.LASTNAME]}"
                  :placeholder="$t('myAccountAddressesCreate.companyPlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="35"
                  autofocus>
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.LASTNAME]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.LASTNAME]" />
              </div>
            </div>

            <!-- Vorname -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label for="firstname">
                  {{ $t('myAccountAddressesCreate.firstName') }}
                </label>
                <input
                  id="firstname"
                  v-model="formFieldName2"
                  :placeholder="$t('myAccountAddressesCreate.firstNamePlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="35">
              </div>
            </div>

            <!-- Straße -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label for="street">
                  {{ $t('myAccountAddressesCreate.street') }} <span class="required" />
                </label>
                <input
                  id="street"
                  v-model="formFieldStreet"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.STREET]}"
                  :placeholder="$t('myAccountAddressesCreate.streetPlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="60">
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.STREET]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.STREET]" />
              </div>
            </div>

            <!-- Postleitzahl -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label for="postalCode">
                  {{ $t('myAccountAddressesCreate.plz') }} <span class="required" />
                </label>
                <input
                  id="postalCode"
                  v-model="formFieldPostalCode"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.ZIPCODE]}"
                  :placeholder="$t('myAccountAddressesCreate.plzPlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="10">
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.ZIPCODE]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.ZIPCODE]" />
              </div>
            </div>

            <!-- Ort -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label for="city">
                  {{ $t('myAccountAddressesCreate.city') }} <span class="required" />
                </label>
                <input
                  id="city"
                  v-model="formFieldCity"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.CITY]}"
                  :placeholder="$t('myAccountAddressesCreate.cityPlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="35">
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.CITY]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.CITY]" />
              </div>
            </div>

            <!-- Land -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label for="country">
                  {{ $t('myAccountAddressesCreate.country') }} <span class="required" />
                </label>
                <select
                  id="country"
                  v-model="formFieldCountry"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.COUNTRY]}"
                  class="form-control custom-select">
                  <option
                    v-for="country of countries"
                    :key="country.key"
                    :value="country.key">
                    {{ country.label }}
                  </option>
                </select>
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.COUNTRY]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.COUNTRY]" />
              </div>
            </div>

            <div class="col-12 col-lg-6 mb-2 mb-lg-0">
              <app-form-required-hint />
            </div>

            <!-- Buttons -->
            <div class="col-12 col-lg-6 text-lg-right">
              <!-- Buttons Mobile -->
              <div class="d-lg-none">
                <button
                  :disabled="isCreateInProcess"
                  type="submit"
                  class="btn btn-block btn-primary mb-1">
                  <app-icon-state
                    :is-loading="isCreateInProcess"
                    icon="fas fa-save" />
                  {{ $t('myAccountAddressesCreate.create') }}
                </button>
                <a
                  href="my-account-addresses"
                  class="btn btn-block btn-secondary">
                  <i class="fas fa-times fa-fw" />
                  {{ $t('general.cancel') }}
                </a>
              </div>

              <!-- Buttons Desktop -->
              <div class="d-none d-lg-block">
                <a
                  href="my-account-addresses"
                  class="btn btn-secondary">
                  <i class="fas fa-times fa-fw" />
                  {{ $t('general.cancel') }}
                </a>
                <button
                  :disabled="isCreateInProcess"
                  type="submit"
                  class="btn btn-primary">
                  <app-icon-state
                    :is-loading="isCreateInProcess"
                    icon="fas fa-save" />
                  {{ $t('myAccountAddressesCreate.create') }}
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { pageSettingsMyAccountAddressesCreate as pageSettings } from '@scripts/app/settings'
import { createFlashMessage } from '@scripts/helper/flash-messages'
import { redirect } from '@scripts/helper/redirect'
import { ErrorCode } from '@scripts/modules/errors'
import { DeliveryAddressFieldErrors, addDeliveryAddress } from '@scripts/modules/delivery-addresses'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

import MyAccountHeader from '@components/pages/my-account/header.vue'


export default {
  components: {
    'my-account-header': MyAccountHeader,
  },

  data () {
    return {
      countries: pageSettings.countries,
      isCreateInProcess: false,

      formFieldCity: void 0,
      formFieldCountry: pageSettings.countries[0] ? pageSettings.countries[0].key : void 0,
      formFieldName1: void 0,
      formFieldName2: void 0,
      formFieldPostalCode: void 0,
      formFieldStreet: void 0,
      errorMessage: '',
      formErrors: {},
      DeliveryAddressFieldErrors,
    }
  },

  created () {
    this.setPageTitle(this.$t('myAccountAddressesCreate.title'))
  },

  methods: {
    async createAddress () {
      this.isCreateInProcess = true
      this.errorMessage = ''
      this.formErrors = {}
      try {
        await addDeliveryAddress(
          this.formFieldName1,
          this.formFieldName2,
          this.formFieldStreet,
          this.formFieldPostalCode,
          this.formFieldCity,
          this.formFieldCountry,
        )
        createFlashMessage(
          this.$t('myAccountAddressesCreate.successMessage'),
          'success',
        )
        redirect('my-account-addresses')
      } catch (e) {
        if (e.code === ErrorCode.INVALID_FIELDS) {
          this.errorMessage = this.$t('general.invalidFieldsMessage')
          this.formErrors = e.fieldErrors
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
      this.isCreateInProcess = false
    },
  },
}
</script>

<style lang="scss" src="./my-account-addresses-create.scss"></style>
