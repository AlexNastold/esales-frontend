<template>
  <b-modal
    ref="modal"
    :title="$t('myAccountLists.detail.actions.renameDialogTitle')"
    :ok-disabled="isProcessing || !formIsValid"
    :visible="true"
    header-bg-variant="primary"
    header-text-variant="white"
    @hidden="$emit('hidden')"
    @ok.prevent="rename">
    <!-- Inhalt -->
    <form @submit.prevent="rename">
      <p v-html="$t('myAccountLists.detail.actions.renameDialogMessage')" />

      <input
        v-model="name"
        :class="{'is-invalid': nameError}"
        :placeholder="list.name"
        class="form-control"
        maxlength="50"
        autofocus>
      <div
        v-if="nameError"
        class="invalid-feedback">
        {{ nameError }}
      </div>
    </form>

    <template slot="modal-cancel">
      <i class="fas fa-times fa-fw" />
      {{ $t('myAccountLists.detail.actions.renameDialogCancel') }}
    </template>

    <template slot="modal-ok">
      <i class="fas fa-edit fa-fw" />
      {{ $t('myAccountLists.detail.actions.renameDialogOk') }}
    </template>
  </b-modal>
</template>

<script>
import { ErrorCode } from '@scripts/modules/errors'
import { editListName } from '@scripts/modules/lists'
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  props: {
    list: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      isProcessing: false,

      name: '',
      nameError: '',
    }
  },

  computed: {
    formIsValid () {
      return !!this.name
    },
  },

  methods: {
    async rename () {
      this.isProcessing = true
      this.nameError = ''

      try {
        const oldName = this.list.name
        const newName = this.name

        await editListName(this.list.id, newName)
        showSuccessMessage(this.$t('myAccountLists.detail.actions.renameDialogSuccessMessage', {
          nameOld: oldName,
          name: newName,
        }))
        this.$refs.modal.hide()
        this.$emit('rename')
      } catch (e) {
        if (e.code === ErrorCode.INVALID_OR_MISSING_PARAMS) {
          this.nameError = this.$t('myAccountLists.detail.actions.renameDialogErrorInvalidName')
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }

      this.isProcessing = false
    },
  },
}
</script>
