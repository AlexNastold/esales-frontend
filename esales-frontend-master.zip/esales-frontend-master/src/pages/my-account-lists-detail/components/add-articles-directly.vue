<template>
  <div class="rounded bg-light p-3 mb-3">
    <h4>
      {{ $t('myAccountLists.detail.addArticles.headline') }}
    </h4>

    <form @submit.prevent="addArticle">
      <!-- Eingabe Artikel, Menge -->
      <div class="row no-gutters">
        <!-- Eingabe Artikel -->
        <div class="col-12 col-md mb-1 mb-md-0">
          <div class="input-group">
            <app-form-input-product-search
              ref="matnrInput"
              v-model="matnr"
              :class="{'is-invalid': matnrError}"
              :max-items="5"
              class="form-control d-flex" />
            <div class="input-group-append">
              <app-scan-button
                id="btnScan"
                :button-class="`btn-tertiary`"
                :tabindex="-1"
                :is-disabled="isProcessing"
                :scan-options="{'page':'list', 'listId': list.id}"
                @success="onScanSuccess" />
            </div>
          </div>
          <div
            v-if="matnrError"
            class="invalid-feedback d-block">
            <!-- d-block wird benötigt, da das Element nicht direkt nach dem Input kommt -->
            {{ matnrError }}
          </div>
        </div>

        <!-- Menge -->
        <div class="col-12 col-sm col-md-auto ml-md-1 mb-1 mb-md-0">
          <!-- Menge Mobile -->
          <app-form-input-quantity
            v-model="amount"
            width="auto"
            class="d-md-none"
            btn-type="btn-tertiary" />

          <!-- Menge ab MD -->
          <app-form-input-quantity
            v-model="amount"
            class="d-none d-md-flex"
            btn-type="btn-tertiary" />
        </div>

        <!-- Button Hinzufügen -->
        <div class="col-12 col-sm-auto ml-sm-1">
          <button
            :disabled="isProcessing || !matnr"
            type="submit"
            class="btn btn-block btn-primary">
            <app-icon-state
              :is-loading="isProcessing"
              icon="fas fa-plus" />
            {{ $t('myAccountLists.detail.addArticles.actions.addArticle') }}
          </button>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
import { ErrorCode } from '@scripts/modules/errors'

import { showTechnicalErrorMessage, showSuccessMessage } from '@scripts/modules/dialogs'
import { addArticleToList } from '@scripts/modules/lists'

export default {
  props: {
    matnrOrBismt: {
      type: String,
      default: '',
    },
    list: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      matnr: '',
      isProcessing: false,
      amount: 1,
      matnrError: '',
    }
  },

  created () {
    this.matnr = this.matnrOrBismt
  },

  mounted () {
    if (this.matnr !== '') {
      this.$refs.matnrInput.focus()
    }
  },

  methods: {
    async addArticle () {
      this.isProcessing = true
      this.matnrError = ''

      try {
        const matnr = this.matnr
        await addArticleToList(this.list.id, this.matnr, this.amount)
        showSuccessMessage(this.$t('myAccountLists.detail.addArticles.actions.addArticleSuccessMessage', {
          articleNumber: matnr,
        }))
        this.matnr = ''
        this.amount = 1
        this.$emit('articleAdded')
      } catch (e) {
        if (e.code === ErrorCode.INVALID_OR_MISSING_PARAMS) {
          this.matnrError = this.$t('myAccountLists.detail.addArticles.actions.addArticleErrorNotFound')
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
      this.isProcessing = false
    },
    onScanSuccess (text) {
      this.matnrOrBismt = text
    },
  },
}
</script>

