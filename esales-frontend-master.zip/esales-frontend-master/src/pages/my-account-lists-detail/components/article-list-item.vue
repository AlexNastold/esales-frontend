<template>
  <app-article-item
    :article="article"
    pitcher="list"
    @amountChange="onAmountChange"
    @updatedList="(listId) => $emit('updatedList', listId)">
    <!-- Buttons nach Mengenfeld -->
    <template slot="buttons-after-amount">
      <button
        v-if="list.isOwnList"
        v-show="hasAmountChanged"
        type="button"
        class="btn btn-warning ml-1"
        @click.prevent="updateAmount(amount)">
        <app-icon-state
          :is-loading="isUpdateAmountInProcess"
          icon="fas fa-sync" />
      </button>
    </template>

    <!-- Löschen Button -->
    <template slot="buttons">
      <button
        v-if="list.isOwnList"
        :disabled="isDeleteInProcess"
        type="button"
        class="btn btn-secondary ml-1"
        @click="deleteArticle">
        <app-icon-state
          :is-loading="isDeleteInProcess"
          icon="fas fa-trash-alt" />
      </button>
    </template>
  </app-article-item>
</template>

<script>
import { confirmDialog, showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { editArticleInList, removeArticleFromList } from '@scripts/modules/lists'

export default {
  props: {
    article: {
      required: true,
      type: Object,
    },
    list: {
      required: true,
      type: Object,
    },
  },
  data () {
    return {
      isDeleteInProcess: false,
      isUpdateAmountInProcess: false,
      newAmount: this.article.amount,
    }
  },

  computed: {
    hasAmountChanged () {
      return this.newAmount !== this.article.amount
    },
  },

  methods: {
    async deleteArticle () {
      const articleName = this.article.maktx + (this.article.maktx2 ? ` ${this.article.maktx2}` : '')
      if (await confirmDialog(
        this.$t('myAccountLists.detail.actions.deleteArticleConfirmTitle'),
        this.$t('myAccountLists.detail.actions.deleteArticleConfirmMessage', {
          articleName,
          listName: this.list.name,
        }),
        {
          buttonCancelText: `
            <i class="fas fa-times"></i>
            ${this.$t('myAccountLists.detail.actions.deleteArticleConfirmCancel')}
          `,
          buttonConfirmText: `
            <i class="fas fa-trash-alt"></i>
            ${this.$t('myAccountLists.detail.actions.deleteArticleConfirmOk')}
          `,
          type: 'danger',
        },
      )) {
        this.isDeleteInProcess = true
        try {
          await removeArticleFromList(this.list.id, this.article.id)
          showSuccessMessage(this.$t('myAccountLists.detail.actions.deleteArticleSuccessMessage', {
            articleName,
            listName: this.list.name,
          }))
          this.$emit('delete')
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
          this.isDeleteInProcess = false
        }
      }
    },

    async updateAmount () {
      this.isUpdateAmountInProcess = true
      try {
        const amount = this.newAmount
        await editArticleInList(this.list.id, this.article.id, this.newAmount)
        this.article.amount = amount
        showSuccessMessage(this.$t('myAccountLists.detail.actions.updateAmountSuccessMessage'))
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
      this.isUpdateAmountInProcess = false
    },

    onAmountChange (newAmount) {
      this.newAmount = newAmount
    },
  },
}
</script>
