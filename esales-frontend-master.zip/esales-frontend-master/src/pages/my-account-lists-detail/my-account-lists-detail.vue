<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-lists-detail">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountLists.list.headline')"
        page="lists" />

      <div class="container">
        <!-- Breadcrumb   -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item">
            <a href="my-account-lists">
              {{ $t('myAccountLists.list.breadcrumb') }}
            </a>
          </li>
          <li
            v-if="isLoading"
            class="breadcrumb-item">
            <app-loading-spinner class="d-inline-block" />
          </li>
          <li
            v-else-if="!list"
            class="breadcrumb-item active text-danger">
            {{ $t('myAccountLists.detail.listNotFoundBreadcrumb') }}
          </li>
          <li
            v-else
            class="breadcrumb-item active">
            {{ list.name }}
          </li>
        </ol>

        <!-- Ladeanzeige -->
        <app-loading-box v-if="isLoading" />

        <template v-else>
          <!-- Keine Liste gefunden -->
          <app-box-oops
            v-if="!list"
            link-title="Zurück zur Übersicht"
            link-href="my-account-lists">
            {{ $t('myAccountLists.detail.listNotFoundMessage') }}
          </app-box-oops>

          <!-- Liste gefunden -->
          <template v-else>
            <!-- Listenname, Freigegeben-Label, Erstellt am -->
            <div class="row no-gutters mb-3">
              <!-- Listenname -->
              <div class="col-12 col-md-auto mb-3 mb-md-0">
                <h2 class="m-0">
                  {{ list.name }}
                </h2>
              </div>

              <!-- Freigegeben-Label -->
              <div class="col-6 col-md d-md-flex align-items-md-center ml-md-2">
                <div>
                  <div
                    v-if="list.isPublic"
                    class="badge badge-primary badge-pill py-1">
                    <i class="fas fa-users fa-fw" />
                    {{ $t('myAccountLists.detail.fields.shared') }}
                  </div>
                </div>
              </div>

              <!-- Erstellt am -->
              <div class="col-6 col-md-3 text-muted d-flex align-items-center justify-content-end">
                {{ $t('myAccountLists.detail.fields.createdAt', { date: $options.filters.date(list.createdAt) }) }}
              </div>
            </div>

            <!-- Aktionen Buttons Mobile -->
            <div class="d-md-none mb-3">
              <!-- Umbenennen -->
              <button
                v-if="list.isOwnList"
                :disabled="isEditInProcess"
                type="button"
                class="btn btn-block btn-secondary mb-1"
                @click="editListName">
                <app-icon-state
                  :is-loading="isEditInProcess"
                  icon="fas fa-edit" />
                {{ $t('myAccountLists.detail.actions.rename') }}
              </button>

              <!-- Liste Freigeben -->
              <button
                v-if="list.canPublish"
                :disabled="isPublishInProcess"
                type="button"
                class="btn btn-block btn-secondary mb-1"
                @click="togglePublishList">
                <app-icon-state
                  :is-loading="isPublishInProcess"
                  icon="fas fa-users" />
                <span v-if="list.isPublic">
                  {{ $t('myAccountLists.detail.actions.unshare') }}
                </span>
                <span v-else>
                  {{ $t('myAccountLists.detail.actions.share') }}
                </span>
              </button>

              <!-- Löschen -->
              <button
                v-if="list.isOwnList"
                :disabled="isDeleteInProcess"
                type="button"
                class="btn btn-block btn-secondary mb-1"
                @click="deleteList">
                <app-icon-state
                  :is-loading="isDeleteInProcess"
                  icon="fas fa-trash-alt" />
                {{ $t('myAccountLists.detail.actions.delete') }}
              </button>

              <!-- In den Warenkorb werfen -->
              <throw-list-into-basket-button
                v-if="app.user.hasPermission('BASKET_ADD_ARTICLES')"
                :list="list"
                :disabled="!list.articles.length"
                button-class="btn-block btn-primary" />
            </div>

            <!-- Aktionen Buttons Desktop -->
            <div class="d-none d-md-flex mb-3">
              <!-- Buttons links -->
              <div>
                <!-- Umbenennen -->
                <button
                  v-if="list.isOwnList"
                  :disabled="isEditInProcess"
                  type="button"
                  class="btn btn-secondary"
                  @click="editListName">
                  <app-icon-state
                    :is-loading="isEditInProcess"
                    icon="fas fa-edit" />
                  {{ $t('myAccountLists.detail.actions.rename') }}
                </button>

                <!-- Liste Freigeben -->
                <button
                  v-if="list.canPublish"
                  :disabled="isPublishInProcess"
                  type="button"
                  class="btn btn-secondary"
                  @click="togglePublishList">
                  <app-icon-state
                    :is-loading="isPublishInProcess"
                    icon="fas fa-users" />
                  <span v-if="list.isPublic">
                    {{ $t('myAccountLists.detail.actions.unshare') }}
                  </span>
                  <span v-else>
                    {{ $t('myAccountLists.detail.actions.share') }}
                  </span>
                </button>
              </div>

              <!-- Buttons rechts -->
              <div class="d-flex ml-auto">
                <!-- Löschen -->
                <button
                  v-if="list.isOwnList"
                  :disabled="isDeleteInProcess"
                  type="button"
                  class="btn btn-secondary mr-1"
                  @click="deleteList">
                  <app-icon-state
                    :is-loading="isDeleteInProcess"
                    icon="fas fa-trash-alt" />
                  {{ $t('myAccountLists.detail.actions.delete') }}
                </button>

                <!-- In den Warenkorb werfen Desktop -->
                <throw-list-into-basket-button
                  v-if="app.user.hasPermission('BASKET_ADD_ARTICLES')"
                  :list="list"
                  :disabled="!list.articles.length"
                  button-class="btn-primary" />
              </div>
            </div>

            <!-- Artikelliste -->
            <div
              v-if="!list.articles.length"
              class="border rounded mb-3">
              <app-box-empty-list
                :headline="$t('myAccountLists.detail.listEmpty')"
                icon="far fa-meh">
                <span
                  v-if="list.isOwnList"
                  v-html="$t('myAccountLists.detail.listEmptyDescriptionOwnList')" />
                <span
                  v-else
                  v-html="$t('myAccountLists.detail.listEmptyDescription')" />
              </app-box-empty-list>
            </div>

            <h4 v-if="list.articles.length">
              {{ list.articles.length }} Artikel
            </h4>

            <div class="list-group mb-3">
              <div
                v-for="article in list.articles"
                :key="article.id"
                class="list-group-item">
                <article-list-item
                  :article="article"
                  :list="list"
                  @delete="onArticleDeleted(article)"
                  @updatedList="(updatedlistId) => { updatedlistId === listId ? loadList() : void 0 }" />
              </div>
            </div>

            <!-- Artikel direkt hinzufügen -->
            <add-articles-directly
              v-if="list.isOwnList"
              :list="list"
              :matnr-or-bismt="matnr"
              @articleAdded="loadList" />

            <!-- Umbennen Dialog -->
            <rename-dialog
              v-if="isRenameDialogOpen"
              :list="list"
              @rename="loadList"
              @hidden="isRenameDialogOpen = false" />
          </template>
        </template>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { createFlashMessage } from '@scripts/helper/flash-messages'
import { redirect } from '@scripts/helper/redirect'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { updateUrlQueryString } from '@scripts/helper/urlUpdate'
import { confirmDialog, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'
import { deleteList, getList, publishList } from '@scripts/modules/lists'

import ThrowListIntoBasketButton from '@components/pages/my-account-lists/throw-list-into-basket.vue'
import MyAccountHeader from '@components/pages/my-account/header.vue'

import AddArticlesDirectly from './components/add-articles-directly.vue'
import ArticleListItem from './components/article-list-item.vue'
import RenameDialog from './components/rename-dialog.vue'

export default {
  components: {
    'my-account-header': MyAccountHeader,
    'throw-list-into-basket-button': ThrowListIntoBasketButton,

    'add-articles-directly': AddArticlesDirectly,
    'article-list-item': ArticleListItem,
    'rename-dialog': RenameDialog,
  },

  data () {
    return {
      isLoading: true,

      isDeleteInProcess: false,
      isEditInProcess: false,
      isPublishInProcess: false,
      isRenameDialogOpen: false,

      list: void 0,
      listId: getQueryParameter('id'),
      matnr: getQueryParameter('matnr'),
    }
  },

  created () {
    this.setPageTitle(this.$t('myAccountLists.detail.title'))
    this.loadList()
    if (this.matnr) {
      updateUrlQueryString({
        id: this.listId,
      })
    }
  },

  methods: {
    async loadList () {
      try {
        this.list = await getList(this.listId)
        this.list.articles = this.list.articles.map((article) => ({
          ...article,
          newAmount: article.amount,
        }))
        this.setPageTitle(this.$t('myAccountLists.detail.titleWithDetails', {
          listName: this.list.name,
        }))
        this.isLoading = false
      } catch (e) {
        if (e.code === ErrorCode.NOT_FOUND) {
          // Ist okay, nur nicht "this.list" setzen
          this.isLoading = false
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },

    async editListName () {
      this.isRenameDialogOpen = true
    },

    async deleteList () {
      if (await confirmDialog(
        this.$t('myAccountLists.detail.actions.deleteConfirmTitle'),
        this.$t('myAccountLists.detail.actions.deleteConfirmMessage', { name: this.list.name }),
        {
          buttonCancelText: `
            <i class="fas fa-times fa-fw"></i>
            ${this.$t('myAccountLists.detail.actions.deleteConfirmCancel')}
          `,
          buttonConfirmText: `
            <i class="fas fa-trash-alt fa-fw"></i>
            ${this.$t('myAccountLists.detail.actions.deleteConfirmOk')}
          `,
          type: 'danger',
        },
      )) {
        this.isDeleteInProcess = true
        try {
          await deleteList(this.list.id)
          createFlashMessage(
            this.$t('myAccountLists.detail.actions.deleteSuccessMessage', {
              name: this.list.name,
            }),
            'success',
          )
          redirect('my-account-lists')
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
          this.isDeleteInProcess = false
        }
      }
    },

    async togglePublishList () {
      this.isPublishInProcess = true

      try {
        await publishList(this.list.id, !this.list.isPublic)
        this.list.isPublic = !this.list.isPublic
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.isPublishInProcess = false
    },

    onArticleDeleted (deletedArticle) {
      this.list.articles = this.list.articles.filter((article) => {
        return article.id !== deletedArticle.id
      })
    },
  },
}
</script>

<style lang="scss" src="./my-account-lists-detail.scss"></style>
