<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-terms-of-use">
      <div class="container">
        <h1 class="headline">
          {{ $t('termsOfUse.headline') }}
        </h1>

        <app-loading-box v-if="isLoading" />
        <p
          v-else
          v-html="content" />
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { PageId, getHtmlContent } from '@scripts/modules/html-content'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  data () {
    return {
      content: '',
      isLoading: true,
    }
  },

  async created () {
    this.setPageTitle(this.$t('termsOfUse.title'))

    try {
      this.content = (await getHtmlContent(PageId.TERMSOFUSE)).html
      this.isLoading = false
    } catch (e) {
      console.error(e)
      showTechnicalErrorMessage()
    }
  },
}
</script>
