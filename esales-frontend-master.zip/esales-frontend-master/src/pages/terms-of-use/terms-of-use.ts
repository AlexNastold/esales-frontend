/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/terms-of-use/terms-of-use.vue'
setup(PageComponent)
