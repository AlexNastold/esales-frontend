<template>
  <div class="section-color my-3 py-5 px-md-5 px-2 text-white text-center">
    <app-loading-box v-if="isContentLoading" />
    <div
      v-else
      class="container">
      <h2>{{ content.title }}</h2>
      <p v-html="content.html" />
      <a
        href="./registration"
        class="btn btn-outline-light text-uppercase mt-3">
        {{ $t('landingPage.registration.registerNow') }}
        <i class="fas fa-chevron-right fa-fw" />
      </a>
    </div>
  </div>
</template>
<script>
import { getHtmlContent, LandingPageSections } from '@scripts/modules/html-content'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
export default {
  data () {
    return {
      content: void 0,
      isContentLoading: true,
    }
  },
  created () {
    this.loadContent()
  },
  methods: {
    async loadContent () {
      try {
        this.content = await getHtmlContent(LandingPageSections.REGISTRATION)
        this.isContentLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
<style lang="scss">
@import '~styles/definitions/all';

.section-color {
  background-color: $landing-page-register-now;
}

</style>
