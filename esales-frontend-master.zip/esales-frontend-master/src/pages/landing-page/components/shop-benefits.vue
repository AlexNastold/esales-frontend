<template>
  <div class="bg-light">
    <div class="container py-4">
      <app-loading-box v-if="isContentLoading" />
      <div
        v-else
        class="row">
        <div
          v-for="(shopBenefit, index) in shopBenefits"
          :key="index"
          class="col-12 col-md-6 mt-4 mt-md-0">
          <h3 class="headline">
            {{ shopBenefit.title }}
          </h3>
          <p
            v-html="shopBenefit.html" />
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { getHtmlContent, LandingPageSections } from '@scripts/modules/html-content'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
export default {
  data () {
    return {
      isContentLoading: true,
      shopBenefits: [],
    }
  },
  created () {
    this.loadData()
  },

  methods: {
    async loadData () {
      try {
        let response = await getHtmlContent(LandingPageSections.BENEFITS_1_1)
        this.shopBenefits.push({
          title: response.title,
          html: response.html,
        })
        response = await getHtmlContent(LandingPageSections.BENEFITS_1_2)
        this.shopBenefits.push({
          title: response.title,
          html: response.html,
        })
        response = await getHtmlContent(LandingPageSections.BENEFITS_2_1)
        this.shopBenefits.push({
          title: response.title,
          html: response.html,
        })
        response = await getHtmlContent(LandingPageSections.BENEFITS_2_2)
        this.shopBenefits.push({
          title: response.title,
          html: response.html,
        })
        this.isContentLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
<style lang="scss">
@import '~styles/definitions/all';
.image-wrapper {
  img {
    max-height: 200px;
    max-width: 100%;

    @include media-breakpoint-up(md) {
      max-height: 250px;
    }
  }
}
</style>
