<template>
  <div class="container mt-5 mb-5">
    <app-loading-box v-if="isLoading" />
    <template v-else>
      <h2 class="text-center">
        {{ $t('landingPage.keyFacts.headline') }}
      </h2>
      <div class="row">
        <div
          v-for="(keyFact, index) in keyFacts"
          :key="index"
          class="col-12 col-md-6 mt-4 mt-md-0">
          <div class="text-center">
            <i
              class="mb-3 shop-benefits-icons"
              :class="keyFact.icon" />
            <h3>
              {{ keyFact.title }}
            </h3>
          </div>
          <p v-html="keyFact.html" />
        </div>
      </div>
    </template>
  </div>
</template>
<script>
import { getHtmlContent, LandingPageSections } from '@scripts/modules/html-content'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
export default {

  data () {
    return {
      isLoading: true,
      keyFacts: [],
    }
  },

  created () {
    this.loadFacts()
  },

  methods: {
    async loadFacts () {
      try {
        let response = await getHtmlContent(LandingPageSections.KEYFACTS_1_1)
        this.keyFacts.push({
          title: response.title,
          html: response.html,
          icon: 'fas fa-map-signs',
        })
        response = await getHtmlContent(LandingPageSections.KEYFACTS_1_2)
        this.keyFacts.push({
          title: response.title,
          html: response.html,
          icon: 'fas fa-truck',
        })
        response = await getHtmlContent(LandingPageSections.KEYFACTS_2_1)
        this.keyFacts.push({
          title: response.title,
          html: response.html,
          icon: 'fas fa-dolly',
        })
        response = await getHtmlContent(LandingPageSections.KEYFACTS_2_2)
        this.keyFacts.push({
          title: response.title,
          html: response.html,
          icon: 'fas fa-map-signs',
        })
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
<style lang="scss" scoped>
@import '~styles/definitions/all';

.shop-benefits-icons {
  background-color: $primary;
  padding: 20px;
  color: white;
  font-size: 40px;
  border-radius: 50%;
  width: 80px;
  height: 80px;
}
</style>
