<template>
  <div class="container">
    <!-- Kontaktformular -->
    <div class="bg-light row p-4">
      <div class="col-12 col-md-6 text-center">
        <!-- Ladeanzeige -->
        <app-loading-box
          v-if="isClerkLoading"
          class="loading-box" />
        <template v-else>
          <h3 class="my-3">
            {{ $t('landingPage.contact.ourContactData') }}
          </h3>
          <img
            v-if="contactPerson.picture"
            :src="contactPerson.picture | articleImage"
            class="clerk-image mb-3"
            alt="">
          <h4>
            {{ contactPerson.title }} {{ contactPerson.firstName }} {{ contactPerson.lastName }}
          </h4>
          <a :href="`mailto:` + contactPerson.emailAddress">
            <i class="fas fa-envelope fa-fw" />
            {{ contactPerson.emailAddress }}
          </a><br>
          <a :href="`tel:` + contactPerson.phone">
            <i class="fas fa-phone fa-fw mt-2" />
            {{ contactPerson.phone }}
          </a>
        </template>
      </div>
      <div class="col-12 col-md-6">
        <h3 class="my-3 text-center">
          {{ $t('landingPage.contact.getInTouch') }}
        </h3>

        <form @submit.prevent="sendMail">
          <!-- Email -->
          <div class="form-group">
            <label>
              {{ $t('landingPage.contact.fields.email') }}
              <span class="required" />
            </label>
            <input
              v-model="formEmail"
              :class="{'is-invalid': formErrors[MailToClerkFieldErrors.EMAIL]}"
              :placeholder="$t('landingPage.contact.fields.emailPlaceholder')"
              type="text"
              class="form-control">
            <div
              v-if="formErrors[MailToClerkFieldErrors.EMAIL]"
              class="invalid-feedback"
              v-html="formErrors[MailToClerkFieldErrors.EMAIL]" />
          </div>

          <!-- Phone -->
          <div class="form-group">
            <label>
              {{ $t('landingPage.contact.fields.phone') }}
            </label>
            <input
              v-model="formPhone"
              :placeholder="$t('landingPage.contact.fields.phonePlaceholder')"
              type="text"
              class="form-control">
          </div>

          <!-- Betreff -->
          <div class="form-group">
            <label>
              {{ $t('landingPage.contact.fields.subject') }}
              <span class="required" />
            </label>
            <input
              v-model="formSubject"
              :class="{'is-invalid': formErrors[MailToClerkFieldErrors.SUBJECT]}"
              :placeholder="$t('landingPage.contact.fields.subjectPlaceholder')"
              type="text"
              class="form-control">
            <div
              v-if="formErrors[MailToClerkFieldErrors.SUBJECT]"
              class="invalid-feedback"
              v-html="formErrors[MailToClerkFieldErrors.SUBJECT]" />
          </div>

          <!-- Nachricht -->
          <div class="form-group">
            <label>
              {{ $t('landingPage.contact.fields.message') }}
              <span class="required" />
            </label>
            <textarea
              v-model="formMessage"
              :class="{'is-invalid': formErrors[MailToClerkFieldErrors.MESSAGE]}"
              :placeholder="$t('landingPage.contact.fields.messagePlaceholder')"
              class="form-control"
              rows="5" />
            <div
              v-if="formErrors[MailToClerkFieldErrors.MESSAGE]"
              class="invalid-feedback"
              v-html="formErrors[MailToClerkFieldErrors.MESSAGE]" />
          </div>

          <!-- Kopie an mich senden -->
          <div
            v-if="canSendCopy"
            class="custom-control custom-checkbox d-flex align-items-center">
            <input
              id="service-contact-checkbox-send-copy"
              v-model="formSendCopy"
              type="checkbox"
              class="custom-control-input">
            <label
              class="custom-control-label"
              for="service-contact-checkbox-send-copy">
              {{ $t('landingPage.contact.fields.copy') }}
            </label>
          </div>

          <app-form-required-hint class="my-2" />

          <!-- Absenden Button -->
          <div class="d-md-flex justify-content-end">
            <!-- Button Mobile -->
            <div class="d-md-none">
              <button
                :disabled="isProcessing"
                type="submit"
                class="btn btn-block btn-primary">
                <app-icon-state
                  :is-loading="isProcessing"
                  icon="fas fa-paper-plane" />
                {{ $t('landingPage.contact.actions.send') }}
              </button>
            </div>

            <!-- Button Desktop -->
            <div class="d-none d-md-block">
              <button
                :disabled="isProcessing"
                type="submit"
                class="btn btn-primary">
                <app-icon-state
                  :is-loading="isProcessing"
                  icon="fas fa-paper-plane" />
                {{ $t('landingPage.contact.actions.send') }}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>
<script>
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { MailToClerkFieldErrors, sendMailToClerk } from '@scripts/modules/service'
import { ErrorCode } from '@scripts/modules/errors'
import { getClerk } from '@scripts/modules/landing-page'

export default {

  data () {
    return {
      isProcessing: false,
      isClerkLoading: true,

      errorMessage: '',

      formMessage: '',
      formSendCopy: true,
      formEmail: '',
      formPhone: '',
      formSubject: '',
      formErrors: {},
      MailToClerkFieldErrors,

      canSendCopy: true,
      contactPerson: {},
    }
  },

  created () {
    this.getContactPerson()
  },

  methods: {
    async getContactPerson () {
      try {
        this.contactPerson = await getClerk()
        this.isClerkLoading = false
      }
      catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },

    async sendMail () {
      if (this.isProcessing) {
        return
      }

      this.isProcessing = true
      this.formErrors = ''
      try {
        await sendMailToClerk(
          this.formEmail,
          this.formPhone,
          this.formSubject,
          this.formMessage,
          this.canSendCopy ? this.formSendCopy : false,
        )
        this.resetForm()
        showSuccessMessage('Hat gefunzt')
        this.resetForm
      } catch (e) {
        if (e.code === ErrorCode.INVALID_FIELDS) {
          this.errorMessage = this.$t('general.invalidFieldsMessage')
          this.formErrors = e.fieldErrors
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
      this.isProcessing = false
    },
    resetForm () {
      this.formPhone = ''
      this.formEmail = ''
      this.formMessage = ''
      this.formSendCopy = true
      this.formSubject = ''
    },
  },
}
</script>

<style lang="scss" src="../landing-page.scss"></style>

<style lang="scss" scoped>
@import '~styles/definitions/all';
.clerk-image {
  border-radius: 50%;
  width: 50%;
}

</style>
