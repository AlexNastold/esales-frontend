<template>
  <div>
    <!-- Header -->
    <layout-header-landing-page />
    <main class="page-landing-page mt-0">
      <!-- Slider -->
      <slider />
      <!-- Shopvorteile -->
      <benefits />
      <!-- Fakten -->
      <key-facts />
      <!-- Registrieren Banner -->
      <registration />
      <!-- Kontaktform -->
      <contact-form />
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import LayoutHeaderLandingPage from './components/layout-header-landing-page'
import Slider from './components/news-slider'
import Benefits from './components/shop-benefits'
import KeyFacts from './components/key-facts'
import Registration from './components/registration'
import ContactForm from './components/contact-form'
export default {
  components: {
    LayoutHeaderLandingPage,
    Slider,
    Benefits,
    KeyFacts,
    Registration,
    ContactForm,
  },

  data () {
    return {
      content: '',
    }
  },

  created () {
    this.setPageTitle(this.$t('landingPage.pageTitle'))
  },
}
</script>

<style lang="scss" src="./landing-page.scss"></style>


