<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-baskets-edit">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountBasketsEdit.baskets')"
        page="baskets" />

      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item">
            <a href="my-account-baskets">
              {{ $t('myAccountBasketsEdit.baskets') }}
            </a>
          </li>
          <li
            v-if="isLoading"
            class="breadcrumb-item">
            <app-loading-spinner class="d-inline-block" />
          </li>
          <li
            v-else-if="!basket"
            class="breadcrumb-item text-danger">
            {{ $t('myAccountBasketsEdit.notFoundBreadcrumb') }}
          </li>
          <li
            v-else
            class="breadcrumb-item">
            {{ basket.name }}
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountBasketsEdit.edit') }}
          </li>
        </ol>

        <h2 class="mb-3">
          {{ $t('myAccountBasketsEdit.editBasket') }}
        </h2>

        <!-- Ladeanzeige -->
        <app-loading-box v-if="isLoading" />

        <!-- Adresse nicht gefunden -->
        <app-box-oops
          v-else-if="!basket"
          link-title="Zurück zur Übersicht"
          link-href="my-account-baskets">
          {{ $t('myAccountBasketsEdit.notFoundMessage') }}
        </app-box-oops>


        <form
          v-else
          @submit.prevent="editBasket">
          <div class="row">
            <!-- Bezeichnung -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label>{{ $t('myAccountBasketsEdit.name') }} <span class="required" /></label>
                <input
                  v-model="name"
                  :class="{'is-invalid': nameError}"
                  :placeholder="$t('myAccountBasketsEdit.namePlaceholder')"
                  type="text"
                  maxlength="35"
                  class="form-control"
                  autofocus>
                <div
                  v-if="nameError"
                  class="invalid-feedback">
                  {{ nameError }}
                </div>
              </div>
            </div>

            <!-- Bestellnummer -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label>{{ $t('myAccountBasketsEdit.orderId') }}</label>
                <input
                  v-model="customOrderNumber"
                  :placeholder="$t('myAccountBasketsEdit.orderIdPlaceholder')"
                  type="text"
                  maxlength="35"
                  class="form-control">
              </div>
            </div>

            <div class="col-12 col-lg-6 mb-2 mb-lg-0">
              <app-form-required-hint />
            </div>

            <!-- Buttons -->
            <div class="col-12 col-lg-6 text-lg-right">
              <!-- Buttons Mobile -->
              <div class="d-lg-none">
                <!-- Button Speichern -->
                <button
                  :disabled="!name || isInProcess"
                  type="submit"
                  class="btn btn-block btn-primary mb-1">
                  <app-icon-state
                    :is-loading="isInProcess"
                    icon="fas fa-save" />
                  {{ $t('general.save') }}
                </button>
                <!-- Button Abbrechen -->
                <a
                  href="my-account-baskets"
                  class="btn btn-block btn-secondary">
                  <i class="fas fa-times fa-fw" />
                  {{ $t('general.cancel') }}
                </a>
              </div>

              <!-- Buttons Desktop -->
              <div class="d-none d-lg-block">
                <!-- Button Abbrechen -->
                <a
                  href="my-account-baskets"
                  class="btn btn-secondary">
                  <i class="fas fa-times fa-fw" />
                  {{ $t('general.cancel') }}
                </a>
                <!-- Button Speichern -->
                <button
                  :disabled="!name || isInProcess"
                  type="submit"
                  class="btn btn-primary">
                  <app-icon-state
                    :is-loading="isInProcess"
                    icon="fas fa-save" />
                  {{ $t('general.save') }}
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { createFlashMessage } from '@scripts/helper/flash-messages'
import { redirect } from '@scripts/helper/redirect'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { editBasket, getBaskets } from '@scripts/modules/basket'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'

import MyAccountHeader from '@components/pages/my-account/header.vue'

export default {
  components: {
    'my-account-header': MyAccountHeader,
  },

  data () {
    return {
      isInProcess: false,
      isLoading: true,

      basket: void 0,

      customOrderNumber: '',
      name: '',

      nameError: '',
    }
  },
  created () {
    this.setPageTitle(this.$t('myAccountBasketsEdit.title'))

    const basketIdFromUrl = getQueryParameter('id')
    this.loadBasket(basketIdFromUrl)
  },

  methods: {
    async loadBasket (basketId) {
      this.isLoading = true

      try {
        const baskets = (await getBaskets()).multibaskets
        this.basket = baskets.find((basket) => basket.name === basketId)
        if (this.basket) {
          this.customOrderNumber = this.basket.kommi
          this.name = this.basket.name
        }
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },

    async editBasket () {
      if (this.isInProcess) {
        return
      }

      this.isInProcess = true
      this.nameError = ''

      try {
        await editBasket(this.basket.name, this.name, this.customOrderNumber)

        createFlashMessage(this.$t('myAccountBasketsEdit.message'), 'success')
        redirect('my-account-baskets')
      } catch (e) {
        if (e.code === ErrorCode.INVALID_NAME) {
          this.nameError = this.$t('myAccountBasketsEdit.invalidName')
        } else if (e.code === ErrorCode.NAME_ALREADY_TAKEN) {
          this.nameError = this.$t('myAccountBasketsEdit.nameAlreadyTaken')
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }

        this.isInProcess = false
      }
    },
  },
}
</script>

<style lang="scss" src="./my-account-baskets-edit.scss"></style>
