<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-campaigns">
      <div class="container">
        <!-- Seitenüberschrift -->
        <h1 class="headline">
          {{ $t('campaigns.headline') }}
        </h1>

        <app-loading-box v-if="isLoading" />
        <div
          v-else-if="!campaigns.length"
          class="border rounded mb-3">
          <app-box-empty-list
            :headline="$t('campaigns.listEmpty')"
            icon="fas fa-percent">
            <span v-html="$t('campaigns.listEmptyDescription')" />
          </app-box-empty-list>
        </div>

        <!-- Auflistung Aktionen -->
        <div
          v-else
          class="row">
          <div
            v-for="campaign in campaigns"
            :key="campaign.id"
            class="col-12 col-lg-6 mb-3">
            <app-campaign-preview :campaign="campaign" />
          </div>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { getCampaigns } from '@scripts/modules/campaigns'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  data () {
    return {
      campaigns: [],
      isLoading: true,
    }
  },

  created () {
    this.setPageTitle(this.$t('campaigns.title'))
    this.loadCampaigns()
  },

  methods: {
    async loadCampaigns () {
      try {
        this.campaigns = await getCampaigns()
        this.isLoading = false
      } catch (e) {
        console.error()
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
