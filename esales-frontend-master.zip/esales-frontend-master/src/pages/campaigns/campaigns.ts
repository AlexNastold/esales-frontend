/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/campaigns/campaigns.vue'
setup(PageComponent)
