<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-manage-users-create">
      <!-- My Account Header -->
      <my-account-header
        page="manage-users"
        headline="Benutzer verwalten" />

      <div class="container">
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item">
            <a href="my-account-manage-users">
              {{ $t('myAccountManageUsersCreate.manageUsers') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountManageUsersCreate.createUser') }}
          </li>
        </ol>

        <h2 class="mb-3">
          {{ $t('myAccountManageUsersCreate.createUser') }}
        </h2>

        <form
          novalidate
          @submit.prevent="createUser">
          <div class="row">
            <!-- Card Persönliche Daten -->
            <div class="col-12 col-lg-6 mb-3 mb-lg-0">
              <div class="card mb-1">
                <div class="card-header">
                  {{ $t('myAccountManageUsersCreate.userdata.cardheader') }}
                </div>
                <div class="card-body">
                  <!-- Anrede -->
                  <div class="form-group">
                    <label for="title">
                      {{ $t('myAccountManageUsersCreate.userdata.title') }} <span class="required" />
                    </label>
                    <select
                      id="title"
                      v-model="formFields.title"
                      :class="{ 'is-invalid': formErrors.title }"
                      class="form-control custom-select">
                      <option :value="void 0">
                        {{ $t('myAccountManageUsersCreate.userdata.placeholder.title') }}
                      </option>
                      <option
                        v-for="title in titles"
                        :key="title.key"
                        :value="title.key">
                        {{ title.label }}
                      </option>
                    </select>
                    <div
                      v-if="formErrors.title"
                      class="invalid-feedback"
                      v-html="formErrors.title" />
                  </div>

                  <!-- Nachname, Firma -->
                  <div class="form-group">
                    <label for="lastname-company">
                      {{ $t('myAccountManageUsersCreate.userdata.company') }} <span class="required" />
                    </label>
                    <input
                      id="lastname-company"
                      v-model="formFields.lastname"
                      :class="{ 'is-invalid': formErrors.lastname }"
                      :placeholder="$t('myAccountManageUsersCreate.userdata.placeholder.company')"
                      type="text"
                      class="form-control"
                      maxlength="35">
                    <div
                      v-if="formErrors.lastname"
                      class="invalid-feedback"
                      v-html="formErrors.lastname" />
                  </div>

                  <!-- Vorname -->
                  <div class="form-group">
                    <label for="firstname">
                      {{ $t('myAccountManageUsersCreate.userdata.firstName') }}
                    </label>
                    <input
                      id="firstname"
                      v-model="formFields.firstname"
                      :placeholder="$t('myAccountManageUsersCreate.userdata.placeholder.firstName')"
                      type="text"
                      class="form-control"
                      maxlength="35">
                  </div>

                  <!-- Alias -->
                  <div class="form-group">
                    <label for="alias">
                      {{ $t('myAccountManageUsersCreate.userdata.alias') }}
                    </label>
                    <input
                      id="alias"
                      v-model="formFields.alias"
                      :class="{ 'is-invalid': formErrors.alias }"
                      :placeholder="$t('myAccountManageUsersCreate.userdata.placeholder.alias')"
                      type="text"
                      class="form-control"
                      maxlength="136">
                    <div
                      v-if="formErrors.alias"
                      class="invalid-feedback"
                      v-html="formErrors.alias" />
                  </div>

                  <!-- E-Mail Adresse -->
                  <div class="form-group">
                    <label for="email">
                      {{ $t('myAccountManageUsersCreate.userdata.mail') }} <sup>1</sup>
                    </label>
                    <input
                      id="email"
                      v-model="formFields.emailAddress"
                      :class="{ 'is-invalid': formErrors.emailAddress }"
                      :placeholder="$t('myAccountManageUsersCreate.userdata.placeholder.mail')"
                      type="email"
                      class="form-control"
                      maxlength="70">
                    <div
                      v-if="formErrors.emailAddress"
                      class="invalid-feedback"
                      v-html="formErrors.emailAddress" />
                  </div>

                  <!-- Telefonnummer -->
                  <div class="form-group">
                    <label for="telephone">
                      {{ $t('myAccountManageUsersCreate.userdata.phone') }}
                    </label>
                    <input
                      id="telephone"
                      v-model="formFields.phone"
                      :class="{ 'is-invalid': formErrors.phone }"
                      :placeholder="$t('myAccountManageUsersCreate.userdata.placeholder.phone')"
                      type="text"
                      class="form-control"
                      maxlength="30">
                    <div
                      v-if="formErrors.phone"
                      class="invalid-feedback"
                      v-html="formErrors.phone" />
                  </div>

                  <!-- Fax -->
                  <div class="form-group">
                    <label for="fax">
                      {{ $t('myAccountManageUsersCreate.userdata.fax') }}
                    </label>
                    <input
                      id="fax"
                      v-model="formFields.fax"
                      :class="{ 'is-invalid': formErrors.fax }"
                      :placeholder="$t('myAccountManageUsersCreate.userdata.placeholder.fax')"
                      type="text"
                      class="form-control"
                      maxlength="30">
                    <div
                      v-if="formErrors.fax"
                      class="invalid-feedback"
                      v-html="formErrors.fax" />
                  </div>
                </div>
              </div>

              <div>
                <sup>1</sup> {{ $t('myAccountManageUsersCreate.sup') }}
              </div>
            </div>

            <!-- Card Einstellungen -->
            <div class="col-12 col-lg-6">
              <div class="card mb-1">
                <div class="card-header">
                  {{ $t('myAccountManageUsersCreate.settings.cardheader') }}
                </div>
                <div class="card-body">
                  <!-- Sprache -->
                  <div class="form-group">
                    <label for="language">
                      {{ $t('myAccountManageUsersCreate.settings.language') }} <span class="required" />
                    </label>
                    <select
                      id="language"
                      v-model="formFields.language"
                      :class="{ 'is-invalid': formErrors.language }"
                      class="form-control custom-select">
                      <option :value="void 0">
                        {{ $t('myAccountManageUsersCreate.settings.placeholder.language') }}
                      </option>
                      <option
                        v-for="language in languages"
                        :key="language.key"
                        :value="language.key">
                        {{ language.label }}
                      </option>
                    </select>
                    <div
                      v-if="formErrors.language"
                      class="invalid-feedback"
                      v-html="formErrors.language" />
                  </div>

                  <!-- Währung -->
                  <div class="form-group">
                    <label for="currency">
                      {{ $t('myAccountManageUsersCreate.settings.currency') }} <span class="required" />
                    </label>
                    <select
                      id="currency"
                      v-model="formFields.currency"
                      :class="{ 'is-invalid': formErrors.currency }"
                      class="form-control custom-select">
                      <option :value="void 0">
                        {{ $t('myAccountManageUsersCreate.settings.placeholder.currency') }}
                      </option>
                      <option
                        v-for="currency in currencies"
                        :key="currency.key"
                        :value="currency.key">
                        {{ currency.label }}
                      </option>
                    </select>
                    <div
                      v-if="formErrors.currency"
                      class="invalid-feedback"
                      v-html="formErrors.currency" />
                  </div>

                  <!-- Gesperrt -->
                  <div class="custom-control custom-checkbox">
                    <input
                      id="checkbox-useradm-create-user-locked"
                      v-model="formFields.locked"
                      type="checkbox"
                      class="custom-control-input">
                    <label
                      for="checkbox-useradm-create-user-locked"
                      class="custom-control-label">
                      <i class="fas fa-lock fa-fw" />
                      {{ $t('myAccountManageUsersCreate.settings.locked') }}
                    </label>
                  </div>
                </div>
              </div>

              <app-form-required-hint class="mb-3" />

              <!-- Buttons -->
              <div class="d-lg-none">
                <button
                  type="submit"
                  class="btn btn-block btn-primary mb-1">
                  <app-icon-state
                    :is-loading="isCreateUserInProcess"
                    icon="fas fa-user-plus" />
                  {{ $t('myAccountManageUsersCreate.createUser') }}
                </button>
                <a
                  class="btn btn-block btn-secondary"
                  href="my-account-manage-users">
                  <i class="fas fa-times fa-fw" />
                  {{ $t('general.cancel') }}
                </a>
              </div>
              <div class="d-none d-lg-block text-right">
                <a
                  class="btn btn-secondary"
                  href="my-account-manage-users">
                  <i class="fas fa-times fa-fw" />
                  {{ $t('general.cancel') }}
                </a>
                <button
                  type="submit"
                  class="btn btn-primary">
                  <app-icon-state
                    :is-loading="isCreateUserInProcess"
                    icon="fas fa-user-plus" />
                  {{ $t('myAccountManageUsersCreate.createUser') }}
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { pageSettingsMyAccountManageUsersCreate } from '@scripts/app/settings'
import { redirect } from '@scripts/helper/redirect'
import { showErrorMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'
import { createUser, CreateUserFields } from '@scripts/modules/useradm'

import MyAccountHeader from '@components/pages/my-account/header.vue'

export default {
  components: {
    'my-account-header': MyAccountHeader,
  },

  data () {
    return {
      isCreateUserInProcess: false,

      currencies: pageSettingsMyAccountManageUsersCreate.currencies,
      languages: pageSettingsMyAccountManageUsersCreate.languages,
      titles: pageSettingsMyAccountManageUsersCreate.titles,

      formFields: {
        alias: '',
        currency: void 0,
        emailAddress: '',
        fax: '',
        firstname: '',
        language: void 0,
        lastname: '',
        locked: false,
        phone: '',
        title: void 0,
      },

      formErrors: {
        alias: '',
        currency: '',
        emailAddress: '',
        fax: '',
        language: '',
        lastname: '',
        phone: '',
        title: '',
      },
    }
  },

  created () {
    this.setPageTitle(this.$t('myAccountManageUsersCreate.title'))
  },

  methods: {
    async createUser () {
      this.isCreateUserInProcess = true

      try {
        const userId = await createUser({
          alias: this.formFields.alias,
          currency: this.formFields.currency,
          emailAddress: this.formFields.emailAddress,
          fax: this.formFields.fax,
          firstname: this.formFields.firstname,
          language: this.formFields.language,
          lastname: this.formFields.lastname,
          locked: this.formFields.locked,
          phone: this.formFields.phone,
          title: this.formFields.title,
        })

        redirect('my-account-manage-users-detail', { id: userId })
      } catch (e) {
        if (e.code === ErrorCode.INVALID_FIELDS) {
          showErrorMessage(this.$t('general.invalidFieldsMessage'))
          this.showFieldErrors(e.fieldErrors)
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }

        this.isCreateUserInProcess = false
      }
    },

    /**
     * Show the field errors
     *
     * @param {any} [fieldErrors] - Field errors
     */
    showFieldErrors (fieldErrors) {
      this.resetFieldErrors()
      for (const fieldname in fieldErrors) {
        if (Object.prototype.hasOwnProperty.call(fieldErrors, fieldname)) {
          const message = fieldErrors[fieldname]
          if (fieldname === CreateUserFields.TITLE) {
            this.formErrors.title = message
          } else if (fieldname === CreateUserFields.LASTNAME) {
            this.formErrors.lastname = message
          } else if (fieldname === CreateUserFields.ALIAS) {
            this.formErrors.alias = message
          } else if (fieldname === CreateUserFields.EMAIL_ADDRESS) {
            this.formErrors.emailAddress = message
          } else if (fieldname === CreateUserFields.PHONE) {
            this.formErrors.phone = message
          } else if (fieldname === CreateUserFields.FAX) {
            this.formErrors.fax = message
          } else if (fieldname === CreateUserFields.LANGUAGE) {
            this.formErrors.language = message
          } else if (fieldname === CreateUserFields.CURRENCY) {
            this.formErrors.currency = message
          }
        }
      }
    },

    /**
     * Reset the field errors
     */
    resetFieldErrors () {
      this.formErrors.title = ''
      this.formErrors.lastname = ''
      this.formErrors.alias = ''
      this.formErrors.emailAddress = ''
      this.formErrors.phone = ''
      this.formErrors.fax = ''
      this.formErrors.language = ''
      this.formErrors.currency = ''
    },
  },
}
</script>

<style lang="scss" src="./my-account-manage-users-create.scss"></style>
