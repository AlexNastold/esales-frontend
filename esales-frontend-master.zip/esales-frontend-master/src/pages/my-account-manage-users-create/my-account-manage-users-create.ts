/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/my-account-manage-users-create/my-account-manage-users-create.vue'
setup(PageComponent)
