<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-addresses-sap-add">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountAddressesSapAdd.addresses')"
        page="addresses" />

      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item">
            <a href="my-account-addresses">
              {{ $t('myAccountAddressesSapAdd.addresses') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountAddressesSapAdd.requestRecipient') }}
          </li>
        </ol>

        <!-- Seitenüberschrift -->
        <h2 class="mb-3">
          {{ $t('myAccountAddressesSapAdd.requestRecipient') }}
        </h2>

        <p class="mb-3">
          {{ $t('myAccountAddressesSapAdd.formDescription') }}.
        </p>

        <div
          v-show="errorMessage"
          class="alert alert-danger"
          role="alert"
          v-html="errorMessage" />

        <form
          class="mb-3"
          @submit.prevent="sendForm">
          <div class="row">
            <!-- Nachname/Firma -->
            <div class="col-12 col-lg-6">
              <div class="form-group">
                <label>{{ $t('myAccountAddressesSapAdd.company') }}</label> <span class="required" />
                <input
                  v-model="formFieldName1"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.LASTNAME]}"
                  :placeholder="$t('myAccountAddressesSapAdd.companyPlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="35"
                  autofocus>
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.LASTNAME]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.LASTNAME]" />
              </div>
            </div>

            <!-- Vorname -->
            <div class="col-12 col-lg-6">
              <div class="form-group">
                <label>{{ $t('myAccountAddressesSapAdd.firstName') }}</label>
                <input
                  v-model="formFieldName2"
                  :placeholder="$t('myAccountAddressesSapAdd.firstNamePlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="35">
              </div>
            </div>

            <!-- Straße -->
            <div class="col-12 col-lg-6">
              <div class="form-group">
                <label>{{ $t('myAccountAddressesSapAdd.street') }}</label> <span class="required" />
                <input
                  v-model="formFieldStreet"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.STREET]}"
                  :placeholder="$t('myAccountAddressesSapAdd.streetPlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="35">
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.STREET]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.STREET]" />
              </div>
            </div>

            <!-- Postleitzahl -->
            <div class="col-12 col-lg-6">
              <div class="form-group">
                <label>{{ $t('myAccountAddressesSapAdd.plz') }}</label> <span class="required" />
                <input
                  v-model="formFieldPostalCode"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.ZIPCODE]}"
                  :placeholder="$t('myAccountAddressesSapAdd.plzPlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="10">
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.ZIPCODE]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.ZIPCODE]" />
              </div>
            </div>

            <!-- Ort -->
            <div class="col-12 col-lg-6">
              <div class="form-group">
                <label>{{ $t('myAccountAddressesSapAdd.city') }}</label> <span class="required" />
                <input
                  v-model="formFieldCity"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.CITY]}"
                  :placeholder="$t('myAccountAddressesSapAdd.cityPlaceholder')"
                  type="text"
                  class="form-control"
                  maxlength="35">
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.CITY]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.CITY]" />
              </div>
            </div>

            <!-- Land -->
            <div class="col-12 col-lg-6">
              <div class="form-group">
                <label>{{ $t('myAccountAddressesSapAdd.country') }}</label>
                <select
                  v-model="formFieldCountry"
                  :class="{'is-invalid': formErrors[DeliveryAddressFieldErrors.COUNTRY]}"
                  class="custom-select">
                  <option :value="void 0">
                    {{ $t('myAccountAddressesSapAdd.selectCountry') }}
                  </option>
                  <option
                    v-for="country of app.pageSettings.countries"
                    :key="country.key"
                    :value="country.key">
                    {{ country.label }}
                  </option>
                </select>
                <div
                  v-if="formErrors[DeliveryAddressFieldErrors.COUNTRY]"
                  class="invalid-feedback"
                  v-html="formErrors[DeliveryAddressFieldErrors.COUNTRY]" />
              </div>
            </div>

            <div class="col-12 col-lg-6 mb-2 mb-lg-0">
              <app-form-required-hint />
            </div>
          </div>

          <!-- Buttons -->
          <div class="d-md-flex justify-content-end">
            <!-- Buttons Mobile -->
            <div class="d-md-none">
              <button
                :disabled="isProcessing"
                type="submit"
                class="btn btn-block btn-primary mb-1">
                <app-icon-state
                  :is-loading="isProcessing"
                  icon="fas fa-paper-plane fa-fw" />
                {{ $t('myAccountAddressesSapAdd.request') }}
              </button>
              <a
                href="my-account-addresses"
                class="btn btn-block btn-secondary">
                <i class="fas fa-times fa-fw" />
                {{ $t('general.cancel') }}
              </a>
            </div>

            <!-- Buttons Desktop -->
            <div class="d-none d-md-block">
              <a
                href="my-account-addresses"
                class="btn btn-secondary">
                <i class="fas fa-times fa-fw" />
                {{ $t('general.cancel') }}
              </a>
              <button
                :disabled="isProcessing"
                type="submit"
                class="btn btn-primary">
                <app-icon-state
                  :is-loading="isProcessing"
                  icon="fas fa-paper-plane fa-fw" />
                {{ $t('myAccountAddressesSapAdd.request') }}
              </button>
            </div>
          </div>
        </form>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { pageSettings } from '@scripts/app/settings'
import { createFlashMessage } from '@scripts/helper/flash-messages'
import { redirect } from '@scripts/helper/redirect'
import { DeliveryAddressFieldErrors, createDeliveryAddressSAP } from '@scripts/modules/delivery-addresses'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'

import MyAccountHeader from '@components/pages/my-account/header.vue'

export default {
  components: {
    'my-account-header': MyAccountHeader,
  },

  data () {
    return {
      formFieldCity: '',
      formFieldCountry: pageSettings.countries.length
        ? pageSettings.countries[0].key
        : void 0,
      formFieldName1: '',
      formFieldName2: '',
      formFieldPostalCode: '',
      formFieldStreet: '',

      errorMessage: '',
      formErrors: {},
      DeliveryAddressFieldErrors,

      isProcessing: false,
    }
  },

  methods: {
    async sendForm () {
      if (this.isProcessing) {
        return
      }

      this.isProcessing = true
      this.formErrors = {}

      try {
        await createDeliveryAddressSAP(
          this.formFieldName1,
          this.formFieldName2,
          this.formFieldStreet,
          this.formFieldPostalCode,
          this.formFieldCity,
          this.formFieldCountry,
        )

        createFlashMessage(
          this.$t('myAccountAddressesSapAdd.requestSent'),
          'success',
        )
        redirect('my-account-addresses')
      } catch (e) {
        if (e.code === ErrorCode.INVALID_FIELDS) {
          this.errorMessage = this.$t('general.invalidFieldsMessage')
          this.formErrors = e.fieldErrors
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
      this.isProcessing = false
    },
  },
}
</script>

<style lang="scss" src="./my-account-addresses-sap-add.scss"></style>
