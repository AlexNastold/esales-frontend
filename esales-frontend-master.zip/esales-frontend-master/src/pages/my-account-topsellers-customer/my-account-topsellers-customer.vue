<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-topsellers-customer">
      <!--  My Account Header -->
      <my-account-header
        :headline="$t('myAccountTopseller.customer.headline')"
        page="topsellers-customer-number" />

      <div class="container">
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountTopseller.customer.breadcrumb') }}
          </li>
        </ol>

        <!-- Button Absprung globale Topseller -->
        <a
          href="my-account-topsellers"
          class="btn btn-primary mb-3">
          {{ $t('myAccountTopseller.personal.show') }}
        </a>

        <!-- Lade Anzeige -->
        <app-loading-box v-if="isLoading" />

        <!-- Topseller Liste -->
        <template v-else-if="topsellers.length">
          <div class="list-group">
            <div
              v-for="topseller in topsellers"
              :key="topseller.matnr"
              class="list-group-item">
              <app-article-item
                :article="topseller"
                pitcher="topseller" />
            </div>
          </div>
        </template>

        <!-- Keine Topseller Meldung -->
        <div
          v-else
          class="border rounded mb-3">
          <app-box-empty-list
            :headline="$t('myAccountTopseller.customer.listEmpty')"
            icon="fas fa-chart-line">
            <span v-html="$t('myAccountTopseller.customer.listEmptyDescription')" />
          </app-box-empty-list>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getTopsellers, TopsellerType } from '@scripts/modules/topseller'

import MyAccountHeader from '@components/pages/my-account/header.vue'

export default {
  components: {
    'my-account-header': MyAccountHeader,
  },

  data () {
    return {
      isLoading: true,
      topsellers: [],
    }
  },

  created () {
    this.setPageTitle(this.$t('myAccountTopseller.customer.title'))
    this.loadTopsellers()
  },

  methods: {
    async loadTopsellers () {
      try {
        this.topsellers = (await getTopsellers(TopsellerType.CUSTOMER, { amount: 99999 })).topsellers
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>

<style lang="scss" src="./my-account-topsellers-customer.scss"></style>
