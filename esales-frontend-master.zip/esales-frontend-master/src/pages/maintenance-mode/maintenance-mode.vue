<template>
  <div>
    <main class="page-maintenance-mode">
      <div class="container">
        <div v-html="html" />
      </div>
    </main>
  </div>
</template>

<script>
import { getHtmlContent, PageId } from '@scripts/modules/html-content'
export default {
  data () {
    return {
      htmlContent: {},
    }
  },
  computed: {
    html () {
      return this.htmlContent.html
    },
    title () {
      return this.htmlContent.title
    },
  },
  async created () {
    this.htmlContent = await getHtmlContent(PageId.MAINTENANCE_MODE)
    this.setPageTitle(this.title)
  },
}
</script>

<style lang="scss" src="./maintenance-mode.scss"></style>

<style lang="scss" scoped>
@import '~styles/definitions/all';
</style>
