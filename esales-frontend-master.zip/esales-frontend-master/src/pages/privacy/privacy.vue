<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-privacy">
      <div class="container">
        <h1 class="headline">
          {{ $t('privacy.headline') }}
        </h1>

        <app-loading-box v-if="isLoading" />
        <p
          v-else
          v-html="content" />

        <div v-if="applicationSettings.gtagActive && applicationSettings.gtagTrackingID">
          <app-loading-box v-if="contentGoogleAnalyticsLoading" />
          <p
            v-else
            v-html="contentGoogleAnalytics" />
          <button
            class="btn btn-warning mb-5 ml-2"
            @click="gtagOptout">
            {{ $t('privacy.googleAnalyticsWebtrackingDeactivate') }}
          </button>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>

import { PageId, getHtmlContent } from '@scripts/modules/html-content'
import { applicationSettings } from '@scripts/app/settings'
import { gtagOptout } from '@scripts/core/setup/gtag'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  data () {
    return {
      content: '',
      isLoading: true,
      contentGoogleAnalytics: '',
      contentGoogleAnalyticsLoading: true,
      gtagOptout,
      applicationSettings,
    }
  },

  async created () {
    this.setPageTitle(this.$t('privacy.title'))

    try {
      this.content = (await getHtmlContent(PageId.PRIVACY)).html
      this.isLoading = false
      this.contentGoogleAnalytics = (await getHtmlContent(PageId.PRIVACY_GOOGLE_ANALYTICS)).html
      this.contentGoogleAnalyticsLoading = false
    } catch (e) {
      console.error(e)
      showTechnicalErrorMessage()
    }
  },
}

</script>
