<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main
      :class="{'mt-0': !isLoading && news && news.banner}"
      class="page-news">
      <!-- Ladeanzeige -->
      <div
        v-if="isLoading"
        class="container">
        <app-loading-box />
      </div>

      <!-- News nicht gefunden -->
      <div
        v-else-if="!news"
        class="container">
        <app-box-oops
          :link-title="$t('news.detail.notFoundActionBackToStartpage')"
          link-href="index">
          {{ $t('news.detail.notFoundDescription') }}
        </app-box-oops>
      </div>

      <!-- News-Inhalt -->
      <template v-else>
        <!-- Banner -->
        <div
          v-if="news.banner"
          :style="`background-image: url(${$options.filters.externalImage(news.banner)});`"
          class="banner-image" />

        <div class="container">
          <!-- Überschrift -->
          <div class="my-3">
            <h1>{{ news.title }}</h1>
            <span
              v-if="news.validTo"
              class="text-muted">
              {{ $t('news.detail.fields.validTo', { date: $options.filters.date(news.validTo) }) }}
            </span>
          </div>

          <!-- Text -->
          <p v-html="news.text" />
        </div>
      </template>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { ErrorCode } from '@scripts/modules/errors'
import { getNews } from '@scripts/modules/news'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'


export default {
  data () {
    return {
      isLoading: true,
      news: void 0,
    }
  },

  created () {
    const newsIdFromUrl = getQueryParameter('id')
    this.loadNews(newsIdFromUrl)
  },

  methods: {
    async loadNews (newsId) {
      try {
        this.news = await getNews(newsId)
        this.setPageTitle(this.news.title)
        this.isLoading = false
      } catch (e) {
        if (e.code === ErrorCode.NOT_FOUND) {
          // Ist ok, es darf nur nicht `this.news` gesetzt werden
          this.isLoading = false
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },
  },
}
</script>

<style lang="scss" src="./news.scss"></style>
