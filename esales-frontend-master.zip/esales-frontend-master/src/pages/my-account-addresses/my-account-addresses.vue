<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-addresses">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountAddresses.addresses')"
        page="addresses" />

      <div class="container">
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountAddresses.addresses') }}
          </li>
        </ol>

        <!-- Ladeanzeige -->
        <app-loading-box v-if="isLoading" />

        <div v-else>
          <!-- Adress-Suche -->
          <div class="input-group mb-3">
            <input
              v-model="filter"
              :placeholder="$t('myAccountAddresses.searchAddress')"
              type="search"
              class="form-control">
            <div class="input-group-append">
              <button
                type="button"
                class="btn btn-secondary"
                @click="resetFilter">
                <i class="fas fa-times fa-fw" />
              </button>
            </div>
          </div>

          <div class="row">
            <!-- Adresse anlegen -->
            <div
              :class="{'col-sm-6': app.user.hasPermission('ADDRESSES_FORM_NEW_ADDRESS_OLTP')}"
              class="col-12 col-lg-4 col-xl-3 mb-3">
              <add-new-address
                :card-text="$t('myAccountAddresses.createAddress')"
                form-link="my-account-addresses-create" />
            </div>

            <!-- SAP Adresse anlegen -->
            <div
              v-if="app.user.hasPermission('ADDRESSES_FORM_NEW_ADDRESS_OLTP')"
              class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-3">
              <add-new-address
                :card-text="$t('myAccountAddresses.createSapAddress')"
                form-link="my-account-addresses-sap-add" />
            </div>

            <!-- Adressen Liste -->
            <template v-if="filteredAddresses">
              <div
                v-for="address in filteredAddresses"
                :key="address.id"
                class="col-12 col-md-6 col-lg-4 col-xl-3 mb-3">
                <address-card
                  :address="address"
                  @set-as-default="onSetAsDefault(address)"
                  @deleted="onAddressDeleted(address)" />
              </div>
            </template>
          </div>

          <!-- Keine Suchergebnisse -->
          <div
            v-if="!filteredAddresses.length"
            class="border rounded p-3">
            <app-box-empty-list
              :headline="$t('myAccountAddresses.addressesNotFound')"
              icon="fas fa-map-signs">
              <span v-html="$t('myAccountAddresses.addressesNotFoundDescription')" />
            </app-box-empty-list>
          </div>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { updateUrlQueryString } from '@scripts/helper/urlUpdate'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { getDeliveryAddresses } from '@scripts/modules/delivery-addresses'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

import MyAccountHeader from '@components/pages/my-account/header.vue'

import AddNewAddress from './components/add-new-address.vue'
import AddressCard from './components/address-card.vue'

export default {
  components: {
    'my-account-header': MyAccountHeader,

    'add-new-address': AddNewAddress,
    'address-card': AddressCard,
  },

  data () {
    return {
      addresses: [],
      filter: getQueryParameter('filter') || '',
      isLoading: true,
    }
  },

  computed: {
    filteredAddresses () {
      if (!this.filter) {
        return this.addresses
      }
      const filterWords = this.filter.toLowerCase().split(/\s+/)
      return this.addresses.filter((address) => {
        for (const filterWord of filterWords) {
          if (address.fullTextSearch.indexOf(filterWord) === -1) {
            return false
          }
        }
        return true
      })
    },
  },

  watch: {
    filter (newFilter) {
      updateUrlQueryString({
        filter: newFilter,
      })
    },
  },

  created () {
    this.setPageTitle('Mein Konto - Adressen')

    this.loadAddresses()
  },

  methods: {
    async loadAddresses () {
      this.isLoading = true

      try {
        this.addresses = (await getDeliveryAddresses()).map((address) => ({
          ...address,
          fullTextSearch: [
            address.id,
            address.name1,
            address.name2,
            address.street,
            address.postalCode,
            address.city,
            address.country,
          ].join(' ').toLowerCase(),
        }))
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
    onSetAsDefault (address) {
      this.address = this.addresses.map((addr) => {
        addr.isDefaultAddress = addr.id === address.id
        return addr
      })
    },
    onAddressDeleted (address) {
      const index = this.addresses.findIndex((addr) => addr.id === address.id)
      this.addresses.splice(index, 1)
    },
    resetFilter () {
      this.filter = ''
    },
  },
}
</script>

<style lang="scss" src="./my-account-addresses.scss"></style>
