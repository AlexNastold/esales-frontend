/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/my-account-addresses/my-account-addresses.vue'
setup(PageComponent)
