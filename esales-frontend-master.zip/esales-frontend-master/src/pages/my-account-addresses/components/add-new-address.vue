<template>
  <a
    :href="formLink"
    class="rounded d-flex align-items-center justify-content-center h-100 p-3 add-new-address ">
    <div class="text-center">
      <div class="text-muted mb-3">
        <i class="fas fa-plus fa-2x fa-fw" />
      </div>
      <strong class="text-dark">
        {{ cardText }}
      </strong>
    </div>
  </a>
</template>

<script>
export default {
  props: {
    formLink: {
      type: String,
      required: true,
    },
    cardText: {
      type: String,
      required: true,
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.add-new-address {
  border: 2px dashed rgba(35, 35, 35, .125);
  text-decoration: none;
  transition: background-color .2s ease-in-out;

  &:hover {
    background-color: $light;
  }
}
</style>

