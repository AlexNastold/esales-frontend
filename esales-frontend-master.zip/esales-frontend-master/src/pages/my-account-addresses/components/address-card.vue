<template>
  <div class="card address h-100">
    <div
      v-if="address.isDefaultAddress"
      class="card-badge">
      <i
        class="fas fa-check fa-fw"
        data-toggle="tooltip"
        data-placement="top"
        title="Standardlieferadresse" />
    </div>
    <div class="card-body">
      <strong>{{ address.name1 }} {{ address.name2 }}</strong>
      <br>
      {{ address.street }}
      <br>
      {{ address.country }}-{{ address.postalCode }} {{ address.city }}
    </div>
    <div
      v-if="!address.isEditable"
      class="card-footer text-muted">
      {{ $t('myAccountAddresses.components.addressCard.notEditable') }}
      <i
        :title="$t('myAccountAddresses.components.addressCard.notEditableDescription')"
        class="fas fa-question-circle fa-fw"
        data-toggle="tooltip"
        data-placement="top" />
    </div>
    <div class="card-footer text-right">
      <button
        :disabled="address.isDefaultAddress || isSetDefaultInProcess"
        type="button"
        class="btn btn-secondary"
        @click="setAsDefaultAddress">
        <app-icon-state
          :is-loading="isSetDefaultInProcess"
          icon="fas fa-truck fa-flip-horizontal" />
        {{ $t('myAccountAddresses.components.addressCard.setDefault') }}
      </button>
      <a
        v-if="address.isEditable"
        :href="`my-account-addresses-edit?id=${encodeURIComponent(address.id)}`"
        class="btn btn-secondary">
        <i class="fas fa-edit fa-fw" />
      </a>

      <!-- Löschen Button (Normal) -->
      <button
        v-if="address.isEditable"
        :disabled="address.isDefaultAddress"
        type="button"
        class="btn btn-secondary"
        @click="deleteAddress">
        <app-icon-state
          :is-loading="isDeleteInProcess"
          icon="fas fa-trash-alt" />
      </button>

      <!-- Löschen Button (OLTP) -->
      <button
        v-else-if="app.user.hasPermission('ADDRESSES_FORM_DELETE_ADDRESS_OLTP')"
        type="button"
        class="btn btn-secondary"
        @click="deleteSapAddress">
        <app-icon-state
          :is-loading="isDeleteSapInProcess"
          icon="fas fa-trash-alt" />
      </button>

      <!-- Löschen Button (Kann nicht gelöscht werden) mit Tooltip -->
      <span
        v-else
        :title="$t('myAccountAddresses.components.addressCard.notDeletable')"
        class="d-inline-block"
        tabindex="0"
        data-toggle="tooltip"
        data-placement="top">
        <button
          type="button"
          class="btn btn-secondary"
          disabled
          style="pointer-events: none;">
          <i class="fas fa-trash-alt fa-fw" />
        </button>
      </span>
    </div>
  </div>
</template>

<script>
import { deleteDeliveryAddress, deleteDeliveryAddressSAP, setDefaultDeliveryAddress } from '@scripts/modules/delivery-addresses'
import { confirmDialog, showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  props: {
    address: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      isDeleteInProcess: false,
      isDeleteSapInProcess: false,
      isSetDefaultInProcess: false,
    }
  },

  computed: {
    fullText () {
      return `
        ${this.address.name1} ${this.address.name2},
        ${this.address.street},
        ${this.address.country}-${this.address.postalCode} ${this.address.city}
      `
    },
  },

  mounted () {
    $(this.$el).find('[data-toggle="tooltip"]').tooltip({ placement: 'top' })
  },

  methods: {
    async deleteAddress () {
      if (await confirmDialog(
        this.$t('myAccountAddresses.components.addressCard.deleteAddress'),
        this.$t('myAccountAddresses.components.addressCard.confirmDeleteAddress', { address: this.fullText }),
        {
          type: 'danger',
          buttonConfirmText: '<i class="fas fa-trash-alt fa-fw"></i> ' + this.$t('general.delete'),
          buttonCancelText: '<i class="fas fa-times fa-fw"></i> ' + this.$t('general.cancel'),
        },
      )) {
        try {
          this.isDeleteInProcess = true
          await deleteDeliveryAddress(this.address.id)
          showSuccessMessage(this.$t('myAccountAddresses.components.addressCard.deletionConfirmed', { address: this.fullText }))
          this.$emit('deleted')
        } catch (e) {
          showTechnicalErrorMessage()
        }
        this.isDeleteInProcess = false
      }
    },
    async deleteSapAddress () {
      if (await confirmDialog(
        this.$t('myAccountAddresses.components.addressCard.deleteAddress'),
        '<i class="fa fa-exclamation-triangle text-danger"></i>' + this.$t('myAccountAddresses.components.addressCard.deleteSapAddressNote', { address: this.fullText }),

        {
          type: 'danger',
          buttonConfirmText: '<i class="fas fa-trash-alt fa-fw"></i> ' + this.$t('myAccountAddresses.components.addressCard.requestDeletion'),
          buttonCancelText: '<i class="fas fa-times fa-fw"></i> ' + this.$t('general.cancel'),
        },
      )) {
        try {
          this.isDeleteSapInProcess = true
          await deleteDeliveryAddressSAP(
            this.address.name1,
            this.address.name2,
            this.address.street,
            this.address.postalCode,
            this.address.city,
            this.address.country,
          )
          showSuccessMessage(this.$t('myAccountAddresses.components.addressCard.confirmRequest', { address: this.fullText }))
        } catch (e) {
          showTechnicalErrorMessage()
        }
        this.isDeleteSapInProcess = false
      }
    },
    async setAsDefaultAddress () {
      try {
        this.isSetDefaultInProcess = true
        await setDefaultDeliveryAddress(this.address.id)
        showSuccessMessage(this.$t('myAccountAddresses.components.addressCard.confirmDefault', { address: this.fullText }))
        this.$emit('set-as-default')
      } catch (e) {
        showTechnicalErrorMessage()
      }
      this.isSetDefaultInProcess = false
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.card-badge {
  position: absolute;
  height: 50px;
  width: 50px;
  overflow: hidden;
  right: 0;

  &:before {
    position: absolute;
    content: "";
    background: $my-account-addresses-color;
    top: -35px;
    right: -35px;
    height: 70px;
    width: 70px;
    transform: rotateZ(-45deg);
  }

  i {
    color: white;
    position: absolute;
    right: 7px;
    top: 7px;
    z-index: 1;
  }
}
</style>

