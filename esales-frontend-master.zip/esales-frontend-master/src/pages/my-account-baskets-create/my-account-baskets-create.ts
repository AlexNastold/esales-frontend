/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/my-account-baskets-create/my-account-baskets-create.vue'
setup(PageComponent)
