<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-baskets-create">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountBasketsCreate.baskets')"
        page="baskets" />

      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item">
            <a href="my-account-baskets">
              {{ $t('myAccountBasketsCreate.baskets') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountBasketsCreate.createBasket') }}
          </li>
        </ol>

        <h2 class="mb-3">
          {{ $t('myAccountBasketsCreate.createBasket') }}
        </h2>

        <form @submit.prevent="addBasket">
          <div class="row">
            <!-- Bezeichnung -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label>{{ $t('myAccountBasketsCreate.name') }} <span class="required" /></label>
                <input
                  v-model="newBasketName"
                  :class="{'is-invalid': newBasketNameError}"
                  :placeholder="$t('myAccountBasketsCreate.namePlaceholder')"
                  type="text"
                  maxlength="35"
                  class="form-control"
                  autofocus>
                <div
                  v-if="newBasketNameError"
                  class="invalid-feedback">
                  {{ newBasketNameError }}
                </div>
              </div>
            </div>

            <!-- Bestellnummer -->
            <div class="col-12 col-md-6">
              <div class="form-group">
                <label>{{ $t('myAccountBasketsCreate.orderId') }}</label>
                <input
                  v-model="newBasketOrderText"
                  :placeholder="$t('myAccountBasketsCreate.orderIdPlaceholder')"
                  type="text"
                  maxlength="35"
                  class="form-control">
              </div>
            </div>

            <!-- Warenkorb aktiv setzen -->
            <div class="col-12 mb-2">
              <div class="custom-control custom-checkbox">
                <input
                  id="checkbox-my-account-baskets-new-active"
                  v-model="newBasketActivate"
                  type="checkbox"
                  class="custom-control-input">
                <label
                  class="custom-control-label"
                  for="checkbox-my-account-baskets-new-active">
                  {{ $t('myAccountBasketsCreate.setBasketActive') }}
                </label>
              </div>
            </div>

            <div class="col-12 col-lg-6 mb-2 mb-lg-0">
              <app-form-required-hint />
            </div>

            <!-- Buttons -->
            <div class="col-12 col-lg-6 text-lg-right">
              <!-- Buttons Mobile -->
              <div class="d-lg-none">
                <!-- Button anlegen -->
                <button
                  :disabled="!newBasketName || isBasketCreationInProcess"
                  type="submit"
                  class="btn btn-block btn-primary mb-1">
                  <app-icon-state
                    :is-loading="isBasketCreationInProcess"
                    icon="fas fa-save" />
                  {{ $t('myAccountBasketsCreate.create') }}
                </button>
                <!-- Button Abbrechen -->
                <a
                  href="my-account-baskets"
                  class="btn btn-block btn-secondary">
                  <i class="fas fa-times fa-fw" />
                  {{ $t('general.cancel') }}
                </a>
              </div>

              <!-- Buttons Desktop -->
              <div class="d-none d-lg-block">
                <!-- Button Abbrechen -->
                <a
                  href="my-account-baskets"
                  class="btn btn-secondary">
                  <i class="fas fa-times fa-fw" />
                  {{ $t('general.cancel') }}
                </a>
                <!-- Button anlegen -->
                <button
                  :disabled="!newBasketName || isBasketCreationInProcess"
                  type="submit"
                  class="btn btn-primary">
                  <app-icon-state
                    :is-loading="isBasketCreationInProcess"
                    icon="fas fa-save" />
                  {{ $t('myAccountBasketsCreate.create') }}
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { createFlashMessage } from '@scripts/helper/flash-messages'
import { redirect } from '@scripts/helper/redirect'
import { addBasket } from '@scripts/modules/basket'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'

import MyAccountHeader from '@components/pages/my-account/header.vue'


export default {
  components: {
    'my-account-header': MyAccountHeader,
  },

  data () {
    return {
      isBasketCreationInProcess: false,

      newBasketActivate: false,
      newBasketName: '',
      newBasketOrderText: '',

      newBasketNameError: '',
    }
  },

  created () {
    this.setPageTitle(this.$t('myAccountBasketsCreate.title'))
  },

  methods: {
    async addBasket () {
      if (this.isBasketCreationInProcess) {
        return
      }

      this.isBasketCreationInProcess = true
      this.newBasketNameError = ''

      try {
        const basketName = this.newBasketName
        await addBasket(basketName, this.newBasketOrderText, this.newBasketActivate)

        createFlashMessage(
          this.$t('myAccountBasketsCreate.message', {basketName: this.basketName}),
          'success',
        )
        redirect('my-account-baskets')
      } catch (e) {
        if (e.code === ErrorCode.INVALID_NAME) {
          this.newBasketNameError = this.$t('myAccountBasketsCreate.invalidName')
        } else if (e.code === ErrorCode.NAME_ALREADY_TAKEN) {
          this.newBasketNameError = this.$t('myAccountBasketsCreate.nameAlreadyTaken')
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }

      this.isBasketCreationInProcess = false
    },
  },
}
</script>

<style lang="scss" src="./my-account-baskets-create.scss"></style>
