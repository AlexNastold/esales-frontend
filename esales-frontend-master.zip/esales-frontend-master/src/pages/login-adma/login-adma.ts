/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/login-adma/login-adma.vue'
setup(PageComponent)
