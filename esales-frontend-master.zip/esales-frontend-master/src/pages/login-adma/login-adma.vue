<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-login-adma">
      <div class="container">
        <!-- Seitenüberschrift -->
        <h1 class="headline">
          {{ $t('loginAdma.selectCostumer') }}
        </h1>

        <div class="alert alert-info">
          {{ $t('loginAdma.selectCostumerDescription') }}
        </div>

        <!-- Suche -->
        <div class="search mb-3">
          <form @submit.prevent="loadCustomerList">
            <div class="input-group">
              <input
                v-model="filter"
                :placeholder="$t('loginAdma.searchPlaceholder')"
                type="text"
                class="form-control">
              <div class="input-group-append">
                <button
                  type="submit"
                  class="btn btn-secondary">
                  <i class="fas fa-search fa-fw" />
                </button>
              </div>
            </div>
          </form>
        </div>


        <app-loading-box v-if="isLoading" />
        <template v-else>
          <!-- Keine Kunden -->
          <div
            v-if="!customers.length"
            class="border rounded mb-3">
            <app-box-empty-list
              :headline="$t('loginAdma.listEmpty')"
              icon="fas fa-male">
              <span v-html="$t('loginAdma.listEmptyDescription')" />
            </app-box-empty-list>
          </div>

          <!-- Auflistung Header, Auflistung Kunden -->
          <template v-else>
            <!-- Auflistung Header -->
            <div class="bg-light p-3 d-none d-lg-block">
              <div class="row">
                <div class="col-2 col-sm-1 col-md-auto" />
                <div class="col-2">
                  {{ $t('loginAdma.costumerId') }}
                </div>
                <div class="col-4">
                  {{ $t('loginAdma.costumerName') }}
                </div>
                <div class="col-4">
                  {{ $t('loginAdma.salesData') }}
                </div>
              </div>
            </div>

            <!-- Auflistung Kunden -->
            <div class="list-group mb-3">
              <div
                v-for="customer in customers"
                :key="customer.sel_adma_user_id"
                :class="{'pinned': customer.isFavorit}"
                class="list-group-item list">
                <!-- Badge zum Pinnen mobile -->
                <div
                  :class="{ 'inactive': !customer.isFavorit }"
                  class="card-badge d-lg-none"
                  @click="togglePin(customer)">
                  <i
                    class="fas fa-thumbtack fa-lg fa-fw add-to-pinned"
                    data-toggle="tooltip"
                    data-placement="top" />
                </div>
                <div class="row">
                  <!-- Badge zum Pinnen Desktop -->
                  <div
                    class="col-2 col-sm-1 col-md-auto d-none d-lg-flex align-items-center justify-content-center text-muted mb-2 mb-lg-0"
                    @click="togglePin(customer)">
                    <i
                      :class="{'item-pinned': customer.isFavorit}"
                      class="fas fa-thumbtack fa-lg fa-fw add-to-pinned" />
                  </div>
                  <!-- Kundennummer, Vertriebsdaten Mobile -->
                  <div class="col-12 col-lg-2 d-lg-flex align-items-center mb-2 mb-lg-0">
                    <span class="font-weight-bold">
                      {{ customer.kunnr }}
                    </span>
                    <span class="d-lg-none">
                      ({{ customer.vkorg }}, {{ customer.vtweg }}, {{ customer.sparte }})
                    </span>
                  </div>

                  <!-- Kunde, Anschrift -->
                  <div class="col-12 col-lg-4 d-flex align-items-center mb-2 mb-lg-0">
                    <div>
                      {{ customer.name1 }} {{ customer.name2 }}<br>
                      <span class="text-muted">
                        {{ customer.country }}-{{ customer.postalCode }} {{ customer.city }}, {{ customer.street }}
                      </span>
                    </div>
                  </div>

                  <!-- Vertriebsdaten Desktop -->
                  <div class="col-lg d-none d-lg-flex align-items-center">
                    {{ customer.vkorg }}, {{ customer.vtweg }}, {{ customer.sparte }}
                  </div>

                  <!-- Button Auswählen -->
                  <div class="col-12 col-lg-auto d-lg-flex align-items-center">
                    <button
                      :disabled="isLoginInProcess"
                      type="button"
                      class="btn btn-block btn-primary"
                      @click="selectCustomer(customer)">
                      <app-icon-state
                        :is-loading="isLoginInProcess && selectedCustomerId === customer.userId"
                        icon="fas fa-sign-in-alt" />
                      {{ $t('general.select') }}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <!-- Pagination   -->
            <app-pagination
              v-if="pages"
              :disabled="isLoading || isLoginInProcess"
              :pages="pages"
              :current-page="currentPageForPagination"
              class="d-flex justify-content-center"
              @change="onPageChange" />
          </template>
        </template>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { getNextShopPageAfterLogin } from '@scripts/helper/nextPageAfterLogin'
import { redirect } from '@scripts/helper/redirect'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { getAdmaCustomerList, loginAdma, pinCustomer } from '@scripts/modules/auth'
import { showTechnicalErrorMessage, showSuccessMessage } from '@scripts/modules/dialogs'

export default {
  props: {
    amountPerPage: {
      default: 10,
      type: Number,
    },
  },

  data () {
    return {
      customers: [],
      isLoading: true,
      redirectUrl: getQueryParameter('redirecturl'),

      isLoginInProcess: false,
      selectedCustomerId: void 0,

      currentDisplayedPage: 0,
      currentLoadingPage: 0,
      filter: '',
      pages: 0,
    }
  },

  computed: {
    currentPageForPagination () {
      if (typeof this.currentLoadingPage !== 'undefined') {
        return this.currentLoadingPage
      }
      return this.currentDisplayedPage
    },
  },

  created () {
    this.setPageTitle(this.$t('loginAdma.title'))

    this.loadCustomerList(0)
  },

  methods: {
    /**
     * Load the customer list
     *
     * @param {number} [page] - The page to load
     */
    async loadCustomerList (page = 0) {
      this.isLoading = true
      this.currentLoadingPage = page

      try {
        const data = await getAdmaCustomerList({
          amount: this.amountPerPage,
          filter: this.filter,
          start: page * this.amountPerPage,
        })

        this.pages = data.paging.pages
        this.currentDisplayedPage = data.paging.currentPage
        this.customers = data.customers
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.currentLoadingPage = void 0
      this.isLoading = false
    },

    /**
     * Try to login with a selected customer
     *
     * @param {IAdmaCustomer} customer
     */
    async selectCustomer (customer) {
      this.isLoginInProcess = true
      this.selectedCustomerId = customer.userId

      try {
        await loginAdma(customer.userId)
        redirect(getNextShopPageAfterLogin(this.redirectUrl))
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
        this.isLoginInProcess = false
      }
    },

    /**
     * Eventhandler for a page change
     */
    onPageChange (page) {
      this.loadCustomerList(page)
    },

    async togglePin (customer) {
      try {
        this.isPinInProcess = true
        await pinCustomer(customer.kunnr, customer.isFavorit, customer.vkorg, customer.sparte, customer.vtweg)
        this.isPinInProcess = false
        customer.isFavorit ? showSuccessMessage(this.$t('loginAdma.favSuccessfullyRemoved', { customerId: customer.kunnr })) : showSuccessMessage(this.$t('loginAdma.favSuccessfullyAdded', { customerId: customer.kunnr }))
        this.loadCustomerList()
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

// stylelint-disable selector-pseudo-element-colon-notation
// stylelint-disable string-quotes

.card-badge {
  position: absolute;
  height: 50px;
  width: 50px;
  overflow: hidden;
  right: 0;
  top: 0;

  &:before {
    position: absolute;
    content: "";
    cursor: pointer;
    background: $my-account-lists-color;
    top: -35px;
    right: -35px;
    height: 70px;
    width: 70px;
    transform: rotateZ(-45deg);
  }
  &.inactive:before {
    background: white;
    border: 1px solid $my-account-lists-color;

  }

  i {
    color: white;
    position: absolute;
    right: 7px;
    top: 7px;
    z-index: 1;
    transform: rotate(45deg);
    cursor: pointer;
  }

  &.inactive i {
    color: $my-account-lists-color;
  }
}

.list {

  &.pinned {
    background-color: lighten($my-account-lists-color, 45%);

    .item-pinned {
      color: $my-account-lists-color;
      transform: rotate(45deg);
      cursor: pointer;
    }
  }

  .add-to-pinned {
    transform: rotate(45deg);
    cursor: pointer;
    transition: color .2s ease-in-out;

    &:hover {
      color: $my-account-lists-color;
    }
  }
}
</style>
