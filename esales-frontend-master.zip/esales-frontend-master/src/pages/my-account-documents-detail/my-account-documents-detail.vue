<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-documents-detail">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountDocuments.headline')"
        page="documents" />

      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item">
            <a :href="breadcrumbUrl">
              {{ $t('myAccountDocuments.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item">
            <a :href="breadcrumbUrl">
              {{ doctype | documentTypeTitlePlural }}
            </a>
          </li>
          <li
            v-if="isLoading"
            class="breadcrumb-item">
            <app-loading-spinner class="d-inline-block" />
          </li>
          <li
            v-else-if="!doc"
            class="breadcrumb-item active text-danger">
            {{ $t('myAccountDocuments.detail.notFoundBreadcrumb') }}
          </li>
          <li
            v-else
            class="breadcrumb-item active">
            {{ doc.documentType | documentTypeTitle }} {{ doc.documentIdDisplay }}
          </li>
        </ol>

        <div class="row">
          <!-- Vergleichsliste -->
          <div class="col-lg-3">
            <compare-list
              :documents="app.state.docComparison.documents"
              :active-doc="doc" />
          </div>

          <!-- Beleg Detail -->
          <div class="col-lg-9">
            <!-- Ladeanzeige -->
            <app-loading-box v-if="isLoading" />

            <!-- Beleg nicht gefunden -->
            <app-box-oops
              v-else-if="!doc"
              link-title=""
              link-href="">
              {{ $t('myAccountDocuments.detail.notFoundMessage') }}
            </app-box-oops>

            <!-- Beleg anzeigen-->
            <document-detail
              v-else
              :doc="doc" />
          </div>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { getQueryParameter, getQueryParameters } from '@scripts/helper/urlParams'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getDocumentDetail, getDocumentTypeTitle } from '@scripts/modules/documents'
import { ErrorCode } from '@scripts/modules/errors'

import MyAccountHeader from '@components/pages/my-account/header.vue'

import CompareList from '../my-account-documents/components/compare-list.vue'
import DocumentDetail from './components/document-detail.vue'

export default {
  components: {
    'compare-list': CompareList,
    'my-account-header': MyAccountHeader,
    'document-detail': DocumentDetail,
  },

  data () {
    return {
      doc: void 0,
      docid: getQueryParameter('docid') || void 0,
      doctype: parseInt(getQueryParameter('doctype'), 10) ? parseInt(getQueryParameter('doctype'), 10) : void 0,

      isLoading: true,
    }
  },

  computed: {
    breadcrumbUrl () {
      const additionalQueryParameters = $.param(getQueryParameters(['docid']))
      return 'my-account-documents' +
        (additionalQueryParameters ? `?${additionalQueryParameters}` : '')
    },
  },

  created () {
    this.setPageTitle(this.$t('myAccountDocuments.detail.title'))
    this.loadDocument()
  },

  methods: {
    async loadDocument () {
      try {
        this.doc = await getDocumentDetail(this.doctype, this.docid)
        this.setPageTitle(this.$t('myAccountDocuments.detail.titleWithDetails', {
          docId: this.doc.documentIdDisplay,
          docType: getDocumentTypeTitle(this.doc.documentType),
        }))
        this.isLoading = false
      } catch (e) {
        if (e.code === ErrorCode.NOT_FOUND) {
          // Ist okay, nur nicht "this.doc" setzen
          this.isLoading = false
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },
  },
}
</script>

<style lang="scss" src="./my-account-documents-detail.scss"></style>
