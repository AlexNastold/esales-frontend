<template>
  <div>
    <div class="d-md-flex mb-3">
      <!-- Überschrift (Belegname, Belegnummer) -->
      <h2>
        {{ doc.documentType | documentTypeTitle }} {{ doc.documentIdDisplay }}
      </h2>

      <!-- Button zur Vergleichsliste hinzufügen -->
      <add-to-compare-list-btn
        class="ml-md-auto d-md-flex align-self-md-center"
        @click.native="addToDocCompareList" />
    </div>

    <!-- Budgetauftrag freigegeben -->
    <app-box-success v-if="isBudgetOrderAccepted">
      <h3>
        {{ $t('myAccountDocuments.detail.budgetOrderAccepted') }}
      </h3>
      {{ $t('myAccountDocuments.detail.budgetOrderAcceptedText') }}
      <br>
      <a
        :href="`my-account-documents?doctype=${encodeURIComponent(DocumentType.BUDGETAUFTRAG)}`"
        class="btn btn-secondary mt-3">
        {{ $t('myAccountDocuments.detail.actions.budgetOrderBackToList') }}
      </a>
    </app-box-success>

    <!-- Budgetauftrag abgelehnt -->
    <app-box-success v-else-if="isBudgetOrderRejected">
      <h3>
        {{ $t('myAccountDocuments.detail.budgetOrderRejected') }}
      </h3>
      {{ $t('myAccountDocuments.detail.budgetOrderRejectedText') }}
      <br>
      <a
        :href="`my-account-documents?doctype=${encodeURIComponent(DocumentType.BUDGETAUFTRAG)}`"
        class="btn btn-secondary mt-3">
        {{ $t('myAccountDocuments.detail.actions.budgetOrderBackToList') }}
      </a>
    </app-box-success>

    <template v-else>
      <!-- Fehler, Warnungen, Anmerkungen -->
      <div
        v-if="doc.remarks.length"
        class="mb-3">
        <div
          v-for="(remark, index) of doc.remarks"
          :key="index"
          :class="{'alert-danger': remark.type === 'E', 'alert-info': remark.type === 'N'}"
          class="alert">
          <i
            v-if="remark.type === 'E'"
            class="fas fa-exclamation-triangle fa-fw" />
          <i
            v-else
            class="fas fa-info-circle fa-fw" />
          {{ remark.text }}
        </div>
      </div>

      <!-- Buttons in Angeboten -->
      <div
        v-if="doc.documentType === DocumentType.ANGEBOT"
        class="d-md-flex justify-content-md-end">
        <!-- Buttons Angebot in Hauptabruf wandeln -->
        <div
          v-if="doc.documentType === DocumentType.ANGEBOT && app.user.hasPermission('DOCUMENTS_HAUPTABRUF')"
          class="text-md-right mb-1 ml-md-1">
          <!-- Buttons Mobile -->
          <div class="d-lg-none">
            <button
              :disabled="isOfferToReleaseOrderProcessing || isOfferToBasketProcessing || noValidPositions"
              type="button"
              class="btn btn-block btn-primary mb-1"
              @click="offerToReleaseOrder">
              <app-icon-state
                :is-loading="isOfferToReleaseOrderProcessing"
                icon="fas fa-shopping-cart" />
              {{ $t('myAccountDocuments.detail.actions.offerToReleaseOrder') }}
            </button>
          </div>
          <!-- Buttons Desktop -->
          <div class="d-none d-lg-block">
            <button
              :disabled="isOfferToReleaseOrderProcessing || isOfferToBasketProcessing || noValidPositions"
              type="button"
              class="btn btn-primary"
              @click="offerToReleaseOrder">
              <app-icon-state
                :is-loading="isOfferToReleaseOrderProcessing"
                icon="fas fa-shopping-cart" />
              {{ $t('myAccountDocuments.detail.actions.offerToReleaseOrder') }}
            </button>
          </div>
        </div>

        <!-- Komplettes Angebot werfen -->
        <div
          v-if="doc.documentType === DocumentType.ANGEBOT"
          class="text-md-right mb-1 ml-md-1">
          <!-- Buttons Mobile -->
          <div class="d-md-none">
            <button
              :disabled="isOfferToBasketProcessing || isOfferToReleaseOrderProcessing || noValidPositions"
              type="button"
              class="btn btn-block btn-primary mb-1"
              @click="offerToBasket">
              <app-icon-state
                :is-loading="isOfferToBasketProcessing"
                icon="fas fa-shopping-cart" />
              {{ $t('myAccountDocuments.detail.actions.offerToBasket') }}
            </button>
          </div>
          <!-- Buttons Desktop -->
          <div class="d-none d-md-block">
            <button
              :disabled="isOfferToBasketProcessing || isOfferToReleaseOrderProcessing || noValidPositions"
              type="button"
              class="btn btn-primary"
              @click="offerToBasket">
              <app-icon-state
                :is-loading="isOfferToBasketProcessing"
                icon="fas fa-shopping-cart" />
              {{ $t('myAccountDocuments.detail.actions.offerToBasket') }}
            </button>
          </div>
        </div>
      </div>

      <!-- Buttons Budgetauftrag -->
      <div
        v-if="doc.documentType === DocumentType.BUDGETAUFTRAG"
        class="text-lg-right mb-3">
        <!-- Buttons Mobile -->
        <div class="d-lg-none">
          <!-- Bestellung freigeben -->
          <button
            :disabled="isBudgetAcceptProcessing || isBudgetRejectProcessing"
            type="button"
            class="btn btn-block btn-primary mb-1"
            @click="acceptBudgetOrder">
            <app-icon-state
              :is-loading="isBudgetAcceptProcessing"
              icon="fas fa-check" />
            {{ $t('myAccountDocuments.detail.actions.acceptBudgetOrder') }}
          </button>

          <!-- Bestellung ablehnen -->
          <button
            :disabled="isBudgetAcceptProcessing || isBudgetRejectProcessing"
            type="button"
            class="btn btn-block btn-secondary"
            @click="rejectBudgetOrder">
            <app-icon-state
              :is-loading="isBudgetRejectProcessing"
              icon="fas fa-ban" />
            {{ $t('myAccountDocuments.detail.actions.rejectBudgetOrder') }}
          </button>
        </div>

        <!-- Buttons Desktop -->
        <div class="d-none d-lg-block">
          <!-- Bestellung freigeben -->
          <button
            :disabled="isBudgetAcceptProcessing || isBudgetRejectProcessing"
            type="button"
            class="btn btn-primary"
            @click="acceptBudgetOrder">
            <app-icon-state
              :is-loading="isBudgetAcceptProcessing"
              icon="fas fa-check" />
            {{ $t('myAccountDocuments.detail.actions.acceptBudgetOrder') }}
          </button>

          <!-- Bestellung ablehnen -->
          <button
            :disabled="isBudgetAcceptProcessing || isBudgetRejectProcessing"
            type="button"
            class="btn btn-secondary"
            @click="rejectBudgetOrder">
            <app-icon-state
              :is-loading="isBudgetRejectProcessing"
              icon="fas fa-ban" />
            {{ $t('myAccountDocuments.detail.actions.rejectBudgetOrder') }}
          </button>
        </div>
      </div>

      <!-- Buttons PDF-Download -->
      <div
        v-if="doc.flags.hasArchivedDocument"
        class="text-lg-right mb-3">
        <!-- Buttons Mobile -->
        <div class="d-lg-none">
          <button
            type="button"
            class="btn btn-block btn-secondary mb-1"
            @click="downloadArchivDocument">
            <i class="fas fa-file-pdf fa-fw" />
            {{ $t('basket.PDFDownloadButton') }}
          </button>
        </div>

        <!-- Buttons Desktop -->
        <div class="d-none d-lg-block">
          <button
            type="button"
            class="btn btn-secondary"
            @click="downloadArchivDocument">
            <i class="fas fa-file-pdf fa-fw" />
            {{ $t('basket.PDFDownloadButton') }}
          </button>
        </div>
      </div>

      <!-- Dropdown-Auswahl, angezeigt ab MD -->
      <div class="d-lg-none mb-3">
        <div class="form-group m-0">
          <select
            v-model="activeTab"
            class="form-control custom-select">
            <option :value="Tab.POSITIONS">
              {{ $t('myAccountDocuments.detail.tabs.positions.title') }}
              ({{ doc.documentPositions.length }})
            </option>
            <option
              v-if="shouldDisplayTabHead"
              :value="Tab.HEAD">
              {{ $t('myAccountDocuments.detail.tabs.head.title') }}
            </option>
            <option
              v-if="shouldDisplayTabFlow"
              :value="Tab.FLOW">
              {{ $t('myAccountDocuments.detail.tabs.flow.title') }}
              ({{ doc.documentFlow.length }})
            </option>
            <option
              v-if="shouldDisplayTabTexts"
              :value="Tab.TEXTS">
              {{ $t('myAccountDocuments.detail.tabs.texts.title') }}
              ({{ doc.documentTexts.length }})
            </option>
          </select>
        </div>
      </div>

      <!-- Tab-Auswahl, angezeigt ab LG -->
      <div class="d-none d-lg-block">
        <ul
          ref="tabs"
          class="nav nav-tabs"
          role="tablist">
          <li class="nav-item">
            <a
              :class="{'active': activeTab === Tab.POSITIONS}"
              href="#"
              class="nav-link"
              @click.prevent="activeTab = Tab.POSITIONS">
              {{ $t('myAccountDocuments.detail.tabs.positions.title') }}
              <span class="badge badge-primary badge-pill">
                {{ doc.documentPositions.length }}
              </span>
            </a>
          </li>
          <li class="nav-item">
            <a
              v-if="shouldDisplayTabHead"
              :class="{'active': activeTab === Tab.HEAD}"
              href="#"
              class="nav-link"
              @click.prevent="activeTab = Tab.HEAD">
              {{ $t('myAccountDocuments.detail.tabs.head.title') }}
            </a>
          </li>
          <li class="nav-item">
            <a
              v-if="shouldDisplayTabFlow"
              :class="{'active': activeTab === Tab.FLOW}"
              href="#"
              class="nav-link"
              @click.prevent="activeTab = Tab.FLOW">
              {{ $t('myAccountDocuments.detail.tabs.flow.title') }}
              <span class="badge badge-primary badge-pill">
                {{ doc.documentFlow.length }}
              </span>
            </a>
          </li>
          <li class="nav-item">
            <a
              v-if="shouldDisplayTabTexts"
              :class="{'active': activeTab === Tab.TEXTS}"
              href="#"
              class="nav-link"
              @click.prevent="activeTab = Tab.TEXTS">
              {{ $t('myAccountDocuments.detail.tabs.texts.title') }}
              <span class="badge badge-primary badge-pill">
                {{ doc.documentTexts.length }}
              </span>
            </a>
          </li>
        </ul>
      </div>

      <div class="tab-content">
        <!-- Belegpositionen -->
        <div
          :class="{'active': activeTab === Tab.POSITIONS}"
          class="tab-document-detail tab-positions tab-pane">
          <tab-belegpositionen :doc="doc" />
        </div>

        <!-- Belegkopf -->
        <div
          v-if="shouldDisplayTabHead"
          :class="{'active': activeTab === Tab.HEAD}"
          class="tab-document-detail p-lg-3 tab-pane">
          <tab-belegkopf :doc="doc" />
        </div>

        <!-- Belegfluss -->
        <div
          v-if="shouldDisplayTabFlow"
          :class="{'active': activeTab === Tab.FLOW}"
          class="tab-document-detail p-lg-3 tab-pane">
          <tab-belegfluss :doc="doc" />
        </div>

        <!-- Belegtexte -->
        <div
          v-if="shouldDisplayTabTexts"
          :class="{'active': activeTab === Tab.TEXTS}"
          class="tab-document-detail px-lg-3 pt-lg-3 tab-pane">
          <tab-belegtexte :doc="doc" />
        </div>
      </div>

      <!-- Auswahldialog Warenkorb -->
      <dialog-basket-selection
        v-if="isDialogBasketSelectionOpen"
        @select="onBasketSelect"
        @hidden="isDialogBasketSelectionOpen = false" />
    </template>
  </div>
</template>

<script>

import { serverPath } from '@scripts/core/paths'

import { DocumentType, rejectOrder, releaseOrder } from '@scripts/modules/documents'
import { addPositionsToBasket, getBaskets } from '@scripts/modules/basket'
import { confirmDialog, showErrorMessage, showSuccessMessage, showTechnicalErrorMessage, showWarningMessage } from '@scripts/modules/dialogs'
import { AddToBasketMode } from '@scripts/modules/user-settings'
import { ErrorCode } from '@scripts/modules/errors'
import { addToDocCompareList } from '@scripts/modules/document-comparison-list'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { redirect } from '@scripts/helper/redirect'
import { updateUrlQueryString } from '@scripts/helper/urlUpdate'

import TabBelegfluss from './tabs/belegfluss.vue'
import TabBelegkopf from './tabs/belegkopf.vue'
import TabBelegpositionen from './tabs/belegpositionen.vue'
import TabBelegtexte from './tabs/belegtexte.vue'

import AddToCompareListBtn from '@components/pages/documents/add-to-compare-list.vue'
import DialogBasketSelection from '@components/dialogs/DialogBasketSelection.vue'

const Tab = {
  POSITIONS: 'tab-positions',
  HEAD: 'tab-head',
  FLOW: 'tab-flow',
  TEXTS: 'tab-texts',
}

export default {
  components: {
    'tab-belegpositionen': TabBelegpositionen,
    'tab-belegkopf': TabBelegkopf,
    'tab-belegfluss': TabBelegfluss,
    'tab-belegtexte': TabBelegtexte,
    'dialog-basket-selection': DialogBasketSelection,
    'add-to-compare-list-btn': AddToCompareListBtn,
  },

  props: {
    doc: {
      type: Object,
      required: true,
    },
  },

  data () {
    const shouldDisplayTabHead =  this.doc.flags.displayHead
    const shouldDisplayTabFlow = this.doc.flags.displayFlow
    const shouldDisplayTabTexts = this.doc.flags.displayTexts

    // Prüfen, ob der übergebene Tab verfügbar ist
    const tabFromUrl = getQueryParameter('tab')
    let startTab = Tab.POSITIONS
    if (
      (tabFromUrl === Tab.HEAD && shouldDisplayTabHead)
      || (tabFromUrl === Tab.FLOW && shouldDisplayTabFlow)
      || (tabFromUrl === Tab.TEXTS && shouldDisplayTabFlow)
    ) {
      startTab = tabFromUrl
    }

    return {
      Tab,
      DocumentType,

      baskets: [],

      isBudgetAcceptProcessing: false,
      isBudgetRejectProcessing: false,
      isOfferToBasketProcessing: false,
      isOfferToReleaseOrderProcessing: false,
      isBudgetOrderAccepted: false,
      isBudgetOrderRejected: false,
      asReleaseOrder: false,

      isDialogBasketSelectionOpen: false,

      activeTab: startTab,
      shouldDisplayTabHead,
      shouldDisplayTabFlow,
      shouldDisplayTabTexts,

      serverPath,

      noValidPositions: true,

    }
  },

  watch: {
    activeTab () {
      updateUrlQueryString({
        doctype: this.doc.documentType,
        docid: this.doc.documentId,
        tab: this.activeTab,
      })
    },
  },

  created () {
    updateUrlQueryString({
      doctype: this.doc.documentType,
      docid: this.doc.documentId,
      tab: this.activeTab,
    })
    this.doc.documentPositions.forEach(position => {
      if (position.flags.isValid === true) {
        this.noValidPositions = false
      }
    })
  },

  mounted () {
    $(this.$refs.tabs).on('show.bs.tab', (e) => {
      this.activeTab = $(e.target).data('tab')
    })
  },



  methods: {
    downloadArchivDocument () {
      redirect(serverPath + 'webservices/docs.ws', { event: 'GET_ARCHIVED_DOCUMENT', order_type: this.doc.documentHead.orderType, docid: this.doc.documentId, doctype: this.doc.documentType })
    },
    async offerToReleaseOrder () {
      this.asReleaseOrder = true
      this.isOfferToReleaseOrderProcessing = true
      switch (this.app.user.settings.addToBasketMode) {
        // Immer Dialog öffnen
        case AddToBasketMode.OPEN_DIALOG_ALWAYS:
          this.isDialogBasketSelectionOpen = true
          break

        // Dialog nur öffnen, wenn es mehr als eine Warenkorb gibt
        case AddToBasketMode.OPEN_DIALOG_MULTIPLE_BASKETS:
          try {
            this.baskets = (await getBaskets()).multibaskets

            if (this.baskets.length > 1) {
              this.isDialogBasketSelectionOpen = true
            } else {
              this.addOfferToBasket()
            }
          } catch (e) {
            console.error(e)
            showTechnicalErrorMessage()
          }
          break

        // Dialgo niemals öffnen
        case AddToBasketMode.OPEN_DIALOG_NEVER:
          this.addOfferToBasket()
          break
      }
    },
    async offerToBasket () {
      this.asReleaseOrder = false
      this.isOfferToBasketProcessing = true
      switch (this.app.user.settings.addToBasketMode) {
        // Immer Dialog öffnen
        case AddToBasketMode.OPEN_DIALOG_ALWAYS:
          this.isDialogBasketSelectionOpen = true
          break

        // Dialog nur öffnen, wenn es mehr als eine Warenkorb gibt
        case AddToBasketMode.OPEN_DIALOG_MULTIPLE_BASKETS:
          try {
            this.baskets = (await getBaskets()).multibaskets

            if (this.baskets.length > 1) {
              this.isDialogBasketSelectionOpen = true
            } else {
              this.addOfferToBasket()
            }
          } catch (e) {
            console.error(e)
            showTechnicalErrorMessage()
          }
          break

        // Dialgo niemals öffnen
        case AddToBasketMode.OPEN_DIALOG_NEVER:
          this.addOfferToBasket()
          break
      }
    },
    onBasketSelect (basket) {
      this.addOfferToBasket(basket)
    },
    async addOfferToBasket (basket) {
      this.isOfferToReleaseOrderProcessing = true
      try {
        let allOfferPositions = []
        this.doc.documentPositions.forEach(position => {
          if (position.flags.isValid === true) {
            allOfferPositions.push({
              matnr: position.matnr,
              amount: position.amountMax,
              bismt: position.bismt,
              volumeUnit: position.unit,
              docType: this.doc.documentType,
              docId: this.doc.documentId,
              docPosnr: position.posnr,
              asZHA: this.asReleaseOrder,
            })
          }
        })
        if (allOfferPositions.length > 0) {
          if (basket) {
            await addPositionsToBasket(allOfferPositions, 'documents', {
              basketName: basket.name,
              asZHA: this.asReleaseOrder,
            })
            showSuccessMessage(this.$t('general.actionButtons.addToSpecificBasketMultipleSuccessMessage_plural', {basketName: basket.name}))
          } else {
            await addPositionsToBasket(allOfferPositions, 'documents', {
              asZHA: this.asReleaseOrder,
            })
            showSuccessMessage(this.$t('general.actionButtons.addToBasketMultipleSuccessMessage_plural'))
          }
        } else {
          showErrorMessage(this.$t('myAccountDocuments.detail.offerToReleaseOrderNoValidPositions'))
        }
      } catch (e) {
        console.error(e)
        showErrorMessage(e.message) // @TODO: Wirklich die Errormessage anzeigen (evtl. showTechnicalErrorMessage verwenden) -> Prüfen, welche Meldungen hier kommen können
      }
      this.asReleaseOrder = false
      this.isOfferToBasketProcessing = false
      this.isOfferToReleaseOrderProcessing = false
    },
    async acceptBudgetOrder () {
      if (await confirmDialog(
        this.$t('myAccountDocuments.detail.actions.acceptBudgetOrderConfirmTitle'),
        this.$t('myAccountDocuments.detail.actions.acceptBudgetOrderConfirmMessage'),
        {
          type: 'success',
          buttonConfirmText: `
            <i class="fas fa-check fa-fw"></i>
            ${this.$t('myAccountDocuments.detail.actions.acceptBudgetOrderConfirmOk')}
          `,
          buttonCancelText: `
            <i class="fas fa-times fa-fw"></i>
            ${this.$t('myAccountDocuments.detail.actions.acceptBudgetOrderConfirmCancel')}
          `,
        },
      )) {
        this.isBudgetAcceptProcessing = true

        try {
          await releaseOrder(this.doc.documentId)
          this.isBudgetOrderAccepted = true
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }

        this.isBudgetAcceptProcessing = false
      }
    },
    async rejectBudgetOrder () {
      if (await confirmDialog(
        this.$t('myAccountDocuments.detail.actions.rejectBudgetOrderConfirmTitle'),
        this.$t('myAccountDocuments.detail.actions.rejectBudgetOrderConfirmMessage'),
        {
          type: 'danger',
          buttonConfirmText: `
            <i class="fas fa-ban fa-fw"></i>
            ${this.$t('myAccountDocuments.detail.actions.rejectBudgetOrderConfirmOk')}
          `,
          buttonCancelText: `
            <i class="fas fa-times fa-fw"></i>
            ${this.$t('myAccountDocuments.detail.actions.rejectBudgetOrderConfirmCancel')}
          `,
        },
      )) {
        this.isBudgetRejectProcessing = true

        try {
          await rejectOrder(this.doc.documentId)
          this.isBudgetOrderRejected = true
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }

        this.isBudgetRejectProcessing = false
      }
    },
    addToDocCompareList () {
      try {
        addToDocCompareList(this.app.state.docComparison.documents, this.doc)
        showSuccessMessage(this.$t('myAccountDocuments.components.compareList.addDocumentSuccessMessage', {
          document: `${this.$options.filters.documentTypeTitle(this.doc.documentType)} ${this.doc.documentIdDisplay}`,
        }))
      } catch (e) {
        if (e.code === ErrorCode.ALREADY_IN_DOC_COMPARISON) {
          showWarningMessage(this.$t('myAccountDocuments.components.compareList.addDocumentErrorMessageExists', {
            document: `${this.$options.filters.documentTypeTitle(this.doc.documentType)} ${this.doc.documentIdDisplay}`,
          }))
        } else {
          console.error(e)
          showErrorMessage(e.message)
        }
      }
    },
  },
}
</script>

