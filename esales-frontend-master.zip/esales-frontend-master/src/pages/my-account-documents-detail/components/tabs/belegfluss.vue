<template>
  <div>
    <h3 class="m-0 mb-3 d-block d-lg-none">
      {{ $t('myAccountDocuments.detail.tabs.flow.title') }}
    </h3>

    <div class="container">
      <div
        v-for="(flow, index) in doc.documentFlow"
        :key="flow.documentId"
        :class="{'bg-light': index % 2, [`doc-type-${flow.documentType}`]: true}"
        class="row py-2 flow-document">
        <!-- Belegname, Nummer, Datum -->
        <div class="col-12 col-md-9 col-lg-5">
          <div
            :style="`margin-left: ${getMarginLeft(flow)}px;`"
            class="d-flex">
            <div
              v-if="flow.level && !flow.isBeforeCurrentDocument"
              class="mr-1">
              <i class="fas fa-level-up-alt fa-rotate-90 fa-lg fa-fw" />
            </div>
            <div>
              <strong class="font-size-lg">
                {{ flow.title }} {{ flow.documentIdDisplay }}
              </strong><br>
              <span class="text-muted">
                {{ flow.date | date }}
              </span>
              <div
                v-for="(tracking) in flow.tracking"
                :key="tracking"
                class="mt-1">
                <a
                  :href="tracking"
                  target="_blank">
                  <i class="fas fa-truck" /> {{ $t('myAccountDocuments.detail.tabs.flow.parcelTracking') }}
                </a>
              </div>
            </div>
          </div>
        </div>

        <template v-if="flow.status || flow.isAccessible || flow.isCurrentDocument">
          <!-- Status -->
          <div class="col-8 col-md-3 col-lg-2 mt-2 mt-md-0">
            <template v-if="flow.status">
              <span class="text-muted">
                {{ $t('myAccountDocuments.detail.tabs.flow.statusLabel') }}
              </span><br>
              <document-status-badge :status="flow.status" />
            </template>
          </div>

          <!-- Anzeigen / Dieser Beleg-Label -->
          <div class="col-4 col-md-3 offset-md-9 offset-lg-0 col-lg-5 mt-2 mt-lg-0 d-flex align-items-center">
            <a
              v-if="flow.isAccessible && !flow.isCurrentDocument"
              :href="`my-account-documents-detail?doctype=${encodeURIComponent(flow.documentType)}&docid=${encodeURIComponent(flow.documentId)}`"
              class="icon-link">
              <i class="fas fa-eye fa-fw" /> <span class="text">
                {{ $t('myAccountDocuments.detail.tabs.flow.actions.openDocument') }}
              </span>
            </a>
            <span
              v-if="flow.isCurrentDocument"
              class="badge badge-pill badge-primary py-1">
              {{ $t('myAccountDocuments.detail.tabs.flow.thisDocument') }}
            </span>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
import DocumentStatusBadge from '@components/pages/documents/status.vue'

export default {
  components: {
    'document-status-badge': DocumentStatusBadge,
  },

  props: {
    doc: {
      type: Object,
      required: true,
    },
  },

  methods: {
    getMarginLeft (flowDocument) {
      if (flowDocument.isBeforeCurrentDocument) {
        return 0
      }
      return flowDocument.level * 25
    },
  },
}
</script>
