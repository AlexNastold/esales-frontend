<template>
  <div>
    <h3 class="m-0 mb-3 d-block d-lg-none">
      {{ $t('myAccountDocuments.detail.tabs.positions.title') }}
    </h3>

    <!-- Filter -->
    <filters
      v-model="filter"
      :show-status="useStatusFilter"
      class="mb-3" />

    <div class="list-group">
      <!-- Auflistung Positionen -->
      <div
        v-for="position of filteredPositions"
        :key="position.posnr"
        class="list-group-item p-0">
        <document-position
          :doc="doc"
          :position="position" />
      </div>

      <!-- Keine Ergebnisse -->
      <app-box-empty-list
        v-if="doc.documentPositions.length && !filteredPositions.length"
        :headline="$t('myAccountDocuments.detail.tabs.positions.filterListEmpty')"
        icon="fas fa-search">
        <span v-html="$t('myAccountDocuments.detail.tabs.positions.filterListEmptyDescription')" />
      </app-box-empty-list>

      <!-- Summenbildung -->
      <div class="list-group-item p-0">
        <document-sum :sum="doc.documentSums" />
      </div>
    </div>
  </div>
</template>

<script>
import { matches } from '@scripts/helper/matches'
import { DocumentType } from '@scripts/modules/documents'

import DocumentPosition from './belegpositionen/position.vue'
import DocumentSum from './belegpositionen/sum.vue'
import Filters from './belegpositionen/filters.vue'

export default {
  components: {
    'document-position': DocumentPosition,
    'document-sum': DocumentSum,
    filters: Filters,
  },

  props: {
    doc: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      filter: {},
    }
  },

  computed: {
    filteredPositions () {
      return this.doc.documentPositions.filter((position) => {
        if (this.filter.fullText && !matches(this.filter.fullText, [
          position.matnrDisplay,
          position.description,
        ])) {
          return false
        }
        if (this.filter.status && position.status !== this.filter.status) {
          return false
        }
        return true
      })
    },

    useStatusFilter () {
      return this.doc.documentType === DocumentType.AUFTRAG
        || this.doc.documentType === DocumentType.ANGEBOT
        || this.doc.documentType === DocumentType.ANFRAGE
        || this.doc.documentType === DocumentType.HAUPTABRUF
        || this.doc.documentType === DocumentType.RETURN
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.list-group-item {

  @include media-breakpoint-up(lg) {
    border: 0;
  }
}
</style>

