<template>
  <div class="price text-right font-weight-bold">
    <template v-if="app.user.hasPermission('SHOW_NET_PRICE')">
      {{ position.netPrice | price }} {{ position.currency | currency }}
      <span
        v-if="position.amountRequested"
        class="amount text-muted">
        /
        {{ position.amountRequested | sapNumber }}
        {{ position.unitFormatted }}
      </span>
    </template>
    <template v-else>
      *** {{ position.currency | currency }}
    </template>
  </div>
</template>

<script>
export default {
  props: {
    position: {
      type: Object,
      required: true,
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.price {
  font-family: $font-family-headline;
  font-size: 1.5rem;
  color: $primary-price-color;

  .amount {
    font-size: $font-size-sm;
    font-weight: 400;
  }
}
</style>

