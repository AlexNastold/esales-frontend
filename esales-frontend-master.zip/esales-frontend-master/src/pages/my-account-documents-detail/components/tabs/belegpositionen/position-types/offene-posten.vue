<template>
  <div>
    <!-- Positionsnummer -->
    <div class="col-12 text-muted bg-light px-3 py-1">
      {{ $t('myAccountDocuments.detail.tabs.positions.fields.positionNumber') }}
      {{ position.posnrDisplay }}
    </div>

    <div class="row p-3">
      <!-- Artikelbild, Artikelname, Artikelnummer, EEK-Label -->
      <div class="col-12 col-md-7 col-xl-6 order-1">
        <article-infos
          :doc="doc"
          :position="position" />
      </div>

      <!-- Menge -->
      <div class="col-12 col-sm-6 col-lg-12 col-xl-2 order-2 order-md-3 order-xl-2 mt-2 mt-xl-0">
        <div class="row">
          <!-- Menge -->
          <div class="col-4 col-lg-2 col-xl-12 text-muted">
            {{ $t('myAccountDocuments.detail.tabs.positions.fields.amount') }}
          </div>
          <div class="col-8 col-lg-10 col-xl-12">
            {{ position.amountRequested | sapNumber }} {{ position.unitFormatted }}
          </div>
        </div>
      </div>

      <!-- Preis, Buttons -->
      <div class="col-12 col-sm-6 col-md-5 col-xl-4 order-3 order-md-2 order-xl-3 mt-2 mt-md-0">
        <price
          :position="position"
          class="mb-2" />

        <!-- Buttons -->
        <template v-if="app.user.hasPermission(['BASKET_ADD_ARTICLES', 'LISTS', 'COMPARISON', 'LABELS'])">
          <!-- Werfen -->
          <div
            v-if="app.user.hasPermission(['BASKET_ADD_ARTICLES', 'LISTS', 'COMPARISON', 'LABELS'])"
            class="d-flex justify-content-end mb-1">
            <app-form-input-quantity
              v-model="amount"
              :unit="position.unit"
              :disabled="!position.flags.isAmountChangeable || !position.flags.isValid" />

            <app-action-button-basket
              v-if="app.user.hasPermission('BASKET_ADD_ARTICLES')"
              :is-icon-only="true"
              :matnr="position.matnr"
              :amount="amount"
              :document-type="doc.documentType"
              :document-id="doc.documentId"
              :document-posnr="position.posnr"
              :disabled="!position.flags.isValid"
              pitcher="documents"
              class="ml-1" />
          </div>

          <!-- Buttons -->
          <div
            v-if="position.flags.isAvailable"
            class="d-flex justify-content-end">
            <app-action-button-list
              v-if="app.user.hasPermission('LISTS')"
              :is-icon-only="true"
              :matnr="position.matnr"
              :amount="amount" />

            <!-- Zum Produktvergleich hinzufügen   -->
            <app-action-button-comparison
              v-if="app.user.hasPermission('COMPARISON')"
              :is-icon-only="true"
              :matnr="position.matnr"
              class="ml-1" />

            <!-- Zu Etiketten hinzufügen -->
            <app-action-button-label
              v-if="app.user.hasPermission('LABELS')"
              :is-icon-only="true"
              :matnr="position.matnr"
              :amount="amount"
              class="ml-1" />
          </div>
        </template>
      </div>

      <!-- Zusatzinformationen -->
      <div class="col-12 order-5 mt-2">
        <!-- Stücklistenposition -->
        <div
          v-if="position.partList.headPosnr"
          class="mt-1">
          <i class="fas fa-level-up-alt fa-rotate-90 fa-fw" />&nbsp;
          <span
            v-html="$t('myAccountDocuments.detail.tabs.positions.additional.partList', {
              posnr: position.partList.headPosnrDisplay
            })" />
        </div>

        <!-- Referenz (Bestellung) -->
        <div v-html="referenceText" />
      </div>
    </div>
  </div>
</template>

<script>
import { DocumentType } from '@scripts/modules/documents'

import ArticleInfos from '../position/article-infos.vue'
import Price from '../position/price.vue'

export default {
  components: {
    'article-infos': ArticleInfos,
    price: Price,
  },

  props: {
    doc: {
      type: Object,
      required: true,
    },
    position: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      amount: 1,
    }
  },

  computed: {
    referenceText () {
      const link = `my-account-documents-detail?doctype=${encodeURIComponent(DocumentType.AUFTRAG)}&docid=${encodeURIComponent(this.position.additionalData.salesDocumentId)}`
      return this.$t('myAccountDocuments.detail.tabs.positions.additional.referenceOrder', {
        orderNumberLink: `<a
          href="${link}"
          class="icon-link">
          <i class="fas fa-file fa-fw"></i>` +
          `<span class="text">${this.position.additionalData.salesDocumentIdDisplay}</span>` +
        '</a>',
        posnr: this.position.additionalData.salesDocumentPosnrDisplay,
      })
    },
  },
}
</script>
