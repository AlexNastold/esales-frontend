<template>
  <div class="row">
    <!-- Artikelbild -->
    <div class="col-auto d-flex">
      <a
        v-if="position.flags.isAvailable"
        :href="articleLink">
        <div class="article-image-wrapper d-flex align-items-center justify-content-center">
          <img
            :src="position.image | articleImage"
            :alt="position.description">
        </div>
      </a>
      <div
        v-else
        class="article-image-wrapper d-flex align-items-center justify-content-center">
        <img
          :src="position.image | articleImage"
          :alt="position.description">
      </div>
    </div>

    <div class="col">
      <!-- EEK-Label -->
      <app-article-atom-eek-label
        v-if="position.eek"
        :classes="position.eek"
        class="float-right pl-1" />

      <!-- Artikelname -->
      <div class="font-weight-bold font-size-lg">
        <a
          v-if="position.flags.isAvailable"
          :href="articleLink"
          class="text-dark">
          {{ position.description }}
        </a>
        <span
          v-else
          class="text-dark">
          {{ position.description }}
        </span>
      </div>

      <!-- Artikelnummer -->
      <div class="text-muted">
        <small>
          {{ $t('general.articleNumberShort') }}
          {{ position.matnrDisplay }}
        </small>
      </div>

      <!-- Artikel-Badges -->
      <app-article-badges
        :additional-material-categories="position.additionalMaterialCategories" />
    </div>
  </div>
</template>

<script>

export default {
  props: {
    doc: {
      type: Object,
      required: true,
    },
    position: {
      type: Object,
      required: true,
    },
  },

  computed: {
    articleLink () {
      return 'article' +
        `?matnr=${encodeURIComponent(this.position.matnr)}` +
        `&amount=${encodeURIComponent(this.position.amount || this.position.amountMax || this.position.amountRequested)}` +
        `&doctype=${encodeURIComponent(this.doc.documentType)}` +
        `&docid=${encodeURIComponent(this.doc.documentId)}` +
        `&docposnr=${encodeURIComponent(this.position.posnr)}`
    },
  },
}
</script>
