<template>
  <div class="">
    <component
      :is="component"
      v-if="component"
      :doc="doc"
      :position="position" />
  </div>
</template>

<script>
import { DocumentType } from '@scripts/modules/documents'

import PositionTypeAnfrage from './position-types/anfrage.vue'
import PositionTypeAngebot from './position-types/angebot.vue'
import PositionTypeAuftrag from './position-types/auftrag.vue'
import PositionTypeBudgetauftrag from './position-types/budgetauftrag.vue'
import PositionTypeGutschrift from './position-types/gutschrift.vue'
import PositionTypeHauptabruf from './position-types/hauptabruf.vue'
import PositionTypeOffenePosten from './position-types/offene-posten.vue'
import PositionTypeRechnung from './position-types/rechnung.vue'
import PositionTypeUnterVorbehalt from './position-types/unter-vorbehalt.vue'
import PositionTypeReturn from './position-types/return.vue'

export default {
  props: {
    doc: {
      type: Object,
      required: true,
    },
    position: {
      type: Object,
      required: true,
    },
  },

  computed: {
    component () {
      switch (this.doc.documentType) {
        case DocumentType.ANFRAGE: return PositionTypeAnfrage
        case DocumentType.ANGEBOT: return PositionTypeAngebot
        case DocumentType.AUFTRAG: return PositionTypeAuftrag
        case DocumentType.BUDGETAUFTRAG: return PositionTypeBudgetauftrag
        case DocumentType.GUTSCHRIFT: return PositionTypeGutschrift
        case DocumentType.HAUPTABRUF: return PositionTypeHauptabruf
        case DocumentType.OFFENE_POSTEN: return PositionTypeOffenePosten
        case DocumentType.RECHNUNG: return PositionTypeRechnung
        case DocumentType.BELEG_UNTER_VORBEHALT: return PositionTypeUnterVorbehalt
        case DocumentType.RETURN: return PositionTypeReturn
      }
      return ''
    },
  },
}
</script>

<style lang="scss" scoped>

</style>
