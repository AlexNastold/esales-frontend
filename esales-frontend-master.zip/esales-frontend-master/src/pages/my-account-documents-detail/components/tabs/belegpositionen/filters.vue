<template>
  <div class="p-lg-3">
    <div class="row">
      <!-- Suche nach Artikelbezeichnung, Artikelnummer -->
      <div
        :class="{'col-lg': showStatus}"
        class="col-12 mb-1">
        <div class="input-group">
          <input
            v-model="fullText"
            :placeholder="$t('myAccountDocuments.detail.tabs.positions.filters.searchPositionPlaceholder')"
            type="text"
            class="form-control">
          <div class="input-group-append">
            <button
              type="button"
              class="btn btn-secondary"
              @click.prevent="resetFullText">
              <i class="fas fa-times fa-fw" />
            </button>
          </div>
        </div>
      </div>

      <!-- Status -->
      <div
        v-if="showStatus"
        class="col-12 col-md col-lg-auto mb-1 mb-md-0">
        <select
          v-model="status"
          class="form-control custom-select">
          <option :value="void 0">
            {{ $t('myAccountDocuments.detail.tabs.positions.filters.statusSelectionDummy') }}
          </option>
          <option :value="DocumentStatus.OPEN">
            {{ DocumentStatus.OPEN | documentStatusTitle }}
          </option>
          <option :value="DocumentStatus.PARTLY_COMPLETED">
            {{ DocumentStatus.PARTLY_COMPLETED | documentStatusTitle }}
          </option>
          <option :value="DocumentStatus.COMPLETED">
            {{ DocumentStatus.COMPLETED | documentStatusTitle }}
          </option>
          <option :value="DocumentStatus.CANCELED">
            {{ DocumentStatus.CANCELED | documentStatusTitle }}
          </option>
        </select>
      </div>
    </div>

    <!-- Aktive Filter -->
    <div
      v-if="fullText || status"
      class="d-flex mt-1">
      <!-- Beschriftung Aktive Filter -->
      <div class="mr-2 font-weight-bold">
        <strong>{{ $t('myAccountDocuments.detail.tabs.positions.activeFilters.label') }}</strong>
      </div>

      <!-- Auflistung Aktive Filter -->
      <div class="d-flex flex-wrap">
        <app-active-filter
          v-if="fullText"
          :value="fullText"
          :label="$t('myAccountDocuments.detail.tabs.positions.activeFilters.searchPositionLabel')"
          type="primary"
          @click="fullText = ''" />

        <app-active-filter
          v-if="status"
          :value="$options.filters.documentStatusTitle(status)"
          label="Status"
          type="primary"
          @click="status = void 0" />

        <app-active-filter
          :label="$t('myAccountDocuments.detail.tabs.positions.activeFilters.resetFiltersLabel')"
          type="dark"
          @click="reset" />
      </div>
    </div>
  </div>
</template>

<script>
import { DocumentStatus } from '@scripts/modules/documents'

export default {
  props: {
    showStatus: {
      default: false,
      type: Boolean,
    },
    value: {
      // eslint-disable-next-line @typescript-eslint/no-empty-function
      default: () => {},
      type: Object,
    },
  },

  data () {
    return {
      DocumentStatus,

      fullText: this.value.fullText || '',
      status: this.value.status || void 0,
    }
  },

  watch: {
    value (newValue) {
      this.fullText = newValue.fullText || ''
      this.status = newValue.status || void 0
    },
    showStatus () {
      this.onChange()
    },
    fullText () {
      this.onChange()
    },
    status () {
      this.onChange()
    },
  },

  methods: {
    reset () {
      this.fullText = ''
      this.status = ''
    },

    resetFullText () {
      this.fullText = ''
    },

    onChange () {
      if (this.showStatus) {
        this.$emit('input', {
          fullText: this.fullText,
          status: this.status,
        })
      } else {
        this.$emit('input', {
          fullText: this.fullText,
        })
      }
    },
  },
}
</script>
