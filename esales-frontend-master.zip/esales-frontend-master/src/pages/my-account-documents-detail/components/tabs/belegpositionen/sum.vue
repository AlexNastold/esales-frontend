<template>
  <div class="component-root container bg-light p-3">
    <div class="row">
      <div class="col-12 d-lg-flex justify-content-end">
        <div class="inner">
          <!-- Summe -->
          <div class="value underlined mb-1">
            <div class="row font-weight-bold mb-1">
              <div class="col">
                {{ $t('myAccountDocuments.detail.tabs.positions.sum.sumWithoutTaxes') }}
              </div>
              <div class="col-auto text-right">
                <template v-if="app.user.hasPermission('SHOW_NET_PRICE')">
                  {{ sum.netPrice.sum | price }}
                </template>
                <template v-else>
                  {{ $t('myAccountDocuments.detail.tabs.positions.sum.placeholder') }}
                </template>
                {{ sum.retailPrice.currency | currency }}
              </div>
            </div>
          </div>

          <!-- MwSt -->
          <div class="value underlined mb-1">
            <div class="row mb-1">
              <div class="col">
                <template v-if="sum.netPrice && sum.netPrice.taxRate">
                  {{ sum.netPrice.taxRate }}%
                </template>
                {{ $t('myAccountDocuments.detail.tabs.positions.sum.taxes') }}
              </div>
              <div class="col-auto text-right">
                <template v-if="app.user.hasPermission('SHOW_NET_PRICE')">
                  {{ sum.netPrice.taxes | price }}
                </template>
                <template v-else>
                  {{ $t('myAccountDocuments.detail.tabs.positions.sum.placeholder') }}
                </template>
                {{ sum.retailPrice.currency | currency }}
              </div>
            </div>
          </div>

          <!-- Gesamt -->
          <div class="total-price">
            <div class="row font-weight-bold mb-1">
              <div class="col">
                {{ $t('myAccountDocuments.detail.tabs.positions.sum.sum') }}
              </div>
              <div class="col-auto text-right">
                <template v-if="app.user.hasPermission('SHOW_NET_PRICE')">
                  {{ sum.netPrice.sumInclTaxes | price }}
                </template>
                <template v-else>
                  {{ $t('myAccountDocuments.detail.tabs.positions.sum.placeholder') }}
                </template>
                {{ sum.retailPrice.currency | currency }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    sum: {
      type: Object,
      required: true,
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.component-root {

  .inner {
    @include media-breakpoint-up(lg) {
      width: 35%;
    }

    .value {
      &.underlined {
        border-bottom: 1px solid #9b9b9b;
      }
    }

    .total-price {
      font-family: $font-family-headline;
      font-size: $font-size-lg;
      color: $primary-price-color;
    }
  }
}
</style>

