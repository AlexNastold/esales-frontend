<template>
  <div>
    <h3 class="m-0 mb-3 d-block d-lg-none">
      {{ $t('myAccountDocuments.detail.tabs.head.title') }}
    </h3>
    <div class="row">
      <!-- Beleginformationen -->
      <div class="col-12 col-lg-6 mb-3 mb-lg-0">
        <h4 class="mb-3">
          {{ $t('myAccountDocuments.detail.tabs.head.headlineInformations') }}
        </h4>

        <div class="row">
          <!-- Status -->
          <div class="col-12 col-md-4 col-lg-5 font-weight-bold">
            {{ $t('myAccountDocuments.detail.tabs.head.fields.status') }}
          </div>
          <div class="col-12 col-md-8 col-lg-7">
            <document-status-badge :status="doc.documentHead.status" />
          </div>

          <!-- Bestellnummer  -->
          <div
            :class="{'text-muted': !doc.documentHead.orderNumber}"
            class="col-12 col-md-4 col-lg-12 col-xl-5 font-weight-bold mt-2">
            {{ $t('myAccountDocuments.detail.tabs.head.fields.orderNumber') }}
          </div>
          <div
            class="col-12 col-md-8 col-lg-12 col-xl-7 mt-md-2 mt-lg-0 mt-xl-2 text-break">
            {{ doc.documentHead.orderNumber }}
          </div>

          <!-- Projektbezeichnung -->
          <div
            :class="{'text-muted': !doc.documentHead.projectName}"
            class="col-12 col-md-4 col-lg-12 col-xl-5 font-weight-bold mt-2">
            {{ $t('myAccountDocuments.detail.tabs.head.fields.projectName') }}
          </div>
          <div
            class="col-12 col-md-8 col-lg-12 col-xl-7 mt-md-2 mt-lg-0 mt-xl-2 text-break">
            {{ doc.documentHead.projectName }}
          </div>

          <!-- Belegdatum -->
          <div class="col-12 col-md-4 col-lg-5 font-weight-bold mt-4">
            {{ $t('myAccountDocuments.detail.tabs.head.fields.date') }}
          </div>
          <div class="col-12 col-md-8 col-lg-7 mt-md-4">
            {{ doc.documentHead.createDate | date }}
          </div>

          <!-- Gültigkeit -->
          <div
            :class="{'text-muted': !doc.documentHead.validTo}"
            class="col-12 col-md-4 col-lg-5 font-weight-bold mt-2">
            {{ $t('myAccountDocuments.detail.tabs.head.fields.validDate') }}
          </div>
          <div class="col-12 col-md-8 col-lg-7 mt-md-2">
            {{ doc.documentHead.validTo | date }}
          </div>

          <!-- Ersteller -->
          <div class="col-12 col-md-4 col-lg-5 font-weight-bold mt-2">
            {{ $t('myAccountDocuments.detail.tabs.head.fields.creatorName') }}
          </div>
          <div class="col-12 col-md-8 col-lg-7 mt-md-2">
            {{ doc.documentHead.createdBy }}
          </div>

          <!-- Niederlassung -->
          <div class="col-12 col-md-4 col-lg-5 font-weight-bold mt-2">
            {{ $t('myAccountDocuments.detail.tabs.head.fields.branch') }}
          </div>
          <div class="col-12 col-md-8 col-lg-7 mt-md-2">
            {{ doc.documentHead.branch }}
          </div>

          <!-- Auftragsart -->
          <div class="col-12 col-md-4 col-lg-5 font-weight-bold mt-2">
            {{ $t('myAccountDocuments.detail.tabs.head.fields.orderType') }}
          </div>
          <div class="col-12 col-md-8 col-lg-7 mt-md-2">
            {{ doc.documentHead.orderType }}
          </div>
        </div>
      </div>

      <!-- Lieferdaten -->
      <div class="col-12 col-lg-6">
        <h4 class="my-3 mt-lg-0">
          {{ $t('myAccountDocuments.detail.tabs.head.headlineDelivery') }}
        </h4>

        <div class="row">
          <!-- Lieferanschrift -->
          <template v-if="doc.documentHead.address.name1 || doc.documentHead.address.name2 || doc.documentHead.address.street || doc.documentHead.address.city">
            <div class="col-12 col-md-4 col-lg-5 font-weight-bold">
              {{ $t('myAccountDocuments.detail.tabs.head.fields.deliveryAddress') }}
            </div>
            <div class="col-12 col-md-8 col-lg-7">
              <strong>{{ doc.documentHead.address.name1 }} {{ doc.documentHead.address.name2 }}</strong>
              <br>
              {{ doc.documentHead.address.street }} {{ doc.documentHead.address.houseNumber }}
              <br>
              {{ doc.documentHead.address.country }}-{{ doc.documentHead.address.postalCode }} {{ doc.documentHead.address.city }}
            </div>
          </template>

          <!-- Wunschlieferdatum -->
          <div class="col-12 col-md-4 col-lg-5 font-weight-bold mt-2">
            {{ $t('myAccountDocuments.detail.tabs.head.fields.deliveryDesiredDate') }}
          </div>
          <div class="col-12 col-md-8 col-lg-7 mt-md-2">
            {{ doc.documentHead.desiredDeliveryDate | date }}
          </div>

          <!-- Lieferart -->
          <div class="col-12 col-md-4 col-lg-5 font-weight-bold mt-2">
            {{ $t('myAccountDocuments.detail.tabs.head.fields.deliveryType') }}
          </div>
          <div class="col-12 col-md-8 col-lg-7 mt-md-2">
            {{ doc.documentHead.deliveryType }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import DocumentStatusBadge from '@components/pages/documents/status.vue'

export default {
  components: {
    'document-status-badge': DocumentStatusBadge,
  },

  props: {
    doc: {
      type: Object,
      required: true,
    },
  },
}
</script>
