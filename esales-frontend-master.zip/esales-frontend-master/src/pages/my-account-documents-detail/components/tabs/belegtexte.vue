<template>
  <div>
    <h3 class="m-0 mb-3 d-block d-lg-none">
      {{ $t('myAccountDocuments.detail.tabs.texts.title') }}
    </h3>

    <app-box-empty-list
      v-if="!doc.documentTexts.length"
      :headline="$t('myAccountDocuments.detail.tabs.texts.listEmpty')"
      icon="fas fa-font">
      <span v-html="$t('myAccountDocuments.detail.tabs.texts.listEmptyDescription')" />
    </app-box-empty-list>

    <div
      v-else
      class="row">
      <!-- Text Card -->
      <div
        v-for="(text, index) in doc.documentTexts"
        :key="index"
        class="col-12 col-lg-6 col-xl-4 mb-3">
        <div class="card">
          <div class="card-header">
            <i class="fas fa-font fa-fw" />
            {{ text.title }}
          </div>
          <div class="card-body">
            {{ text.text }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    doc: {
      type: Object,
      required: true,
    },
  },
}
</script>

