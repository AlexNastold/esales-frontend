/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/my-account-documents-detail/my-account-documents-detail.vue'
setup(PageComponent)
