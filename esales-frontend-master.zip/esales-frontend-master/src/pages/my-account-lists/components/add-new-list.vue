<template>
  <div class="rounded bg-light d-md-flex p-3 mb-3">
    <!-- Icon -->
    <div class="mr-3 mt-1 d-none d-md-block">
      <i class="fas fa-file-alt fa-3x fa-fw" />
    </div>

    <div class="w-100">
      <!-- Überschrift   -->
      <h4>
        <i class="fas fa-file-alt fa-fw d-md-none" />
        {{ $t('myAccountLists.list.addNewList.headline') }}
      </h4>

      <form @submit.prevent="createList">
        <div class="row no-gutters">
          <!-- Listenname -->
          <div class="col-12 col-md mb-1 mb-md-0">
            <input
              v-model="name"
              :placeholder="$t('myAccountLists.list.addNewList.namePlaceholder')"
              class="form-control"
              type="text"
              maxlength="50">
          </div>

          <!-- Button Liste anlegen -->
          <div class="col-12 col-md-auto ml-md-1">
            <button
              :disabled="isCreateListInProcess || !name"
              type="submit"
              class="btn btn-block btn-primary">
              <app-icon-state
                :is-loading="isCreateListInProcess"
                icon="fas fa-file-alt" />
              {{ $t('myAccountLists.list.addNewList.actions.createList') }}
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import { createList } from '@scripts/modules/lists'
import { showTechnicalErrorMessage, showSuccessMessage } from '@scripts/modules/dialogs'

export default {
  data () {
    return {
      name: '',
      isCreateListInProcess: false,
    }
  },

  methods: {
    async createList () {
      if (!this.name || this.isCreateListInProcess) {
        return
      }

      this.isCreateListInProcess = true

      try {
        const listName = this.name
        await createList(listName)
        showSuccessMessage(this.$t('myAccountLists.list.addNewList.actions.createListSuccessMessage', {
          name: listName,
        }))
        this.name = ''
        this.$emit('listCreated')
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.isCreateListInProcess = false
    },
  },
}
</script>
