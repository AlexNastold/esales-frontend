<template>
  <div
    :class="{'pinned': list.isPinned}"
    class="list-group-item list">
    <div class="row">
      <!-- Liste anpinnen -->
      <div class="col-2 col-sm-1 col-md-auto d-flex align-items-center justify-content-center text-muted mb-2 mb-lg-0">
        <i
          v-if="isPinInProcess"
          class="fas fa-circle-notch fa-lg fa-spin fa-fw" />
        <i
          v-else
          :class="{'item-pinned': list.isPinned}"
          class="fas fa-thumbtack fa-md fa-fw add-to-pinned"
          @click="togglePin" />
      </div>

      <!-- Name, Datum -->
      <div class="col-10 col-sm-11 col-md d-flex align-items-center mb-1 mb-lg-0">
        <div>
          <a :href="`my-account-lists-detail?id=${list.id}`">
            <strong class="text-dark font-size-lg">
              {{ list.name }}
            </strong>
            <br>
            <span class="text-muted">
              {{ list.createdAt | date }}
            </span>
          </a>
        </div>
      </div>

      <!-- Freigegeben -->
      <div
        v-if="list.isPublic"
        class="col-5 col-sm-6 col-md-auto offset-2 offset-sm-1 offset-md-0 d-flex align-items-center mb-2 mb-lg-0">
        <div class="badge badge-primary badge-pill py-1 ml-1">
          <i class="fas fa-users fa-fw" />
          {{ $t('myAccountLists.list.fields.shared') }}
        </div>
      </div>

      <!-- Anzahl Artikel -->
      <div
        :class="{'offset-7 offset-md-0' : !list.isPublic}"
        class="col-5 col-md-2 col-xl-1 d-flex align-items-center justify-content-end mb-2 mb-lg-0">
        {{ $t('myAccountLists.list.fields.articleAmount', { count: list.articlesAmount }) }}
      </div>

      <!-- Buttons -->
      <div class="col-12 col-lg-2 col-xl-2 d-md-flex align-items-center justify-content-end ">
        <!-- Buttons Mobile -->
        <div class="d-block d-md-none">
          <throw-list-into-basket-button
            v-if="app.user.hasPermission('BASKET_ADD_ARTICLES') && list.articlesAmount"
            :button-class="`btn-primary btn-block mb-1`"
            :list="list" />

          <button
            :disabled="!list.isOwnList"
            type="button"
            class="btn btn-secondary btn-block"
            @click="deleteList">
            <i class="fas fa-trash-alt fa-fw" />
            {{ $t('myAccountLists.list.actions.delete') }}
          </button>
        </div>

        <!-- Buttons Desktop -->
        <div class="d-none d-md-flex">
          <throw-list-into-basket-button
            v-if="app.user.hasPermission('BASKET_ADD_ARTICLES') && list.articlesAmount"
            :button-class="`btn-primary`"
            :list="list"
            :is-icon-only="true" />

          <button
            :disabled="!list.isOwnList"
            type="button"
            class="btn btn-secondary ml-1"
            @click="deleteList">
            <i class="fas fa-trash-alt fa-fw" />
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { confirmDialog, showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { pinList, deleteList } from '@scripts/modules/lists'

import ThrowListIntoBasketButton from '@components/pages/my-account-lists/throw-list-into-basket.vue'

export default {
  components: {
    'throw-list-into-basket-button': ThrowListIntoBasketButton,
  },

  props: {
    list: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      isPinInProcess: false,
      isDeleteInProcess: false,
    }
  },

  methods: {
    async togglePin () {
      try {
        this.isPinInProcess = true
        await pinList(this.list.id, !this.list.isPinned)
        this.list.isPinned = !this.list.isPinned
        this.isPinInProcess = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },

    async deleteList () {
      if (await confirmDialog(
        this.$t('myAccountLists.list.actions.deleteConfirmTitle'),
        this.$t('myAccountLists.list.actions.deleteConfirmMessage', { name: this.list.name }),
        {
          type: 'danger',
          buttonConfirmText: `
            <i class="fas fa-trash-alt fa-fw"></i>
            ${this.$t('myAccountLists.list.actions.deleteConfirmOk')}
          `,
          buttonCancelText: `
            <i class="fas fa-times fa-fw"></i>
            ${this.$t('myAccountLists.list.actions.deleteConfirmCancel')}
          `,
        },
      )) {
        this.isDeleteInProcess = true

        try {
          await deleteList(this.list.id)
          showSuccessMessage(this.$t('myAccountLists.list.actions.deleteSuccessMessage', {
            name: this.list.name,
          }))
          this.$emit('delete')
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }

        this.isDeleteInProcess = false
      }
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.list {

  &.pinned {
    background-color: lighten($my-account-lists-color, 45%);

    .item-pinned {
      color: $my-account-lists-color;
      transform: rotate(45deg);
      cursor: pointer;
    }
  }

  .add-to-pinned {
    transform: rotate(45deg);
    cursor: pointer;
    transition: color .2s ease-in-out;

    &:hover {
      color: $my-account-lists-color;
    }
  }
}
</style>
