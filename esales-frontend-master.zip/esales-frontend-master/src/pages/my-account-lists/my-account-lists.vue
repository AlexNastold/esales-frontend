<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-lists">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountLists.list.headline')"
        page="lists" />

      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountLists.list.breadcrumb') }}
          </li>
        </ol>

        <app-loading-box v-if="isLoading" />
        <div v-else>
          <!-- Auflistung Merklisten -->
          <div
            v-if="!pinnedLists.length && !unpinnedLists.length"
            class="border rounded mb-3">
            <app-box-empty-list
              :headline="$t('myAccountLists.list.listEmpty')"
              icon="fas fa-file-alt">
              <span v-html="$t('myAccountLists.list.listEmptyDescription')" />
            </app-box-empty-list>
          </div>

          <h3 class="mb-3">
            {{ $t('myAccountLists.list.listHeadline', { count: lists.length }) }}
          </h3>

          <!-- Auflistung Listen -->
          <div class="list-group mb-3">
            <!-- Angepinnte Listen -->
            <list-item
              v-for="list in pinnedLists"
              :key="list.id"
              :list="list"
              @delete="loadLists" />

            <!-- Listen -->
            <list-item
              v-for="list in unpinnedLists"
              :key="list.id"
              :list="list"
              @delete="loadLists" />
          </div>

          <!-- Neue Merkliste anlegen -->
          <add-new-list @listCreated="loadLists" />
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getLists } from '@scripts/modules/lists'

import MyAccountHeader from '@components/pages/my-account/header.vue'

import AddNewList from './components/add-new-list.vue'
import ListItem from './components/lists-list-item.vue'

export default {
  components: {
    'add-new-list': AddNewList,
    'list-item': ListItem,
    'my-account-header': MyAccountHeader,
  },

  data () {
    return {
      isLoading: true,
      lists: [],
    }
  },

  computed: {
    pinnedLists () {
      return this.lists
        .filter((list) => list.isPinned)
        .sort((a, b) => a.name.localeCompare(b.name))
    },
    unpinnedLists () {
      return this.lists
        .filter((list) => !list.isPinned)
        .sort((a, b) => a.name.localeCompare(b.name))
    },
  },

  created () {
    this.setPageTitle(this.$t('myAccountLists.list.title'))
    this.loadLists()
  },

  methods: {
    async loadLists () {
      try {
        this.lists = await getLists()
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>

<style lang="scss" src="./my-account-lists.scss"></style>
