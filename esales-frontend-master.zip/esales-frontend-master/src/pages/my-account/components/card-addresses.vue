<template>
  <dashboard-card
    :title="$t('myAccount.components.cardAddresses.title')"
    card-class="card-addresses"
    link="my-account-addresses"
    icon="fas fa-map-signs">
    <!-- Beschreibung -->
    <template slot="description">
      {{ $t('myAccount.components.cardAddresses.description') }}
    </template>

    <!-- Auflistung letzte Adressen -->
    <template
      v-if="addresses.length"
      slot="list">
      <template v-for="address in addresses">
        <a
          v-if="address.isEditable"
          :key="address.id"
          :href="`my-account-addresses-edit?id=${address.id}`"
          class="icon-link d-flex px-3 py-1">
          <div
            :title="address.name1 + ' ' + address.name2 + ',  ' + address.street + ', ' + address.country + '-' + address.postalCode + ' ' + address.city"
            class="text-truncate">
            <i class="fas fa-map-signs fa-fw text-muted" />&nbsp;
            <span class="text">
              {{ address.name1 }} {{ address.name2 }}, {{ address.street }},
              {{ address.country }}-{{ address.postalCode }} {{ address.city }}
            </span>
          </div>
        </a>
        <div
          v-if="!address.isEditable"
          :key="address.id"
          class="d-flex text-muted px-3 py-1">
          <div
            :title="address.name1 + ' ' + address.name2 + ',  ' + address.street + ', ' + address.country + '-' + address.postalCode + ' ' + address.city"
            class="text-truncate">
            <i class="fas fa-map-signs fa-fw text-muted" />&nbsp;
            {{ address.name1 }} {{ address.name2 }}, {{ address.street }},
            {{ address.country }}-{{ address.postalCode }} {{ address.city }}
          </div>
        </div>
      </template>
    </template>
  </dashboard-card>
</template>

<script>
import DashboardCard from './dashboard-card.vue'

export default {
  components: {
    'dashboard-card': DashboardCard,
  },

  props: {
    addresses: {
      type: Array,
      required: true,
    },
  },
}
</script>

