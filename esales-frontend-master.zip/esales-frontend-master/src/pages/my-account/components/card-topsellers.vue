<template>
  <dashboard-card
    :title="$t('myAccount.components.cardTopsellers.title')"
    card-class="card-topsellers"
    link="my-account-topsellers"
    icon="fas fa-user">
    <!-- Beschreibung -->
    <template slot="description">
      {{ $t('myAccount.components.cardTopsellers.description') }}
    </template>
  </dashboard-card>
</template>

<script>
import DashboardCard from './dashboard-card.vue'

export default {
  components: {
    'dashboard-card': DashboardCard,
  },
}
</script>
