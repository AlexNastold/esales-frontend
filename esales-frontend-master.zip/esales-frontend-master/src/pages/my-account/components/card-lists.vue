<template>
  <dashboard-card
    :title="$t('myAccount.components.cardLists.title')"
    card-class="card-lists"
    link="my-account-lists"
    icon="fas fa-file-alt">
    <!-- Beschreibung -->
    <template slot="description">
      {{ $t('myAccount.components.cardLists.description') }}
    </template>

    <!-- Auflistung letzte Listen -->
    <template
      v-if="lists.length"
      slot="list">
      <div
        v-for="list in lists"
        :key="list.id"
        class="row px-3 py-1">
        <div
          :class="{'col-lg-6 col-xl-7': list.isPublic, 'col-lg-9 col-xl-10': !list.isPublic}"
          class="col-12 col-md-12 mb-1 mb-lg-0">
          <a
            :href="`my-account-lists-detail?id=${list.id}`"
            class="icon-link">
            <div
              :title="list.name"
              class="text-truncate pr-1">
              <i class="fas fa-file-alt fa-fw text-muted" />&nbsp;
              <span class="text">
                {{ list.name }}
              </span>
            </div>
          </a>
        </div>
        <div
          v-if="list.isPublic"
          class="col-6 col-lg-3 d-flex align-items-center justify-content-lg-center">
          <div class="badge badge-primary badge-pill py-1">
            <i class="fas fa-users fa-fw" />
            {{ $t('myAccount.components.cardLists.shared') }}
          </div>
        </div>
        <div
          :class="{'offset-6 offset-lg-0': !list.isPublic}"
          class="col-6 col-lg-3 col-xl-2 text-right">
          {{ $t('myAccount.components.cardLists.article', { count: list.articlesAmount }) }}
        </div>
      </div>
    </template>
  </dashboard-card>
</template>

<script>
import DashboardCard from './dashboard-card.vue'

export default {
  components: {
    'dashboard-card': DashboardCard,
  },

  props: {
    lists: {
      type: Array,
      required: true,
    },
  },
}
</script>

