<template>
  <dashboard-card
    :title="$t('myAccount.components.cardLastArticles.title')"
    card-class="card-last-articles"
    link="my-account-last-articles"
    icon="fas fa-history">
    <!-- Beschreibung -->
    <template slot="description">
      {{ $t('myAccount.components.cardLastArticles.description') }}
    </template>
  </dashboard-card>
</template>

<script>
import DashboardCard from './dashboard-card.vue'

export default {
  components: {
    'dashboard-card': DashboardCard,
  },
}
</script>
