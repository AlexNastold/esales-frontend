<template>
  <div class="col-12 col-md-6 mb-4">
    <div class="border rounded bg-light p-3 h-100 card-my-data">
      <!-- Titel -->
      <h2 class="headline mb-0">
        {{ $t('myAccount.components.cardMyData.title') }}
      </h2>

      <!-- Anrede, Name -->
      <div class="text-muted mb-3">
        {{ app.user.title }} {{ app.user.firstName }} {{ app.user.lastName }}
      </div>


      <div class="mb-3">
        <!-- E-Mail Adresse -->
        <div
          v-if="app.user.emailAddress"
          class="mb-1">
          <i class="fas fa-envelope fa-fw" />
          <a :href="`mailto:${app.user.emailAddress}`">
            {{ app.user.emailAddress }}
          </a>
        </div>
        <!-- Telefonnummer -->
        <div
          v-if="app.user.phone"
          class="mb-1">
          <i class="fas fa-phone fa-fw" />
          {{ app.user.phone }}
        </div>

        <!-- Fax -->
        <div v-if="app.user.fax">
          <i class="fas fa-fax fa-fw" />
          {{ app.user.fax }}
        </div>
      </div>


      <div class="row mb-3">
        <!-- Firma -->
        <div class="col-12 col-sm-5 col-md-12 col-lg-4 font-weight-bold mb-sm-1 mb-md-0 mb-lg-1">
          {{ $t('myAccount.components.cardMyData.company') }}
        </div>
        <div class="col-12 col-sm-7 col-md-12 col-lg-8 mb-1">
          {{ app.user.kunnrName }}
        </div>

        <!-- Kundennummer -->
        <div class="col-12 col-sm-5 col-md-12 col-lg-4 font-weight-bold mb-sm-1 mb-md-0 mb-lg-1">
          {{ $t('myAccount.components.cardMyData.customerNumber') }}
        </div>
        <div class="col-12 col-sm-7 col-md-12 col-lg-8 mb-1">
          {{ app.user.kunnr }}
        </div>

        <!-- Sachbearbeiter -->
        <div class="col-12 col-sm-5 col-md-12 col-lg-4 font-weight-bold d-flex align-items-start mb-sm-1 mb-md-0 mb-lg-1">
          {{ $t('myAccount.components.cardMyData.clerk') }}
        </div>
        <div class="col-12 col-sm-7 col-md-12 col-lg-8 mb-1 d-flex align-items-center">
          <div>
            {{ app.user.contactPerson.title }} {{ app.user.contactPerson.lastName }}
            <br>
            <template v-if="app.user.contactPerson.emailAddress">
              <i class="fas fa-envelope fa-fw" />
              <a :href="`mailto:${app.user.contactPerson.emailAddress}`">
                {{ app.user.contactPerson.emailAddress }}
              </a>
            </template>
            <br>
            <template v-if="app.user.contactPerson.phone">
              <i class="fas fa-phone fa-fw" />
              {{ app.user.contactPerson.phone }} {{ app.user.contactPerson.phoneExtension }}
            </template>
          </div>

          <!-- Bild -->
          <div
            v-if="app.user.contactPerson.picture"
            :style="`background-image: url('${$options.filters.externalImage(app.user.contactPerson.picture)}')`"
            class="clerk-image bg-white rounded-circle ml-auto" />
        </div>
      </div>

      <!-- Alias, Benutzerkennung, Letzter Login -->
      <div class="row">
        <!-- Alias -->
        <div class="col-12 col-sm-5 col-md-12 col-lg-4 font-weight-bold mb-sm-1 mb-md-0 mb-lg-1">
          {{ $t('myAccount.components.cardMyData.alias') }}
        </div>
        <div class="col-12 col-sm-7 col-md-12 col-lg-8 mb-1">
          {{ app.user.alias }}
        </div>

        <!-- Benutzerkennung -->
        <div class="col-12 col-sm-5 col-md-12 col-lg-4 font-weight-bold mb-sm-1 mb-md-0 mb-lg-1">
          {{ $t('myAccount.components.cardMyData.userId') }}
        </div>
        <div class="col-12 col-sm-7 col-md-12 col-lg-8 mb-1">
          {{ app.user.userId | removeLeadingZeros }}
        </div>

        <!-- Letzter Login -->
        <div class="col-12 col-sm-5 col-md-12 col-lg-4 font-weight-bold">
          {{ $t('myAccount.components.cardMyData.lastLogin') }}
        </div>
        <div class="col-12 col-sm-7 col-md-12 col-lg-8">
          <i class="fas fa-calendar-alt fa-fw" />
          {{ app.user.lastLogin | datetime }}
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.card-my-data {
  border-color: $my-account-dashboard-card-border-color !important;

  .clerk-image {
    background-size: cover;
    background-position: center center;
    box-shadow: 0 2px 7px 0 rgba(0, 0, 0, 0.5);
    height: $my-account-my-data-card-clerk-image-size;
    width: $my-account-my-data-card-clerk-image-size;

    @include media-breakpoint-up(md) {
      height: $my-account-my-data-card-clerk-image-size-md;
      width: $my-account-my-data-card-clerk-image-size-md;
    }
  }
}


</style>
