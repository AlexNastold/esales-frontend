<template>
  <div class="col-12 col-md-6 mb-4">
    <div
      :class="cardClass"
      class="dashboard-item rounded bg-light pb-2 h-100">
      <!-- Header -->
      <a
        :href="link"
        class="item-header text-dark">
        <!-- Icon -->
        <div class="icon-wrapper">
          <div class="icon text-center text-white py-3">
            <i :class="`${icon} fa-5x fa-fw`" />
          </div>
        </div>

        <!-- Titel -->
        <h2 class="headline px-3 pt-3">
          {{ title }}
        </h2>
      </a>

      <!-- Beschreibung -->
      <div
        :class="{'border-bottom mb-1': hasListSlot}"
        class="description px-3 py-2">
        <slot name="description" />
      </div>

      <!-- Auflistung -->
      <slot name="list" />
    </div>
  </div>
</template>

<script>
export default {
  props: {
    cardClass: {
      type: String,
      required: true,
    },
    link: {
      type: String,
      required: true,
    },
    icon: {
      type: String,
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
  },

  computed: {
    hasListSlot () {
      return this.$slots.list
    },
  },
}
</script>
