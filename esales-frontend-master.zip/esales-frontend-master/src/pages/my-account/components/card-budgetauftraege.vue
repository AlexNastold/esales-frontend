<template>
  <dashboard-card
    :link="`my-account-documents?doctype=${DocumentType.BUDGETAUFTRAG}`"
    :title="$t('myAccount.components.cardBudgetauftraege.title')"
    card-class="card-budgetauftraege"
    icon="fas fa-money-bill-alt">
    <!-- Beschreibung -->
    <template slot="description">
      {{ $t('myAccount.components.cardBudgetauftraege.description') }}
    </template>

    <!-- Auflistung letzte Budgetaufträge -->
    <template
      v-if="budgetOrders.length"
      slot="list">
      <div
        v-for="budgetOrder in budgetOrders"
        :key="budgetOrder.documentId"
        class="row px-3 py-1">
        <div class="col">
          <a
            :href="`my-account-documents-detail?doctype=${DocumentType.BUDGETAUFTRAG}&docid=${encodeURIComponent(budgetOrder.documentId)}`"
            class="icon-link">
            <i class="far fa-money-bill-alt fa-fw text-muted" />&nbsp;
            <span class="text">
              {{ budgetOrder.documentIdDisplay }}
            </span>
          </a>
        </div>
        <div class="col-5 col-xl-3 font-weight-bold text-right">
          {{ budgetOrder.netPrice | price }} {{ budgetOrder.currency }}
        </div>
        <div class="col-12 col-lg-3 text-lg-right mt-1 mt-lg-0">
          {{ budgetOrder.createDate | date }}
        </div>
      </div>
    </template>
  </dashboard-card>
</template>

<script>
import { DocumentType } from '@scripts/modules/documents'

import DashboardCard from './dashboard-card.vue'

export default {
  components: {
    'dashboard-card': DashboardCard,
  },

  props: {
    budgetOrders: {
      type: Array,
      required: true,
    },
  },

  data () {
    return {
      DocumentType,
    }
  },
}
</script>

