<template>
  <dashboard-card
    :title="$t('myAccount.components.cardTopsellersCustomer.title')"
    card-class="card-topsellers"
    link="my-account-topsellers-customer"
    icon="fas fa-users">
    <!-- Beschreibung -->
    <template slot="description">
      {{ $t('myAccount.components.cardTopsellersCustomer.description') }}
    </template>
  </dashboard-card>
</template>

<script>
import DashboardCard from './dashboard-card.vue'

export default {
  components: {
    'dashboard-card': DashboardCard,
  },
}
</script>

