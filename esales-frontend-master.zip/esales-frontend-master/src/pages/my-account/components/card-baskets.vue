<template>
  <dashboard-card
    :title="$t('myAccount.components.cardBaskets.title')"
    card-class="card-baskets"
    link="my-account-baskets"
    icon="fas fa-shopping-cart">
    <!-- Beschreibung -->
    <template slot="description">
      {{ $t('myAccount.components.cardBaskets.description') }}
    </template>

    <!-- Auflistung letzte Warenkörbe -->
    <template
      v-if="baskets.length"
      slot="list">
      <a
        v-for="basket in baskets"
        :key="basket.id"
        href="my-account-baskets"
        class="icon-link d-flex px-3 py-1">
        <div
          :title="basket.name"
          class="text-truncate pr-1">
          <i class="fas fa-shopping-cart fa-fw text-muted" />&nbsp;
          <span class="text">
            {{ basket.name }}
          </span>
        </div>
        <div class="text-dark ml-auto">
          {{ $t('myAccount.components.cardBaskets.article', { count: basket.amountPositions }) }}
        </div>
      </a>
    </template>
  </dashboard-card>
</template>

<script>
import DashboardCard from './dashboard-card.vue'

export default {
  components: {
    'dashboard-card': DashboardCard,
  },

  props: {
    baskets: {
      type: Array,
      required: true,
    },
  },
}
</script>

