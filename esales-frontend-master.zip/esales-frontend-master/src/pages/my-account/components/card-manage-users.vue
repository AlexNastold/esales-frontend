<template>
  <dashboard-card
    :title="$t('myAccount.components.cardManageUsers.title')"
    card-class="card-manage-users"
    link="my-account-manage-users"
    icon="fas fa-users">
    <!-- Beschreibung -->
    <template slot="description">
      {{ $t('myAccount.components.cardManageUsers.description') }}
    </template>

    <!-- Auflistung neueste Benutzer -->
    <template
      v-if="users.length"
      slot="list">
      <div
        v-for="user in users"
        :key="user.userId"
        class="row px-3 py-1">
        <div class="col">
          <a
            :href="`my-account-manage-users-detail?id=${encodeURIComponent(user.userId)}`"
            class="icon-link">
            <i class="fas fa-user fa-fw text-muted" />&nbsp;
            <span class="text">
              {{ user.userId }}
            </span>
          </a>
        </div>
        <div class="col-5 col-lg-4">
          <div
            v-if="user.surname || user.forename"
            :title="user.surname + ' ' + user.forename"
            class="name">
            {{ user.surname }}
            {{ user.forename }}
          </div>
        </div>
        <div class="col-12 col-lg-3 text-muted text-lg-right mt-1 mt-lg-0">
          {{ user.createdAt | date }}
        </div>
      </div>
    </template>
  </dashboard-card>
</template>

<script>
import DashboardCard from './dashboard-card.vue'

export default {
  components: {
    'dashboard-card': DashboardCard,
  },

  props: {
    users: {
      type: Array,
      required: true,
    },
  },
}
</script>

