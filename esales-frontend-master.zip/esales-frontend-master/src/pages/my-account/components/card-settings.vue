<template>
  <dashboard-card
    :title="$t('myAccount.components.cardSettings.title')"
    card-class="card-settings"
    link="my-account-settings"
    icon="fas fa-wrench">
    <!-- Beschreibung -->
    <template slot="description">
      {{ $t('myAccount.components.cardSettings.description') }}
    </template>
  </dashboard-card>
</template>

<script>
import DashboardCard from './dashboard-card.vue'

export default {
  components: {
    'dashboard-card': DashboardCard,
  },
}
</script>

