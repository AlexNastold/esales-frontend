<template>
  <dashboard-card
    :link="`my-account-documents?doctype=${DocumentType.AUFTRAG}`"
    :title="$t('myAccount.components.cardAuftraege.title')"
    card-class="card-auftraege"
    icon="fas fa-folder-open">
    <!-- Beschreibung -->
    <template slot="description">
      {{ $t('myAccount.components.cardAuftraege.description') }}
    </template>

    <!-- Auflistung letzte Bestellungen -->
    <template
      v-if="orders.length"
      slot="list">
      <div
        v-for="order in orders"
        :key="order.documentId"
        class="row px-3 py-1">
        <div class="col">
          <a
            :href="`my-account-documents-detail?doctype=${DocumentType.AUFTRAG}&docid=${encodeURIComponent(order.documentId)}`"
            class="icon-link">
            <i class="fas fa-file fa-fw text-muted" />&nbsp;
            <span class="text">
              {{ order.documentIdDisplay }}
            </span>
          </a>
        </div>
        <div class="col-5 col-lg-3">
          <document-status-badge
            v-if="order.status"
            :status="order.status" />
        </div>
        <div class="col-12 col-lg-3 mt-1 mt-lg-0 text-lg-right">
          {{ order.createDate | date }}
        </div>
      </div>
    </template>
  </dashboard-card>
</template>

<script>
import { DocumentType } from '@scripts/modules/documents'

import DocumentStatusBadge from '@components/pages/documents/status.vue'
import DashboardCard from './dashboard-card.vue'

export default {
  components: {
    'dashboard-card': DashboardCard,
    'document-status-badge': DocumentStatusBadge,
  },

  props: {
    orders: {
      type: Array,
      required: true,
    },
  },

  data () {
    return {
      DocumentType,
    }
  },
}
</script>
