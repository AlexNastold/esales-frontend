<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccount.headline')"
        page="dashboard" />

      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item active">
            {{ $t('myAccount.breadcrumb') }}
          </li>
        </ol>

        <!-- Ladeanzeige -->
        <app-loading-box v-if="isLoading" />

        <div
          v-else
          class="row">
          <!-- Card Ihre Daten -->
          <card-my-data />

          <!-- Card Einstellungen -->
          <card-settings v-if="app.user.hasPermission('SETTINGS') " />

          <!-- Card Benutzer verwalten -->
          <card-manage-users
            v-if="app.user.hasPermission('USERS_MANAGE')"
            :users="informations.users" />

          <!-- Card Adressen -->
          <card-addresses
            v-if="app.user.hasPermission('ADDRESSES_MANAGE')"
            :addresses="informations.addresses" />

          <!-- Card Aufträge -->
          <card-auftraege
            v-if="app.user.hasPermission('DOCUMENTS_AUFTRAG')"
            :orders="informations.orders" />

          <!-- Card Budgetaufträge -->
          <card-budgetauftraege
            v-if="app.user.hasPermission('DOCUMENTS_BUDGETAUFTRAG')"
            :budget-orders="informations.budgetOrders" />

          <!-- Card Listen -->
          <card-lists
            v-if="app.user.hasPermission('LISTS')"
            :lists="informations.lists" />

          <!-- Card Warenkörbe -->
          <card-baskets
            v-if="app.user.hasPermission('BASKETS_MANAGE')"
            :baskets="informations.baskets" />

          <!-- Card Persönliche Topseller -->
          <card-topsellers v-if="app.user.hasPermission('TOPSELLER_PERSONAL')" />

          <!-- Card Topseller zur Kundennummer -->
          <card-topsellers-customer v-if="app.user.hasPermission('TOPSELLER_CUSTOMER')" />

          <!-- Card Zuletzt angesehene Artikel -->
          <card-last-articles v-if="app.user.hasPermission('LAST_SEEN_ARTICLES')" />
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getDashboardInfos } from '@scripts/modules/myaccount'

import MyAccountHeader from '@components/pages/my-account/header.vue'

import CardAddresses from './components/card-addresses.vue'
import CardAuftraege from './components/card-auftraege.vue'
import CardBaskets from './components/card-baskets.vue'
import CardBudgetauftraege from './components/card-budgetauftraege.vue'
import CardLastArticles from './components/card-last-articles.vue'
import CardLists from './components/card-lists.vue'
import CardManageUsers from './components/card-manage-users.vue'
import CardMyData from './components/card-my-data.vue'
import CardSettings from './components/card-settings.vue'
import CardTopsellersCustomer from './components/card-topsellers-customer.vue'
import CardTopsellers from './components/card-topsellers.vue'

export default {
  components: {
    'my-account-header': MyAccountHeader,

    'card-addresses': CardAddresses,
    'card-auftraege': CardAuftraege,
    'card-baskets': CardBaskets,
    'card-budgetauftraege': CardBudgetauftraege,
    'card-last-articles': CardLastArticles,
    'card-lists': CardLists,
    'card-manage-users': CardManageUsers,
    'card-my-data': CardMyData,
    'card-settings': CardSettings,
    'card-topsellers': CardTopsellers,
    'card-topsellers-customer': CardTopsellersCustomer,
  },

  data () {
    return {
      informations: void 0,
      isLoading: true,
    }
  },

  created () {
    this.setPageTitle(this.$t('myAccount.title'))
    this.loadInformations()
  },

  methods: {
    async loadInformations () {
      try {
        this.informations = await getDashboardInfos()
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>

<style lang="scss" src="./my-account.scss"></style>
