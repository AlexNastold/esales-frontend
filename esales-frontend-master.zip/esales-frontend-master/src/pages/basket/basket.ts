/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/basket/basket.vue'
setup(PageComponent)
