<template>
  <div>
    <div class="d-flex">
      <!-- Aktionen Buttons -->
      <div>
        <!-- Mobile -->
        <div class="d-flex d-lg-none">
          <!-- Dropdown Aktionen -->
          <div class="dropdown mr-1">
            <!-- Aufklapp-Button Aktionen -->
            <button
              type="button"
              class="btn btn-secondary dropdown-toggle"
              data-toggle="dropdown">
              <!-- Aktionen -->
              {{ $t('basket.components.actionButtons.selectActionButtonLabel') }}
            </button>

            <div class="dropdown-menu">
              <!-- Upload -->
              <a
                v-if="!isRunningInInAppBrowser"
                href="#"
                class="dropdown-item"
                @click.prevent="showUploadDialog">
                <i class="fas fa-upload fa-fw" />
                {{ $t('basket.components.actionButtons.buttonTextUpload') }}
              </a>
              <button
                v-else
                class="dropdown-item"
                disabled
                @click.prevent>
                <i class="fas fa-upload fa-fw" />
                {{ $t('basket.components.actionButtons.buttonTextUpload') }}
              </button>

              <!-- CSV-Download -->
              <a
                v-if="isBasketOk && !isRunningInInAppBrowser"
                :href="downloadUriCSV"
                class="dropdown-item"
                target="_blank">
                <i class="fas fa-download fa-fw" />
                {{ $t('basket.components.actionButtons.buttonTextDownloadCSV') }}
              </a>
              <button
                v-else
                class="dropdown-item"
                disabled
                @click.prevent>
                <i class="fas fa-download fa-fw" />
                {{ $t('basket.components.actionButtons.buttonTextDownloadCSV') }}
              </button>

              <!-- UGS-Download -->
              <a
                v-if="isBasketOk && !isRunningInInAppBrowser"
                :href="downloadUriUGS"
                class="dropdown-item"
                target="_blank">
                <i class="fas fa-download fa-fw" />
                {{ $t('basket.components.actionButtons.buttonTextDownloadUGS') }}
              </a>
              <button
                v-else
                class="dropdown-item"
                disabled
                @click.prevent>
                <i class="fas fa-download fa-fw" />
                {{ $t('basket.components.actionButtons.buttonTextDownloadUGS') }}
              </button>

              <!-- Als Liste Speichern - bis MD in Dropdown -->
              <button
                v-if="app.user.hasPermission('LISTS')"
                :disabled="isBasketEmpty || hasFaultyPositions"
                class="dropdown-item d-inline-block d-md-none"
                type="button"
                @click.prevent="toggleCreateListDialog">
                <i class="fas fa-file-alt fa-fw" />
                {{ $t('basket.components.actionButtons.buttonTextSaveAsList') }}
              </button>

              <!-- Warenkorb leeren - bis MD in Dropdown -->
              <button
                :disabled="isBasketEmpty"
                class="dropdown-item d-inline-block d-md-none"
                type="button"
                @click.prevent="deleteAllPositions">
                <i class="fas fa-trash-alt fa-fw" />
                {{ $t('basket.components.actionButtons.buttonTextClearBasket') }}
              </button>
            </div>
          </div>

          <!-- Buttons in Ansicht MD -->
          <div class="d-none d-md-flex d-lg-none">
            <!-- Button als Liste speichern -->
            <button
              v-if="app.user.hasPermission('LISTS')"
              :disabled="isBasketEmpty || hasFaultyPositions"
              class="btn btn-secondary mr-1"
              type="button"
              @click.prevent="toggleCreateListDialog">
              <i class="fas fa-file-alt fa-fw" />
              {{ $t('basket.components.actionButtons.buttonTextSaveAsList') }}
            </button>

            <!-- Button Warenkorb leeren -->
            <button
              :disabled="isBasketEmpty"
              class="btn btn-secondary"
              type="button"
              @click.prevent="deleteAllPositions">
              <i class="fas fa-trash-alt fa-fw" />
              {{ $t('basket.components.actionButtons.buttonTextClearBasket') }}
            </button>
          </div>
        </div>

        <!-- Desktop -->
        <div class="d-none d-lg-flex">
          <!-- Button Upload -->
          <button
            :disabled="isRunningInInAppBrowser"
            type="button"
            class="btn btn-secondary mr-1"
            @click="showUploadDialog">
            <i class="fas fa-upload fa-fw" />
            {{ $t('basket.components.actionButtons.buttonTextUpload') }}
          </button>

          <!-- Dropdown Download -->
          <div class="dropdown mr-1">
            <!-- Aufklapp-Button Download -->
            <button
              :disabled="!isBasketOk || isRunningInInAppBrowser"
              type="button"
              class="btn btn-secondary dropdown-toggle"
              data-toggle="dropdown">
              <i class="fas fa-download fa-fw" />
              {{ $t('basket.components.actionButtons.selectDownloadActionLabel') }}
            </button>

            <div class="dropdown-menu">
              <!-- CSV-Download -->
              <a
                v-if="isBasketOk && !isRunningInInAppBrowser"
                :href="downloadUriCSV"
                class="dropdown-item"
                target="_blank">
                <i class="fas fa-download fa-fw" />
                {{ $t('basket.components.actionButtons.buttonTextDownloadCSV') }}
              </a>
              <button
                v-else
                class="dropdown-item"
                disabled
                @click.prevent>
                <i class="fas fa-download fa-fw" />
                {{ $t('basket.components.actionButtons.buttonTextDownloadCSV') }}
              </button>

              <!-- UGS-Download -->
              <a
                v-if="isBasketOk && !isRunningInInAppBrowser"
                :href="downloadUriUGS"
                class="dropdown-item"
                target="_blank">
                <i class="fas fa-download fa-fw" />
                {{ $t('basket.components.actionButtons.buttonTextDownloadUGS') }}
              </a>
              <button
                v-else
                class="dropdown-item"
                disabled
                @click.prevent>
                <i class="fas fa-download fa-fw" />
                {{ $t('basket.components.actionButtons.buttonTextDownloadUGS') }}
              </button>
            </div>
          </div>

          <!-- Button als Liste speichern -->
          <button
            v-if="app.user.hasPermission('LISTS')"
            :disabled="isBasketEmpty || hasFaultyPositions"
            type="button"
            class="btn btn-secondary mr-1"
            @click="toggleCreateListDialog">
            <i class="fas fa-file-alt fa-fw" />
            {{ $t('basket.components.actionButtons.buttonTextSaveAsList') }}
          </button>

          <!-- Button Warenkorb leeren -->
          <button
            :disabled="isBasketEmpty"
            type="button"
            class="btn btn-secondary"
            @click="deleteAllPositions">
            <i class="fas fa-trash-alt fa-fw" />
            {{ $t('basket.components.actionButtons.buttonTextClearBasket') }}
          </button>
        </div>
      </div>

      <!-- Fehlerhafte Positionen Buttons -->
      <div class="ml-auto">
        <!-- Mobile -->
        <div class="d-xl-none">
          <div class="dropdown">
            <!-- Aufklapp-Button Fehlerhafte -->
            <button
              id="dropdownMenuButton"
              :disabled="numberOfFaultyPositions === 0"
              type="button"
              class="btn btn-secondary dropdown-toggle"
              data-toggle="dropdown">
              {{ $t('basket.components.actionButtons.selectFaultyPositionsLabel') }}
            </button>

            <div class="dropdown-menu dropdown-menu-right">
              <!-- Fehlerhafte anzeigen -->
              <button
                :disabled="!hasFaultyPositions"
                class="dropdown-item"
                type="button"
                @click.prevent="applyFilter(PredefinedFilters.FILTER_ERROR)">
                <i class="fas fa-eye fa-fw" />
                {{ $t('basket.components.actionButtons.faultyPositionsShowSelectOption') }}
              </button>

              <!-- Fehlerhafte löschen -->
              <button
                :disabled="!hasFaultyPositions"
                class="dropdown-item"
                type="button"
                @click.prevent="deleteFaultyPositions">
                <i class="fas fa-trash-alt fa-fw" />
                {{ $t('general.delete') }}
              </button>
            </div>
          </div>
        </div>

        <!-- Desktop ab XL -->
        <div class="d-none d-xl-block">
          <!-- Button Fehlerhafte anzeigen -->
          <button
            :disabled="!hasFaultyPositions"
            class="btn btn-secondary"
            type="button"
            @click="applyFilter(PredefinedFilters.FILTER_ERROR)">
            <i class="fas fa-eye fa-fw" />
            <span class="text">
              {{ $t('basket.components.actionButtons.buttonTextFaultyPositionsShow') }}
            </span>
          </button>

          <!-- Button Fehlerhafte löschen -->
          <button
            :disabled="!hasFaultyPositions"
            class="btn btn-secondary"
            type="button"
            @click="deleteFaultyPositions">
            <i class="fas fa-trash-alt fa-fw" />
            <span class="text">
              {{ $t('basket.components.actionButtons.buttonTextFaultyPositionsDelete') }}
            </span>
          </button>
        </div>
      </div>
    </div>

    <!-- Dialog Upload -->
    <upload-dialog
      :visible.sync="isUploadDialogVisible"
      @upload="onFileUpload" />

    <!-- Dialog CSV Upload Detail Informations -->
    <csv-upload-dialog
      :visible.sync="isUploadDialogCsvDetailVisible"
      :lines="uploadedLines"
      @upload="$emit('upload')" />

    <!-- Dialog Auf Liste speichern -->
    <create-list-dialog
      :visible.sync="isCreateListDialogVisible" />
  </div>
</template>

<script>
import browserStore from '@scripts/core/browserStore'
import { getDownloadUri, PredefinedFilters, UpDownloadFormat  } from '@scripts/modules/basket'
import { upload } from '@scripts/modules/basket'

import UploadDialog from './upload-dialog.vue'
import CreateListDialog from './create-list-dialog.vue'

import DialogCsvUpload from './dialog-csv-upload.vue'

export default {
  components: {
    'upload-dialog': UploadDialog,
    'create-list-dialog': CreateListDialog,
    'csv-upload-dialog': DialogCsvUpload,
  },

  props: {
    positions: {
      type: Array,
      required: true,
    },
    numberOfPositions: {
      type: Number,
      default: 0,
    },
    numberOfFaultyPositions: {
      type: Number,
      default: 0,
    },
    uploadSuccessful: {
      type: Boolean,
      default: false,
    },
  },

  data () {
    return {
      PredefinedFilters,
      UpDownloadFormat,
      isUploadDialogVisible: false,
      isCreateListDialogVisible: false,
      isUploadDialogCsvDetailVisible: false,
      uploadedLines: [],
    }
  },

  computed: {
    downloadUriUGS () {
      return getDownloadUri(UpDownloadFormat.UGS)
    },
    downloadUriCSV () {
      return getDownloadUri(UpDownloadFormat.CSV)
    },
    isBasketOk () {
      return this.numberOfPositions > 0 && !this.hasFaultyPositions
    },
    isBasketEmpty () {
      return this.numberOfPositions === 0
    },
    hasFaultyPositions () {
      return this.numberOfFaultyPositions > 0
    },
    isRunningInInAppBrowser () {
      return browserStore.get('InAppBrowser') === true
    },
  },

  methods: {
    applyFilter (filterValue) {
      this.$emit('applyfilter', filterValue)
    },
    showUploadDialog () {
      this.isUploadDialogVisible = true
    },
    deleteAllPositions () {
      if (!this.isBasketEmpty) {
        this.$emit('deleteallpositions')
      }
    },
    deleteFaultyPositions () {
      if (!this.isBasketEmpty) {
        this.$emit('deletefaultypositions')
      }
    },
    toggleCreateListDialog () {
      this.isCreateListDialogVisible = !this.isCreateListDialogVisible
    },
    async onFileUpload (format, file) {
      this.uploadedLines = await upload(format, file)
      if (format === UpDownloadFormat.CSV) {
        this.isUploadDialogCsvDetailVisible = true
      } else  if (format === UpDownloadFormat.UGS) {
        this.$emit('upload')
      }
    },
  },
}
</script>
