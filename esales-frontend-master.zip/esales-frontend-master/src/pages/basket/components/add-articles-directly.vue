<template>
  <div class="rounded bg-light p-3">
    <h4>{{ $t('basket.components.addArticlesDirectly.headline') }}</h4>

    <form @submit.prevent="addPosition">
      <!-- Eingabe Artikel, Menge -->
      <div class="row no-gutters">
        <!-- Eingabe Artikel   -->
        <div class="col-12 col-md mb-1 mb-md-0">
          <div class="input-group">
            <app-form-input-product-search
              ref="matnrInput"
              v-model="matnr"
              :max-items="5"
              :is-disabled="isDisabled"
              class="form-control" />
            <div class="input-group-append">
              <app-scan-button
                :button-class="`btn-tertiary`"
                :tabindex="-1"
                :is-disabled="isDisabled"
                :scan-options="{page:'basket'}"
                @success="onScanSuccess" />
            </div>
          </div>
        </div>

        <!-- Menge -->
        <div class="col-12 col-sm col-md-auto ml-md-1 mb-1 mb-md-0">
          <!-- Menge Mobile -->
          <app-form-input-quantity
            v-model="amount"
            :disabled="isDisabled"
            :unit="$t('components.formInputQuantity.unitDefault')"
            width="auto"
            class="d-md-none"
            btn-type="btn-tertiary" />

          <!-- Menge ab MD -->
          <app-form-input-quantity
            v-model="amount"
            :disabled="isDisabled"
            :unit="$t('components.formInputQuantity.unitDefault')"
            class="d-none d-md-flex"
            btn-type="btn-tertiary" />
        </div>

        <!-- Button Hinzufügen -->
        <div class="col-12 col-sm-auto ml-sm-1">
          <button
            :disabled="!matnr || isAddToBasketInProcess"
            type="submit"
            class="btn btn-block btn-primary">
            <app-icon-state
              :is-loading="isAddToBasketInProcess"
              icon="fas fa-plus" />
            {{ $t('basket.components.addArticlesDirectly.buttonText') }}
          </button>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
import { addPositionToBasket } from '@scripts/modules/basket'
import { showSuccessMessage, showErrorMessage } from '@scripts/modules/dialogs'

export default {
  props: {
    isDisabled: {
      default: false,
      type: Boolean,
    },
    matnrOrBismt: {
      default: '',
      type: String,
    },
  },

  data () {
    return {
      amount: 1,
      isAddToBasketInProcess: false,
      matnr: '',

    }
  },

  created () {
    this.matnr = this.matnrOrBismt
  },

  mounted () {
    if (this.matnr !== void 0 && this.matnr !== '') {
      this.$refs.matnrInput.focus()
    }
  },

  methods: {
    async addPosition () {
      try {
        this.isAddToBasketInProcess = true
        await addPositionToBasket(this.matnr, this.amount, 'basket')
        showSuccessMessage(this.$t('basket.components.addArticlesDirectly.successMessage'))
        this.reset()
        this.$emit('changedpositions', true)
      } catch (error) {
        showErrorMessage(error.message)
      }
      this.isAddToBasketInProcess = false
    },
    reset () {
      this.matnr = ''
      this.amount = 1

      this.$refs.matnrInput.focus()
      return false
    },
    onScanSuccess (text) {
      this.matnr = text
    },
  },
}
</script>
