<template>
  <div class="row">
    <!-- Lieferdaten -->
    <div class="col-12 order-1">
      <!-- Lieferdaten Mobile -->
      <div class="d-lg-none">
        <!-- Lieferart -->
        <span class="badge badge-secondary p-1 mb-1">
          {{ basketOverview.shipment.label }}
        </span>

        <!-- Link Lieferdaten Ändern -->
        <a
          href="#"
          class="icon-link d-inline-block ml-1"
          @click.prevent="showShipmentDataDialog">
          <i class="fas fa-edit fa-fw" />
          <span class="text">
            {{ $t('basket.components.shipmentData.changeShipmentDataButton') }}
          </span>
        </a>
      </div>

      <!-- Lieferdaten Desktop -->
      <div class="card h-100 d-none d-lg-block">
        <div class="card-header">
          <i class="fas fa-truck fa-flip-horizontal fa-fw" />
          {{ $t('basket.components.shipmentData.headline') }}

          <!-- Link Lieferdaten Ändern -->
          <div class="float-right">
            <a
              href="#"
              class="icon-link"
              @click.prevent="showShipmentDataDialog">
              <i class="fas fa-edit fa-fw" />
              <span class="text">
                {{ $t('basket.components.shipmentData.changeButton') }}
              </span>
            </a>
          </div>
        </div>
        <div class="card-body d-flex align-items-stretch align-items-end flex-column">
          <div class="row">
            <!-- Belegart, Lieferart und Zusatzinfos zu Lieferarten -->
            <div class="col-lg-6">
              <div class="row">
                <!-- Belegart (nur bei Abrufaufträgen anzeigen) -->
                <template v-if="basketOverview.isCallOffOrder">
                  <div class="col-4 col-xl-5 font-weight-bold mb-2">
                    {{ $t('basket.components.shipmentData.documentType') }}
                  </div>
                  <div class="col-8 col-xl-7 mb-2">
                    {{ basketOverview.auartDescription }}
                  </div>
                </template>

                <!-- Lieferart -->
                <div class="col-4 col-xl-5 font-weight-bold mb-1">
                  {{ $t('basket.components.shipmentData.deliveryType') }}
                </div>
                <div class="col-8 col-xl-7 mb-1">
                  {{ basketOverview.shipment.label }}
                </div>

                <template v-if="basketOverview.shipment.ship_cond === ShipmentCondition.PICKUP">
                  <!-- Abholdatum -->
                  <div class="col-4 col-xl-5 font-weight-bold mb-1">
                    {{ $t('basket.components.shipmentData.pickupDate') }}
                  </div>
                  <div class="col-8 col-xl-7 mb-1">
                    {{ basketOverview.shipment.date | date }}
                  </div>
                </template>

                <template v-else-if="basketOverview.shipment.ship_cond === ShipmentCondition.DELIVERY_IMMEDIATE">
                  <!-- Komplettlieferkennzeichen -->
                  <div class="col-4 col-xl-5 font-weight-bold mb-1">
                    {{ $t('basket.components.shipmentData.deliverWhenComplete') }}
                  </div>
                  <div class="col-8 col-xl-7 mb-1">
                    <i
                      class="far fa-fw"
                      :class="basketOverview.shipment.deliverWhenComplete ? 'fa-check-square' : 'fa-square'" />
                  </div>
                </template>

                <template v-else-if="basketOverview.shipment.ship_cond === ShipmentCondition.DELIVERY">
                  <!-- Lieferdatum -->
                  <div class="col-4 col-xl-5 font-weight-bold mb-1">
                    {{ $t('basket.components.shipmentData.deliveryDate') }}
                  </div>
                  <div class="col-8 col-xl-7 mb-1">
                    <template v-if="isZhaDateMissing">
                      <a
                        href="checkout"
                        class="icon-link">
                        <i class="fas fa-truck fa-flip-horizontal fa-fw" />
                        <span class="text">
                          {{ $t('basket.components.shipmentData.dateMissingMessage') }}
                        </span>
                      </a>
                    </template>
                    <template v-else>
                      {{ basketOverview.shipment.date | date }}
                    </template>
                  </div>
                </template>
              </div>
            </div>

            <div class="col-lg-6">
              <div class="row">
                <template v-if="basketOverview.shipment.ship_cond === ShipmentCondition.PICKUP">
                  <!-- Ort -->
                  <div class="col-4 col-xl-5  font-weight-bold mb-1">
                    {{ $t('basket.components.shipmentData.pickupLocation') }}
                  </div>
                  <div class="col-8 col-xl-7 mb-1">
                    {{ basketOverview.shipment.place }}
                  </div>
                </template>

                <!-- Lieferadresse -->
                <template v-if="basketOverview.shipment.type === ShipmentType.DELIVERY">
                  <div class="col-4 col-xl-5 font-weight-bold">
                    {{ $t('basket.components.shipmentData.deliveryAdress') }}
                  </div>
                  <div class="col-8 col-xl-7">
                    <strong>{{ basketOverview.shipment.address.name1 }} {{ basketOverview.shipment.address.name2 }}</strong>
                    <br>
                    {{ basketOverview.shipment.address.stras }}, {{ basketOverview.shipment.address.land1 }}-{{ basketOverview.shipment.address.pstlz }} {{ basketOverview.shipment.address.ort01 }}
                  </div>
                </template>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <dialog-delivery
      ref="dialogDelivery"
      @change="onChange" />
  </div>
</template>

<script>
import { ShipmentCondition, ShipmentType } from '@scripts/modules/basket'
import DialogDelivery from '@components/dialogs/DialogDelivery.vue'

export default {
  components: {
    'dialog-delivery': DialogDelivery,
  },

  props: {
    basketOverview: {
      type: Object,
      default: void 0,
    },
  },

  data () {
    return {
      ShipmentCondition,
      ShipmentType,
    }
  },

  computed: {
    isZhaDateMissing () {
      return this.basketOverview.shipment.missingZhaLdat
    },
  },

  methods: {
    showShipmentDataDialog () {
      this.$refs.dialogDelivery.show()
    },
    onChange () {
      this.$emit('change')
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.texts-list {
  list-style: none;

  li {
    &.set {
      i {
        color: $value-set-color;
      }
    }
  }
}

.word-break {
  word-wrap: break-word;
}
</style>
