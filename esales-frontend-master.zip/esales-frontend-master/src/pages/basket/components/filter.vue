<template>
  <div class="d-flex">
    <!-- Suche -->
    <div class="w-100 w-lg-50">
      <form @submit.prevent="applyFilter">
        <div class="input-group">
          <!-- Suchfeld -->
          <input
            v-model="filterValue"
            :placeholder="$t('basket.components.filter.inputPlaceholder')"
            type="text"
            class="form-control">


          <div class="input-group-append">
            <!-- Button Suchen -->
            <button
              type="submit"
              class="btn btn-secondary">
              <i class="fas fa-search fa-fw" />
            </button>

            <!-- Button Suchfeld leeren -->
            <button
              :disabled="!filterValue"
              type="button"
              class="btn btn-secondary"
              @click="reset">
              <i class="fas fa-times fa-fw" />
            </button>

            <!-- Aufklapp-Button Dropdown -->
            <button
              type="button"
              class="btn btn-secondary dropdown-toggle dropdown-toggle-split"
              data-toggle="dropdown" />

            <!-- Spezialsuchbegriffe Dropdown -->
            <div class="dropdown-menu dropdown-menu-right">
              <!-- Spezialsuchbegriff Fehlerhafte -->
              <a
                class="dropdown-item"
                href="#"
                @click.prevent="selectPredefinedFilter(PredefinedFilters.FILTER_ERROR)">
                <i class="fas fa-exclamation-triangle fa-fw" />
                {{ $t('basket.components.filter.filterOptionFaulty') }}
              </a>

              <!-- Spezialsuchbegriff Materialsubstitution -->
              <a
                class="dropdown-item"
                href="#"
                @click.prevent="selectPredefinedFilter(PredefinedFilters.FILTER_SUBSTITUTION)">
                <i class="fas fa-exchange-alt fa-fw" />
                {{ $t('basket.components.filter.filterOptionHasSubstitute') }}
              </a>

              <!-- Spezialsuchbegriff Stücklisten Artikel -->
              <a
                class="dropdown-item"
                href="#"
                @click.prevent="selectPredefinedFilter(PredefinedFilters.FILTER_STL)">
                <i class="fas fa-list-ol fa-fw" />
                {{ $t('basket.components.filter.filterOptionIsPartsList') }}
              </a>

              <!-- Spezialsuchbegriff Smart-Konfigurator -->
              <!--
              <a
                class="dropdown-item"
                href="#"
                @click.prevent="selectPredefinedFilter(PredefinedFilters.FILTER_SMARTCONFIG)">
                <i class="fas fa-magic fa-fw" />
                {{$t('basket.components.filter.filterOptionIsConfigurable')}}
              </a>
              -->
            </div>
          </div>
        </div>
      </form>
    </div>

    <div class="d-none d-lg-block w-25 ml-auto">
      <!-- Button per IDS/OCI/SAP übernehmen -->
      <send-data-button
        :disabled="!mayProceedToCheckout"
        class="btn-block mb-1" />

      <!-- Aktualisieren, Zur Kasse -->
      <proceed-to-checkout-button
        :is-update-required="isUpdateRequired"
        :is-update-in-process="isUpdateInProcess"
        :may-proceed-to-checkout="mayProceedToCheckout"
        @update="update" />
    </div>
  </div>
</template>

<script>
import { PredefinedFilters } from '@scripts/modules/basket'

import ProceedToCheckoutButton from './proceed-to-checkout-button.vue'
import SendDataButton from './send-data-button.vue'

export default {
  components: {
    'proceed-to-checkout-button': ProceedToCheckoutButton,
    'send-data-button': SendDataButton,
  },

  props: {
    value: {
      type: String,
      default: '',
    },
    isUpdateRequired: {
      type: Boolean,
      required: true,
    },
    mayProceedToCheckout: {
      type: Boolean,
      required: true,
    },
    isUpdateInProcess: {
      type: Boolean,
      default: false,
    },
  },

  data () {
    return {
      filterValue: this.value,
      PredefinedFilters,
    }
  },

  watch: {
    // Update component value when prop value changes
    value (newValue) {
      this.filterValue = newValue
    },
  },

  methods: {
    applyFilter () {
      this.$emit('applyfilter', this.filterValue)
    },
    selectPredefinedFilter (value) {
      this.filterValue = value
      this.applyFilter()
    },
    reset () {
      this.filterValue = ''
      this.applyFilter()
    },
    update () {
      this.$emit('update')
    },
  },
}
</script>

