<template>
  <div>
    <!-- Fehlermeldung -->
    <div
      v-if="position.hasError"
      class="text-danger font-weight-bold mb-2">
      <i class="fas fa-exclamation-triangle fa-fw" />&nbsp;
      {{ position.error }}
    </div>

    <div class="row">
      <!-- Artikebild, Artikelname, Artikelnummer, EEK-Label -->
      <div class="col-12 col-md-9 col-lg-5 col-xl-6 mb-2 mb-lg-0">
        <div
          :class="{'ml-1 ml-xl-2' : position.position.partList && position.position.partList.headPosnr}"
          class="row">
          <!-- Stücklistenartikel, Artikelbild -->
          <div class="col-auto d-flex">
            <!-- Anzeige Stücklistenartikel -->
            <div
              v-if="position.position.partList.isPartListArticle && app.settings.showPartsListItems"
              :class="{'part-list-items-trigger' : position.position.partList.isHead }"
              class="d-flex align-items-center pr-1">
              <i
                v-if="position.position.partList.isHead"
                :class="[showPartListItems ? 'fa-angle-down' : 'fa-angle-right']"
                class="fas fa-lg fa-fw"
                @click="togglePartListVisibility" />
              <i
                v-else
                class="fas fa-level-up-alt fa-rotate-90 fa-lg fa-fw" />
            </div>

            <!-- Artikelbild -->
            <template v-if="!position.flags.isVariousOrTextPosition">
              <a
                :href="detailLink(position.article.matnr, position.article.maktx, position.article.maktx2)">
                <div class="article-image-wrapper d-flex align-items-center justify-content-center">
                  <img
                    :src="position.article.image | articleImage"
                    :alt="position.article.maktx">
                </div>
              </a>
            </template>
            <template v-else>
              <div class="article-image-wrapper d-flex align-items-center justify-content-center">
                <img
                  :src="position.article.image | articleImage"
                  :alt="position.article.maktx">
              </div>
            </template>
          </div>

          <div class="col">
            <!-- EEK-Label -->
            <app-article-atom-eek-label
              v-if="position.article.eek"
              :classes="position.article.eek"
              class="float-right pl-1" />

            <!-- Artikelname -->
            <div class="font-weight-bold font-size-lg">
              <template v-if="!position.flags.isVariousOrTextPosition">
                <a
                  :href="detailLink(position.article.matnrDisplay, position.article.maktx, position.article.maktx2)"
                  class="text-dark text-break">
                  {{ position.article.maktx }}
                  {{ position.article.maktx2 }}
                </a>
              </template>
              <template v-else>
                <span class="text-break">
                  {{ position.article.maktx }}
                  {{ position.article.maktx2 }}
                </span>
              </template>
            </div>

            <!-- Artikelnummer -->
            <div class="text-muted">
              <small>{{ $t('general.articleNumberShort') }} {{ position.article.matnrDisplay }}</small>
            </div>

            <!-- Verfügbarkeit -->
            <app-article-atom-availability
              v-if="app.user.hasPermission('SHOW_AVAILABILITY') && !position.hasError && position.flags.canHaveAvailablity"
              :is-loading="isAdditionalDataLoading"
              :availability="additionalData && additionalData.availability"
              class="mt-2" />

            <!-- Artikel-Badges -->
            <app-article-badges
              :is-loading="isAdditionalDataLoading"
              :already-purchased="additionalData && additionalData.alreadyPurchased"
              :additional-material-categories="position.article.additionalMaterialCategories"
              class="mt-1" />
          </div>
        </div>
      </div>

      <!-- Preise Mobile -->
      <div class="col-12 col-md-3 mb-2 d-lg-none">
        <app-article-atom-prices-basket
          v-if="!position.hasError && position.flags.canHavePrices"
          :retail-price="additionalData && additionalData.retailPrice"
          :retail-price-single="additionalData && additionalData.retailPriceSingle"
          :net-price="additionalData && additionalData.netPrice"
          :is-price-loading="isAdditionalDataLoading" />
      </div>

      <!-- Button Materialsubstitution mobile -->
      <div class="col-12 mb-2 text-right d-md-none">
        <button
          v-if="isSubstitutionArticle(position)"
          type="button"
          class="btn btn-info"
          @click.prevent="showSubstitutionDialog(position)">
          <i class="fas fa-exchange-alt fa-fw" />
          {{ $t('basket.components.positionItem.substitution') }}
        </button>
      </div>

      <!-- Menge, Preise Desktop, Werfen, Buttons -->
      <div class="col-12 col-lg-7 col-xl-6">
        <div class="row">
          <!-- Menge ab SM -->
          <div class="col col-lg-auto d-none d-sm-flex d-lg-block justify-content-sm-end">
            <!-- Button Materialsubstitution MD -->
            <button
              v-if="isSubstitutionArticle(position)"
              type="button"
              class="btn btn-info mr-1 d-none d-md-block d-lg-none"
              @click="showSubstitutionDialog(position)">
              <i class="fas fa-exchange-alt fa-fw" />
              {{ $t('basket.components.positionItem.substitution') }}
            </button>

            <!-- Aktualisieren Link ab SM -->
            <div class="d-inline">
              <button
                v-if="updateRequired"
                type="button"
                :disabled="isUpdateInProcess"
                class="btn btn-warning d-none d-sm-inline d-lg-none mr-1"
                @click.prevent="onUpdate">
                <app-icon-state
                  :is-loading="isUpdateInProcess"
                  icon="fas fa-sync" />
              </button>
            </div>

            <!-- Menge ab SM -->
            <app-form-input-quantity
              v-model="position.position.amount"
              :disabled="!position.position.editable_qty"
              :unit="position.article.unitFormatted"
              :stepsize="position.article.stepsize"
              :should-emit-on-mount="false"
              class="d-none d-sm-flex"
              @input="onQuantityChanged"
              @enter="onUpdate" />

            <!-- Aktualisieren Link ab LG -->
            <div class="d-inline">
              <button
                v-if="updateRequired"
                type="button"
                :disabled="isUpdateInProcess"
                class="btn btn-sm btn-block btn-warning d-none d-lg-block mt-1"
                @click.prevent="onUpdate">
                <app-icon-state
                  :is-loading="isUpdateInProcess"
                  icon="fas fa-sync fa-sm" />
                {{ $t('basket.components.positionItem.updateLink') }}
              </button>
            </div>
          </div>

          <!-- Artikelpreis Desktop -->
          <div class="col-lg d-none d-lg-block">
            <app-article-atom-prices-basket
              v-if="!position.hasError && position.flags.canHavePrices"
              :retail-price-single="additionalData && additionalData.retailPriceSingle"
              :is-price-loading="isAdditionalDataLoading"
              mode="single" />
          </div>

          <!-- Gesamtpreis Desktop -->
          <div class="col-lg d-none d-lg-block">
            <app-article-atom-prices-basket
              v-if="!position.hasError && position.flags.canHavePrices"
              :retail-price="additionalData && additionalData.retailPrice"
              :net-price="additionalData && additionalData.netPrice"
              :is-price-loading="isAdditionalDataLoading"
              mode="sum" />
          </div>

          <!-- Menge bis SM -->
          <div class="col-12 d-sm-none d-flex justify-content-end">
            <!-- Aktualisieren Link bis SM -->
            <div class="d-inline">
              <button
                v-if="updateRequired"
                type="button"
                class="btn btn-warning mr-1"
                :disabled="isUpdateInProcess"
                @click.prevent="onUpdate">
                <app-icon-state
                  :is-loading="isUpdateInProcess"
                  icon="fas fa-sync" />
              </button>
            </div>

            <!-- Menge bis SM -->
            <app-form-input-quantity
              v-model="position.position.amount"
              :disabled="!position.position.editable_qty"
              :unit="position.article.unitFormatted"
              :stepsize="position.article.stepsize"
              :should-emit-on-mount="false"
              class="mb-2"
              @input="onQuantityChanged"
              @enter="onUpdate" />
          </div>

          <!-- Buttons -->
          <div class="col-12 col-sm-auto col-lg-12 d-flex justify-content-end mt-lg-2">
            <!-- Button Materialsubstitution ab LG -->
            <button
              v-if="isSubstitutionArticle(position)"
              type="button"
              class="btn btn-info mr-1 d-none d-lg-block"
              @click="showSubstitutionDialog(position)">
              <i class="fas fa-exchange-alt fa-fw" />
              {{ $t('basket.components.positionItem.substitution') }}
            </button>

            <!-- Dropdown Aktionen -->
            <div
              v-if="showActionsDropdown"
              class="dropdown mr-1">
              <button
                type="button"
                class="btn btn-secondary dropdown-toggle"
                data-toggle="dropdown">
                <span class="d-inline">
                  {{ $t('basket.components.positionItem.selectActionLabel') }}
                </span>
              </button>
              <div class="dropdown-menu dropdown-menu-right">
                <a
                  v-if="app.user.hasPermission('BASKET_POSITION_DATE') && position.flags.canHaveDesiredDeliveryDate"
                  class="dropdown-item"
                  href="#"
                  @click.prevent="showDeliveryDateDialog">
                  <i class="fas fa-calendar-alt fa-fw" />
                  {{ $t('basket.components.positionItem.chooseDesiredDeliveryDate') }}
                </a>
                <a
                  v-if="app.user.hasPermission('BASKET_POSITION_TEXT') && position.flags.canHaveCustomerText"
                  class="dropdown-item"
                  href="#"
                  @click.prevent="showPosTextDialog">
                  <i class="fas fa-sticky-note fa-fw" />
                  {{ $t('basket.components.positionItem.addPositionText') }}
                </a>
                <a
                  v-if="app.user.hasPermission('COMPARISON')"
                  class="dropdown-item"
                  href="#"
                  @click.prevent="addToComparison">
                  <i class="fas fa-balance-scale fa-fw" />
                  {{ $t('basket.components.positionItem.addToComparison') }}
                </a>
                <a
                  v-if="app.user.hasPermission('LISTS')"
                  class="dropdown-item"
                  href="#"
                  @click.prevent="toggleAddToListDialog">
                  <i class="fas fa-file-alt fa-fw" />
                  {{ $t('basket.components.positionItem.addToList') }}
                </a>
                <a
                  v-if="app.user.hasPermission('LABELS')"
                  class="dropdown-item"
                  href="#"
                  @click.prevent="addToLabels">
                  <i class="fas fa-tag fa-fw" />
                  {{ $t('basket.components.positionItem.addToLabels') }}
                </a>
              </div>
            </div>

            <!-- Button Löschen -->
            <button
              v-if="position.flags.canBeDeleted"
              type="button"
              class="btn btn-secondary"
              @click="deletePosition">
              <i class="fas fa-trash-alt fa-fw" />
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Zusatzinformationen -->
    <position-item-info
      :position="position.position"
      :flags="position.flags">
      <template slot="delivery-date-addition">
        <a
          href="#"
          class="icon-link"
          @click.prevent="showDeliveryDateDialog">
          <i class="fas fa-edit fa-fw" />
          <span class="text">
            {{ $t('general.edit') }}
          </span>
        </a>
      </template>

      <template slot="position-text-addition">
        <a
          href="#"
          class="icon-link"
          @click.prevent="showPosTextDialog">
          <i class="fas fa-edit fa-fw" />
          <span class="text">
            {{ $t('general.edit') }}
          </span>
        </a>
      </template>
    </position-item-info>

    <!-- Dialog Wunschlieferdatum -->
    <b-modal
      v-model="isDeliveryDateDialogVisible"
      :title="$t('basket.components.positionItem.headline')"
      :header-close-label="$t('general.dialogCloseLabel')"
      header-bg-variant="primary"
      header-text-variant="white"
      @ok="setDesiredDeliveryDate"
      @hide="onDeliveryDateDialogHide">
      <div class="form-group">
        <label for="deliveryDate">
          {{ $t('basket.components.positionItem.text') }}
        </label>
        <app-form-input-datepicker
          v-model="desiredDeliveryDate"
          :placeholder="$t('basket.components.positionItem.placeholder')"
          :error-message="desiredDeliveryDateErrorMessage" />
      </div>

      <template slot="modal-cancel">
        <i class="fas fa-times fa-fw" />
        {{ $t('general.cancel') }}
      </template>

      <template slot="modal-ok">
        <i class="fas fa-calendar-alt fa-fw" />
        {{ $t('basket.components.positionItem.buttonOk') }}
      </template>
    </b-modal>

    <!-- Dialog Positionstext -->
    <b-modal
      v-model="isPosTextDialogVisible"
      :title="$t('basket.components.positionItem.positionTextDialogHeadline')"
      :header-close-label="$t('general.dialogCloseLabel')"
      header-bg-variant="primary"
      header-text-variant="white"
      @ok="setPosText">
      <div class="form-group">
        <label for="posText">
          {{ $t('basket.components.positionItem.positionTextDialogText') }}
        </label>
        <textarea
          v-if="app.user.hasPermission('BASKET_POSITION_TEXT')"
          id="posText"
          v-model="posText"
          :placeholder="$t('basket.components.positionItem.positionTextDialogPlaceholder')"
          class="form-control"
          rows="3"
          autofocus />
      </div>

      <template slot="modal-cancel">
        <i class="fas fa-times fa-fw" />
        {{ $t('general.cancel') }}
      </template>

      <template slot="modal-ok">
        <i class="fas fa-save fa-fw" />
        {{ $t('basket.components.positionItem.positionTextDialogButtonOk') }}
      </template>
    </b-modal>

    <!-- Dialog Materialsubstitution -->
    <substitution-dialog
      v-if="isSubstitutionDialogVisible"
      :position="position"
      :availability="additionalData.availability"
      @dosubstitution="doSubstitution"
      @abortsubstitution="abortSubstitution" />

    <!-- Dialog zur Liste hinzufügen -->
    <dialog-list-selection
      v-if="isAddToListDialogVisible"
      @select="onListSelect"
      @hidden="isAddToListDialogVisible = false" />
  </div>
</template>

<script>
import { getSingleAdditionalPositionData, setDesiredDeliveryDate, setPosText, substitutePosition } from '@scripts/modules/basket'
import { showErrorMessage, showSuccessMessage, showTechnicalErrorMessage, showWarningMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'
import { addArticleToList } from '@scripts/modules/lists'
import { addLabel } from '@scripts/modules/labels'
import { addToComparison } from '@scripts/modules/comparison'

import DialogListSelection from '@components/dialogs/DialogListSelection.vue'
import PositionItemInfo from '@components/pages/ordering-process/position-item-info.vue'
import SubstitutionDialog from './substitution-dialog.vue'
import { detailLink } from '@scripts/helper/generateLink'
export default {
  components: {
    'dialog-list-selection': DialogListSelection,
    'position-item-info': PositionItemInfo,
    'substitution-dialog': SubstitutionDialog,
  },

  props: {
    position: {
      type: Object,
      required: true,
    },
    isUpdateInProcess: {
      type: Boolean,
      default: false,
    },
  },

  data () {
    return {
      additionalData: void 0,
      isAdditionalDataLoading: false,

      detailLink,

      desiredDeliveryDate: this.position.position.desiredDeliveryDate ? new Date(this.position.position.desiredDeliveryDate) : void 0,
      desiredDeliveryDateErrorMessage: void 0,
      desiredDeliveryDateNextPossible: void 0, // ToDo: mit Lieferdatum aus Head vorbelegen
      posText: this.position.position.customerText || void 0,
      isPosTextDialogVisible: false,
      isDeliveryDateDialogVisible: false,
      isSubstitutionDialogVisible: false,
      isAddToListDialogVisible: false,
      shouldKeepDeliveryDateDialogOpen: false,

      // Bei automatischer Artikelsubstitution muss aktualisiert werden können
      updateRequired: this.position.matStatus === 'N' ? true : false,

    }
  },

  computed: {

    showPartListItems: {
      get () {
        return (typeof this.position.showPartListItems === 'boolean') ? this.position.showPartListItems : false
      },
      set (newValue) {

        // Ensure the new property is reactive
        this.$set(this.position, 'showPartListItems', newValue)
      },
    },

    isArticleNotExisting () {
      return (this.position.hasError && !this.position.matStatus)
    },

    showActionsDropdown () {
      // Artikel existiert nicht -> keine zusätzlichen Aktionen
      if (this.isArticleNotExisting) {
        return false
      }

      return (this.app.user.hasPermission('BASKET_POSITION_DATE') && this.position.flags.canHaveDesiredDeliveryDate)
        || (this.app.user.hasPermission('BASKET_POSITION_TEXT') && this.position.flags.canHaveCustomerText)
        || this.app.user.hasPermission('COMPARISON')
        || this.app.user.hasPermission('LISTS')
        || this.app.user.hasPermission('LABELS')
    },
  },

  created () {
    if (!this.position.hasError) {
      this.isAdditionalDataLoading = true
      this.loadAdditionalArticleData()
    }
    if (this.position.position.nextAmount > 0) {
      this.position.position.amount = this.position.position.nextAmount
      this.onQuantityChanged()
    }
  },

  methods: {
    async loadAdditionalArticleData () {
      try {
        this.additionalData = await getSingleAdditionalPositionData(this.position.position.posnr)
        this.isAdditionalDataLoading = false
      } catch (e) {
        console.error()
        showTechnicalErrorMessage()
      }
    },
    deletePosition () {
      this.$emit('deleteposition', this.position)
    },
    showDeliveryDateDialog () {
      this.isDeliveryDateDialogVisible = true
    },
    hideDeliveryDateDialog () {
      this.isDeliveryDateDialogVisible = false
    },
    async setDesiredDeliveryDate () {
      this.shouldKeepDeliveryDateDialogOpen = true
      this.desiredDeliveryDateErrorMessage = void 0
      try {
        await setDesiredDeliveryDate(this.position.position.posnrDisplay, this.desiredDeliveryDate)
        this.shouldKeepDeliveryDateDialogOpen = false
        this.hideDeliveryDateDialog()
        this.$emit('changedpositions')
      } catch (error) {
        this.shouldKeepDeliveryDateDialogOpen = false
        if (error.code === ErrorCode.DATE_NOT_POSSIBLE) {
          this.desiredDeliveryDateNextPossible = error.nextPossibleDeliveryDate
          this.desiredDeliveryDate = this.desiredDeliveryDateNextPossible // ToDo: User bestätigen lassen
          this.desiredDeliveryDateErrorMessage = this.$t('basket.components.positionItem.errorMessage', { nextPossibleDate: this.$options.filters.date(this.desiredDeliveryDateNextPossible) })
        } else {
          this.desiredDeliveryDateErrorMessage = error.message
        }
      }
    },
    onDeliveryDateDialogHide (event) {
      if (this.shouldKeepDeliveryDateDialogOpen) {
        event.preventDefault()
      }
    },
    showPosTextDialog () {
      this.posText = this.position.position.customerText || void 0
      this.isPosTextDialogVisible = true
    },
    hidePosTextDialog () {
      this.isPosTextDialogVisible = false
    },
    async setPosText () {
      try {
        await setPosText(this.position.position.posnr, this.posText)
        this.position.position.customerText = this.posText
        this.hidePosTextDialog()
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
    isSubstitutionArticle (position) {
      if (position.matStatus === 'E' && !position.position.referenceDocument) {
        return true
      }
    },
    showSubstitutionDialog () {
      this.isSubstitutionDialogVisible = true
    },
    async doSubstitution (substitutionType) {
      try {
        await substitutePosition(this.position.position.posnrDisplay, substitutionType)
        showSuccessMessage(this.$t('basket.components.positionItem.successMessage'))
        this.isSubstitutionDialogVisible = false
        this.$emit('changedpositions')
      } catch (error) {
        showErrorMessage(error.message)
      }
    },
    abortSubstitution () {
      this.isSubstitutionDialogVisible = false
    },
    toggleAddToListDialog () {
      this.isAddToListDialogVisible = true
    },
    togglePartListVisibility () {
      this.showPartListItems = !this.showPartListItems
      this.$emit('togglepartlistvisibility', this.position)
    },
    onQuantityChanged () {
      this.updateRequired = true
      this.$emit('quantitychanged', this.position)
    },
    onUpdate () {
      this.$emit('update', this.position)
    },
    async onListSelect (list) {
      try {
        await addArticleToList(list.id, this.position.article.matnr, this.position.position.amount)
        showSuccessMessage(this.$t('basket.components.positionItem.addToListSuccess', { listName: list.name }))
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
    async addToComparison () {
      try {
        await addToComparison(this.position.article.matnr)
        showSuccessMessage(this.$t('general.actionButtons.addToComparisonSuccessMessage') + `<br><br>
          <a href="product-comparison" class="icon-link text-white">
            <i class="fas fa-balance-scale fa-fw"></i>
            <span class="text text-underline">` + this.$t('general.actionButtons.addToComparisonLinkLabel') + `
          </a>
        `)
      } catch (e) {
        if (e.code === ErrorCode.ALREADY_IN_COMPARISON) {
          showWarningMessage(this.$t('general.actionButtons.addToComparisonErrorMessageExists'))
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },
    async addToLabels () {
      try {
        await addLabel(this.position.article.matnr, this.position.position.amount)
        showSuccessMessage(this.$t('general.actionButtons.addToLabelsSuccessMessage') + `<br><br>
          <a href="labels" class="icon-link text-white">
            <i class="fas fa-tags fa-fw"></i>
            <span class="text text-underline">` + this.$t('general.actionButtons.addToLabelsLinkLabel') + `
          </a>
        `)
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
