<template>
  <div>
    <!-- Buttons Mobile -->
    <div class="d-md-none">
      <!-- Button Aktualisieren / Zur Kasse Mobile -->
      <proceed-to-checkout-button
        :is-update-required="isUpdateRequired"
        :is-update-in-process="isUpdateInProcess"
        :may-proceed-to-checkout="mayProceedToCheckout"
        class="mb-1"
        @update="update" />

      <!-- Button per IDS/OCI/SAP übernehmen -->
      <send-data-button
        :disabled="!mayProceedToCheckout"
        class="mb-1 btn-block" />

      <!-- Button Angebot anfordern -->
      <button
        v-if="mayRequestQuote"
        :disabled="numberOfPositions === 0"
        type="button"
        class="btn btn-block btn-secondary mb-1"
        @click="requestOffer">
        {{ $t('basket.components.pageEndButtons.buttonRequestOffer') }}
      </button>

      <!-- Button weiter einkaufen -->
      <a
        v-if="app.user.hasPermission('CATALOGUE')"
        href="catalogue"
        class="btn btn-block btn-secondary mb-1">
        {{ $t('basket.components.pageEndButtons.buttonContinueShopping') }}
      </a>
    </div>

    <!-- Buttons ab MD -->
    <div class="d-none d-md-flex flex-md-wrap">
      <!-- Buttons Weiter einkaufen, Angebot anfordern -->
      <div class="w-100 w-md-50 w-lg-75 d-md-flex">
        <!-- Button weiter einkaufen -->
        <a
          v-if="app.user.hasPermission('CATALOGUE')"
          href="catalogue"
          class="btn btn-secondary">
          {{ $t('basket.components.pageEndButtons.buttonContinueShopping') }}
        </a>

        <!-- Button Angebot anfordern -->
        <button
          v-if="mayRequestQuote"
          :disabled="numberOfPositions === 0"
          type="button"
          class="btn btn-secondary ml-auto"
          @click="requestOffer">
          {{ $t('basket.components.pageEndButtons.buttonRequestOffer') }}
        </button>
      </div>

      <!-- Button Aktualisieren / Zur Kasse Desktop -->
      <div class="w-50 w-lg-25 pl-1">
        <proceed-to-checkout-button
          :is-update-required="isUpdateRequired"
          :is-update-in-process="isUpdateInProcess"
          :may-proceed-to-checkout="mayProceedToCheckout"
          @update="update" />
      </div>

      <!-- Button per IDS/OCI/SAP übernehmen -->
      <send-data-button
        :disabled="!mayProceedToCheckout"
        class="w-100 mt-1" />
    </div>
  </div>
</template>

<script>
import { showErrorMessage, confirmDialog } from '@scripts/modules/dialogs'
import { redirect } from '@scripts/helper/redirect.ts'
import { requestOffer } from '@scripts/modules/basket'

import ProceedToCheckoutButton from './proceed-to-checkout-button.vue'
import SendDataButton from './send-data-button.vue'

export default {
  components: {
    'proceed-to-checkout-button': ProceedToCheckoutButton,
    'send-data-button': SendDataButton,
  },

  props: {
    numberOfPositions: {
      type: Number,
      default: 0,
    },
    isUpdateRequired: {
      type: Boolean,
      required: true,
    },
    isUpdateInProcess: {
      type: Boolean,
      default: false,
    },
    mayProceedToCheckout: {
      type: Boolean,
      required: true,
    },
    mayRequestQuote: {
      type: Boolean,
      required: true,
    },
  },

  methods: {
    async requestOffer () {
      if (await confirmDialog(
        this.$t('basket.components.pageEndButtons.requestOffer.headline'),
        this.$t('basket.components.pageEndButtons.requestOffer.question'),
        {
          type: 'primary',
          buttonConfirmText: `<i class="fas fa-check fa-fw"></i> ${this.$t('basket.components.pageEndButtons.requestOffer.buttonOk')}`,
          buttonCancelText: `<i class="fas fa-times fa-fw"></i> ${this.$t('general.cancel')}`,
        },
      )) {
        try {
          await requestOffer()
          redirect('ordering-process-ordered')
        } catch (error) {
          showErrorMessage(error.message)
        }
      }
    },
    update () {
      this.$emit('update')
    },
  },
}
</script>

