<template>
  <b-modal
    ref="modal"
    v-model="isVisible"
    :title="title"
    :header-close-label="$t('general.dialogCloseLabel')"
    :cancel-disabled="isProcessing"
    :ok-disabled="isProcessing || !formIsValid"
    header-bg-variant="primary"
    header-text-variant="white"
    no-stacking
    @show="onDialogShow"
    @hide="onDialogHide"
    @ok="upload"
    @cancel="shouldKeepOpen = false">
    <div class="position-relative">
      <app-loading-spinner
        v-if="isProcessing"
        class="position-absolute w-100 h-100 text-center" />

      <!-- Upload Format -->
      <div class="form-group">
        <label class="d-block">
          {{ $t('basket.components.uploadDialog.uploadFormat') }}
        </label>
        <div class="custom-control custom-radio">
          <input
            id="upload-format-csv"
            v-model="format"
            :value="UpDownloadFormat.CSV"
            name="upload-format"
            type="radio"
            class="custom-control-input"
            @change="onFormatChange">
          <label
            class="custom-control-label"
            for="upload-format-csv">
            {{ $t('basket.components.uploadDialog.uploadFormatCSV') }}
          </label>
        </div>
        <div class="custom-control custom-radio">
          <input
            id="upload-format-ugs"
            v-model="format"
            :value="UpDownloadFormat.UGS"
            name="upload-format"
            type="radio"
            class="custom-control-input"
            @change="onFormatChange">
          <label
            class="custom-control-label"
            for="upload-format-ugs">
            {{ $t('basket.components.uploadDialog.uploadFormatUGS') }}
          </label>
        </div>
      </div>

      <!-- Datei auswählen -->
      <div class="form-group">
        <label class="d-block">
          {{ $t('basket.components.uploadDialog.buttonChooseFile') }}
        </label>
        <div class="custom-file">
          <b-form-file
            ref="fileinput"
            v-model="file"
            :accept="uploadAcceptedFileTypes"
            :placeholder="$t('basket.components.uploadDialog.inputPlaceholder')"
            :lang="language" />
        </div>
      </div>
    </div>

    <template slot="modal-cancel">
      <i class="fas fa-times fa-fw" />
      {{ $t('general.cancel') }}
    </template>

    <template slot="modal-ok">
      <app-icon-state
        :is-loading="isProcessing"
        icon="fas fa-upload" />
      {{ $t('basket.components.uploadDialog.buttonOk') }}
    </template>
  </b-modal>
</template>

<script>
import I18n from '@scripts/modules/i18n'
import { UpDownloadFormat } from '@scripts/modules/basket'
import { showErrorMessage } from '@scripts/modules/dialogs'


export default {
  props: {
    visible: {
      type: Boolean,
      default: true,
    },
  },

  data () {
    return {
      format: UpDownloadFormat.UGS,
      file: void 0,
      isVisible: this.visible,
      isProcessing: false,
      shouldKeepOpen: false,
      UpDownloadFormat,
      language: I18n.language,
    }
  },

  computed: {
    formIsValid () {
      return !!this.file
    },
    uploadAcceptedFileTypes () {
      switch (this.format) {
        case UpDownloadFormat.CSV:
          return '.csv,text/csv'
        case UpDownloadFormat.UGS:
          return '.ugs,text/ugs'
        default:
          return 'text'
      }
    },
    title () {
      return `${this.$t('basket.components.uploadDialog.headline')} ${this.$t('basket.components.uploadDialog.uploadFormatCSV')}`
    },

  },

  watch: {
    visible (newValue) {
      return this.isVisible = newValue
    },
  },

  methods: {
    async upload () {
      this.shouldKeepOpen = true
      this.isProcessing = true

      try {
        this.$emit('upload', this.format, this.file)
        this.resetFile()
        this.shouldKeepOpen = false
        this.isVisible = false
      } catch (error) {
        showErrorMessage(error.message)
      }
      this.isProcessing = false
    },
    onFormatChange () {
      // File zurücksetzen, wenn es nicht zum ausgewählten Format passt
      if (this.file && this.format) {
        const fileExtensionOffset = this.file.name.length - this.format.length
        const fileExtensionLowerCase = this.file.name.substring(fileExtensionOffset).toLowerCase()
        const formatLowerCase = this.format.toLowerCase()
        const doesFormatAndFileExtensionMatch = fileExtensionLowerCase.indexOf(formatLowerCase) !== -1

        if (!doesFormatAndFileExtensionMatch) {
          this.resetFile()
        }
      }
    },
    onDialogShow () {
      this.isProcessing = false
      this.shouldKeepOpen = false
      this.$emit('update:visible', true)
    },
    onDialogHide (event) {
      if (this.shouldKeepOpen) {
        event.preventDefault()
        return
      }

      // See https://vuejs.org/v2/guide/components.html#sync-Modifier
      this.$emit('update:visible', false)
    },
    resetFile () {
      this.$refs.fileinput.reset()
    },
  },
}
</script>
