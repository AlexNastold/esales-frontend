<template>
  <b-modal
    ref="modal"
    v-model="isVisible"
    size="lg"
    :title="title"
    :header-close-label="$t('general.dialogCloseLabel')"
    :cancel-disabled="isProcessing"
    :ok-disabled="isProcessing || !formIsValid"
    header-bg-variant="primary"
    header-text-variant="white"
    @show="onDialogShow"
    @hide="onDialogHide"
    @ok="upload"
    @cancel="shouldKeepOpen = false">
    <div class="position-relative">
      <app-loading-spinner
        v-if="isProcessing"
        class="position-absolute w-100 h-100 text-center" />

      <template v-else>
        <b-form-group
          :label="$t('basket.components.csvUploadDialog.delimiters')">
          <!-- Trennzeichen auswählen -->
          <b-form-radio-group
            v-model="selectedDelimiter"
            :options="delimiterOptions"
            name="delimiter" />
          <!-- Spezial Trennzeichen auswählen -->
          <b-form-input
            v-if="selectedDelimiter === CSVdelimiter.OTHER"
            v-model="customDelimiter"
            size="sm"
            class="mt-1"
            :placeholder="$t('basket.components.csvUploadDialog.placeHolderDelimiter')" />
        </b-form-group>

        <!-- Checkbox: erste Zeile enthält Spaltenüberschriften -->
        <b-form-checkbox
          v-model="hasColumnHeadings"
          name="checkboxFirstRowContainsHeadlines">
          {{ $t('basket.components.csvUploadDialog.columnHeadings') }}
        </b-form-checkbox>
        <table class="table table-bordered table-sm mt-3">
          <thead
            v-if="hasColumnHeadings">
            <tr>
              <th
                v-for="(col, colIndex) in basketCSV.headline"
                :key="colIndex">
                {{ col }}
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="(row, rowIndex) in basketCSV.body"
              :key="rowIndex">
              <td
                v-for="(column, columnIndex) in row"
                :key="columnIndex">
                {{ column }}
              </td>
            </tr>
          </tbody>
        </table>

        <!-- Information Anzahl Datensaetze -->
        <div class="text-right">
          <div>
            {{ $t('basket.components.csvUploadDialog.numberRecords') }}: {{ basketCSV.amountColumns }}
          </div>
          <div>
            {{ $t('basket.components.csvUploadDialog.numberRecordsWithErrors') }}: {{ basketCSV.amountBrokenColumns }}
          </div>
        </div>

        <!-- Verknüpfung der Tabellenspalten mit Feldern -->
        <div class="mt-2">
          <h6>
            {{ $t('basket.components.csvUploadDialog.linkArticleAmount') }}
          </h6>
          <b-form-group
            :label="$t('basket.components.csvUploadDialog.article')">
            <b-form-select
              v-model="colArticle"
              :options="basketCSV.columns" />
          </b-form-group>
          <b-form-group
            :label="$t('basket.components.csvUploadDialog.amount')">
            <b-form-select
              ref="formInput"
              v-model="colAmount"
              :options="basketCSV.columns" />
          </b-form-group>
        </div>
      </template>
    </div>

    <template slot="modal-cancel">
      <i class="fas fa-times fa-fw" />
      {{ $t('general.cancel') }}
    </template>

    <template slot="modal-ok">
      <app-icon-state
        :is-loading="isProcessing"
        icon="fas fa-upload" />
      {{ $t('basket.components.uploadDialog.buttonOk') }}
    </template>
  </b-modal>
</template>

<script>
import I18n from '@scripts/modules/i18n'
import { UpDownloadFormat, CSVdelimiter } from '@scripts/modules/basket'
import { showErrorMessage, showSuccessMessage } from '@scripts/modules/dialogs'
import  { BasketCSV } from '@scripts/helper/csvUpload'
export default {
  props: {
    visible: {
      type: Boolean,
      default: true,
    },
    lines: {
      type: Array,
      required: true,
    },
  },

  data () {
    return {
      format: UpDownloadFormat.CSV,
      file: void 0,
      isVisible: this.visible,
      isProcessing: false,
      shouldKeepOpen: false,
      UpDownloadFormat,
      CSVdelimiter,

      hasColumnHeadings: void 0,
      selectedDelimiter: void 0,
      customDelimiter: void 0,
      colArticle: null,
      colAmount: null,

      delimiterOptions: [
        {
          text: I18n.t('basket.components.csvUploadDialog.delimiterComma'),
          value: CSVdelimiter.COMMA,
        },
        {
          text: I18n.t('basket.components.csvUploadDialog.delimiterSemikolon'),
          value: CSVdelimiter.SEMICOLON,
        },
        {
          text: I18n.t('basket.components.csvUploadDialog.delimiterTab'),
          value: CSVdelimiter.TAB,
        },
        {
          text: I18n.t('basket.components.csvUploadDialog.delimiterCustom'),
          value: CSVdelimiter.OTHER,
        },
      ],
      basketCSV: new BasketCSV(),
    }
  },

  computed: {
    formIsValid () {
      return (this.colAmount !== undefined && this.colArticle !== undefined && this.colAmount !== null && this.colArticle !== null)
    },
    title () {
      return `${this.$t('basket.components.uploadDialog.headline')} ${this.$t('basket.components.uploadDialog.uploadFormatCSV')}`
    },
  },

  watch: {
    visible (newValue) {
      this.isVisible = newValue
      if (this.isVisible) {
        this.basketCSV.csvData = this.lines
        this.selectedDelimiter = CSVdelimiter.SEMICOLON
      }
      return this.isVisible
    },
    selectedDelimiter (newValue) {
      this.basketCSV.delimiter = newValue
    },
    customDelimiter (newValue) {
      if (newValue !== '') {
        this.basketCSV.delimiter = newValue
      }
    },
    hasColumnHeadings (newValue) {
      this.basketCSV.hasColumnHeadings = newValue
    },
    colArticle (newValue) {
      this.basketCSV.articleIndex = newValue
    },
    colAmount (newValue) {
      this.basketCSV.amountIndex = newValue
    },
  },

  methods: {
    async upload () {
      this.shouldKeepOpen = true
      this.isProcessing = true

      try {
        await this.basketCSV.upload()
        showSuccessMessage(this.$t('basket.uploadSuccessfulMessage'))
        this.$emit('upload')
        this.resetFile()
        this.shouldKeepOpen = false
        this.isVisible = false
      } catch (error) {
        showErrorMessage(error.message)
      }
      this.isProcessing = false
    },
    onFormatChange () {
      // File zurücksetzen, wenn es nicht zum ausgewählten Format passt
      if (this.file && this.format) {
        const fileExtensionOffset = this.file.name.length - this.format.length
        const fileExtensionLowerCase = this.file.name.substring(fileExtensionOffset).toLowerCase()
        const formatLowerCase = this.format.toLowerCase()
        const doesFormatAndFileExtensionMatch = fileExtensionLowerCase.indexOf(formatLowerCase) !== -1

        if (!doesFormatAndFileExtensionMatch) {
          this.resetFile()
        }
      }
    },
    onDialogShow () {
      this.isProcessing = false
      this.shouldKeepOpen = false
      this.$emit('update:visible', true)
    },
    onDialogHide (event) {
      if (this.shouldKeepOpen) {
        event.preventDefault()
        return
      }

      // See https://vuejs.org/v2/guide/components.html#sync-Modifier
      this.$emit('update:visible', false)
    },
    resetFile () {
      this.colArticle = undefined
      this.colAmount = undefined
      this.selectedDelimiter = CSVdelimiter.SEMICOLON
      this.customDelimiter = ''
    },
  },
}
</script>
