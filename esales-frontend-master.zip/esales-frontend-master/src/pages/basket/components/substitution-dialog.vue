<template>
  <b-modal
    ref="modal"
    v-model="isVisible"
    :header-close-label="$t('general.dialogCloseLabel')"
    :title="$t('basket.components.positionItem.substitution')"
    header-bg-variant="primary"
    header-text-variant="white"
    @hide="handleImplicitVisibilityChange"
    @ok.prevent="doSubstitution">
    <div class="custom-controls-stacked">
      <div
        v-if="!isDirectSubstitutionPossible"
        class="custom-control custom-radio">
        <input
          id="substitution1"
          v-model="substitutionType"
          :value="1"
          type="radio"
          name="substitution-type"
          class="custom-control-input">
        <label
          class="custom-control-label"
          for="substitution1">
          {{ $t('basket.components.substitutionDialog.option1') }}
        </label>
      </div>

      <!-- Direkte Substitution -->
      <div class="custom-control custom-radio">
        <input
          id="substitution2"
          v-model="substitutionType"
          :value="2"
          type="radio"
          name="substitution-type"
          class="custom-control-input">
        <label
          class="custom-control-label"
          for="substitution2">
          {{ $t('basket.components.substitutionDialog.option2') }}
        </label>
      </div>

      <div
        v-if="!isDirectSubstitutionPossible"
        class="custom-control custom-radio">
        <input
          id="substitution3"
          v-model="substitutionType"
          :value="3"
          type="radio"
          name="substitution-type"
          class="custom-control-input">
        <label
          class="custom-control-label"
          for="substitution3">
          {{ $t('basket.components.substitutionDialog.option3') }}
        </label>
      </div>
    </div>

    <template slot="modal-cancel">
      <i class="fas fa-times fa-fw" />
      {{ $t('general.cancel') }}
    </template>

    <template slot="modal-ok">
      <i class="fas fa-exchange-alt fa-fw" />
      {{ $t('basket.components.substitutionDialog.buttonOk') }}
    </template>
  </b-modal>
</template>

<script>
import { AvailabilityFlag } from '@scripts/modules/additional-article-data'

export default {
  props: {
    visible: {
      type: Boolean,
      default: true,
    },
    position: {
      type: Object,
      required: true,
    },
    availability: {
      type: Object,
      default: void 0,
    },
  },

  data () {
    return {
      isVisible: this.visible,
      substitutionType: void 0,
    }
  },

  computed: {
    isDirectSubstitutionPossible () {
      return !this.availability || this.availability.availabilityFlag === AvailabilityFlag.NOT_AVAILABLE || !this.availability.directly
    },
  },

  watch: {
    visible (newValue) {
      return this.isVisible = newValue
    },
  },

  created () {
    this.substitutionType = this.isDirectSubstitutionPossible ? 2 : 1
  },

  methods: {
    doSubstitution () {
      this.$emit('dosubstitution', this.substitutionType)
    },
    handleImplicitVisibilityChange (event) {
      if (event.trigger !== 'ok') {
        this.$emit('abortsubstitution', this.substitutionType)
      }
    },
  },
}
</script>
