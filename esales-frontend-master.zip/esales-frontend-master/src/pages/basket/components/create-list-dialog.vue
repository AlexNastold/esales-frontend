<template>
  <b-modal
    ref="modal"
    v-model="isVisible"
    :title="$t('basket.components.createListDialog.headline')"
    :header-close-label="$t('general.dialogCloseLabel')"
    :cancel-disabled="isProcessing"
    :ok-disabled="isProcessing || !formIsValid"
    header-bg-variant="primary"
    header-text-variant="white"
    @show="onDialogShow"
    @shown="setFocus"
    @hide="onDialogHide"
    @ok.prevent="createList">
    <div class="position-relative">
      <app-loading-spinner
        v-if="isProcessing"
        class="position-absolute w-100 h-100 text-center" />
      <p>
        {{ $t('basket.components.createListDialog.description') }}
      </p>
      <form @submit.stop.prevent="onSubmit">
        <input
          ref="nameInput"
          v-model="name"
          :disabled="isProcessing"
          :placeholder="$t('basket.components.createListDialog.inputPlaceholder')"
          class="form-control"
          type="text"
          maxlength="50">
        <div
          v-if="errorMessage"
          class="invalid-feedback d-block"
          v-html="errorMessage" />
      </form>
    </div>

    <template slot="modal-cancel">
      <i class="fas fa-times fa-fw" />
      {{ $t('general.cancel') }}
    </template>

    <template slot="modal-ok">
      <app-icon-state
        :is-loading="isProcessing"
        icon="fas fa-file-alt" />
      {{ $t('basket.components.createListDialog.buttonOk') }}
    </template>
  </b-modal>
</template>

<script>
import { showSuccessMessage } from '@scripts/modules/dialogs'
import { createListFromBasket } from '@scripts/modules/lists'

export default {
  props: {
    visible: {
      type: Boolean,
      default: true,
    },
  },

  data () {
    return {
      isVisible: this.visible,
      shouldKeepOpen: false,
      name: void 0,
      errorMessage: void 0,
      isProcessing: false,
    }
  },

  computed: {
    formIsValid () {
      return !!this.name
    },
  },

  watch: {
    visible (newValue) {
      return this.isVisible = newValue
    },
  },

  methods: {
    async createList () {
      this.shouldKeepOpen = true
      this.isProcessing = true
      try {
        const list = await createListFromBasket(this.name)
        showSuccessMessage(this.$t('basket.components.createListDialog.successMessage', { listName: list.name }))
        this.name = void 0
        this.shouldKeepOpen = false
        this.isProcessing = false
        this.isVisible = false
      } catch (error) {
        this.errorMessage = error.message
        this.shouldKeepOpen = false
        this.isProcessing = false
      }
    },
    setFocus () {
      this.$refs.nameInput.focus()
    },
    onSubmit (event) {
      if (!this.formIsValid) {
        event.preventDefault()
        return
      }
      this.createList()
    },
    onDialogShow () {
      this.isProcessing = false
      this.errorMessage = void 0
    },
    onDialogHide (event) {
      if (this.shouldKeepOpen) {
        event.preventDefault()
        return
      }

      // See https://vuejs.org/v2/guide/components.html#sync-Modifier
      this.$emit('update:visible', false)
    },
  },
}
</script>
