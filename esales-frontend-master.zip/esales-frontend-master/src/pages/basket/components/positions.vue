<template>
  <div>
    <div class="list-group">
      <!-- Positionen werden geladen -->
      <div
        v-if="isLoading"
        class="list-group-item">
        <app-loading-spinner class="my-5 text-center" />
      </div>

      <!-- Auflistung Positionen -->
      <template v-if="!isLoading">
        <template v-for="position in positions">
          <div
            v-if="!position.position.partList.isPartListArticle || position.position.partList.isHead || app.settings.showPartsListItems"
            v-show="!position.hidden"
            :key="position.position.posnr"
            class="list-group-item">
            <position-item
              :position="position"
              :is-update-in-process="isUpdateInProcess"
              @deleteposition="deletePosition"
              @togglepartlistvisibility="togglePartListVisibility"
              @quantitychanged="changedQuantity"
              @update="update"
              @changedpositions="changedPositions" />
          </div>
        </template>
      </template>
    </div>
  </div>
</template>

<script>
import PositionItem from './position-item.vue'

export default {
  components: {
    'position-item': PositionItem,
  },

  props: {
    positions: {
      type: Array,
      default () {
        return []
      },
    },
    isLoading: {
      type: Boolean,
      default: true,
    },
    isUpdateInProcess: {
      type: Boolean,
      default: false,
    },
  },

  methods: {
    deletePosition (position) {
      this.$emit('deleteposition', position)
    },
    togglePartListVisibility (headPosition) {
      this.positions.forEach((position, index) => {
        if (position.position.partList.headPosnr === headPosition.position.posnr) {
          position.hidden = !position.hidden
          this.$set(this.positions, index, position)
        }
      })
    },
    changedPositions () {
      this.$emit('changedpositions')
    },
    changedQuantity (position) {
      this.$emit('changedquantity', position)
    },
    update (position) {
      this.$emit('update', position)
    },
  },
}
</script>
