<template>
  <span>
    <!-- Button Aktualisieren -->
    <button
      v-if="isUpdateRequired"
      type="button"
      class="btn btn-block btn-warning"
      :disabled="isUpdateInProcess"
      @click="update">
      <app-icon-state
        :is-loading="isUpdateInProcess"
        icon="fas fa-sync" />
      {{ $t('basket.components.proceedToCheckoutButton.buttonUpdate') }}
    </button>

    <button
      v-else-if="!isUpdateRequired && app.state.orderVariant !== OrderVariant.SAP && app.state.orderVariant !== OrderVariant.OCI"
      :class="{ 'disabled': !mayProceedToCheckout }"
      :aria-disabled="!mayProceedToCheckout"
      class="btn btn-block btn-primary"
      @click="goToCheckout">
      <i class="fas fa-shopping-cart" />
      {{ $t('basket.components.proceedToCheckoutButton.buttonProceedToCheckout') }}
    </button>

    <proceed-to-checkout-dialog
      ref="dialogGuestOrder" />
  </span>
</template>

<script>

import { OrderVariant } from '@scripts/modules/basket'
import ProceedToCheckoutDialog from './proceed-to-checkout-dialog'
import { redirect } from '@scripts/helper/redirect'

export default {
  components: {
    'proceed-to-checkout-dialog': ProceedToCheckoutDialog,
  },
  props: {
    isUpdateRequired: {
      type: Boolean,
      required: true,
    },
    mayProceedToCheckout: {
      type: Boolean,
      required: true,
    },
    isUpdateInProcess: {
      type: Boolean,
      default: false,
    },
  },

  data () {
    return {
      OrderVariant,
    }
  },

  methods: {
    update () {
      this.$emit('update')
    },

    goToCheckout () {
      if (!this.app.user.isLoggedIn) {
        if (this.app.state.orderVariant === OrderVariant.NONE) {
          redirect('login', { redirecturl: 'checkout' })
        } else {
          this.$refs.dialogGuestOrder.show()
        }
      } else {
        redirect('checkout')
      }
    },
  },
}
</script>
