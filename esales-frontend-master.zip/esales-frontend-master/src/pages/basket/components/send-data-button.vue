<template>
  <!-- per IDS übertragen -->
  <button
    v-if="app.state.orderVariant === OrderVariant.IDS"
    :disabled="buttonDisabled"
    type="button"
    class="btn btn-secondary"
    @click="sendDataViaIDS">
    <app-icon-state
      :is-loading="isSending"
      icon="fas fa-download" />
    {{ $t('basket.components.sendDataButton.sendDataIDS') }}
  </button>

  <!-- per OCI übertragen -->
  <button
    v-else-if="app.state.orderVariant === OrderVariant.OCI"
    :disabled="buttonDisabled"
    type="button"
    class="btn btn-secondary"
    @click="sendDataViaOCI">
    <app-icon-state
      :is-loading="isSending"
      icon="fas fa-download" />
    {{ $t('basket.components.sendDataButton.sendDataOCI') }}
  </button>

  <!-- in SAP übertragen -->
  <button
    v-else-if="app.state.orderVariant === OrderVariant.SAP"
    :disabled="buttonDisabled"
    type="button"
    class="btn btn-secondary"
    @click="sendDataToSAP">
    <app-icon-state
      :is-loading="isSending"
      icon="fas fa-download" />
    {{ $t('basket.components.sendDataButton.sendDataSAP') }}
  </button>
</template>

<script>
import { OrderVariant } from '@scripts/modules/basket'
import { showErrorMessage } from '@scripts/modules/dialogs'
import { idsBack, sendDataOci, sendDataSap } from '@src/pages/checkout/scripts/order'

export default {
  props: {
    disabled: {
      type: Boolean,
      required: true,
    },
  },

  data () {
    return {
      OrderVariant,

      isSending: false,
    }
  },

  computed: {
    buttonDisabled () {
      return this.disabled || this.isSending
    },
  },

  methods: {
    async sendDataViaIDS () {
      this.isSending = true
      try {
        await idsBack()
      } catch (e) {
        showErrorMessage(e.message || this.$t('general.unspecifiedErrorMessage'))
        this.isSending = false
      }
    },
    async sendDataViaOCI () {
      this.isSending = true
      try {
        await sendDataOci()
      } catch (e) {
        showErrorMessage(e.message || this.$t('general.unspecifiedErrorMessage'))
        this.isSending = false
      }
    },
    async sendDataToSAP () {
      this.isSending = true
      try {
        await sendDataSap()
      } catch (e) {
        showErrorMessage(e.message || this.$t('general.unspecifiedErrorMessage'))
        this.isSending = false
      }
    },
  },
}
</script>
