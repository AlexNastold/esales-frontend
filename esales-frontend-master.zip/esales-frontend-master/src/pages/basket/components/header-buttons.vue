<template>
  <div class="d-flex flex-wrap">
    <!-- Button Aktualisieren / Zur Kasse -->
    <proceed-to-checkout-button
      :is-update-required="isUpdateRequired"
      :is-update-in-process="isUpdateInProcess"
      :may-proceed-to-checkout="mayProceedToCheckout"
      @update="update" />

    <!-- Button per IDS/OCI/SAP übernehmen -->
    <send-data-button
      :disabled="!mayProceedToCheckout"
      class="w-100 btn-block mt-1" />
  </div>
</template>

<script>
import ProceedToCheckoutButton from './proceed-to-checkout-button.vue'
import SendDataButton from './send-data-button.vue'

export default {
  components: {
    'proceed-to-checkout-button': ProceedToCheckoutButton,
    'send-data-button': SendDataButton,
  },

  props: {
    numberOfPositions: {
      type: Number,
      default: 0,
    },
    numberOfFaultyPositions: {
      type: Number,
      default: 0,
    },
    isUpdateRequired: {
      type: Boolean,
      required: true,
    },
    mayProceedToCheckout: {
      type: Boolean,
      required: true,
    },
    isUpdateInProcess: {
      type: Boolean,
      required: true,
    },
  },

  methods: {
    update () {
      this.$emit('update')
    },
  },
}
</script>

