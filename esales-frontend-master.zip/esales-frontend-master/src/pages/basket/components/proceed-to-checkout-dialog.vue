<template>
  <b-modal
    ref="modal"
    :title="$t('basket.components.proceedToCheckoutDialog.title')"
    header-bg-variant="primary"
    header-text-variant="white"
    size="md">
    <!-- Sie sind bereits Kunde? -->
    <div class="mb-4">
      <div class="font-weight-bold font-size-lg">
        {{ $t('basket.components.proceedToCheckoutDialog.alreadyCustomer') }}
      </div>
      <div class="mb-2">
        {{ $t('basket.components.proceedToCheckoutDialog.loginToFinishOrder') }}
      </div>
      <a
        class="btn btn-block btn-primary"
        href="login?redirecturl=checkout">
        <i class="fas fa-user fa-fw" />&nbsp;
        {{ $t('basket.components.proceedToCheckoutDialog.login') }}
      </a>
    </div>

    <!-- Als Gast bestellen -->
    <div>
      <div class="font-weight-bold">
        {{ $t('basket.components.proceedToCheckoutDialog.orderAsGuest') }}
      </div>
      <div class="mb-2">
        {{ $t('basket.components.proceedToCheckoutDialog.notACustomer') }}
      </div>
      <a
        class="btn btn-block btn-secondary"
        href="ordering-process-guestdata">
        <i class="fas fa-shopping-cart" />&nbsp;
        {{ $t('basket.components.proceedToCheckoutDialog.proceedAsGuest') }}
      </a>
    </div>

    <template #modal-footer="{ cancel }">
      <button
        class="btn btn-secondary"
        @click="cancel()">
        <i class="fas fa-times fa-fw" />
        {{ $t('general.cancel') }}
      </button>
    </template>
  </b-modal>
</template>

<script>
export default {
  methods: {
    show () {
      this.$refs.modal.show()
    },
  },
}
</script>
