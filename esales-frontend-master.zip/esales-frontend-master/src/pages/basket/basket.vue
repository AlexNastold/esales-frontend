<template>
  <div>
    <!-- Header -->
    <app-layout-header class="d-print-none" />

    <!-- Navigation -->
    <app-layout-navigation class="d-print-none" />

    <main class="page-basket">
      <div class="container">
        <app-loading-box v-if="isLoading" />
        <template v-else>
          <!-- Process Bar -->
          <process-bar
            :disable-next-steps="!mayProceedToCheckout || app.user.isGuest"
            step="basket"
            class="d-print-none" />

          <div class="row">
            <!-- Überschrift -->
            <div class="col-lg">
              <h1 class="headline mb-1">
                {{ $t('basket.headline') }}
              </h1>
            </div>

            <!-- Button PDF herunterladen Desktop -->
            <div class="col-lg-auto d-none d-lg-block d-print-none">
              <a
                v-if="canDownloadAsPdf"
                :href="downloadUriPdf"
                target="_blank"
                class="btn btn-secondary">
                <i class="fas fa-file-pdf fa-fw" />
                {{ $t('basket.PDFDownloadButton') }}
              </a>
              <button
                v-else
                disabled
                type="button"
                class="btn btn-secondary">
                <i class="fas fa-file-pdf fa-fw" />
                {{ $t('basket.PDFDownloadButton') }}
              </button>
            </div>
          </div>

          <!-- Warenkorb, Warenkörbe verwalten -->
          <div class="d-md-flex align-items-end mb-3 mb-lg-4">
            <div class="text-muted text-uppercase small">
              <h2 class="m-0 basket-name">
                {{ activeBasketName }}
              </h2>
            </div>
            <div
              v-if="app.user.hasPermission('BASKETS_MANAGE')"
              class="mt-2 mt-md-0 ml-md-2 d-print-none">
              <a
                href="my-account-baskets"
                class="icon-link">
                <i class="fas fa-shopping-cart fa-fw" />
                <span class="text">
                  {{ $t('basket.manageBaskets') }}
                </span>
              </a>
            </div>
          </div>

          <!-- Button PDF herunterladen Mobile -->
          <div class="mb-1 d-lg-none">
            <a
              v-if="canDownloadAsPdf"
              :href="downloadUriPdf"
              target="_blank"
              class="btn btn-block btn-secondary">
              <i class="fas fa-file-pdf fa-fw" />
              {{ $t('basket.PDFDownloadButton') }}
            </a>
            <button
              v-else
              disabled
              type="button"
              class="btn btn-block btn-secondary">
              <i class="fas fa-file-pdf fa-fw" />
              {{ $t('basket.PDFDownloadButton') }}
            </button>
          </div>

          <!-- Buttons Lieferdaten / Zur Kasse Mobile -->
          <header-buttons
            :number-of-positions="numberOfPositions"
            :number-of-faulty-positions="numberOfFaultyPositions"
            :is-update-required="isUpdateRequired"
            :is-update-in-process="isUpdateInProcess"
            :may-proceed-to-checkout="mayProceedToCheckout"
            class="mb-3 d-lg-none d-print-none"
            @update="updatePositions" />


          <!-- Lieferdaten -->
          <delivery-data
            v-if="app.user.hasPermission('DELIVERY_DATA')"
            :basket-overview="basketOverview"
            :is-loading="isOverviewLoading"
            class="mb-3"
            @change="onDeliveryDataChange" />

          <!-- Anzahl Positionen, Anzahl Fehlerhafte Positionen -->
          <div class="d-flex border-bottom px-1 mb-3">
            <div>
              <h4>
                {{ $t('basket.numberOfPositions', { count: numberOfPositions }) }}
              </h4>
            </div>
            <div class="ml-auto">
              <h4
                v-if="numberOfFaultyPositions"
                class="text-danger">
                {{ $t('basket.numberOfFaultyPositions', { count: numberOfFaultyPositions }) }}
              </h4>
            </div>
          </div>

          <!-- Aktionen Buttons -->
          <action-buttons
            :positions="positions"
            :number-of-positions="numberOfPositions"
            :number-of-faulty-positions="numberOfFaultyPositions"
            :is-update-in-process="isUpdateInProcess"
            class="mb-3 d-print-none"
            @applyfilter="applyFilter"
            @upload="onUpload"
            @deletefaultypositions="deleteFaultyPositions"
            @deleteallpositions="deleteAllPositions" />

          <!-- Suchleiste -->
          <filter-input
            v-show="numberOfPositions"
            :value="filter"
            :is-update-required="isUpdateRequired"
            :is-update-in-process="isUpdateInProcess"
            :may-proceed-to-checkout="mayProceedToCheckout"
            class="mb-3 d-print-none"
            @applyfilter="applyFilter"
            @update="updatePositions" />

          <!-- Dropdown Treffer pro Seite -->
          <div class="d-flex flex-column flex-sm-row align-items-sm-center mb-3 bg-none">
            <div class="mr-2">
              {{ $t('basket.hitsPerPage') }}
            </div>
            <div class="options">
              <select
                v-model="paging.itemsPerPage"
                class="form-control custom-select"
                @change="getPositions(0)">
                <option value="5">
                  5
                </option>
                <option value="10">
                  10
                </option>
                <option value="20">
                  20
                </option>
              </select>
            </div>
          </div>

          <!-- Keine Positionen im Warenkorb -->
          <div
            v-if="!positions.length"
            class="mb-3">
            <!-- Keine Artikel zum Filter -->
            <div
              v-if="filter.length"
              class="border rounded p-3">
              <app-box-empty-list
                :headline="$t('basket.listEmptyFilterApplied')"
                icon="fas fa-search">
                <span v-html="$t('basket.listEmptyFilterAppliedDescription', { appliedFilter: filter })" />
                <div class="mt-2">
                  <button
                    type="button"
                    class="btn btn-outline-primary text-uppercase"
                    @click.prevent="resetFilter">
                    {{ $t('basket.resetFilter') }}
                  </button>
                </div>
              </app-box-empty-list>
            </div>

            <!-- Keine Artikel im Warenkorb -->
            <div
              v-else
              class="border rounded p-3">
              <app-box-empty-list
                :headline="$t('basket.listEmpty')"
                icon="fas fa-shopping-cart">
                <span v-html="$t('basket.listEmptyDescription')" />
                <div
                  v-if="app.user.hasPermission('SEARCH')"
                  class="mt-2">
                  <a
                    href="search"
                    class="btn btn-outline-primary text-uppercase">
                    {{ $t('basket.searchArticles') }}
                  </a>
                </div>
              </app-box-empty-list>
            </div>
          </div>

          <!-- Auflistung Positionen -->
          <positions
            v-if="positions.length"
            :positions="positions"
            :is-loading="isPositionsLoading"
            :is-update-in-process="isUpdateInProcess"
            class="mb-3"
            @deleteposition="deletePosition"
            @changedquantity="onQuantityChanged"
            @changedpositions="reloadPositions"
            @update="updatePositions" />

          <!-- Seitenauswahl -->
          <app-pagination
            v-if="paging.numberOfPages > 1"
            :disabled="isLoading"
            :pages="paging.numberOfPages"
            :current-page="paging.currentPage"
            class="mb-3 d-flex justify-content-center d-print-none"
            @change="onPageChange" />

          <!-- Artikel direkt hinzufügen -->
          <add-articles-directly
            :is-disabled="isUpdateRequired"
            :matnr-or-bismt="matnr"
            class="mb-3 d-print-none"
            @changedpositions="reloadPositions" />

          <!-- Summenbildung Warenkorb -->
          <app-article-list-sum
            v-show="numberOfPositions"
            :sum="sum"
            class="mb-3" />

          <!-- Buttons Seitenende -->
          <page-end-buttons
            :number-of-positions="numberOfPositions"
            :is-update-required="isUpdateRequired"
            :is-update-in-process="isUpdateInProcess"
            :may-proceed-to-checkout="mayProceedToCheckout"
            :may-request-quote="mayRequestQuote"
            class="mb-3 d-print-none"
            @update="updatePositions" />
        </template>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer class="d-print-none" />
  </div>
</template>

<script>

import { getQueryParameter } from '@scripts/helper/urlParams'
import { updateUrlQueryString } from '@scripts/helper/urlUpdate'
import {
  deleteAllPositionsFromBasket,
  deleteFaultyPositionsFromBasket,
  deletePositionsFromBasket,
  getBasketOverview,
  getBasketPositions,
  getDownloadUri,
  updateBasketPositions,
} from '@scripts/modules/basket'
import {
  confirmDialog,
  showErrorMessage,
  showSuccessMessage,
  showTechnicalErrorMessage,
} from '@scripts/modules/dialogs'
import ProcessBar from '@components/pages/ordering-process/process-bar.vue'

import ActionButtons from './components/action-buttons.vue'
import AddArticlesDirectly from './components/add-articles-directly.vue'
import browserStore from '@scripts/core/browserStore'
import DeliveryData from './components/delivery-data.vue'
import Filter from './components/filter.vue'
import HeaderButtons from './components/header-buttons.vue'
import PageEndButtons from './components/page-end-buttons.vue'
import Positions from './components/positions.vue'

export default {
  components: {
    'action-buttons': ActionButtons,
    'add-articles-directly': AddArticlesDirectly,
    'delivery-data': DeliveryData,
    'filter-input': Filter,
    'header-buttons': HeaderButtons,
    'page-end-buttons': PageEndButtons,
    positions: Positions,
    'process-bar': ProcessBar,
  },

  data () {
    return {
      activeBasketName: void 0,
      basketOverview: void 0,
      filter: getQueryParameter('filter') ? getQueryParameter('filter') : '',
      isLoading: true,
      isOverviewLoading: true,
      isPositionsLoading: true,
      isUpdateRequired: false,
      isUpdateInProcess: false,
      numberOfBaskets: 0,
      numberOfFaultyPositions: 0,
      numberOfPositions: 0,
      matnr: getQueryParameter('matnr'),
      paging: {
        currentPage: 0,
        itemsPerPage: getQueryParameter('itemsPerPage') ? getQueryParameter('itemsPerPage') : 5,
        numberOfPages: 0,
      },
      positions: [],
      sum: void 0,

    }
  },

  computed: {
    // Computed value that observes multiple data properties
    // for easier watching
    // See https://github.com/vuejs/vue/issues/844#issuecomment-265315349
    urlQueryString () {
      return this.paging.currentPage, this.paging.itemsPerPage, this.filter, Date.now()
    },
    isBasketEmpty () {
      return this.numberOfPositions === 0
    },
    mayProceedToCheckout () {
      const check = !this.isUpdateRequired
        && !this.isBasketEmpty
        && this.numberOfFaultyPositions === 0

      if (this.app.user.isLoggedIn) {
        return check && this.app.user.hasPermission('BASKET_ORDER')
      }
      return check
    },
    mayRequestQuote () {
      return this.app.user.hasPermission('BASKET_INQUIRY')
        && !this.isBasketEmpty
        && this.numberOfFaultyPositions === 0
    },
    canDownloadAsPdf () {
      return browserStore.get('InAppBrowser') === true ? false : this.numberOfPositions > 0 && this.numberOfFaultyPositions === 0
    },
    downloadUriPdf () {
      return getDownloadUri('BASKETPDF')
    },
  },

  watch: {
    urlQueryString () {
      updateUrlQueryString({
        filter: this.filter,
        page: this.paging.currentPage >= 0 ? this.paging.currentPage : void 0,
        itemsPerPage: this.paging.itemsPerPage,
      })
    },
  },

  async created () {
    this.setPageTitle(this.$t('basket.title'))

    await Promise.all([
      this.getBasketOverview(),
      this.getPositions(getQueryParameter('page') ? parseInt(getQueryParameter('page'), 10) : 0),
    ])
    if (this.matnr) {
      updateUrlQueryString({
        filter: this.filter,
        page: this.paging.currentPage >= 0 ? this.paging.currentPage : void 0,
        itemsPerPage: this.paging.itemsPerPage,
      })
    }
    this.isLoading = false
  },

  mounted () {
    window.addEventListener('beforeunload', (event) => {
      if (this.isUpdateRequired) {
        const message = this.$t('basket.dataLossPossibleMessage')
        event.returnValue = message
        return message
      }
      return void 0
    })
  },

  methods: {
    async getBasketOverview () {
      this.isOverviewLoading = true

      try {
        const basketOverview = await getBasketOverview()
        this.basketOverview = basketOverview
        this.numberOfBaskets = basketOverview.numberOfBaskets
        this.activeBasketName = basketOverview.activeBasketName
        this.isOverviewLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
    async getPositions (page = 0) {
      this.isPositionsLoading = true

      try {
        const from = (page * parseInt(this.paging.itemsPerPage)) + 1
        const to = from + parseInt(this.paging.itemsPerPage) - 1
        const data = await getBasketPositions(from, to, this.filter)

        // Falls keine Ergebnisse und Seite > 1, dann vorherige Seite laden
        if (page > 0 && data.positionsAmount.all.uepos < from) {
          this.getPositions(page - 1)
          return
        }

        this.positions = data.positions.map((position) => ({
          ...position,
          hidden: !!(!position.position.partList.isHead && position.position.partList.headPosnr),
        }))
        this.numberOfPositions = data.positionsAmount.all.all
        this.numberOfFaultyPositions = data.positionsAmount.all.faulty
        this.sum = data.sum

        this.paging.numberOfPages = Math.ceil(data.positionsAmount.filtered.uepos / this.paging.itemsPerPage)
        this.paging.currentPage = Math.floor(data.filter.from / this.paging.itemsPerPage)

        this.isUpdateRequired = false
      } catch (error) {
        console.error(error)
        showTechnicalErrorMessage()
      }

      this.isPositionsLoading = false
    },
    async updatePositions () {
      try {
        this.isUpdateInProcess = true
        const reloadRequired = await updateBasketPositions(this.positions)
        this.isUpdateRequired = false
        if (reloadRequired) {
          this.reloadPositions()
        }
        this.isUpdateInProcess = false
      } catch (error) {
        showErrorMessage(error.message)
        this.isUpdateInProcess = false
      }
    },
    async deletePosition (position) {
      if (await confirmDialog(
        this.$t('basket.confirmDeletePositionHeadline'),
        this.$t('basket.confirmDeletePositionText', { articleName: position.article.maktx, partNumber: position.article.matnrDisplay }),
        {
          buttonCancelText: `<i class="fas fa-times fa-fw"></i> ${this.$t('general.cancel')}`,
          buttonConfirmText: `<i class="fas fa-trash-alt fa-fw"></i> ${this.$t('basket.confirmDeletePositionButtonOk')}`,
          type: 'danger',
        },
      )) {
        try {

          // Im Basket-Cookie steht die Posnr in der externen Darstellung (ohne führende Nullen)
          await deletePositionsFromBasket([{
            matnr: position.article.matnr,
            matnr_d: position.article.matnrDisplay,
            posnr: position.position.posnrDisplay,
            revenue: position.position.netPrice ? position.position.netPrice.price : position.position.retailPrice.price,
            flag: position.position.flag,
          }])
          showSuccessMessage(this.$t('basket.positionDeletedMessage', { count: 1 }))
          this.reloadPositions()
          this.getBasketOverview()
        } catch (error) {
          showErrorMessage(error.message)
        }
      }
    },
    async deleteFaultyPositions () {
      if (await confirmDialog(
        this.$t('basket.confirmDeleteFaultyPositionsHeadline'),
        this.$t('basket.confirmDeleteFaultyPositionsText'),
        {
          buttonCancelText: `<i class="fas fa-times fa-fw"></i> ${this.$t('general.cancel')}`,
          buttonConfirmText: `<i class="fas fa-trash-alt fa-fw"></i> ${this.$t('general.delete')}`,
          type: 'danger',
        },
      )) {
        try {
          await deleteFaultyPositionsFromBasket()
          showSuccessMessage(this.$t('basket.faultyPositionsDeletedMessage'))
          this.reloadPositions()
          this.getBasketOverview()
        } catch (error) {
          showErrorMessage(error.message)
        }
      }
    },
    async deleteAllPositions () {
      if (await confirmDialog(
        this.$t('basket.confirmDeleteAllPositionsHeadline'),
        this.$t('basket.confirmDeleteAllPositionsText'),
        {
          buttonCancelText: `<i class="fas fa-times fa-fw"></i> ${this.$t('general.cancel')}`,
          buttonConfirmText: `<i class="fas fa-trash-alt fa-fw"></i> ${this.$t('general.delete')}`,
          type: 'danger',
        },
      )) {
        try {
          await deleteAllPositionsFromBasket()
          showSuccessMessage(this.$t('basket.allPositionsDeletedMessage'))
          this.getPositions()
          this.getBasketOverview()
        } catch (error) {
          showErrorMessage(error.message)
        }
      }
    },
    reloadPositions (showLastPage) {
      this.getPositions(showLastPage ? this.paging.numberOfPages : this.paging.currentPage)
    },
    async applyFilter (filterValue) {
      this.filter = filterValue
      this.getPositions()
    },
    resetFilter () {
      this.applyFilter('')
    },
    onPageChange (page) {
      this.getPositions(page)
    },
    onUpload () {
      this.reloadPositions()
    },
    onQuantityChanged () {
      this.isUpdateRequired = true
    },
    onDeliveryDataChange () {
      this.getBasketOverview()
      this.reloadPositions()
    },
  },
}
</script>

<style lang="scss" src="./basket.scss">

select {
  &:hover {
    background-color: green;
  }
}
</style>
