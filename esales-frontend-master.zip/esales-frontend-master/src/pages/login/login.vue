<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-login">
      <div class="container">
        <h1 class="headline">
          {{ $t('login.headline') }}
        </h1>
        <div class="row">
          <div
            :class="{
              'col-12 col-lg-8 col-xl-6 offset-lg-2 offset-xl-3': !shouldDisplayNotACustomerBox && !infoMessage,
              'col-12 col-lg-6 mb-4 mb-lg-none': shouldDisplayNotACustomerBox || infoMessage,
            }">
            <div class="card already-customer">
              <div class="card-header">
                {{ $t('login.alreadyCostumer') }}
              </div>
              <div class="card-body">
                <div
                  v-show="isInitialPasswordMode"
                  class="alert alert-info"
                  role="alert">
                  <i class="fas fa-unlock fa-fw" />
                  {{ $t('login.isInitialPassword') }}
                </div>
                <form
                  ref="loginForm"
                  novalidate
                  @submit.prevent="onSubmit">
                  <div
                    v-show="errorMessage"
                    class="alert alert-danger"
                    role="alert"
                    v-html="errorMessage" />
                  <div class="form-group">
                    <label for="username">
                      {{ $t('login.username') }}
                    </label>
                    <input
                      v-model="username"
                      :placeholder="$t('login.usernameOrAlias')"
                      type="text"
                      class="form-control"
                      name="username"
                      required>
                  </div>
                  <div class="form-group">
                    <label for="password">
                      {{ $t('login.password') }}
                    </label>
                    <input
                      v-model="password"
                      :class="{'is-invalid': formErrors['password']}"
                      type="password"
                      class="form-control"
                      name="password"
                      required>
                    <div
                      v-if="formErrors['password']"
                      class="invalid-feedback"
                      v-html="formErrors['password']" />
                  </div>
                  <div
                    v-if="isInitialPasswordMode"
                    class="form-group">
                    <label for="password">
                      {{ $t('login.newPassword') }}
                    </label>
                    <input
                      v-model="passwordNew"
                      :class="{'is-invalid': formErrors['password_new1']}"
                      type="password"
                      class="form-control"
                      name="password-new"
                      required>
                    <div
                      v-if="formErrors['password_new1']"
                      class="invalid-feedback"
                      v-html="formErrors['password_new1']" />
                  </div>
                  <div
                    v-if="isInitialPasswordMode"
                    class="form-group">
                    <label for="password">
                      {{ $t('login.repeatNewPassword') }}
                    </label>
                    <input
                      v-model="passwordNewConfirm"
                      :class="{'is-invalid': formErrors['password_new2']}"
                      type="password"
                      class="form-control"
                      name="password-new-confirm"
                      required>
                    <div
                      v-if="formErrors['password_new2']"
                      class="invalid-feedback"
                      v-html="formErrors['password_new2']" />
                  </div>
                  <!-- Mobile Buttons -->
                  <div class="d-block d-lg-none">
                    <button
                      :disabled="isLoginInProcess"
                      type="submit"
                      class="btn btn-block btn-primary">
                      <app-icon-state
                        :is-loading="isLoginInProcess"
                        icon="fas fa-sign-in-alt" />
                      {{ $t('login.loginNow') }}
                    </button>
                    <button
                      v-if="isInitialPasswordMode"
                      :disabled="isLoginInProcess"
                      type="button"
                      class="btn btn-block mt-2"
                      @click="cancelInitialPasswordMode">
                      <i class="fas fa-times fa-fw" />
                      {{ $t('general.cancel') }}
                    </button>
                    <div
                      v-if="!isInitialPasswordMode"
                      class="forgot-password mt-3">
                      <a href="forgot-password">
                        {{ $t('login.forgotPassword') }}?
                      </a>
                    </div>
                  </div>

                  <!-- Desktop Buttons -->
                  <div class="d-none d-lg-flex align-items-center">
                    <div
                      v-if="!isInitialPasswordMode"
                      class="forgot-password">
                      <a href="forgot-password">
                        {{ $t('login.forgotPassword') }}?
                      </a>
                    </div>
                    <div class="ml-auto">
                      <button
                        v-if="isInitialPasswordMode"
                        :disabled="isLoginInProcess"
                        type="button"
                        class="btn mr-1"
                        @click="cancelInitialPasswordMode">
                        <i class="fas fa-times fa-fw" />
                        {{ $t('general.cancel') }}
                      </button>
                      <button
                        :disabled="isLoginInProcess"
                        type="submit"
                        class="btn btn-primary">
                        <app-icon-state
                          :is-loading="isLoginInProcess"
                          icon="fas fa-sign-in-alt" />
                        {{ $t('login.loginNow') }}
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <small class="safe-connection text-right d-block mt-2">
              <i class="fas fa-lock fa-fw" />
              {{ $t('login.safeConnection') }}
            </small>
          </div>

          <div
            v-if="shouldDisplayNotACustomerBox || infoMessage"
            class="col-12 col-lg-6">
            <div
              v-if="shouldDisplayNotACustomerBox"
              class="card no-customer mb-2">
              <div class="card-header">
                {{ $t('login.noCostumer') }}?
              </div>
              <div class="card-body">
                <a
                  v-if="shouldDisplayRegistrationLink"
                  href="registration">
                  <i class="fas fa-angle-right fa-fw" />
                  <span class="text">
                    {{ $t('login.register') }}
                  </span>
                </a>
              </div>
            </div>
            <div
              v-if="infoMessage"
              class="alert alert-info alert-icon"
              role="alert"
              v-html="infoMessage" />
          </div>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { pageSettingsLogin } from '@scripts/app/settings'
import user from '@scripts/app/user'
import { getNextShopPageAfterLogin } from '@scripts/helper/nextPageAfterLogin'
import { redirect } from '@scripts/helper/redirect'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { login, loginInitial, LoginMode } from '@scripts/modules/auth'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'
import { getHtmlContent, PageId } from '@scripts/modules/html-content'

export default {
  data () {
    return {
      shouldDisplayRegistrationLink: pageSettingsLogin.registrationActive,

      errorMessage: getQueryParameter('errorMessage') || getQueryParameter('warningMessage'),
      infoMessage: '',
      isInitialPasswordMode: getQueryParameter('initialLogin') === 'true',
      isLoginInProcess: false,
      redirectUrl: getQueryParameter('redirecturl'),

      password: getQueryParameter('password'),
      passwordNew: '',
      passwordNewConfirm: '',
      username: getQueryParameter('username'),

      cmd: getQueryParameter('cmd') || LoginMode.NORMAL,
      ram: getQueryParameter('ram'),

      formErrors: {},
    }
  },

  computed: {
    shouldDisplayNotACustomerBox () {
      return this.shouldDisplayRegistrationLink
    },
  },

  /**
   * Vue hook when the component is created
   */
  async created () {
    this.setPageTitle('Login')

    // Check if the shop is locked
    const ignoreShopLock = getQueryParameter('ignoreShopLock')
    if (pageSettingsLogin.shopLocked && typeof ignoreShopLock === 'undefined') {
      redirect('maintenance-mode.html')
      return
    }

    this.infoMessage = (await getHtmlContent(PageId.LOGIN)).html
  },

  methods: {
    /**
     * Form submit handler
     */
    onSubmit () {
      if (this.isInitialPasswordMode) {
        this.tryInitialPasswordLogin()
        return
      }

      this.tryNormalLogin()
    },

    /**
     * Try the login normally
     */
    async tryNormalLogin () {
      this.isLoginInProcess = true
      this.errorMessage = void 0

      try {
        const { showAdmaLogin, hasToAcceptTerms } = await login(
          this.username,
          this.password,
          {
            sessionId: user.guestSid,
            mode: this.cmd,
            ramId: this.ram,
          },
        )

        this.redirectToNextPage(showAdmaLogin, hasToAcceptTerms)
      } catch (e) {
        if (e.code === ErrorCode.LOGIN_INVALID_CREDENTIALS) {
          this.errorMessage = this.$t('login.invalidCredentials')
        } else if (e.code === ErrorCode.SHOP_LOCKED) {
          this.errorMessage = this.$t('login.shopLocked')
        } else if (e.code === ErrorCode.USER_LOCKED) {
          this.errorMessage = this.$t('login.userLocked')
        } else if (e.code === ErrorCode.DEBITOR_LOCKED) {
          this.errorMessage = this.$t('login.debitorLocked')
        } else if (e.code === ErrorCode.USER_INITIAL) {
          this.showInitialPasswordMode()
          this.errorMessage = ''
        } else if (e.code === ErrorCode.USER_INITIAL_EXPIRED) {
          this.errorMessage = this.$t('login.passwordExpired')
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }

        this.isLoginInProcess = false
      }
    },

    /**
     * Try the login in initial password mode
     */
    async tryInitialPasswordLogin () {
      this.isLoginInProcess = true

      this.errorMessage = void 0
      Object.keys(this.formErrors).forEach((key) => this.formErrors[key] = void 0)

      try {
        const { showAdmaLogin, hasToAcceptTerms } = await loginInitial(
          this.username,
          this.password,
          this.passwordNew,
          this.passwordNewConfirm,
        )

        this.redirectToNextPage(showAdmaLogin, hasToAcceptTerms)
      } catch (e) {
        if (e.code === ErrorCode.LOGIN_INVALID_CREDENTIALS) {
          this.errorMessage = this.$t('login.invalidCredentials')
        } else if (e.code === ErrorCode.SHOP_LOCKED) {
          this.errorMessage = this.$t('login.shopLocked')
        } else if (e.code === ErrorCode.USER_LOCKED) {
          this.errorMessage = this.$t('login.userLocked')
        } else if (e.code === ErrorCode.DEBITOR_LOCKED) {
          this.errorMessage = this.$t('login.debitorLocked')
        } else if (e.code === ErrorCode.LOGIN_MISSING_NEW_PASSWORD) {
          this.errorMessage = this.$t('login.missingNewPassword')
        } else if (e.code === ErrorCode.LOGIN_PASSWORD_ALREADY_USED) {
          this.errorMessage = this.$t('login.passwordAlreadyUsed')
        } else if (e.code === ErrorCode.INVALID_FIELDS) {
          this.errorMessage = this.$t('general.invalidFieldsMessage')
          this.formErrors = e.fieldErrors
          for (const fieldname in this.formErrors) {
            this.formErrors[fieldname] = this.formErrors[fieldname].join('<br>')
          }
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }

        this.isLoginInProcess = false
      }
    },

    /**
     * Redirect to the next page
     *
     * @param {boolean} showAdmaLogin - Redirect to the adma login instead of the startpage
     */
    redirectToNextPage (showAdmaLogin, hasToAcceptTerms) {
      // Weiter nach Direkteinsprung
      if ((this.redirectUrl === void 0 || this.redirectUrl === '')
        && document.referrer && document.referrer.indexOf(location.origin) === 0) {
        this.redirectUrl = document.referrer.split('/').pop()
      }

      if (hasToAcceptTerms) {
        if (showAdmaLogin) {
          // Benutzer ist ADMA uns muss vorher AGBs bestätigen (AGBs -> ADMA-Login -> weiter)
          // Wird normalerweise nicht passieren, da ein ADMA keine AGBs bestätigen muss,
          // aber der Code bleibt vorsorglich mal hier drin
          return redirect('login-accept-terms', {
            redirecturl: this.redirectUrl
              ? `login-adma?redirecturl=${encodeURIComponent(this.redirectUrl)}`
              : 'login-adma',
          })
        }
        // Benutzer uns muss vorher AGBs bestätigen (AGBs -> weiter)
        return redirect('login-accept-terms', {
          redirecturl: this.redirectUrl ? this.redirectUrl : void 0,
        })
      }

      // Benutzer ist ADMA (ADMA-Login -> weiter)
      if (showAdmaLogin) {
        return redirect('login-adma', {
          redirecturl: this.redirectUrl ? this.redirectUrl : void 0,
        })
      }

      // Alles normal (direkt weiter)
      redirect(getNextShopPageAfterLogin(this.redirectUrl))
    },

    /**
     * Switch to the initial password mode
     */
    showInitialPasswordMode () {
      this.isInitialPasswordMode = true
    },

    /**
     * Cancel the initial password mode
     */
    cancelInitialPasswordMode () {
      this.passwordNew = ''
      this.passwordNewConfirm = ''
      this.errorMessage = void 0
      this.isInitialPasswordMode = false
    },
  },
}
</script>

<style lang="scss" src="./login.scss"></style>
