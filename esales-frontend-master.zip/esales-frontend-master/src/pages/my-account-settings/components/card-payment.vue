<template>
  <div class="card">
    <!-- Icon, Überschrift -->
    <div class="card-header">
      <i class="fas fa-credit-card fa-fw" />
      {{ $t('myAccountSettings.components.cardPayment.title') }}
    </div>

    <!-- Inhalt -->
    <div class="card-body">
      <!-- Beschreibung -->
      <p class="mb-3">
        {{ $t('myAccountSettings.components.cardPayment.description') }}.
      </p>

      <!-- Zahlungsart -->
      <div class="form-group">
        <label>{{ $t('myAccountSettings.components.cardPayment.typeOfPayment') }}</label>
        <select
          v-model="settings.paymentMethod"
          class="custom-select">
          <option :value="void 0">
            {{ $t('myAccountSettings.components.cardPayment.placeholder.typeOfPayment') }}
          </option>
          <option
            v-for="paymentMethod in settings.paymentMethods"
            :key="paymentMethod.id"
            :value="paymentMethod.id">
            {{ paymentMethod.label }}
          </option>
        </select>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    settings: {
      type: Object,
      required: true,
    },
    formErrors: {
      type: Object,
      required: true,
    },
  },
}
</script>
