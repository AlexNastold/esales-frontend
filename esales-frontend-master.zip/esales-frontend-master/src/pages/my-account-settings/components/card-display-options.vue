<template>
  <div class="card">
    <!-- Icon, Überschrift -->
    <div class="card-header">
      <i class="fas fa-eye fa-fw" />
      {{ $t('myAccountSettings.components.cardDisplayOptions.title') }}
    </div>

    <!-- Inhalt -->
    <div class="card-body">
      <!-- Beschreibung -->
      <p class="mb-3">
        {{ $t('myAccountSettings.components.cardDisplayOptions.description') }}.
      </p>

      <!-- Verfügbarkeiten -->
      <div
        v-if="settings.flags.canChangeAvailability"
        class="custom-control custom-checkbox mb-1">
        <input
          id="my-account-settings-show-availability"
          v-model="settings.showAvailability"
          type="checkbox"
          class="custom-control-input">
        <label
          class="custom-control-label"
          for="my-account-settings-show-availability">
          {{ $t('myAccountSettings.components.cardDisplayOptions.availability') }}
        </label>
      </div>

      <!-- Nettopreise -->
      <div
        v-if="settings.flags.canChangeNetPrice"
        class="custom-control custom-checkbox mb-1">
        <input
          id="my-account-settings-show-netprices"
          v-model="settings.showNetPrice"
          type="checkbox"
          class="custom-control-input">
        <label
          class="custom-control-label"
          for="my-account-settings-show-netprices">
          {{ $t('myAccountSettings.components.cardDisplayOptions.netto') }}
        </label>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    settings: {
      type: Object,
      required: true,
    },
    formErrors: {
      type: Object,
      required: true,
    },
  },
}
</script>

