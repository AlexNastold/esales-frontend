<template>
  <b-modal
    ref="modal"
    :ok-disabled="isProcessing"
    :title="$t('myAccountSettings.components.dialogPassword.title')"
    header-bg-variant="primary"
    header-text-variant="white"
    @ok.prevent="save">
    <form @submit.prevent="save">
      <!-- Altes Passwort -->
      <div class="form-group">
        <label>{{ $t('myAccountSettings.components.dialogPassword.oldPassword') }} <span class="required" /></label>
        <input
          v-model="passwordOld"
          :class="{'is-invalid': formErrors[ChangePasswordFieldErrors.PASSWORD_OLD]}"
          :placeholder="$t('myAccountSettings.components.dialogPassword.oldPasswordPlaceholder')"
          class="form-control"
          type="password"
          autofocus>
        <div
          v-if="formErrors[ChangePasswordFieldErrors.PASSWORD_OLD]"
          class="invalid-feedback"
          v-html="formErrors[ChangePasswordFieldErrors.PASSWORD_OLD]" />
      </div>

      <!-- Neues Passwort -->
      <div class="form-group">
        <label>{{ $t('myAccountSettings.components.dialogPassword.newPassword') }} <span class="required" /></label>
        <input
          v-model="passwordNew1"
          :class="{'is-invalid': formErrors[ChangePasswordFieldErrors.PASSWORD_NEW1]}"
          :placeholder="$t('myAccountSettings.components.dialogPassword.newPasswordPlaceholder')"
          class="form-control"
          type="password">
        <div
          v-if="formErrors[ChangePasswordFieldErrors.PASSWORD_NEW1]"
          class="invalid-feedback"
          v-html="formErrors[ChangePasswordFieldErrors.PASSWORD_NEW1]" />
      </div>

      <!-- Neues Passwort bestätigen  -->
      <div class="form-group">
        <label>{{ $t('myAccountSettings.components.dialogPassword.newPasswordRepeat') }} <span class="required" /></label>
        <input
          v-model="passwordNew2"
          :class="{'is-invalid': formErrors[ChangePasswordFieldErrors.PASSWORD_NEW2]}"
          :placeholder="$t('myAccountSettings.components.dialogPassword.newPasswordRepeatPlaceholder')"
          class="form-control"
          type="password">
        <div
          v-if="formErrors[ChangePasswordFieldErrors.PASSWORD_NEW2]"
          class="invalid-feedback"
          v-html="formErrors[ChangePasswordFieldErrors.PASSWORD_NEW2]" />
      </div>

      <app-form-required-hint class="mt-1" />

      <!-- Ausgeblendeted Submit-Button (zum Abschicken des Formulars mit Enter) -->
      <button
        class="d-none"
        tabindex="-1"
        type="submit" />
    </form>



    <template slot="modal-cancel">
      <i class="fas fa-times fa-fw" />
      {{ $t('general.cancel') }}
    </template>

    <template slot="modal-ok">
      <app-icon-state
        :is-loading="isProcessing"
        icon="fas fa-save" />
      {{ $t('general.save') }}
    </template>
  </b-modal>
</template>

<script>

import { changePassword, ChangePasswordFieldErrors } from '@scripts/modules/user-settings'
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'

export default {
  data () {
    return {
      isProcessing: false,
      passwordOld: void 0,
      passwordNew1: void 0,
      passwordNew2: void 0,
      formErrors: {},
      ChangePasswordFieldErrors,

    }
  },

  methods: {
    show () {
      this.passwordOld = ''
      this.passwordNew1 = ''
      this.passwordNew2 = ''
      Object.keys(this.formErrors).forEach((key) => this.formErrors[key] = void 0)
      this.$refs.modal.show()
    },

    hideDialog () {
      this.$refs.modal.hide()
    },

    async save () {
      if (this.isProcessing) {
        return
      }
      try {
        this.isProcessing = true
        await changePassword(this.passwordOld, this.passwordNew1, this.passwordNew2)
        this.hideDialog()
        showSuccessMessage(this.$t('myAccountSettings.successMessage'))
      } catch (e) {
        if (e.code === ErrorCode.INVALID_FIELDS) {
          this.errorMessage = this.$t('general.invalidFieldsMessage')
          this.formErrors = e.fieldErrors
          // for (const fieldname in this.formErrors) {
          //   this.formErrors[fieldname] = this.formErrors[fieldname].join('<br>')
          // }
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
      this.isProcessing = false
    },
  },
}
</script>

<style lang="scss" scoped>

</style>
