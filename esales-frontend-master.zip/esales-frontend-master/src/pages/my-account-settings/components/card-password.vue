<template>
  <div class="card">
    <!-- Icon, Überschrift -->
    <div class="card-header">
      <i class="fas fa-key fa-fw" />
      {{ $t('myAccountSettings.components.cardPassword.title') }}
    </div>

    <!-- Inhalt -->
    <div class="card-body">
      <!-- Button Ändern -->
      <button
        class="btn btn btn-secondary d-print-none"
        @click.prevent="$refs.dialogPassword.show()">
        <i class="fas fa-edit fa-fw" />
        {{ $t('myAccountSettings.components.cardPassword.changeButton') }}
      </button>
    </div>

    <dialog-password
      ref="dialogPassword" />
  </div>
</template>

<script>

import DialogPassword from './dialog-password.vue'

export default {
  components: {
    'dialog-password': DialogPassword,
  },
}
</script>

