<template>
  <div class="card">
    <!-- Icon, Überschrift -->
    <div class="card-header">
      <i class="fas fa-user fa-fw" />
      {{ $t('myAccountSettings.components.cardUserAlias.title') }}
    </div>

    <!-- Inhalt -->
    <div class="card-body">
      <!-- Beschreibung   -->
      <p class="mb-3">
        {{ $t('myAccountSettings.components.cardUserAlias.description') }}
      </p>

      <!-- User-Alias -->
      <div class="form-group">
        <label>{{ $t('myAccountSettings.components.cardUserAlias.alias') }}</label>
        <input
          v-model="settings.userAlias"
          :class="{'is-invalid': formErrors[SaveUserSettingsFieldErrors.USER_ALIAS]}"
          class="form-control text-uppercase"
          type="text">
        <div
          v-if="formErrors[SaveUserSettingsFieldErrors.USER_ALIAS]"
          class="invalid-feedback"
          v-html="formErrors[SaveUserSettingsFieldErrors.USER_ALIAS]" />
      </div>
    </div>
  </div>
</template>

<script>
import { SaveUserSettingsFieldErrors } from '@scripts/modules/user-settings'

export default {
  props: {
    settings: {
      type: Object,
      required: true,
    },
    formErrors: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      SaveUserSettingsFieldErrors,
    }
  },
}
</script>

