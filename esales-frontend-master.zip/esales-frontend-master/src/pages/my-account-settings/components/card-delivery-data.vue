<template>
  <div class="card">
    <!-- Icon, Überschrift -->
    <div class="card-header">
      <i class="fas fa-truck fa-flip-horizontal fa-fw" />
      {{ $t('myAccountSettings.components.cardShipmentData.title') }}
    </div>

    <!-- Inhalt -->
    <div class="card-body">
      <!-- Beschreibung -->
      <p class="mb-3">
        {{ $t('myAccountSettings.components.cardShipmentData.description') }}.
      </p>

      <!-- Lieferart -->
      <div class="form-group">
        <label>{{ $t('myAccountSettings.components.cardShipmentData.deliveryType.header') }}</label>
        <select
          v-model="settings.deliveryType"
          class="custom-select">
          <option :value="void 0">
            {{ $t('myAccountSettings.components.cardShipmentData.placeholder.deliveryType') }}...
          </option>
          <option
            v-for="deliveryType in settings.deliveryTypes"
            :key="deliveryType.id"
            :value="deliveryType.id">
            {{ deliveryType.label }}
          </option>
        </select>
      </div>

      <!-- Abholwerk -->
      <div
        v-show="showFactory"
        class="form-group">
        <label>{{ $t('myAccountSettings.components.cardShipmentData.pickupFactory') }}</label>
        <select
          v-model="settings.deliveryLocation"
          class="custom-select">
          <option :value="void 0">
            {{ $t('myAccountSettings.components.cardShipmentData.placeholder.pickupFactory') }}...
          </option>
          <option
            v-for="deliveryLocation in settings.deliveryLocations"
            :key="deliveryLocation.id"
            :value="deliveryLocation.id">
            {{ deliveryLocation.label }}
          </option>
        </select>
      </div>

      <!-- Adresse -->
      <div
        v-show="showDeliveryAddress"
        class="form-group">
        <label>{{ $t('myAccountSettings.components.cardShipmentData.address') }}</label>
        <select
          v-model="settings.deliveryAddressId"
          :class="{'is-invalid': formErrors[SaveUserSettingsFieldErrors.DELIVERY_ADDRESS]}"
          class="custom-select mb-1">
          <option :value="void 0">
            {{ $t('myAccountSettings.components.cardShipmentData.placeholder.address') }}...
          </option>
          <option
            v-for="deliveryAddress in settings.deliveryAddresses"
            :key="deliveryAddress.id"
            :value="deliveryAddress.id">
            {{ deliveryAddress.name1 }} {{ deliveryAddress.name2 }},
            {{ deliveryAddress.street }},
            {{ deliveryAddress.country }}-{{ deliveryAddress.postalCode }} {{ deliveryAddress.city }}
          </option>
        </select>
        <div
          v-if="formErrors[SaveUserSettingsFieldErrors.DELIVERY_ADDRESS]"
          class="invalid-feedback"
          v-html="formErrors[SaveUserSettingsFieldErrors.DELIVERY_ADDRESS]" />
      </div>

      <!-- Link zu Adressen verwalten -->
      <a
        href="my-account-addresses"
        class="icon-link">
        <i class="fas fa-map-signs fa-fw" />
        <span class="text">
          {{ $t('myAccountSettings.components.cardShipmentData.manageAddresses') }}
        </span>
      </a>
    </div>
  </div>
</template>

<script>
import { ShipmentCondition } from '@scripts/modules/basket'
import { SaveUserSettingsFieldErrors } from '@scripts/modules/user-settings'

export default {
  props: {
    settings: {
      type: Object,
      required: true,
    },
    formErrors: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      SaveUserSettingsFieldErrors,
    }
  },

  computed: {
    showFactory () {
      return this.settings.deliveryType === ShipmentCondition.PICKUP
    },
    showDeliveryAddress () {
      return this.settings.deliveryType === ShipmentCondition.DELIVERY_IMMEDIATE
       || this.settings.deliveryType === ShipmentCondition.DELIVERY
    },
  },
}
</script>
