<template>
  <div class="card">
    <!-- Icon, Überschrift -->
    <div class="card-header">
      <i class="fas fa-shopping-cart fa-fw" />
      {{ $t('myAccountSettings.components.cardThrowBasket.title') }}
    </div>

    <!-- Inhalt -->
    <div class="card-body">
      <!-- Beschreibung -->
      <p class="mb-3">
        {{ $t('myAccountSettings.components.cardThrowBasket.description') }}.
      </p>

      <!-- Dialog immer anzeigen -->
      <div class="custom-control custom-radio mb-1">
        <input
          id="my-account-settings-basket-popup-show-always"
          v-model="settings.addToBasketMode"
          :value="AddToBasketMode.OPEN_DIALOG_ALWAYS"
          type="radio"
          name="my-account-settings-throw-basket"
          class="custom-control-input">
        <label
          class="custom-control-label"
          for="my-account-settings-basket-popup-show-always">
          {{ $t('myAccountSettings.components.cardThrowBasket.showBasketDialog.always') }}
        </label>
      </div>

      <!-- Dialog erst ab 2 Warenkörben anzeigen -->
      <div class="custom-control custom-radio mb-1">
        <input
          id="my-account-settings-basket-popup-show-from-two-baskets"
          v-model="settings.addToBasketMode"
          :value="AddToBasketMode.OPEN_DIALOG_MULTIPLE_BASKETS"
          type="radio"
          name="my-account-settings-throw-basket"
          class="custom-control-input">
        <label
          class="custom-control-label"
          for="my-account-settings-basket-popup-show-from-two-baskets">
          {{ $t('myAccountSettings.components.cardThrowBasket.showBasketDialog.dependent') }}
        </label>
      </div>

      <!-- Keinen Dialog anzeigen und immer in den aktiven Warenkorb werfen -->
      <div class="custom-control custom-radio">
        <input
          id="my-account-settings-basket-no-popup"
          v-model="settings.addToBasketMode"
          :value="AddToBasketMode.OPEN_DIALOG_NEVER"
          type="radio"
          name="my-account-settings-throw-basket"
          class="custom-control-input">
        <label
          class="custom-control-label"
          for="my-account-settings-basket-no-popup">
          {{ $t('myAccountSettings.components.cardThrowBasket.showBasketDialog.never') }}
        </label>
      </div>
    </div>
  </div>
</template>

<script>
import { AddToBasketMode } from '@scripts/modules/user-settings'

export default {
  props: {
    settings: {
      type: Object,
      required: true,
    },
    formErrors: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      AddToBasketMode,
    }
  },
}
</script>
