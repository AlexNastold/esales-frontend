<template>
  <div class="card">
    <!-- Icon, Überschrift -->
    <div class="card-header">
      <i class="fas fa-envelope fa-fw" />
      {{ $t('myAccountSettings.components.cardNotificationMail.title') }}
    </div>

    <!-- Inhalt -->
    <div class="card-body">
      <!-- Beschreibung -->
      <p class="mb-3">
        {{ $t('myAccountSettings.components.cardNotificationMail.description') }}
      </p>

      <!-- Benutzer E-Mail Adresse -->
      <div class="d-flex mb-1">
        <div class="input-group">
          <!-- Checkbox -->
          <div class="input-group-prepend">
            <div class="input-group-text">
              <input
                v-model="settings.orderMailActive"
                type="checkbox">
            </div>
          </div>

          <!-- Eingabe E-Mail Adresse -->
          <input
            :value="settings.orderMailAddress"
            type="text"
            class="form-control"
            readonly>
        </div>

        <!-- SelectBox Brutto / Netto -->
        <div class="ml-1 w-50 w-sm-25">
          <select
            v-model="settings.orderMailNetPrice"
            class="custom-select">
            <option :value="false">
              {{ $t('myAccountSettings.components.cardNotificationMail.brutto') }}
            </option>
            <option :value="true">
              {{ $t('myAccountSettings.components.cardNotificationMail.netto') }}
            </option>
          </select>
        </div>
      </div>

      <!-- Zusätzliche E-Mail Adresse hinzufügen -->
      <div class="d-flex mb-1">
        <div class="input-group">
          <!-- Checkbox -->
          <div class="input-group-prepend">
            <div class="input-group-text">
              <input
                v-model="settings.orderMailCustomActive"
                type="checkbox">
            </div>
          </div>

          <!-- Eingabe E-Mail Adresse -->
          <input
            v-model="settings.orderMailCustomAddress"
            :class="{'is-invalid': formErrors[SaveUserSettingsFieldErrors.CUSTOM_ORDERMAIL_ADDRESS]}"
            :placeholder="$t('myAccountSettings.components.cardNotificationMail.placeholder.mail')"
            type="text"
            class="form-control">
          <div
            v-if="formErrors[SaveUserSettingsFieldErrors.CUSTOM_ORDERMAIL_ADDRESS]"
            class="invalid-feedback"
            v-html="formErrors[SaveUserSettingsFieldErrors.CUSTOM_ORDERMAIL_ADDRESS]" />
        </div>

        <!-- SelectBox Brutto / Netto -->
        <div class="ml-1 w-50 w-sm-25">
          <select
            v-model="settings.orderMailCustomNetPrice"
            class="custom-select">
            <option :value="false">
              {{ $t('myAccountSettings.components.cardNotificationMail.brutto') }}
            </option>
            <option :value="true">
              {{ $t('myAccountSettings.components.cardNotificationMail.netto') }}
            </option>
          </select>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { SaveUserSettingsFieldErrors } from '@scripts/modules/user-settings'

export default {
  props: {
    settings: {
      type: Object,
      required: true,
    },
    formErrors: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      SaveUserSettingsFieldErrors,
    }
  },
}
</script>

