<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-settings">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountSettings.settings')"
        page="settings" />

      <div class="container">
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountSettings.settings') }}
          </li>
        </ol>

        <!-- Ladeanzeige -->
        <app-loading-box v-if="isLoading" />

        <!-- Formular -->
        <form
          v-else
          @submit.prevent="saveSettings">
          <div
            v-show="errorMessage"
            class="alert alert-danger"
            role="alert"
            v-html="errorMessage" />

          <div class="row">
            <!-- Anzeigeoptionen -->
            <div
              v-if="settings.flags.canChangeAvailability || settings.flags.canChangeNetPrice"
              class="col-12 col-lg-6 mb-3">
              <card-display-options
                :settings="settings"
                :form-errors="formErrors"
                class="h-100" />
            </div>

            <!-- Benachrichtigung  per E-Mail -->
            <div class="col-12 col-lg-6 mb-3">
              <card-notification-mail
                :settings="settings"
                :form-errors="formErrors"
                class="h-100" />
            </div>

            <!-- Werfen -->
            <div class="col-12 col-lg-6 mb-3">
              <card-throw-basket
                :settings="settings"
                :form-errors="formErrors"
                class="h-100" />
            </div>

            <!-- Lieferdaten -->
            <div
              v-if="settings.flags.canChangeDelivery"
              class="col-12 col-lg-6 mb-3">
              <card-delivery-data
                :settings="settings"
                :form-errors="formErrors"
                class="h-100" />
            </div>

            <!-- Zahlungsart -->
            <div
              v-if="settings.flags.canChangePayment"
              class="col-12 col-lg-6 mb-3">
              <card-payment
                :settings="settings"
                :form-errors="formErrors"
                class="h-100" />
            </div>

            <!-- Alias -->
            <div
              v-if="settings.flags.canChangeUserAlias"
              class="col-12 col-lg-6 mb-3">
              <card-user-alias
                :settings="settings"
                :form-errors="formErrors"
                class="h-100" />
            </div>

            <!-- Password -->
            <div
              v-if="settings.flags.canChangePassword"
              class="col-12 col-lg-6 mb-3">
              <card-password class="h-100" />
            </div>
          </div>

          <!-- Buttons -->
          <div class="d-md-flex justify-content-end">
            <!-- Buttons Mobile -->
            <div class="d-md-none">
              <!-- Speichern -->
              <button
                :disabled="isSaving"
                type="submit"
                class="btn btn-block btn-primary mb-1">
                <app-icon-state
                  :is-loading="isSaving"
                  icon="fas fa-save" />
                {{ $t('myAccountSettings.save') }}
              </button>

              <!-- Abbrechen -->
              <a
                href="my-account"
                class="btn btn-block btn-secondary">
                <i class="fas fa-times fa-fw" />
                {{ $t('general.cancel') }}
              </a>
            </div>

            <!-- Buttons Desktop -->
            <div class="d-none d-md-block">
              <!-- Abbrechen -->
              <a
                href="my-account"
                class="btn btn-secondary">
                <i class="fas fa-times fa-fw" />
                {{ $t('general.cancel') }}
              </a>

              <!-- Speichern -->
              <button
                :disabled="isSaving"
                type="submit"
                class="btn btn-primary">
                <app-icon-state
                  :is-loading="isSaving"
                  icon="fas fa-save" />
                {{ $t('myAccountSettings.save') }}
              </button>
            </div>
          </div>
        </form>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { ShipmentCondition } from '@scripts/modules/basket'
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'
import { getUserSettings, saveUserSettings } from '@scripts/modules/user-settings'

import MyAccountHeader from '@components/pages/my-account/header.vue'

import CardDeliveryData from './components/card-delivery-data.vue'
import CardDisplayOptions from './components/card-display-options.vue'
import CardNotificationMail from './components/card-notification-mail.vue'
import CardPayment from './components/card-payment.vue'
import CardThrowBasket from './components/card-throw-basket.vue'
import CardUserAlias from './components/card-user-alias.vue'
import CardPassword from './components/card-password.vue'

export default {
  components: {
    'card-delivery-data': CardDeliveryData,
    'card-display-options': CardDisplayOptions,
    'card-notification-mail': CardNotificationMail,
    'card-payment': CardPayment,
    'card-throw-basket': CardThrowBasket,
    'card-user-alias': CardUserAlias,
    'card-password': CardPassword,
    'my-account-header': MyAccountHeader,
  },

  data () {
    return {
      isLoading: true,
      isSaving: false,
      settings: void 0,

      errorMessage: '',
      formErrors: {},
    }
  },

  created () {
    this.setPageTitle(this.$t('myAccountSettings.title'))

    this.loadSettings()
  },

  methods: {
    async loadSettings () {
      try {
        this.settings = await getUserSettings()
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },

    async saveSettings () {
      if (this.isSaving) {
        return
      }

      this.errorMessage = ''
      this.formErrors = {}
      this.isSaving = true

      try {
        await saveUserSettings({
          addToBasketMode: this.settings.addToBasketMode,
          deliveryAddressId: this.settings.deliveryAddressId,
          deliveryLocation: this.settings.deliveryLocation,
          deliveryPhone: this.settings.deliveryPhone,
          deliveryType: this.settings.deliveryType,
          orderMailActive: this.settings.orderMailActive,
          orderMailCustomActive: this.settings.orderMailCustomActive,
          orderMailCustomAddress: this.settings.orderMailCustomAddress,
          orderMailCustomNetPrice: this.settings.orderMailCustomNetPrice,
          orderMailNetPrice: this.settings.orderMailNetPrice,
          paymentMethod: this.settings.paymentMethod,
          showAvailability: this.settings.showAvailability,
          showNetPrice: this.settings.showNetPrice,
          userAlias: this.settings.userAlias,
        }, {
          addToBasketMode: true,
          deliveryAddress: this.settings.flags.canChangeDelivery && !(this.settings.deliveryType === ShipmentCondition.PICKUP),
          deliveryType: this.settings.flags.canChangeDelivery,
          orderMail: true,
          payment: this.settings.flags.canChangePayment,
          showAvailability: this.settings.flags.canChangeAvailability,
          showNetPrice: this.settings.flags.canChangeNetPrice,
          userAlias: this.settings.flags.canChangeUserAlias,
        })
        showSuccessMessage(this.$t('myAccountSettings.successMessage'))
      } catch (e) {
        if (e.code === ErrorCode.INVALID_FIELDS) {
          this.errorMessage = this.$t('general.invalidFieldsMessage')
          this.formErrors = e.fieldErrors
          for (const fieldname in this.formErrors) {
            this.formErrors[fieldname] = this.formErrors[fieldname].join('<br>')
          }
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }

      this.isSaving = false
    },
  },
}
</script>

<style lang="scss" src="./my-account-settings.scss"></style>
