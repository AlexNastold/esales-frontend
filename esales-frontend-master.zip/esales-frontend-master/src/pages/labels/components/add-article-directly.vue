<template>
  <div class="rounded bg-light d-md-flex p-3 mb-3">
    <!-- Icon -->
    <div class="mr-3 mt-1 d-none d-md-block">
      <i class="fas fa-tags fa-fw fa-3x" />
    </div>

    <div class="w-100">
      <!-- Überschrift -->
      <h4>
        <i class="fas fa-tags fa-fw d-md-none" />
        {{ $t('labels.components.addArticleDirectly.headline') }}
      </h4>

      <form @submit.prevent="addLabel">
        <div class="row">
          <!-- Artikelnummer -->
          <div class="col-12 col-md-4">
            <div class="form-group mb-0">
              <label>{{ $t('general.articleNumber') }}</label>
              <app-form-input-product-search
                ref="newLabelPartNo"
                v-model="newLabelPartNo"
                :max-items="5"
                class="form-control"
                btn-type="btn-tertiary" />
            </div>
          </div>

          <!-- Menge Artikel -->
          <div class="col-12 col-md-4">
            <div class="form-group">
              <label>{{ $t('labels.components.addArticleDirectly.amountArticle') }}</label>
              <app-form-input-quantity
                v-model="newLabelQuantity"
                :placeholder="$t('labels.components.addArticleDirectly.amountArticlePlaceholder')"
                width="auto"
                :unit="$t('components.formInputQuantity.unitDefault')"
                btn-type="btn-tertiary" />
            </div>
          </div>

          <!-- Menge Etiketten -->
          <div class="col-12 col-md-4">
            <div class="form-group">
              <label>{{ $t('labels.components.addArticleDirectly.amountLabels') }}</label>
              <app-form-input-quantity
                v-model="newLabelLabelQuantity"
                :placeholder="$t('labels.components.addArticleDirectly.amountLabelsPlaceholder')"
                :unit="$t('labels.components.addArticleDirectly.unitLabels')"
                width="auto"
                btn-type="btn-tertiary" />
            </div>
          </div>

          <!-- Button Hinzufügen -->
          <div class="col-12 text-right">
            <!-- Button Mobile -->
            <div class="d-md-none">
              <button
                :disabled="isProcessing"
                type="submit"
                class="btn btn-block btn-primary">
                <app-icon-state
                  :is-loading="isProcessing"
                  icon="fas fa-plus" />
                {{ $t('labels.components.addArticleDirectly.buttonOk') }}
              </button>
            </div>

            <!-- Button Desktop -->
            <div class="d-none d-md-block">
              <button
                :disabled="isProcessing || isDisabled"
                type="submit"
                class="btn btn-primary">
                <app-icon-state
                  :is-loading="isProcessing"
                  icon="fas fa-plus" />
                {{ $t('labels.components.addArticleDirectly.buttonOk') }}
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { addLabel } from '@scripts/modules/labels'

export default {
  data () {
    return {
      isProcessing: false,

      newLabelPartNo: '',
      newLabelQuantity: 1,
      newLabelLabelQuantity: 1,
    }
  },

  computed: {
    isDisabled () {
      if (this.newLabelPartNo === '') {
        return true
      } else {
        return false
      }
    },
  },

  methods: {
    async addLabel () {
      if (this.isProcessing || this.isDisabled) {
        return
      }

      this.isProcessing = true

      try {
        await addLabel(this.newLabelPartNo, this.newLabelQuantity, this.newLabelLabelQuantity)

        showSuccessMessage(this.$t('labels.components.addArticleDirectly.articleAdded'))

        this.newLabelPartNo = ''
        this.newLabelQuantity = 1
        this.newLabelLabelQuantity = 1

        this.$refs.newLabelPartNo.focus()

        this.$emit('add')
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.isProcessing = false
    },
  },
}
</script>

