<template>
  <b-modal
    ref="modal"
    :title="$t('labels.components.printDialog.title')"
    header-bg-variant="primary"
    header-text-variant="white"
    size="lg"
    @ok.prevent="print">
    <!-- Inhalt -->
    <form @submit.prevent="print">
      <div class="row">
        <!-- Formular -->
        <div class="col-md-7 col-lg-8">
          <!-- Formular-Typ -->
          <div class="form-group">
            <label>
              {{ $t('labels.components.printDialog.fields.formTypeLabel') }}
              <span class="required" />
            </label>
            <select
              v-model="formFields.formType"
              class="custom-select">
              <option
                v-for="formType of formTypes"
                :key="formType.key"
                :value="formType">
                {{ formType.label }}
              </option>
            </select>
          </div>

          <!-- Barcode-Typ -->
          <div class="form-group">
            <label>
              {{ $t('labels.components.printDialog.fields.barcodeTypeLabel') }}
              <span class="required" />
            </label>
            <select
              v-model="formFields.barcodeType"
              :class="{'is-invalid': formErrors.barcodeType}"
              class="custom-select"
              @change="checkBarcodeType">
              <option
                v-for="barcodeType of barcodeTypes"
                :key="barcodeType.key"
                :value="barcodeType">
                {{ barcodeType.label }}
              </option>
            </select>
            <div
              v-if="formErrors.barcodeType"
              class="invalid-feedback"
              v-text="formErrors.barcodeType" />
          </div>

          <div class="row">
            <!-- Startzeile -->
            <div class="col-12 col-lg-6">
              <div class="form-group">
                <label>
                  {{ $t('labels.components.printDialog.fields.startRowLabel') }}
                </label>
                <input
                  v-model.number="formFields.startRow"
                  :class="{'is-invalid': formErrors.startRow}"
                  type="number"
                  class="form-control"
                  min="1"
                  step="1">
                <div
                  v-if="formErrors.startRow"
                  class="invalid-feedback"
                  v-text="formErrors.startRow" />
              </div>
            </div>

            <!-- Startspalte -->
            <div class="col-12 col-lg-6">
              <div class="form-group">
                <label>
                  {{ $t('labels.components.printDialog.fields.startCellLabel') }}
                </label>
                <input
                  v-model.number="formFields.startCell"
                  :class="{'is-invalid': formErrors.startCell}"
                  type="number"
                  class="form-control"
                  min="1"
                  step="1">
                <div
                  v-if="formErrors.startCell"
                  class="invalid-feedback"
                  v-text="formErrors.startCell" />
              </div>
            </div>
          </div>

          <!-- Sendemethode -->
          <div class="form-group">
            <label>
              {{ $t('labels.components.printDialog.fields.sendMethodLabel') }}
            </label>
            <select
              v-model="formFields.sendMethod"
              class="custom-select">
              <option value="DOWNLOAD">
                {{ $t('labels.components.printDialog.sendMethod.download') }}
              </option>
              <option value="EMAIL">
                {{ $t('labels.components.printDialog.sendMethod.email') }}
              </option>
            </select>
          </div>

          <!-- E-Mail-Adresse -->
          <div
            v-show="formFields.sendMethod === 'EMAIL'"
            class="form-group">
            <label>
              {{ $t('labels.components.printDialog.fields.emailAddressLabel') }}
              <span class="required" />
            </label>
            <input
              v-model="formFields.emailAddress"
              :class="{'is-invalid': formErrors.emailAddress}"
              :placeholder="$t('labels.components.printDialog.fields.emailAddressPlaceholder')"
              type="email"
              class="form-control">
            <div
              v-if="formErrors.emailAddress"
              class="invalid-feedback"
              v-text="formErrors.emailAddress" />
          </div>
        </div>

        <!-- Vorschau -->
        <div class="col-md-5 col-lg-4">
          <!-- Formular-Typ Vorschau -->
          <div class="mb-3 text-center">
            <div class="font-italic mb-1">
              {{ $t('labels.components.printDialog.previewFormType') }}
            </div>
            <div class="form-type-image-wrapper d-flex align-items-center mx-auto">
              <img
                v-if="formFields.formType"
                :src="formFields.formType.image"
                :alt="formFields.formType.label">
            </div>
          </div>

          <!-- Barcode-Typ Vorschau -->
          <div class="text-center mb-3 mb-md-0">
            <div class="font-italic mb-1">
              {{ $t('labels.components.printDialog.previewBarcodeType') }}
            </div>
            <div class="barcode-type-image-wrapper d-flex align-items-center justify-content-center mx-auto">
              <img
                v-if="formFields.barcodeType"
                :src="formFields.barcodeType.image"
                :title="formFields.barcodeType.label"
                :alt="formFields.barcodeType.label">
            </div>
          </div>
        </div>
      </div>

      <!-- Optionen -->
      <div
        v-for="(printOption, index) of printOptions"
        :key="index"
        class="custom-control custom-checkbox">
        <input
          :id="`checkbox-label-print-dialog-option-${index}`"
          :ref="printOption.key"
          v-model="printOption.checked"
          :disabled="isBarcodeAmountDisabled && printOption.key === 'PRINT_AMOUNT_BARCODE'"
          type="checkbox"
          class="custom-control-input"
          @change="checkBarcodeType">
        <label
          :for="`checkbox-label-print-dialog-option-${index}`"
          class="custom-control-label">
          {{ printOption.label }}
        </label>
      </div>

      <app-form-required-hint class="mt-1" />
    </form>

    <template slot="modal-cancel">
      <i class="fas fa-times fa-fw" />
      {{ $t('labels.components.printDialog.buttonCancel') }}
    </template>

    <template slot="modal-ok">
      <template v-if="formFields.sendMethod === 'EMAIL'">
        <i class="fas fa-paper-plane fa-fw" />
        {{ $t('labels.components.printDialog.buttonOkEmail') }}
      </template>
      <template v-else>
        <i class="fas fa-download fa-fw" />
        {{ $t('labels.components.printDialog.buttonOkPrint') }}
      </template>
    </template>
  </b-modal>
</template>

<script>
import user from '@scripts/app/user'
import { pageSettingsLabels } from '@scripts/app/settings'
// import { serverOrigin } from '@scripts/core/paths'
import { redirect, RedirectMethod } from '@scripts/helper/redirect'
import { numberToSapNumber } from '@scripts/helper/sapFormat'
import { validateEmailAddress, validateBarcode } from '@scripts/helper/validator'
import { showSuccessMessage } from '@scripts/modules/dialogs'

export default {
  props: {
    labels: {
      type: Array,
      required: true,
    },
  },

  data () {
    const formTypes = [
      { key: 'a4', image: require('@src/images/labels/forms/din_a4.jpg'), label: 'DIN A4' },
      { key: 'herma_4677', image: require('@src/images/labels/forms/herma_4677.png'), label: 'HERMA 4677' },
      { key: 'herma_5076', image: require('@src/images/labels/forms/herma_5076.png'), label: 'HERMA 5067' },
      { key: 'zweckform_3420', image: require('@src/images/labels/forms/zweckform_3420.png'), label: 'Avery Zweckform 3420' },
      { key: 'zweckform_3421', image: require('@src/images/labels/forms/zweckform_3421.png'), label: 'Avery Zweckform 3421' },
      { key: 'zweckform_3425', image: require('@src/images/labels/forms/zweckform_3425.png'), label: 'Avery Zweckform 3425' },
      { key: 'zweckform_3474', image: require('@src/images/labels/forms/zweckform_3474.png'), label: 'Avery Zweckform 3474' },
      { key: 'zweckform_3475', image: require('@src/images/labels/forms/zweckform_3475.png'), label: 'Avery Zweckform 3475' },
      { key: 'zweckform_3477', image: require('@src/images/labels/forms/zweckform_3477.png'), label: 'Avery Zweckform 3477' },
      { key: 'zweckform_3484', image: require('@src/images/labels/forms/zweckform_3484.png'), label: 'Avery Zweckform 3484' },
      { key: 'zweckform_3563', image: require('@src/images/labels/forms/zweckform_3563.png'), label: 'Avery Zweckform 3563' },
      { key: 'zweckform_3652', image: require('@src/images/labels/forms/zweckform_3652.png'), label: 'Avery Zweckform 3652' },
      { key: 'zweckform_L4743', image: require('@src/images/labels/forms/zweckform_L4743.png'), label: 'Avery Zweckform L4743' },
      { key: 'zweckform_L4744', image: require('@src/images/labels/forms/zweckform_L4744.png'), label: 'Avery Zweckform L4744' },
      { key: 'zweckform_c32258', image: require('@src/images/labels/forms/zweckform_c32258.png'), label: 'Avery Zweckform C32258' },
    ]
    const barcodeTypes = [
      { key: 'C39', image: require('@src/images/labels/barcodes/c39.png'), label: 'C39' },
      { key: 'C39+', image: require('@src/images/labels/barcodes/c39.png'), label: 'C39+' },
      { key: 'C39E', image: require('@src/images/labels/barcodes/c39e.png'), label: 'C39E' },
      { key: 'C39E+', image: require('@src/images/labels/barcodes/c39e.png'), label: 'C39E+' },
      { key: 'C93', image: require('@src/images/labels/barcodes/c93.png'), label: 'C93' },
      { key: 'C128', image: require('@src/images/labels/barcodes/c128.png'), label: 'C128' },
      { key: 'DATAMATRIX', image: require('@src/images/labels/barcodes/datamatrix.png'), label: 'DATAMATRIX' },
      { key: 'QRCODE,H', image: require('@src/images/labels/barcodes/qrcode.png'), label: 'QR-Code' },
      { key: 'PDF417', image: require('@src/images/labels/barcodes/pdf417.png'), label: 'PDF417' },
    ]
    const printOptions = [
      { key: 'PRINT_BORDER', label: this.$t('labels.components.printDialog.options.printBorders'), checked: false },
      { key: 'PRINT_MARGIN', label: this.$t('labels.components.printDialog.options.printMargins'), checked: true },
      { key: 'PRINT_PICTURE', label: this.$t('labels.components.printDialog.options.printPicture'), checked: true },
      { key: 'PRINT_PRICE', label: this.$t('labels.components.printDialog.options.printPrice'), checked: false },
      { key: 'PRINT_DATE', label: this.$t('labels.components.printDialog.options.printDate'), checked: false },
      { key: 'PRINT_MATNR_BARCODE', label: this.$t('labels.components.printDialog.options.printMatnrBarcode'), checked: true },
      { key: 'PRINT_AMOUNT_BARCODE', label: this.$t('labels.components.printDialog.options.printAmountBarcode'), checked: false },
    ]

    return {
      barcodeTypes,
      formTypes,
      printOptions,
      isBarcodeAmountDisabled: false,

      formFields: {
        formType: formTypes[0],
        barcodeType: barcodeTypes[0],
        sendMethod: 'DOWNLOAD',
        emailAddress: '',
        startRow: 1,
        startCell: 1,
      },

      formErrors: {
        barcodeType: '',
        emailAddress: '',
        startRow: '',
        startCell: '',
      },
    }
  },

  methods: {
    show () {
      this.$refs.modal.show()
    },

    print () {
      this.resetFormErrors()
      let isValid = true

      if (!this.checkBarcodeType()) {
        isValid = false
      }

      if (this.formFields.sendMethod === 'EMAIL') {
        if (!this.formFields.emailAddress) {
          this.formErrors.emailAddress = this.$t('labels.components.printDialog.messages.errorEmailMissing')
          isValid = false
        } else if (!validateEmailAddress(this.formFields.emailAddress).success) {
          this.formErrors.emailAddress = this.$t('labels.components.printDialog.messages.errorEmailInvalid')
          isValid = false
        }
      }

      if (this.formFields.startRow <= 0) {
        this.formErrors.startRow = this.$t('labels.components.printDialog.messages.errorStartRowLessThan1')
        isValid = false
      }

      if (this.formFields.startCell <= 0) {
        this.formErrors.startCell = this.$t('labels.components.printDialog.messages.errorStartCellLessThan1')
        isValid = false
      }

      if (isValid) {
        this.sendToServer()
      }
    },

    sendToServer () {
      let params = {}

      params['it_kop[sessionid]'] = user.sessionId
      params['it_kop[customerid]'] = user.kunnr
      params['it_kop[userid]'] = user.userId
      params['it_kop[operator_name]'] = pageSettingsLabels.operatorName
      params['it_kop[operator_system]'] = pageSettingsLabels.systemId
      params['it_kop[hash]'] = pageSettingsLabels.labelsHash
      params['it_kop[serverpath]'] = pageSettingsLabels.serverPath

      params['it_kop[vkorg]'] = user.vkorg
      params['it_kop[vtweg]'] = user.vtweg
      params['it_kop[sparte]'] = user.sparte
      params['it_kop[werk]'] = user.werk

      params['it_kop[form]'] = this.formFields.formType.key
      params['it_kop[barcodetype]'] = this.formFields.barcodeType.key
      // Wenn der Kunde die Funktion des Emailversands nutzen möchte, muss seine Absenderadresse auf dem Mailserver freigeschalten werden und die entsprechende Adresse im Etikettenserver unter /srv/www/htdocs/etiketten/v18-prod/config/customers/[kundenname]/settings.json eingetragen werden
      params['it_kop[sendmethod]'] = this.formFields.sendMethod === 'DOWNLOAD' ? 'download' : 'email'
      params['it_kop[email]'] = this.formFields.emailAddress
      params['it_kop[startrow]'] = this.formFields.startRow
      params['it_kop[startcol]'] = this.formFields.startCell
      params['it_kop[borders]'] = this.printOptions.find((o) => o.key === 'PRINT_BORDER').checked ? 'on' : 'off'
      params['it_kop[printbordersx]'] = this.printOptions.find((o) => o.key === 'PRINT_MARGIN').checked ? 'on' : 'off'
      params['it_kop[printarticleimages]'] = this.printOptions.find((o) => o.key === 'PRINT_PICTURE').checked ? 'on' : 'off'
      params['it_kop[printpartnobarcode]'] =  this.printOptions.find((o) => o.key === 'PRINT_MATNR_BARCODE').checked ? 'on' : 'off'
      params['it_kop[qtybarcode]'] = this.printOptions.find((o) => o.key === 'PRINT_AMOUNT_BARCODE').checked ? 'on' : 'off'
      params['it_kop[printprice]'] = this.printOptions.find((o) => o.key === 'PRINT_PRICE').checked ? 'on' : 'off'
      params['it_kop[printdate]'] = this.printOptions.find((o) => o.key === 'PRINT_DATE').checked ? 'on' : 'off'

      // Index bei 1 beginnen, der Etikettenserver 1.0 bei 1 beginnt
      this.labels.forEach((label, index) => {
        params[`it_pos[${index + 1}][matnr]`] = label.article.matnr
        params[`it_pos[${index + 1}][maktx]`] = label.article.maktx
        params[`it_pos[${index + 1}][maktx2]`] = label.article.maktx2
        params[`it_pos[${index + 1}][qty]`] = label.labelQuantity
        params[`it_pos[${index + 1}][qty2]`] = label.quantity
        params[`it_pos[${index + 1}][unit]`] = label.article.unitFormatted
        params[`it_pos[${index + 1}][source]`] = encodeURIComponent(label.article.image)
        params[`it_pos[${index + 1}][barcode]`] = label.article.matnr
        if (label.article.retailPrice.price > 0) {
          params[`it_pos[${index + 1}][price]`] = `${this.$options.filters.price(label.article.retailPrice.price)} ${this.$options.filters.replaceCurrencyWithSign(label.article.retailPrice.currency)}`
          params[`it_pos[${index + 1}][pricetext]`] = this.$t('labels.pdf.price')
        } else {
          params[`it_pos[${index + 1}][pricetext]`] = this.$t('labels.pdf.priceUponRequest')
        }
      })

      redirect(
        pageSettingsLabels.labelServiceUri,
        params,
        RedirectMethod.POST,
        {
          target: '_blank',
        },
      )

      showSuccessMessage(this.$t('labels.components.printDialog.messages.success'))

      this.$refs.modal.hide()
    },

    checkBarcodeType () {
      let isValid = true
      this.formErrors.barcodeType = ''

      if (this.printOptions.find((o) => o.key === 'PRINT_MATNR_BARCODE').checked) {
        const invalidLabelsForBarcodeType = this.labels.filter((label) => {
          return !validateBarcode(this.formFields.barcodeType.key, label.article.matnr).success
        })

        if (invalidLabelsForBarcodeType.length) {
          this.formErrors.barcodeType = this.$t('labels.components.printDialog.messages.errorBarcodeInvalidCharactersMatnr')
          isValid = false
        }
        this.isBarcodeAmountDisabled = false
      } else {
        this.printOptions.find((o) => o.key === 'PRINT_AMOUNT_BARCODE').checked = false
        this.isBarcodeAmountDisabled = true
      }

      if (this.printOptions.find((o) => o.key === 'PRINT_AMOUNT_BARCODE').checked) {
        const invalidLabelsForBarcodeType = this.labels.filter((label) => {
          return !validateBarcode(this.formFields.barcodeType.key, numberToSapNumber(label.quantity)).success
        })

        if (invalidLabelsForBarcodeType.length) {
          this.formErrors.barcodeType = this.$t('labels.components.printDialog.messages.errorBarcodeInvalidCharactersAmount')
          isValid = false
        }
      }

      return isValid
    },

    resetFormErrors () {
      this.formErrors = {
        barcodeType: '',
        emailAddress: '',
        startRow: '',
        startCell: '',
      }
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.form-type-image-wrapper {
  height: $labels-form-type-image-height;
  width: $labels-form-type-image-width;

  @include media-breakpoint-up(lg) {
    height: $labels-form-type-image-height-lg;
    width: $labels-form-type-image-width-lg;
  }

  img {
    height: auto;
    max-height: 100%;
    max-width: 100%;
    width: auto;
  }
}

.barcode-type-image-wrapper {
  height: $labels-barcode-type-image-height;
  width: $labels-barcode-type-image-width;

  @include media-breakpoint-up(lg) {
    height: $labels-barcode-type-image-height-lg;
    width: $labels-barcode-type-image-width-lg;
  }

  img {
    height: auto;
    max-height: 100%;
    max-width: 100%;
    width: auto;
  }
}

</style>

