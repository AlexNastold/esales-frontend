<template>
  <div>
    <div class="row">
      <!-- Artikelbild, Artikelname, Artikelnummer, EEK-Label -->
      <div class="col-12 col-md col-lg-5">
        <div class="row">
          <!-- Artikelbild -->
          <div class="col-auto">
            <!-- Ohne Fehler: Bild verlinken -->
            <a
              v-if="!hasError"
              :href="detailLink(label.article.matnr, label.article.maktx, label.article.maktx2)">
              <div class="article-image-wrapper d-flex align-items-center justify-content-center">
                <img
                  :src="label.article.image | articleImage"
                  :alt="label.article.maktx">
              </div>
            </a>
            <!-- Mit Fehler: Bild nicht verlinken -->
            <div
              v-else
              class="article-image-wrapper d-flex align-items-center justify-content-center">
              <img
                :src="label.article.image | articleImage"
                :alt="label.article.maktx">
            </div>
          </div>

          <!-- Artikelinformationen -->
          <div class="col">
            <!-- EEK-Label -->
            <app-article-atom-eek-label
              v-if="label.article.eek"
              :classes="label.article.eek"
              class="float-right pl-1" />

            <!-- Artikelname -->
            <div class="font-weight-bold font-size-lg">
              <!-- Ohne Fehler: Artikelname verlinken -->
              <a
                v-if="!hasError"
                :href="detailLink(label.article.matnr, label.article.maktx, label.article.maktx2)"
                class="text-dark text-break">
                {{ label.article.maktx }}
                {{ label.article.maktx2 }}
              </a>
              <!-- Mit Fehler: Artikelname nicht verlinken -->
              <span
                v-else
                class="text-dark text-break">
                {{ label.article.maktx }}
                {{ label.article.maktx2 }}
              </span>
            </div>

            <!-- Artikelnummer -->
            <div class="text-muted mb-2">
              <small>{{ $t('general.articleNumberShort') }} {{ label.article.matnrDisplay }}</small>
            </div>

            <!-- Verfügbarkeit -->
            <app-article-atom-availability
              v-if="app.user.hasPermission('SHOW_AVAILABILITY') && !hasError"
              :is-loading="isAdditionalDataLoading"
              :availability="additionalData && additionalData.availability"
              class="mt-2" />

            <!-- Fehlermeldung -->
            <div
              v-if="hasError"
              class="text-danger">
              <i class="fas fa-exclamation-triangle" />
              {{ errorMessage }}
            </div>
          </div>
        </div>
      </div>

      <!-- Menge Artikel, Menge Etiketten -->
      <div class="col-md-auto col-lg-3">
        <!-- Menge Artikel -->
        <div class="d-xl-flex mb-1">
          <div class="d-flex align-items-center text-muted">
            {{ $t('labels.components.labelsListItem.listItem.amountArticle') }}
          </div>
          <div class="ml-auto">
            <app-form-input-quantity
              :disabled="hasError"
              :value="articleAmount"
              :unit="label.article.unitFormatted"
              @input="$emit('update:articleAmount', $event)" />
          </div>
        </div>

        <!-- Menge Etiketten -->
        <div class="d-xl-flex">
          <div class="d-flex align-items-center text-muted">
            {{ $t('labels.components.labelsListItem.listItem.amountLabels') }}
          </div>
          <div class="ml-auto">
            <app-form-input-quantity
              :disabled="hasError"
              :value="labelAmount"
              :unit="$t('labels.components.addArticleDirectly.unitLabels')"
              @input="$emit('update:labelAmount', $event)" />
          </div>
        </div>
      </div>

      <!-- Preise, Menge, Werfen, Buttons -->
      <div class="col-12 col-lg-4">
        <div class="row">
          <!-- Preise (bei Fehler ausblenden) -->
          <div class="col-12 col-md text-right mt-2 mb-2 mt-lg-0 mb-xl-0">
            <app-article-atom-prices
              v-if="!hasError"
              :retail-price="additionalData && additionalData.retailPrice"
              :net-price="additionalData && additionalData.netPrice"
              :is-price-loading="isAdditionalDataLoading" />
          </div>

          <!-- Buttons -->
          <div class="col-12 mt-2 d-flex justify-content-end">
            <!-- Auf die Liste -->
            <app-action-button-list
              v-if="app.user.hasPermission('LISTS')"
              :is-icon-only="true"
              :matnr="label.article.matnr"
              :amount="amount"
              :disabled="hasError" />

            <!-- Zum Produktvergleich hinzufügen   -->
            <app-action-button-comparison
              v-if="app.user.hasPermission('COMPARISON')"
              :is-icon-only="true"
              :matnr="label.article.matnr"
              :disabled="hasError"
              class="ml-1" />
              
            <!-- Position löschen -->
            <button
              :disabled="isDeleteInProcess"
              type="button"
              class="btn btn-secondary ml-1"
              @click="deleteLabel">
              <app-icon-state
                :is-loading="isDeleteInProcess"
                icon="fas fa-trash-alt" />
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { confirmDialog, showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getSingleAdditionalArticleData } from '@scripts/modules/additional-article-data'
import { deleteLabel } from '@scripts/modules/labels'
import { detailLink } from '@scripts/helper/generateLink'

export default {
  props: {
    label: {
      type: Object,
      required: true,
    },
    articleAmount: {
      type: Number,
      required: true,
    },
    labelAmount: {
      type: Number,
      required: true,
    },
  },

  data () {
    return {
      amount: this.label.article.stepsize || 1,

      additionalData: void 0,
      hasError: false,
      errorMessage: '',
      isAdditionalDataLoading: true,

      isDeleteInProcess: false,
      detailLink,
    }
  },

  created () {
    this.loadAdditionalData()
  },

  methods: {
    async loadAdditionalData () {
      try {
        this.additionalData = await getSingleAdditionalArticleData(this.label.article.matnr)
        this.hasError = this.additionalData.hasError
        this.errorMessage = this.additionalData.error
        this.isAdditionalDataLoading = false
      } catch (e) {
        console.error()
        showTechnicalErrorMessage()
      }
    },
    async deleteLabel () {
      if (await confirmDialog(
        this.$t('labels.components.labelsListItem.deleteLabelConfirmTitle'),
        this.$t('labels.components.labelsListItem.deleteLabelConfirmMessage'),
        {
          type: 'danger',
          buttonCancelText: '<i class="fas fa-times fa-fw"></i> ' + this.$t('general.cancel'),
          buttonConfirmText: '<i class="fas fa-trash-alt fa-fw"></i> ' + this.$t('labels.components.labelsListItem.deleteLabelConfirmButtonOk'),
        },
      )) {
        this.isDeleteInProcess = true

        try {
          await deleteLabel(this.label.posnr)
          showSuccessMessage(this.$t('labels.components.labelsListItem.deleteLabelSuccessMessage'))
          this.$emit('delete')
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }

        this.isDeleteInProcess = false
      }
    },
  },
}
</script>
