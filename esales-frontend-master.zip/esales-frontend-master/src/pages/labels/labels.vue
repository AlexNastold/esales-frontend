<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-labels">
      <div class="container">
        <h1 class="headline">
          {{ $t('labels.headline') }}
        </h1>

        <app-loading-box v-if="isLoading" />
        <template v-else>
          <!-- Aktionen Buttons -->
          <div class="d-md-flex mb-3">
            <!-- Buttons Mobile -->
            <div class="d-md-none">
              <button
                :disabled="!labels.length || isUpdateInProcess"
                type="button"
                class="btn btn-block btn-warning mb-1"
                @click="updateLabels">
                <app-icon-state
                  :is-loading="isUpdateInProcess"
                  icon="fas fa-save" />
                {{ $t('labels.save') }}
              </button>
              <button
                :disabled="!labels.length || isDeleteAllInProcess"
                type="button"
                class="btn btn-block btn-secondary mb-1"
                @click="deleteAllLabels">
                <app-icon-state
                  :is-loading="isDeleteAllInProcess"
                  icon="fas fa-trash-alt" />
                {{ $t('labels.deleteAll') }}
              </button>
              <button
                :disabled="!labels.length"
                type="button"
                class="btn btn-block btn-primary"
                @click="openPrintDialog">
                <i class="fas fa-print fa-fw" />
                {{ $t('labels.print') }}
              </button>
            </div>

            <!-- Buttons Desktop -->
            <div class="d-none d-md-flex">
              <button
                :disabled="!labels.length || isUpdateInProcess"
                type="button"
                class="btn btn-warning"
                @click="updateLabels">
                <app-icon-state
                  :is-loading="isUpdateInProcess"
                  icon="fas fa-save" />
                {{ $t('labels.save') }}
              </button>
              <button
                :disabled="!labels.length || isDeleteAllInProcess"
                type="button"
                class="btn btn-secondary ml-1"
                @click="deleteAllLabels">
                <app-icon-state
                  :is-loading="isDeleteAllInProcess"
                  icon="fas fa-trash-alt" />
                {{ $t('labels.deleteAll') }}
              </button>
            </div>
            <div class="ml-auto d-none d-md-flex">
              <button
                :disabled="!labels.length"
                type="button"
                class="btn btn-primary"
                @click="openPrintDialog">
                <i class="fas fa-print fa-fw" />
                {{ $t('labels.print') }}
              </button>
            </div>
          </div>

          <h3>
            {{ $t('labels.listHeadline', {count: labels.length}) }}
          </h3>

          <!-- Keine Etiketten-Positionen -->
          <div
            v-if="!labels.length"
            class="border rounded mb-3">
            <app-box-empty-list
              :headline="$t('labels.listEmpty')"
              icon="fas fa-tags">
              <span v-html="$t('labels.listEmptyDescription')" />
            </app-box-empty-list>
          </div>

          <!-- Auflistung Etiketten-Positionen -->
          <div
            v-if="labels.length"
            class="list-group mb-3">
            <app-loading-box v-if="isUpdateInProcess || isDeleteAllInProcess" />
            <template v-else>
              <div
                v-for="label in labels"
                :key="label.posnr"
                class="list-group-item">
                <labels-list-item
                  :label="label"
                  :article-amount.sync="label.quantity"
                  :label-amount.sync="label.labelQuantity"
                  @delete="updateLabels" />
              </div>
            </template>
          </div>

          <!-- Etiketten direkt hinzufügen -->
          <add-article-directly
            class="mb-3"
            @add="updateLabels" />
        </template>
      </div>

      <print-dialog
        ref="printDialog"
        :labels="labels" />
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { confirmDialog, showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { deleteAllLabels, getLabels, updateLabels } from '@scripts/modules/labels'

import AddArticleDirectly from './components/add-article-directly.vue'
import LabelsListItem from './components/labels-list-item.vue'
import PrintDialog from './components/print-dialog.vue'

export default {
  components: {
    'add-article-directly': AddArticleDirectly,
    'labels-list-item': LabelsListItem,
    'print-dialog': PrintDialog,
  },

  data () {
    return {
      isLoading: true,

      labels: [],

      newLabelLabelQuantity: 1,
      newLabelPartNo: '',
      newLabelQuantity: 1,

      isDeleteAllInProcess: false,
      isUpdateInProcess: false,
    }
  },

  created () {
    this.setPageTitle(this.$t('labels.title'))
    this.loadLabels()
  },

  methods: {
    /**
     * Etiketten (neu) laden
     */
    async loadLabels () {
      try {
        this.labels = await getLabels()
        this.isLoading = false
      } catch (e) {
        console.error()
        showTechnicalErrorMessage()
      }
    },

    /**
     * Etiketten speichern & new laden
     */
    async updateLabels () {
      this.isUpdateInProcess = true

      try {
        await updateLabels(this.labels.map((label) => ({
          labelQuantity: label.labelQuantity,
          posnr: label.posnr,
          quantity: label.quantity,
        })))
        showSuccessMessage(this.$t('labels.savedSuccessMessage'))
        this.loadLabels()
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.isUpdateInProcess = false
    },

    /**
     * Alle Etiketten löschen
     */
    async deleteAllLabels () {
      if (await confirmDialog(
        this.$t('labels.deleteAllConfirmTitle'),
        this.$t('labels.deleteAllConfirmMessage'),
        {
          buttonCancelText: `
            <i class="fas fa-times fa-fw"></i>
            ${this.$t('general.cancel')}
          `,
          buttonConfirmText: `
            <i class="fas fa-trash-alt fa-fw"></i>
            ${this.$t('labels.deleteAllConfirmButtonOk')}
          `,
          type: 'danger',
        },
      )) {
        this.isDeleteAllInProcess = true

        try {
          await deleteAllLabels()
          showSuccessMessage(this.$t('labels.deleteAllSuccessMessage'))
          this.loadLabels()
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }

        this.isDeleteAllInProcess = false
      }
    },

    openPrintDialog () {
      this.$refs.printDialog.show()
    },
  },
}
</script>
