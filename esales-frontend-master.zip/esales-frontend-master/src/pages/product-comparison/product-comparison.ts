/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/product-comparison/product-comparison.vue'
setup(PageComponent)
