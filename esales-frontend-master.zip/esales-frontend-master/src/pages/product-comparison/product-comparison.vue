<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-product-comparison">
      <div class="container">
        <h1 class="headline">
          {{ $t('productComparison.list.headline') }}
        </h1>

        <app-loading-box v-if="isLoading" />

        <!-- Keine Artikel im Produktvergleich -->
        <div
          v-else-if="!comparison.length"
          class="border rounded p-3">
          <app-box-empty-list
            :headline="$t('productComparison.list.noArticles')"
            icon="fas fa-balance-scale">
            {{ $t('productComparison.list.addArticlesToComparison') }}
            <div class="mt-2">
              <a
                href="search"
                class="btn btn-outline-primary text-uppercase">
                {{ $t('productComparison.list.searchArticles') }}
              </a>
            </div>
          </app-box-empty-list>
        </div>

        <!-- Artikel im Produktvergleich -->
        <div
          v-else
          class="table-responsive mb-3">
          <table class="table table-bordered table-sm mb-0">
            <!-- Table Head -->
            <thead>
              <tr>
                <th class="border-top-0 border-bottom-0 border-left-0 d-none d-md-table-cell" />

                <!-- Spalten für Artikel -->
                <comparison-article-header
                  v-for="(article, index) in articles"
                  :key="index"
                  :article="article"
                  @updated="loadComparison" />
              </tr>
            </thead>

            <!-- Merkmale -->
            <tbody>
              <tr
                v-for="(attribute, index) in attributes"
                :key="attribute.id"
                :class="{'bg-light': index % 2}">
                <!-- Label Desktop -->
                <td class="font-weight-bold d-none d-md-table-cell">
                  {{ attribute.label }}
                </td>

                <td
                  v-for="article in articles"
                  :key="article.matnr">
                  <!-- Label Mobile -->
                  <div class="font-weight-bold mb-1 d-md-none">
                    {{ attribute.label }}
                  </div>

                  <template v-if="attribute.type === 'TYPE_CODED'">
                    <!-- Verfügbarkeit -->
                    <app-article-atom-availability
                      v-if="attribute.id === 'AVAIL' && app.user.hasPermission('SHOW_AVAILABILITY')"
                      :availability="article.additionalData && article.additionalData.availability"
                      :is-loading="isAdditionalDataLoading" />

                    <!-- Preise -->
                    <app-article-atom-prices
                      v-else-if="attribute.id === 'NETTOPREIS' && app.user.hasPermission('SHOW_NET_PRICE')"
                      :retail-price="article.additionalData && article.additionalData.retailPrice"
                      :net-price="article.additionalData && article.additionalData.netPrice"
                      :is-price-loading="isAdditionalDataLoading" />

                    <!-- EEK Label -->
                    <app-article-atom-eek-label
                      v-else-if="attribute.id === 'EEK' && article.eek"
                      :classes="article.eek" />
                  </template>

                  <!-- Staffelpreise -->
                  <app-scale-prices
                    v-else-if="attribute.type === 'TYPE_SCALEPRICES' && getAttributeValue(article, attribute)"
                    :prices="getAttributeValue(article, attribute)"
                    :striped="false"
                    class="scale-price-table mb-0" />

                  <!-- Alle anderen Typen -->
                  <span
                    v-else
                    v-html="getAttributeValue(article, attribute)" />
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { showErrorMessage } from '@scripts/modules/dialogs'
import { getAdditionalArticleData } from '@scripts/modules/additional-article-data'
import { getComparisonList } from '@scripts/modules/comparison'

import ComparisonArticleHeader from './components/comparison-article-header.vue'

export default {
  components: {
    'comparison-article-header': ComparisonArticleHeader,
  },

  data () {
    return {
      isLoading: true,
      isAdditionalDataLoading: true,

      attributes: [],
      comparison: [],

      additionalData: void 0,
    }
  },

  computed: {
    articles () {
      return this.comparison.map((compare) => {
        const article = compare.article
        article.additionalData = (this.additionalData || []).find((data) => {
          return data.matnr === article.matnr
        })
        return article
      })
    },
  },

  async created () {
    this.setPageTitle(this.$t('productComparison.list.title'))
    this.loadComparison()
  },

  methods: {
    async loadComparison () {
      this.isLoading = true

      try {
        const data = await getComparisonList()
        this.attributes = data.attributes.filter((attribute) => {
          return attribute.hasValues
        })
        this.comparison = data.comparison

        this.loadAdditionalArticleData()
      } catch (e) {
        console.error(e)
        showErrorMessage(e.message)
      }

      this.isLoading = false
    },

    async loadAdditionalArticleData () {
      this.isAdditionalDataLoading = true
      this.additionalData = await getAdditionalArticleData(this.articles.map((article) => {
        return {
          matnr: article.matnr,
          amount: 1,
          volumeUnit: article.unit,
        }
      }))
      this.isAdditionalDataLoading = false
    },

    getIconClass (type) {
      switch (type) {
        case 'PDF':
          return 'fa-file-pdf'
        default:
          return 'fa-file'
      }
    },

    getAttributeValue (article, attribute) {
      const compare = this.comparison.find((comp) => {
        return comp.article === article
      })

      const rawValue = compare.values[attribute.id] ? compare.values[attribute.id] : void 0

      switch (attribute.type) {
        case 'TYPE_PRICE':
          if (rawValue.value) {
            return `${this.$options.filters.price(rawValue.value)} ${rawValue.unit}`
          }
          return this.$t('components.articleAtomPrices.priceOnRequest')

        case 'TYPE_TEXT':
          return rawValue

        case 'TYPE_INTEGER':
          return (rawValue.value) ? `${parseInt(rawValue.value)} ${rawValue.unit}` : ''

        case 'TYPE_FLOAT':
          return (rawValue.value) ? `${this.$options.filters.sapNumber(rawValue.value)} ${rawValue.unit}` : ''

        case 'TYPE_IMAGE':
          return (rawValue.src)
            ? `<img class="attribute-value-image" src="${this.$options.filters.externalImage(rawValue.src)}" alt="${rawValue.tooltip}" title="${rawValue.tooltip}"> ${rawValue.label}`
            : ''

        case 'TYPE_LINK': {
          let links = []
          const htmlLinks = []
          if (Array.isArray(rawValue)) {
            links = rawValue
          } else if (rawValue && typeof rawValue === 'object') {
            links.push(rawValue)
          }
          links.forEach((link) => {
            htmlLinks.push(
              `<a href="${link.href}" title="${link.label}">` +
                `<i class="fas ${this.getIconClass(link.type)} fa-fw"></i> ${link.label}` +
              '</a>',
            )
          })
          return htmlLinks.join('<br>')
        }

        case 'TYPE_TABLE':
          return Array.isArray(rawValue) ? rawValue.join('<br>') : rawValue

        // Wird im Template verarbeitet
        case 'TYPE_CODED':
        case 'TYPE_SCALEPRICES':
          return rawValue

        default:
          console.error(`Unknown attribute type "${attribute.type}"`)
          return ''
      }
    },
  },
}

</script>

<style lang="scss">
@import '~styles/definitions/all';

.attribute-value-image {
  max-width: 100px;
  max-height: 100px;
}

.scale-price-table {
  th,
  td {
    border-right-width: 0;
    border-left-width: 0;
  }
}

</style>
