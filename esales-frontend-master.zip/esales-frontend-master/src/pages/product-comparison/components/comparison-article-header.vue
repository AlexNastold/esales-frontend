<template>
  <th class="component-root align-top p-2 border-bottom-0 h-100">
    <div class="h-100">
      <!-- Artikel aus Produktvergleich entfernen, Artikelbild -->
      <div class="position-relative">
        <!-- Artikel aus Produktvergleich entfernen -->
        <div class="position-absolute remove-button">
          <button
            :disabled="isRemoveArticleInProcess"
            type="button"
            class="btn btn-sm btn-secondary"
            @click.prevent="removeArticle">
            <app-icon-state
              :is-loading="isRemoveArticleInProcess"
              icon="fas fa-times" />
          </button>
        </div>

        <!-- Artikelbild -->
        <div class="d-flex align-items-center justify-content-center mb-2">
          <a :href="detailLink(article.matnr, article.maktx, article.maktx2)">
            <div class="article-image-wrapper">
              <img
                :src="article.image | articleImage"
                :alt="article.maktx">
            </div>
          </a>
        </div>
      </div>

      <!-- Artikelname -->
      <a
        :href="detailLink(article.matnr, article.maktx, article.maktx2)"
        class="text-dark font-size-lg d-block article-name text-break">
        {{ article.maktx }}
      </a>

      <!-- Artikelnummer -->
      <div class="small text-muted">
        {{ $t('general.articleNumberShort') }} {{ article.matnrDisplay }}
      </div>

      <div class="mt-auto">
        <!-- Menge, Werfen -->
        <div class="d-flex mt-2 mb-1">
          <!-- Menge -->
          <app-form-input-quantity
            v-model="amount"
            :unit="article.unitFormatted"
            :stepsize="article.stepsize"
            width="auto" />

          <!-- In den Warenkorb -->
          <app-action-button-basket
            v-if="app.user.hasPermission('BASKET_ADD_ARTICLES')"
            :is-icon-only="true"
            :matnr="article.matnr"
            :amount="amount"
            pitcher="comparison"
            class="ml-1" />
        </div>
      </div>
    </div>
  </th>
</template>

<script>
import { confirmDialog, showSuccessMessage, showErrorMessage } from '@scripts/modules/dialogs'
import { removeFromComparison } from '@scripts/modules/comparison'
import { detailLink } from '@scripts/helper/generateLink'
export default {
  props: {
    article: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      amount: this.article.stepsize || 1,
      isRemoveArticleInProcess: false,
      detailLink,
    }
  },
  methods: {
    async removeArticle () {
      if (await confirmDialog(
        this.$t('productComparison.list.confirmRemoveArticleHeadline'),
        this.$t('productComparison.list.confirmRemoveArticleText', {article: this.article.maktx}),
        {
          type: 'danger',
          buttonConfirmText: `<i class="fas fa-trash-alt fa-fw"></i> ${this.$t('productComparison.list.confirmRemoveArticleButtonRemove')}`,
          buttonCancelText: `<i class="fas fa-times fa-fw"></i> ${this.$t('general.cancel')}`,
        },
      )) {
        this.isRemoveArticleInProcess = true


        try {
          await removeFromComparison(this.article.matnr)
          showSuccessMessage(this.$t('productComparison.list.articleWasRemoved', { article: this.article.maktx }))
          this.$emit('updated')
        } catch (e) {
          console.error(e)
          showErrorMessage(e.message)
        }

        this.isRemoveArticleInProcess = false
      }
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.component-root {
  min-width: 250px;
  width: 250px;

  .remove-button {
    right: 0;
    top: 0;
  }

  .article-name {
    height: 52px;
  }
}

</style>
