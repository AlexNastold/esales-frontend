<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation :is-article-menu-open="true" />

    <main class="page-index mt-0">
      <!-- News-Section -->
      <section class="bg-light pt-3 pb-4">
        <div class="container">
          <div class="row">
            <div class="col-12 col-xl-9 offset-xl-3">
              <!-- News-Slider -->
              <news-slider />

              <!-- Unsere Marken -->
              <h1 class="headline text-center text-lg-left my-3">
                {{ $t('index.brands') }}
              </h1>
              <brands-slider />
            </div>
          </div>
        </div>
      </section>

      <!-- Shop Vorteile -->
      <shop-arguments />

      <div class="container">
        <!-- Aktionen -->
        <campaigns
          v-if="app.user.hasPermission('CAMPAIGNS')"
          class="mb-5" />
      </div>

      <!-- Unsere Top-Empfehlungen -->
      <topsellers
        v-if="app.user.hasPermission('TOPSELLER_SHOP')"
        class="mb-5" />

      <div class="container">
        <!-- Kategorien -->
        <categories
          v-if="app.user.hasPermission('CATALOGUE')"
          class="mb-5" />

        <!-- Bestellmatrizen -->
        <order-matrices
          v-if="app.user.hasPermission('ORDERMATRIX')"
          class="mb-5" />
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import BrandsSlider from './components/brands-slider.vue'
import Campaigns from './components/campaigns.vue'
import Categories from './components/categories.vue'
import NewsSlider from './components/news-slider.vue'
import OrderMatrices from './components/order-matrices.vue'
import ShopArguments from './components/shop-arguments.vue'
import Topsellers from './components/topsellers.vue'


export default {
  name: 'IndexPage',

  components: {
    'brands-slider': BrandsSlider,
    campaigns: Campaigns,
    categories: Categories,
    'news-slider': NewsSlider,
    'order-matrices': OrderMatrices,
    'shop-arguments': ShopArguments,
    topsellers: Topsellers,
  },
}
</script>

<style lang="scss" src="./index.scss"></style>
