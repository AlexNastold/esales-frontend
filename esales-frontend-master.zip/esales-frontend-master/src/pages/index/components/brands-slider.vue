<template>
  <div class="wrapper">
    <!-- Ladeanzeige -->
    <app-loading-box
      v-if="isLoading"
      :delay="500"
      class="loading-box" />

    <!-- Brands-Slider -->
    <transition name="fade">
      <slick-slider
        v-if="!isLoading"
        :options="slickSliderOptions"
        class="brands-slider">
        <template v-if="app.user.hasPermission('CATALOGUE')">
          <a
            v-for="(brand, index) in brands"
            :key="index"
            :href="getLinkUri(brand)"
            class="brands-item mr-4">
            <img
              :src="brand.logo | externalImage"
              :alt="brand.altText"
              class="brand">
          </a>
        </template>
        <template v-else>
          <span
            v-for="(brand, index) in brands"
            :key="index"
            class="brands-item mr-4">
            <img
              :src="brand.logo | externalImage"
              :alt="brand.altText"
              class="brand">
          </span>
        </template>
      </slick-slider>
    </transition>
  </div>
</template>

<script>
import { getBrands } from '@scripts/modules/brands'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { constructFilterQuery } from '@scripts/modules/search'

import SlickSlider from 'vue-slick'

export default {
  components: {
    'slick-slider': SlickSlider,
  },

  data () {
    return {
      isLoading: true,
      brands: void 0,
      slickSliderOptions: {
        autoplay: true,
        autoplaySpeed: 10000,
        arrows: false,
        slidesToScroll: 3,
        speed: 1000,
        variableWidth: true,
        responsive: [
          {
            breakpoint: 576,
            settings: {
              slidesToScroll: 2,
            },
          },
        ],
      },
    }
  },

  created () {
    this.loadBrands()
  },

  methods: {
    async loadBrands () {
      try {
        this.brands = await getBrands()
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
    getLinkUri (brand) {
      const filterQuery = brand.supplierName
        ? constructFilterQuery('supplier', brand.supplierName)
        : constructFilterQuery('supplier_id', brand.supplierId)

      return `catalogue?fq=${encodeURIComponent(filterQuery)}`
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.wrapper {
  height: $index-brands-item-height;
}

.brands-slider,
.loading-box {
  height: 100%;
}

.brands-slider {
  .brands-item {
    img {
      height: $index-brands-item-height;
      width: auto;
    }
  }
}
</style>

