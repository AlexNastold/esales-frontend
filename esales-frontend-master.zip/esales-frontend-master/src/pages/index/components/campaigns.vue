<template>
  <section>
    <!-- Überschrift -->
    <h2 class="headline text-center my-4 h1">
      {{ $t('index.components.campaigns.headline') }}
    </h2>

    <!-- Ladeanzeige -->
    <app-loading-box
      v-if="isLoading"
      :delay="500" />

    <transition name="fade">
      <div v-if="!isLoading">
        <!-- Keine Aktionen -->
        <div
          v-if="!campaignsToDisplay.length"
          class="border rounded p-3">
          <app-box-empty-list
            :headline="$t('index.components.campaigns.listEmpty')"
            icon="fas fa-percent">
            <span v-html="$t('index.components.campaigns.listEmptyDescription')" />
          </app-box-empty-list>
        </div>

        <!-- Auflistung Aktionen -->
        <template v-else>
          <div class="row mb-2">
            <div
              v-for="campaign in campaignsToDisplay"
              :key="campaign.id"
              class="col-12 col-lg-6 mb-3">
              <app-campaign-preview
                :campaign="campaign"
                size="small" />
            </div>
          </div>

          <!-- Weitere Aktionen -->
          <div
            v-if="furtherCampaignsAmount"
            class="text-center">
            <a
              class="btn btn-outline-primary text-uppercase font-weight-bold px-3 py-2"
              href="campaigns">
              {{ $t('index.components.campaigns.gotoList', { count: furtherCampaignsAmount }) }}
            </a>
          </div>
        </template>
      </div>
    </transition>
  </section>
</template>

<script>
import { getCampaigns } from '@scripts/modules/campaigns'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  data () {
    return {
      isLoading: true,
      campaigns: [],
    }
  },

  computed: {
    campaignsToDisplay () {
      return this.campaigns.slice(0, 4)
    },
    furtherCampaignsAmount () {
      return this.campaigns.length - this.campaignsToDisplay.length
    },
  },

  created () {
    this.loadCampaigns()
  },

  methods: {
    async loadCampaigns () {
      try {
        this.campaigns = await getCampaigns(true)
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>


