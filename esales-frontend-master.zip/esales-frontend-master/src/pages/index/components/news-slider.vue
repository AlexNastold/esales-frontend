<template>
  <div class="wrapper">
    <!-- Ladeanzeige -->
    <app-loading-box
      v-if="isLoading"
      :delay="500"
      class="loading-box" />

    <!-- News-Slider -->
    <transition name="fade">
      <slick-slider
        v-if="!isLoading"
        :options="slickSliderOptions"
        class="news-slider">
        <a
          v-for="newsItem in news"
          :key="newsItem.key"
          :href="`news?id=${encodeURIComponent(newsItem.id)}`"
          :style="`background-image: url(${$options.filters.externalImage(newsItem.banner)})`"
          class="news-item">
          <div class="news-caption p-2 p-md-3">
            <span class="title text-decoration-none text-dark font-weight-bold d-block mb-2">
              {{ newsItem.title }}
            </span>

            <!-- Button Mobile -->
            <a
              :href="`news?id=${encodeURIComponent(newsItem.id)}`"
              class="btn btn-sm btn-primary d-md-none">
              {{ $t('index.components.newsSlider.readOn') }}
              <i class="fas fa-angle-right fa-fw" />
            </a>

            <!-- Button Desktop -->
            <a
              :href="`news?id=${encodeURIComponent(newsItem.id)}`"
              class="btn btn-primary d-none d-md-inline-block">
              {{ $t('news.startpage.actions.readMore') }}
              <i class="fas fa-angle-right fa-fw" />
            </a>
          </div>
        </a>
        <div
          v-if="!news.length"
          :style="`background-image: url(${$options.filters.externalImage(newsFallback.banner)})`"
          class="news-item">
          <div class="news-caption p-3">
            <span class="title text-decoration-none text-dark font-weight-bold d-block mb-2">
              {{ newsFallback.title }}
            </span>
          </div>
        </div>
      </slick-slider>
    </transition>
  </div>
</template>

<script>
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getNewsList } from '@scripts/modules/news'

import SlickSlider from 'vue-slick'

export default {
  components: {
    'slick-slider': SlickSlider,
  },

  data () {
    return {
      isLoading: true,
      news: void 0,
      newsFallback: void 0,
      slickSliderOptions: {
        autoplay: true,
        autoplaySpeed: 5000,
        dots: true,
        slidesToScroll: 1,
        fade: true,
      },
    }
  },

  created () {
    this.loadNews()
  },

  methods: {
    async loadNews () {
      try {
        const { news, fallback } = await getNewsList()
        this.news = news
        this.newsFallback = fallback
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';


.wrapper {
  height: $index-news-slider-height / 2;

  @include media-breakpoint-up(md) {
    height: $index-news-slider-height;
  }
}

.loading-box,
.news-slider {
  height: 100% !important;
}

.news-slider {
  background: #ccc;

  .news-item {
    background-position: center center;
    background-size: cover;
    height: $index-news-slider-height / 2;
    position: relative;

    @include media-breakpoint-up(md) {
      height: $index-news-slider-height;
    }

    .news-caption {
      position: absolute;
      bottom: 30px;
      left: 40px;
      margin-right: 40px;
      overflow: hidden;
      z-index: 0;

      &:after {
        content: '';
        position: absolute;
        background: transparentize($index-news-caption-background-color, .1);
        width: 1100%;
        height: 1100%;
        bottom: 10px;
        right: -500%;
        transform-origin: 54% 100%;
        transform: rotate(-45deg);
        z-index: -1;
      }

      @include media-breakpoint-up(md) {
        bottom: 60px;
        left: 100px;
        margin-right: 80px;
      }

      .title {
        font-size: 1.2rem;

        @include media-breakpoint-up(md) {
          font-size: 2.4rem;
        }
      }
    }
  }
}
</style>
