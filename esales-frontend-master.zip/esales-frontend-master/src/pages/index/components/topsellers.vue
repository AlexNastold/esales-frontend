<template>
  <section class="bg-light p-3">
    <div class="container">
      <!-- Überschrift -->
      <h2 class="headline text-center my-4 h1">
        {{ $t('index.components.topsellers.recommendations') }}
      </h2>

      <!-- Ladeanzeige -->
      <app-loading-box
        v-if="isLoading"
        :delay="500" />

      <!-- Topseller-Slider -->
      <transition name="fade">
        <app-article-slider
          v-if="!isLoading"
          :articles="topsellers" />
      </transition>
    </div>
  </section>
</template>

<script>
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getTopsellers, TopsellerType } from '@scripts/modules/topseller'

export default {
  data () {
    return {
      isLoading: true,
      topsellers: [],
    }
  },

  created () {
    this.loadTopsellers()
  },

  methods: {
    async loadTopsellers () {
      try {
        this.topsellers = (await getTopsellers(TopsellerType.SHOP)).topsellers
        this.isLoading = false
      } catch (e) {
        console.error()
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
