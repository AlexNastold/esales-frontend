<template>
  <section>
    <!-- Überschrift -->
    <h2 class="headline text-center my-4 h1">
      {{ $t('index.components.categories.categories') }}
    </h2>

    <!-- Ladeanzeige -->
    <app-loading-box
      v-if="isLoading"
      :delay="500" />

    <!-- Topseller-Slider -->
    <transition-group name="fade">
      <div
        v-if="!isLoading"
        key="categories"
        class="row">
        <div
          v-for="(category, index) in categories"
          :key="index"
          class="col-12 col-md-6 col-lg-4 mb-2">
          <category-item :category="category" />
        </div>
      </div>

      <!-- Weitere Kategorien -->
      <div
        v-if="furtherCategoriesAmount"
        key="button"
        class="text-center mt-3">
        <a
          class="btn btn-outline-primary text-uppercase font-weight-bold px-3 py-2"
          href="catalogue">
          {{ $t('index.components.categories.furtherCategories', { count: furtherCategoriesAmount }) }}
        </a>
      </div>
    </transition-group>
  </section>
</template>

<script>
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getShopCategories } from '@scripts/modules/shop-categories'

import CategoryItem from './category-item.vue'

export default {
  components: {
    'category-item': CategoryItem,
  },

  data () {
    return {
      amountAll: 0,
      categories: [],
      isLoading: true,
      maxCategories: 10,
    }
  },

  computed: {
    furtherCategoriesAmount () {
      return this.amountAll - this.categories.length
    },
  },

  created () {
    this.loadCategories()
  },

  methods: {
    async loadCategories () {
      try {
        const { categories, amountAll } = await getShopCategories(this.maxCategories)
        this.categories = categories
        this.amountAll = amountAll
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
