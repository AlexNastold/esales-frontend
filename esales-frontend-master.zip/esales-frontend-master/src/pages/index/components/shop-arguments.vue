<template>
  <section class="pt-4">
    <div class="container">
      <div class="row">
        <div
          v-for="(shopArgument, index) in app.pageSettings.shopArguments"
          :key="index"
          class="shop-argument col-6 col-sm-4 col-lg-4 col-xl-2 font-size-sm text-center mb-4">
          <!-- Icon -->
          <div class="mb-2">
            <i :class="`${shopArgument.icon} fa-fw fa-2x`" />
          </div>

          <!-- Text -->
          <div class="d-flex align-items-center justify-content-center">
            {{ shopArgument.text }}
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<style lang="scss" scoped>
@import '~styles/definitions/all';

section {
  background-color: $index-shop-arguments-background-color;
  color: $index-shop-arguments-color;
}
</style>
