<template>
  <section>
    <!-- Überschrift -->
    <h2 class="headline text-center my-4 h1">
      {{ $t('index.components.orderMatrices.headline') }}
    </h2>

    <p>
      {{ $t('index.components.orderMatrices.matrixDescription') }}
    </p>

    <!-- Ladeanzeige -->
    <app-loading-box
      v-if="isLoading"
      :delay="500" />

    <transition name="fade">
      <div v-if="!isLoading">
        <!-- Keine Bestellmatrizen -->
        <div
          v-if="!ordermatrices.length"
          class="border rounded p-3">
          <app-box-empty-list
            :headline="$t('index.components.orderMatrices.currentlyNoOrdermatricesHeadline')"
            icon="fas fa-table">
            {{ $t('index.components.orderMatrices.currentlyNoOrdermatrices') }}<br>
            {{ $t('index.components.orderMatrices.revisitLater') }}
          </app-box-empty-list>
        </div>

        <!-- Auflistung Bestellmatrizen -->
        <template v-else>
          <div class="list-group">
            <a
              v-for="ordermatrix in ordermatrices"
              :key="ordermatrix.id"
              :href="`ordermatrix?id=${encodeURIComponent(ordermatrix.id)}`"
              class="list-group-item list-group-item-action">
              <div class="d-flex">
                <!-- Name -->
                <div class="w-50 w-md-25 text-truncate mr-2">
                  <i class="fas fa-table fa-fw" />
                  {{ ordermatrix.name }}
                </div>

                <!-- Kateogrie -->
                <span
                  v-if="ordermatrix.category"
                  class="text-muted">
                  {{ ordermatrix.category }}
                </span>
              </div>
            </a>
          </div>

          <!-- Weitere Bestellmatrizen -->
          <div
            v-if="furtherOrdermatricesAmount"
            class="text-center mt-3">
            <a
              class="btn btn-outline-primary text-uppercase font-weight-bold px-3 py-2"
              href="ordermatrix">
              {{ $t('index.components.orderMatrices.furtherOrdermatrices', { count: furtherOrdermatricesAmount }) }}
            </a>
          </div>
        </template>
      </div>
    </transition>
  </section>
</template>

<script>
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getList } from '@scripts/modules/ordermatrix'

export default {
  data () {
    return {
      isLoading: true,
      ordermatrices: [],
      ordermatricesAmountAll: 0,
      maxOrdermatrices: 10,
    }
  },

  computed: {
    furtherOrdermatricesAmount () {
      return this.ordermatricesAmountAll - this.ordermatrices.length
    },
  },

  created () {
    this.loadOrdermatrices()
  },

  methods: {
    async loadOrdermatrices () {
      try {
        const { ordermatrices, amountAll } = await getList(void 0, this.maxOrdermatrices)
        this.ordermatrices = ordermatrices
        this.ordermatricesAmountAll = amountAll
        this.isLoading = false
      } catch (e) {
        console.error()
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
