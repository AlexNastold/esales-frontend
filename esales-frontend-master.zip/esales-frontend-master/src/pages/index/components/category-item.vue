<template>
  <a
    :href="`catalogue?fq=${encodeURIComponent(category.filterQuery)}`"
    class="category-item border rounded text-dark p-3 d-flex align-items-center h-100">
    <div class="category-image mr-3 d-flex align-items-center justify-content-center">
      <img
        v-if="category.image"
        :src="category.image | externalImage"
        :alt="category.label">
    </div>
    <div class="category-caption">
      <div class="font-weight-bold font-size-lg">
        {{ category.label }}
      </div>
      <small class="text-muted">
        {{ $t('index.components.categories.categoryItem.amount', { count: category.articleAmount }) }}
      </small>
    </div>
    <div class="ml-auto">
      <i class="fas fa-angle-right fa-fw fa-1x" />
    </div>
  </a>
</template>

<script>
export default {
  props: {
    category: {
      type: Object,
      required: true,
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.category-item {
  transition: background .2s ease-in-out;

  .category-image {
    height: $index-category-image-height;
    width: $index-category-image-height;

    img {
      height: auto;
      max-height: 100%;
      max-width: 100%;
      width: auto;
    }
  }

  &:hover {
    background-color: $light;
  }

}


</style>
