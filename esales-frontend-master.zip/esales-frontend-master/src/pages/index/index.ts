/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/index/index.vue'
setup(PageComponent)
