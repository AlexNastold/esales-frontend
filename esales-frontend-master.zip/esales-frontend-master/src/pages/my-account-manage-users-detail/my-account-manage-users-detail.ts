/* eslint-disable sort-imports */
import setup from '@scripts/core/setup'
import PageComponent from '@src/pages/my-account-manage-users-detail/my-account-manage-users-detail.vue'
setup(PageComponent)
