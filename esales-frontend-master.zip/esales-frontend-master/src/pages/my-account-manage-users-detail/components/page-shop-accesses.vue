<template>
  <div class="page rounded p-lg-3">
    <h2 class="m-0 mb-3">
      <i class="fas fa-shopping-basket fa-fw mr-1 d-inline-block d-lg-none" />
      {{ $t('myAccountManageUsersDetail.components.pageShopAccesses.title') }}
    </h2>

    <form
      novalidate
      @submit.prevent="saveUserData">
      <div class="row">
        <!-- Auflistung Webshops -->
        <div
          v-for="shopAccess in shopAccesses"
          :key="shopAccess.shop"
          class="col-12 col-md-6 col-lg-4 mb-1">
          <div class="custom-control custom-checkbox">
            <input
              :id="`checkbox-useradm-edit-shops-${shopAccess.shop}`"
              v-model="shopAccess.active"
              :disabled="!shopAccess.editable"
              type="checkbox"
              class="custom-control-input">
            <label
              :for="`checkbox-useradm-edit-shops-${shopAccess.shop}`"
              class="custom-control-label">
              {{ shopAccess.name }}
            </label>
          </div>
        </div>
      </div>

      <!-- Button Speichern -->
      <div class="mt-3">
        <!-- Button Mobile -->
        <div class="d-lg-none">
          <button
            type="submit"
            class="btn btn-block btn-primary mb-1">
            <app-icon-state
              :is-loading="isEditUserInProcess"
              icon="fas fa-save" />
            {{ $t('general.save') }}
          </button>
        </div>

        <!-- Button Desktop -->
        <div class="d-none d-lg-block text-right">
          <button
            type="submit"
            class="btn btn-primary">
            <app-icon-state
              :is-loading="isEditUserInProcess"
              icon="fas fa-save" />
            {{ $t('general.save') }}
          </button>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
import { editUserShopAccesses } from '@scripts/modules/useradm'
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  props: {
    user: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      isEditUserInProcess: false,
      shopAccesses: this.user.shopAccesses.map((shopAccess) => Object.assign({}, shopAccess)),
    }
  },

  watch: {
    user () {
      this.shopAccesses = this.user.shopAccesses.map((shopAccess) => Object.assign({}, shopAccess))
    },
  },

  methods: {
    async saveUserData () {
      this.isEditUserInProcess = true

      try {
        const activatedShopAccesses = this.shopAccesses
          .filter((shopAccess) => shopAccess.editable && shopAccess.active)
          .map((shopAccess) => shopAccess.shop)

        await editUserShopAccesses(this.user.userId, activatedShopAccesses)

        showSuccessMessage(this.$t('myAccountManageUsersDetail.components.pageShopAccesses.successMessage'))
        this.isEditUserInProcess = false
        this.$emit('change')
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
        this.isEditUserInProcess = false
      }
    },
  },
}
</script>

