<template>
  <div class="page rounded p-lg-3">
    <h2 class="m-0 mb-3">
      <i class="fas fa-book fa-fw mr-1 d-inline-block d-lg-none" />
      {{ $t('myAccountManageUsersDetail.components.pageCatalogues.title') }}
    </h2>

    <app-box-empty-list
      v-if="!catalogues.length"
      icon="fas fa-book"
      headline="Keine Kataloge">
      {{ $t('myAccountManageUsersDetail.components.pageCatalogues.noCatalogues') }}
    </app-box-empty-list>

    <form
      v-if="catalogues.length"
      novalidate
      @submit.prevent="saveUserData">
      <div
        v-for="catalogue in catalogues"
        :key="catalogue.id"
        class="border rounded bg-light p-3 mb-1">
        <div class="row">
          <!-- ID, Beschreibung -->
          <div class="col-md-6 col-lg-7 mb-2 mb-md-0">
            <strong class="font-size-lg">
              {{ catalogue.description }}
            </strong>
            <small class="d-block text-muted">
              {{ catalogue.id }}
            </small>
          </div>

          <!-- Sprache, Währung -->
          <div class="col-md-6 col-lg-5">
            <div class="row">
              <div class="col-6 col-lg-4 text-muted mb-1">
                {{ $t('myAccountManageUsersDetail.components.pageCatalogues.language') }}
              </div>
              <div class="col-6 col-lg-8 mb-1">
                {{ catalogue.language }}
              </div>

              <div class="col-6 col-lg-4 text-muted">
                {{ $t('myAccountManageUsersDetail.components.pageCatalogues.currency') }}
              </div>
              <div class="col-6 col-lg-8">
                {{ catalogue.currency }}
              </div>
            </div>
          </div>

          <!-- Katalogzuordnungen -->
          <div class="col-12 col-lg-7 mt-2">
            <div class="row">
              <!-- Zuordnung Benutzer -->
              <div class="col-12 col-md-6 mb-1 mb-md-0">
                <strong class="d-block mb-1">
                  {{ $t('myAccountManageUsersDetail.components.pageCatalogues.assignmentUser') }}
                </strong>

                <!-- Benutzer -->
                <div class="custom-control custom-checkbox d-block">
                  <input
                    :id="`checkbox-useradm-catalogues-assignment1-${catalogue.id}`"
                    v-model="catalogue.assignments.user.active"
                    type="checkbox"
                    class="custom-control-input">
                  <label
                    :for="`checkbox-useradm-catalogues-assignment1-${catalogue.id}`"
                    class="custom-control-label">
                    {{ $t('myAccountManageUsersDetail.components.pageCatalogues.active') }}
                  </label>
                </div>

                <!-- Exklusiv -->
                <div class="custom-control custom-checkbox d-block">
                  <input
                    :id="`checkbox-useradm-catalogues-assignment2-${catalogue.id}`"
                    v-model="catalogue.assignments.user.exclusive"
                    type="checkbox"
                    class="custom-control-input">
                  <label
                    :for="`checkbox-useradm-catalogues-assignment2-${catalogue.id}`"
                    class="custom-control-label">
                    {{ $t('myAccountManageUsersDetail.components.pageCatalogues.exclusive') }}
                  </label>
                </div>
              </div>

              <!-- Zuordnung Kunde -->
              <div class="col-12 col-md-6">
                <strong class="d-block mb-1">
                  {{ $t('myAccountManageUsersDetail.components.pageCatalogues.assignmentCostumer') }}
                </strong>

                <!-- Kunde -->
                <div class="custom-control custom-checkbox d-block">
                  <input
                    :id="`checkbox-useradm-catalogues-assignment3-${catalogue.id}`"
                    :checked="catalogue.assignments.customer.active"
                    type="checkbox"
                    class="custom-control-input"
                    disabled>
                  <label
                    :for="`checkbox-useradm-catalogues-assignment3-${catalogue.id}`"
                    class="custom-control-label">
                    {{ $t('myAccountManageUsersDetail.components.pageCatalogues.active') }}
                  </label>
                </div>

                <!-- Exklusiv -->
                <div class="custom-control custom-checkbox d-block">
                  <input
                    :id="`checkbox-useradm-catalogues-assignment4-${catalogue.id}`"
                    :checked="catalogue.assignments.customer.exclusive"
                    type="checkbox"
                    class="custom-control-input"
                    disabled>
                  <label
                    :for="`checkbox-useradm-catalogues-assignment4-${catalogue.id}`"
                    class="custom-control-label">
                    {{ $t('myAccountManageUsersDetail.components.pageCatalogues.exclusive') }}
                  </label>
                </div>
              </div>
            </div>
          </div>

          <!-- Gültig von, Gültig bis -->
          <div class="col-12 col-md-6 col-lg-5 mt-2">
            <div class="row">
              <div class="col-12 col-md-4 font-weight-bold d-flex align-items-center mb-md-1">
                {{ $t('myAccountManageUsersDetail.components.pageCatalogues.validFrom') }}
              </div>
              <div class="col-12 col-md-8 mb-1">
                <app-form-input-datepicker v-model="catalogue.assignments.user.validFrom" />
              </div>

              <div class="col-12 col-md-4 font-weight-bold d-flex align-items-center">
                {{ $t('myAccountManageUsersDetail.components.pageCatalogues.validTo') }}
              </div>
              <div class="col-12 col-md-8">
                <app-form-input-datepicker v-model="catalogue.assignments.user.validTo" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Button Speichern -->
      <div class="mt-3">
        <!-- Button Mobile -->
        <div class="d-lg-none">
          <button
            type="submit"
            class="btn btn-block btn-primary mb-1">
            <app-icon-state
              :is-loading="isEditUserInProcess"
              icon="fas fa-save" />
            {{ $t('general.save') }}
          </button>
        </div>

        <!-- Button Desktop -->
        <div class="d-none d-lg-block text-right">
          <button
            type="submit"
            class="btn btn-primary">
            <app-icon-state
              :is-loading="isEditUserInProcess"
              icon="fas fa-save" />
            {{ $t('general.save') }}
          </button>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
import { editUserCatalogues } from '@scripts/modules/useradm'
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  props: {
    user: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      isEditUserInProcess: false,

      catalogues: this.user.catalogues.map((catalogue) => {
        return Object.assign({}, catalogue, {
          assignments: {
            user: Object.assign({}, catalogue.assignments.user),
            customer: Object.assign({}, catalogue.assignments.customer),
          },
        })
      }),
    }
  },

  watch: {
    user () {
      this.catalogues = this.user.catalogues.map((catalogue) => {
        return Object.assign({}, catalogue, {
          assignments: {
            user: Object.assign({}, catalogue.assignments.user),
            customer: Object.assign({}, catalogue.assignments.customer),
          },
        })
      })
    },
  },

  methods: {
    async saveUserData () {
      this.isEditUserInProcess = true

      try {
        await editUserCatalogues(this.user.userId, this.catalogues.map((catalogue) => ({
          id: catalogue.id,
          active: catalogue.assignments.user.active,
          validFrom: catalogue.assignments.user.validFrom,
          validTo: catalogue.assignments.user.validTo,
          exclusive: catalogue.assignments.user.exclusive,
        })))

        showSuccessMessage(this.$t('myAccountManageUsersDetail.components.pageCatalogues.successMessage'))
        this.isEditUserInProcess = false
        this.$emit('change')
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
        this.isEditUserInProcess = false
      }
    },
  },
}
</script>

