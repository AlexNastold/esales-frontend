<template>
  <div class="page rounded p-lg-3">
    <h2 class="m-0 mb-3">
      <i class="fas fa-user fa-fw mr-1 d-inline-block d-lg-none" />
      {{ $t('myAccountManageUsersDetail.components.pageUserData.header') }}
    </h2>

    <form
      novalidate
      @submit.prevent="saveUserData">
      <div class="row">
        <!-- Anrede -->
        <div class="col-12 col-lg-4">
          <div class="form-group">
            <label for="salutation">
              {{ $t('myAccountManageUsersDetail.components.pageUserData.title') }} <span class="required" />
            </label>
            <select
              id="salutation"
              v-model="formFields.title"
              :class="{ 'is-invalid': formErrors.title }"
              class="form-control custom-select">
              <option :value="void 0">
                {{ $t('myAccountManageUsersDetail.components.pageUserData.placeholder.title') }}
              </option>
              <option
                v-for="title in titles"
                :key="title.key"
                :value="title.key">
                {{ title.label }}
              </option>
            </select>
            <div
              v-if="formErrors.title"
              class="invalid-feedback"
              v-html="formErrors.title" />
          </div>
        </div>

        <!-- Nachname, Firma -->
        <div class="col-12 col-lg-4">
          <div class="form-group">
            <label for="lastname-company">
              {{ $t('myAccountManageUsersDetail.components.pageUserData.company') }} <span class="required" />
            </label>
            <input
              id="lastname-company"
              v-model="formFields.lastname"
              :class="{ 'is-invalid': formErrors.lastname }"
              :placeholder="$t('myAccountManageUsersDetail.components.pageUserData.placeholder.company')"
              type="text"
              class="form-control"
              maxlength="35">
            <div
              v-if="formErrors.lastname"
              class="invalid-feedback"
              v-html="formErrors.lastname" />
          </div>
        </div>

        <!-- Vorname -->
        <div class="col-12 col-lg-4">
          <div class="form-group">
            <label for="firstname">
              {{ $t('myAccountManageUsersDetail.components.pageUserData.firstName') }}
            </label>
            <input
              id="firstname"
              v-model="formFields.firstname"
              :placeholder="$t('myAccountManageUsersDetail.components.pageUserData.placeholder.firstName')"
              type="text"
              class="form-control"
              maxlength="35">
          </div>
        </div>

        <!-- Alias -->
        <div class="col-12 col-lg-6">
          <div class="form-group">
            <label for="alias">
              {{ $t('myAccountManageUsersDetail.components.pageUserData.alias') }}
            </label>
            <input
              id="alias"
              v-model="formFields.alias"
              :class="{ 'is-invalid': formErrors.alias }"
              :placeholder="$t('myAccountManageUsersDetail.components.pageUserData.placeholder.alias')"
              type="text"
              class="form-control"
              maxlength="136">
            <div
              v-if="formErrors.alias"
              class="invalid-feedback"
              v-html="formErrors.alias" />
          </div>
        </div>

        <!-- E-Mail Adresse -->
        <div class="col-12 col-lg-6">
          <div class="form-group">
            <label for="email">
              {{ $t('myAccountManageUsersDetail.components.pageUserData.mail') }} <sup>1</sup>
            </label>
            <input
              id="email"
              v-model="formFields.emailAddress"
              :class="{ 'is-invalid': formErrors.emailAddress }"
              :placeholder="$t('myAccountManageUsersDetail.components.pageUserData.placeholder.mail')"
              type="email"
              class="form-control"
              maxlength="70">
            <div
              v-if="formErrors.emailAddress"
              class="invalid-feedback"
              v-html="formErrors.emailAddress" />
          </div>
        </div>

        <!-- Telefonnummer -->
        <div class="col-12 col-lg-6">
          <div class="form-group">
            <label for="telephone">
              {{ $t('myAccountManageUsersDetail.components.pageUserData.phone') }}
            </label>
            <input
              id="telephone"
              v-model="formFields.phone"
              :class="{ 'is-invalid': formErrors.phone }"
              :placeholder="$t('myAccountManageUsersDetail.components.pageUserData.placeholder.phone')"
              type="text"
              class="form-control"
              maxlength="30">
            <div
              v-if="formErrors.phone"
              class="invalid-feedback"
              v-html="formErrors.phone" />
          </div>
        </div>

        <!-- Fax -->
        <div class="col-12 col-lg-6">
          <div class="form-group">
            <label for="fax">
              {{ $t('myAccountManageUsersDetail.components.pageUserData.fax') }}
            </label>
            <input
              id="fax"
              v-model="formFields.fax"
              :class="{ 'is-invalid': formErrors.fax }"
              :placeholder="$t('myAccountManageUsersDetail.components.pageUserData.placeholder.fax')"
              type="text"
              class="form-control"
              maxlength="30">
            <div
              v-if="formErrors.fax"
              class="invalid-feedback"
              v-html="formErrors.fax" />
          </div>
        </div>

        <!-- Sprache -->
        <div class="col-12 col-lg-6">
          <div class="form-group">
            <label for="language">
              {{ $t('myAccountManageUsersDetail.components.pageUserData.language') }} <span class="required" />
            </label>
            <select
              id="language"
              v-model="formFields.language"
              :class="{ 'is-invalid': formErrors.language }"
              class="form-control custom-select">
              <option :value="void 0">
                {{ $t('myAccountManageUsersDetail.components.pageUserData.placeholder.language') }}
              </option>
              <option
                v-for="language in languages"
                :key="language.key"
                :value="language.key">
                {{ language.label }}
              </option>
            </select>
            <div
              v-if="formErrors.language"
              class="invalid-feedback"
              v-html="formErrors.language" />
          </div>
        </div>

        <!-- Währung -->
        <div class="col-12 col-lg-6">
          <div class="form-group">
            <label for="currency">
              {{ $t('myAccountManageUsersDetail.components.pageUserData.currency') }} <span class="required" />
            </label>
            <select
              id="currency"
              v-model="formFields.currency"
              :class="{ 'is-invalid': formErrors.currency }"
              class="form-control custom-select">
              <option :value="void 0">
                {{ $t('myAccountManageUsersDetail.components.pageUserData.placeholder.currency') }}
              </option>
              <option
                v-for="currency in currencies"
                :key="currency.key"
                :value="currency.key">
                {{ currency.label }}
              </option>
            </select>
            <div
              v-if="formErrors.currency"
              class="invalid-feedback"
              v-html="formErrors.currency" />
          </div>
        </div>

        <div class="col-12">
          <div class="mb-1">
            <sup>1</sup> {{ $t('myAccountManageUsersDetail.components.pageUserData.sup') }}
          </div>
          <app-form-required-hint />
        </div>
      </div>

      <!-- Button Speichern -->
      <div class="mt-3">
        <!-- Buttons Mobile -->
        <div class="d-lg-none">
          <button
            type="submit"
            class="btn btn-block btn-primary mb-1">
            <app-icon-state
              :is-loading="isEditUserInProcess"
              icon="fas fa-save" />
            {{ $t('general.save') }}
          </button>
        </div>

        <!-- Buttons Desktop -->
        <div class="d-none d-lg-block text-right">
          <button
            type="submit"
            class="btn btn-primary">
            <app-icon-state
              :is-loading="isEditUserInProcess"
              icon="fas fa-save" />
            {{ $t('general.save') }}
          </button>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
import { pageSettingsMyAccountManageUsersEdit } from '@scripts/app/settings'
import { showErrorMessage, showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'
import { editUserData, EditUserDataFields } from '@scripts/modules/useradm'

export default {
  props: {
    user: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      isEditUserInProcess: false,

      languages: pageSettingsMyAccountManageUsersEdit.languages,
      titles: pageSettingsMyAccountManageUsersEdit.titles,
      currencies: pageSettingsMyAccountManageUsersEdit.currencies,

      formFields: {
        title: this.user.title,
        lastname: this.user.lastName,
        firstname: this.user.firstName,
        alias: this.user.userAlias,
        emailAddress: this.user.emailAddress,
        phone: this.user.phone,
        fax: this.user.fax,
        language: this.user.language,
        currency: this.user.currency,
      },

      formErrors: {
        title: '',
        lastname: '',
        alias: '',
        emailAddress: '',
        phone: '',
        fax: '',
        language: '',
        currency: '',
      },
    }
  },

  methods: {
    async saveUserData () {
      this.isEditUserInProcess = true

      try {
        await editUserData(this.user.userId, {
          title: this.formFields.title,
          firstname: this.formFields.firstname,
          lastname: this.formFields.lastname,
          alias: this.formFields.alias,
          emailAddress: this.formFields.emailAddress,
          phone: this.formFields.phone,
          fax: this.formFields.fax,
          language: this.formFields.language,
          currency: this.formFields.currency,
          locked: this.formFields.locked,
        })

        this.resetFieldErrors()

        showSuccessMessage(this.$t('myAccountManageUsersDetail.components.pageUserData.successMessage'))
        this.$emit('change')
      } catch (e) {
        if (e.code === ErrorCode.INVALID_FIELDS) {
          showErrorMessage(this.$t('general.invalidFieldsMessage'))
          this.showFieldErrors(e.fieldErrors)
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }

      this.isEditUserInProcess = false
    },

    /**
     * Show the field errors
     *
     * @param {any} [fieldErrors] - Field errors
     */
    showFieldErrors (fieldErrors) {
      this.resetFieldErrors()
      for (let fieldname in fieldErrors) {
        const message = fieldErrors[fieldname]
        if (fieldname === EditUserDataFields.TITLE) {
          this.formErrors.title = message
        } else if (fieldname === EditUserDataFields.LASTNAME) {
          this.formErrors.lastname = message
        } else if (fieldname === EditUserDataFields.ALIAS) {
          this.formErrors.alias = message
        } else if (fieldname === EditUserDataFields.EMAIL_ADDRESS) {
          this.formErrors.emailAddress = message
        } else if (fieldname === EditUserDataFields.PHONE) {
          this.formErrors.phone = message
        } else if (fieldname === EditUserDataFields.FAX) {
          this.formErrors.fax = message
        } else if (fieldname === EditUserDataFields.LANGUAGE) {
          this.formErrors.language = message
        } else if (fieldname === EditUserDataFields.CURRENCY) {
          this.formErrors.currency = message
        }
      }
    },

    /**
     * Reset the field errors
     */
    resetFieldErrors () {
      this.formErrors.title = ''
      this.formErrors.lastname = ''
      this.formErrors.alias = ''
      this.formErrors.emailAddress = ''
      this.formErrors.phone = ''
      this.formErrors.fax = ''
      this.formErrors.language = ''
      this.formErrors.currency = ''
    },
  },
}
</script>
