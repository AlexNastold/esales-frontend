<template>
  <div class="page rounded p-lg-3">
    <h2 class="m-0 mb-3">
      <i class="far fa-money-bill-alt fa-fw mr-1 d-inline-block d-lg-none" />
      {{ $t('myAccountManageUsersDetail.components.pageBudget.title') }}
    </h2>

    <form
      novalidate
      @submit.prevent="saveUserData">
      <!-- Checkboxen -->
      <div class="custom-control custom-checkbox d-block">
        <input
          id="checkbox-useradm-edit-budget-active"
          v-model="formFields.active"
          type="checkbox"
          class="custom-control-input">
        <label
          for="checkbox-useradm-edit-budget-active"
          class="custom-control-label">
          {{ $t('myAccountManageUsersDetail.components.pageBudget.budgetActive') }}
        </label>
      </div>
      <div class="custom-control custom-checkbox d-block">
        <input
          id="checkbox-useradm-edit-budget-orderstop"
          v-model="formFields.orderStop"
          type="checkbox"
          class="custom-control-input">
        <label
          for="checkbox-useradm-edit-budget-orderstop"
          class="custom-control-label">
          {{ $t('myAccountManageUsersDetail.components.pageBudget.lockOrderAbility') }}
        </label>
      </div>

      <!-- Budgetverantwortlicher -->
      <div class="form-group mt-3 mb-3">
        <label>
          {{ $t('myAccountManageUsersDetail.components.pageBudget.liableForBudget') }} <span class="required" />
        </label>
        <select
          v-model="formFields.responsiveUserId"
          :class="{ 'is-invalid': formErrors.responsiveUserId }"
          class="form-control custom-select">
          <option :value="void 0">
            {{ $t('myAccountManageUsersDetail.components.pageBudget.chooseLiableForBudget') }}
          </option>
          <option
            v-for="responsiveUser in user.budget.possibleResponsiveUsers"
            :key="responsiveUser.userId"
            :value="responsiveUser.userId">
            {{ responsiveUser.firstName }}
            {{ responsiveUser.lastName }}
            ({{ responsiveUser.userId }})
          </option>
        </select>
        <div
          v-if="formErrors.responsiveUserId"
          class="invalid-feedback"
          v-html="formErrors.responsiveUserId" />
      </div>

      <div class="container border rounded mb-2">
        <!-- Jahres-Budget -->
        <div class="row bg-light py-2">
          <!-- Aktiv -->
          <div class="col-6 col-md-2 col-xl-auto mb-1 mb-xl-0">
            <div class="custom-control custom-checkbox m-0">
              <input
                id="checkbox-useradm-edit-budget-year-active"
                v-model="formFields.budgetYearActive"
                type="checkbox"
                class="custom-control-input">
              <label
                for="checkbox-useradm-edit-budget-year-active"
                class="custom-control-label">
                {{ $t('myAccountManageUsersDetail.components.pageBudget.active') }}
              </label>
            </div>
          </div>

          <!-- Budget Jahr -->
          <div class="col-6 col-md-5 col-xl mb-1 mb-xl-0">
            <strong class="d-block">
              {{ $t('general.budgetTexts.yearly') }}
            </strong>
            {{ user.sales.year.year }}
          </div>

          <!-- Betrag -->
          <div class="col-6 col-md-5 col-xl mb-1 mb-xl-0">
            <div class="input-group">
              <app-form-input-number-formatted
                ref="sapNumberInputYear"
                :class="{ 'is-invalid': formErrors.budgetYear }"
                :is-price="true"
                :value="user.budget.budgets.year.budget"
                :placeholder="0 | price"
                class="form-control"
                @input="formFields.budgetYear = arguments[1]" />
              <div class="input-group-append">
                <span class="input-group-text">
                  {{ user.currency | currency }}
                </span>
              </div>
            </div>
            <div
              v-if="formErrors.budgetYear"
              class="invalid-feedback d-block"
              v-html="formErrors.budgetYear" />
          </div>

          <!-- Umsatz -->
          <div class="col-6 col-md-5 col-xl offset-md-2 offset-xl-0 mb-1 mb-md-0">
            <strong class="d-block">
              {{ $t('myAccountManageUsersDetail.components.pageBudget.sales') }}
            </strong>
            {{ user.sales.year.sales | price }}
            {{ user.currency | currency }}
          </div>

          <!-- Überschreitung -->
          <div class="col-6 col-md-5 col-xl offset-6 offset-md-0">
            <strong class="d-block">
              {{ $t('myAccountManageUsersDetail.components.pageBudget.transgression') }}
            </strong>
            <span :class="user.budget.budgets.year.exceed ? 'text-danger' : ''">
              {{ user.budget.budgets.year.exceed | price }}
              {{ user.currency | currency }}
            </span>
          </div>
        </div>

        <!-- Monats-Budget -->
        <div class="row py-2">
          <!-- Aktiv -->
          <div class="col-6 col-md-2 col-xl-auto mb-1 mb-xl-0">
            <div class="custom-control custom-checkbox m-0">
              <input
                id="checkbox-useradm-edit-budget-month-active"
                v-model="formFields.budgetMonthActive"
                type="checkbox"
                class="custom-control-input">
              <label
                for="checkbox-useradm-edit-budget-month-active"
                class="custom-control-label">
                {{ $t('myAccountManageUsersDetail.components.pageBudget.active') }}
              </label>
            </div>
          </div>

          <!-- Budget Monat -->
          <div class="col-6 col-md-5 col-xl mb-1 mb-xl-0">
            <strong class="d-block">
              {{ $t('general.budgetTexts.monthly') }}
            </strong>
            {{ user.sales.month.month }}
          </div>

          <!-- Betrag -->
          <div class="col-6 col-md-5 col-xl mb-1 mb-xl-0">
            <div class="input-group">
              <app-form-input-number-formatted
                ref="sapNumberInputMonth"
                :class="{ 'is-invalid': formErrors.budgetMonth }"
                :is-price="true"
                :value="user.budget.budgets.month.budget"
                :placeholder="0 | price"
                class="form-control"
                @input="formFields.budgetMonth = arguments[1]" />
              <div class="input-group-append">
                <span class="input-group-text">
                  {{ user.currency | currency }}
                </span>
              </div>
            </div>
            <div
              v-if="formErrors.budgetMonth"
              class="invalid-feedback d-block"
              v-html="formErrors.budgetMonth" />
          </div>

          <!-- Umsatz -->
          <div class="col-6 col-md-5 col-xl offset-md-2 offset-xl-0 mb-1 mb-md-0">
            <strong class="d-block">
              {{ $t('myAccountManageUsersDetail.components.pageBudget.sales') }}
            </strong>
            {{ user.sales.month.sales | price }}
            {{ user.currency | currency }}
          </div>

          <!-- Überschreitung -->
          <div class="col-6 col-md-5 col-xl offset-6 offset-md-0">
            <strong class="d-block">
              {{ $t('myAccountManageUsersDetail.components.pageBudget.transgression') }}
            </strong>
            <span :class="user.budget.budgets.month.exceed ? 'text-danger' : ''">
              {{ user.budget.budgets.month.exceed | price }}
              {{ user.currency | currency }}
            </span>
          </div>
        </div>

        <!-- Wochen-Budget -->
        <div class="row bg-light py-2">
          <!-- Aktiv -->
          <div class="col-6 col-md-2 col-xl-auto mb-1 mb-xl-0">
            <div class="custom-control custom-checkbox m-0">
              <input
                id="checkbox-useradm-edit-budget-week-active"
                v-model="formFields.budgetWeekActive"
                type="checkbox"
                class="custom-control-input">
              <label
                for="checkbox-useradm-edit-budget-week-active"
                class="custom-control-label">
                {{ $t('myAccountManageUsersDetail.components.pageBudget.active') }}
              </label>
            </div>
          </div>

          <!-- Budget Woche -->
          <div class="col-6 col-md-5 col-xl mb-1 mb-xl-0">
            <strong class="d-block">
              {{ $t('general.budgetTexts.weekly') }}
            </strong>
            {{ $t('myAccountManageUsersDetail.components.pageBudget.weekNumber') }} {{ user.sales.week.week }}
          </div>

          <!-- Betrag -->
          <div class="col-6 col-md-5 col-xl mb-1 mb-xl-0">
            <div class="input-group">
              <app-form-input-number-formatted
                ref="sapNumberInputWeek"
                :class="{ 'is-invalid': formErrors.budgetWeek }"
                :is-price="true"
                :value="user.budget.budgets.week.budget"
                :placeholder="0 | price"
                class="form-control"
                @input="formFields.budgetWeek = arguments[1]" />
              <div class="input-group-append">
                <span class="input-group-text">
                  {{ user.currency | currency }}
                </span>
              </div>
            </div>
            <div
              v-if="formErrors.budgetWeek"
              class="invalid-feedback d-block"
              v-html="formErrors.budgetWeek" />
          </div>

          <!-- Umsatz -->
          <div class="col-6 col-md-5 col-xl offset-md-2 offset-xl-0 mb-1 mb-md-0">
            <strong class="d-block">
              {{ $t('myAccountManageUsersDetail.components.pageBudget.sales') }}
            </strong>
            {{ user.sales.week.sales | price }}
            {{ user.currency | currency }}
          </div>

          <!-- Überschreitung -->
          <div class="col-6 col-md-5 col-xl offset-6 offset-md-0">
            <strong class="d-block">
              {{ $t('myAccountManageUsersDetail.components.pageBudget.transgression') }}
            </strong>
            <span :class="user.budget.budgets.week.exceed ? 'text-danger' : ''">
              {{ user.budget.budgets.week.exceed | price }}
              {{ user.currency | currency }}
            </span>
          </div>
        </div>

        <!-- Tages-Budget -->
        <div class="row py-2">
          <!-- Aktiv -->
          <div class="col-6 col-md-2 col-xl-auto mb-1 mb-xl-0">
            <div class="custom-control custom-checkbox m-0">
              <input
                id="checkbox-useradm-edit-budget-day-active"
                v-model="formFields.budgetDayActive"
                type="checkbox"
                class="custom-control-input">
              <label
                for="checkbox-useradm-edit-budget-day-active"
                class="custom-control-label">
                {{ $t('myAccountManageUsersDetail.components.pageBudget.active') }}
              </label>
            </div>
          </div>

          <!-- Budget Tag -->
          <div class="col-6 col-md-5 col-xl mb-1 mb-xl-0">
            <strong class="d-block">
              {{ $t('general.budgetTexts.daily') }}
            </strong>
            {{ user.sales.day.date | date }}
          </div>

          <!-- Betrag -->
          <div class="col-6 col-md-5 col-xl mb-1 mb-xl-0">
            <div class="input-group">
              <app-form-input-number-formatted
                ref="sapNumberInputDay"
                :class="{ 'is-invalid': formErrors.budgetDay }"
                :is-price="true"
                :value="user.budget.budgets.day.budget"
                :placeholder="0 | price"
                class="form-control"
                @input="formFields.budgetDay = arguments[1]" />
              <div class="input-group-append">
                <span class="input-group-text">
                  {{ user.currency | currency }}
                </span>
              </div>
            </div>
            <div
              v-if="formErrors.budgetDay"
              class="invalid-feedback d-block"
              v-html="formErrors.budgetDay" />
          </div>

          <!-- Umsatz -->
          <div class="col-6 col-md-5 col-xl offset-md-2 offset-xl-0 mb-1 mb-md-0">
            <strong class="d-block">
              {{ $t('myAccountManageUsersDetail.components.pageBudget.sales') }}
            </strong>
            {{ user.sales.day.sales | price }}
            {{ user.currency | currency }}
          </div>

          <!-- Überschreitung -->
          <div class="col-6 col-md-5 col-xl offset-6 offset-md-0">
            <strong class="d-block">
              {{ $t('myAccountManageUsersDetail.components.pageBudget.transgression') }}
            </strong>
            <span :class="user.budget.budgets.day.exceed ? 'text-danger' : ''">
              {{ user.budget.budgets.day.exceed | price }}
              {{ user.currency | currency }}
            </span>
          </div>
        </div>

        <!-- Auftrags-Budget -->
        <div class="row bg-light py-2">
          <!-- Aktiv -->
          <div class="col-6 col-md-2 col-xl-auto mb-1 mb-xl-0">
            <div class="custom-control custom-checkbox m-0">
              <input
                id="checkbox-useradm-edit-budget-order-active"
                v-model="formFields.budgetOrderActive"
                type="checkbox"
                class="custom-control-input">
              <label
                for="checkbox-useradm-edit-budget-order-active"
                class="custom-control-label">
                {{ $t('myAccountManageUsersDetail.components.pageBudget.active') }}
              </label>
            </div>
          </div>

          <!-- Budget Auftrag -->
          <div class="col-6 col-md-5 col-xl mb-1 mb-xl-0">
            <strong class="d-block">
              {{ $t('general.budgetTexts.order') }}
            </strong>
            {{ user.sales.order.order }}
          </div>

          <!-- Betrag -->
          <div class="col-6 col-md-5 col-xl mb-1 mb-xl-0">
            <div class="input-group">
              <app-form-input-number-formatted
                ref="sapNumberInputOrder"
                :class="{ 'is-invalid': formErrors.budgetOrder }"
                :is-price="true"
                :value="user.budget.budgets.order.budget"
                :placeholder="0 | price"
                class="form-control"
                @input="formFields.budgetOrder = arguments[1]" />
              <div class="input-group-append">
                <span class="input-group-text">
                  {{ user.currency | currency }}
                </span>
              </div>
            </div>
            <div
              v-if="formErrors.budgetOrder"
              class="invalid-feedback d-block"
              v-html="formErrors.budgetOrder" />
          </div>

          <!-- Umsatz -->
          <div class="col-6 col-md-5 col-xl offset-md-2 offset-xl-0 mb-1 mb-md-0">
            <strong class="d-block">
              {{ $t('myAccountManageUsersDetail.components.pageBudget.sales') }}
            </strong>
            {{ user.sales.order.sales | price }}
            {{ user.currency | currency }}
          </div>

          <!-- Überschreitung -->
          <div class="col-6 col-md-5 col-xl offset-6 offset-md-0">
            <strong class="d-block">
              {{ $t('myAccountManageUsersDetail.components.pageBudget.transgression') }}
            </strong>
            <span :class="user.budget.budgets.order.exceed ? 'text-danger' : ''">
              {{ user.budget.budgets.order.exceed | price }}
              {{ user.currency | currency }}
            </span>
          </div>
        </div>
      </div>

      <app-form-required-hint />

      <!-- Button Speichern -->
      <div class="mt-3">
        <!-- Button Mobile -->
        <div class="d-lg-none">
          <button
            type="submit"
            class="btn btn-block btn-primary mb-1">
            <app-icon-state
              :is-loading="isEditUserInProcess"
              icon="fas fa-save" />
            {{ $t('general.save') }}
          </button>
        </div>

        <!-- Button Desktop -->
        <div class="d-none d-lg-block text-right">
          <button
            type="submit"
            class="btn btn-primary">
            <app-icon-state
              :is-loading="isEditUserInProcess"
              icon="fas fa-save" />
            {{ $t('general.save') }}
          </button>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
import { showErrorMessage, showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'
import { editUserBudget, EditUserBudgetFields } from '@scripts/modules/useradm'

export default {
  props: {
    user: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      isEditUserInProcess: false,

      formFields: {
        responsiveUserId: this.user.budget.responsiveUserId,
        active: this.user.budget.active,
        orderStop: this.user.budget.orderStop,
        budgetYearActive: this.user.budget.budgets.year.active,
        budgetYear: this.user.budget.budgets.year.budget,
        budgetMonthActive: this.user.budget.budgets.month.active,
        budgetMonth: this.user.budget.budgets.month.budget,
        budgetWeekActive: this.user.budget.budgets.week.active,
        budgetWeek: this.user.budget.budgets.week.budget,
        budgetDayActive: this.user.budget.budgets.day.active,
        budgetDay: this.user.budget.budgets.day.budget,
        budgetOrderActive: this.user.budget.budgets.order.active,
        budgetOrder: this.user.budget.budgets.order.budget,
      },

      formErrors: {
        responsiveUserId: '',
        budgetYear: '',
        budgetMonth: '',
        budgetWeek: '',
        budgetDay: '',
        budgetOrder: '',
      },
    }
  },

  watch: {
    user () {
      this.formFields = {
        responsiveUserId: this.user.budget.responsiveUserId,
        active: this.user.budget.active,
        orderStop: this.user.budget.orderStop,
        budgetYearActive: this.user.budget.budgets.year.active,
        budgetYear: this.user.budget.budgets.year.budget,
        budgetMonthActive: this.user.budget.budgets.month.active,
        budgetMonth: this.user.budget.budgets.month.budget,
        budgetWeekActive: this.user.budget.budgets.week.active,
        budgetWeek: this.user.budget.budgets.week.budget,
        budgetDayActive: this.user.budget.budgets.day.active,
        budgetDay: this.user.budget.budgets.day.budget,
        budgetOrderActive: this.user.budget.budgets.order.active,
        budgetOrder: this.user.budget.budgets.order.budget,
      },

      // Force update on app-form-input-number-formatted to reset form values
      // If the budget is 0 and a user types -5 and sumbits the form, the app-form-input-number-formatted
      // wouldn't notice the change, because the budget is still 0 (webservice cant handle negative numbers)
      this.$refs.sapNumberInputYear.$forceUpdate()
      this.$refs.sapNumberInputMonth.$forceUpdate()
      this.$refs.sapNumberInputWeek.$forceUpdate()
      this.$refs.sapNumberInputDay.$forceUpdate()
      this.$refs.sapNumberInputOrder.$forceUpdate()

      this.resetFieldErrors()
    },
  },

  methods: {
    async saveUserData () {
      this.isEditUserInProcess = true

      try {
        await editUserBudget(this.user.userId, this.formFields)
        this.resetFieldErrors()
        showSuccessMessage(this.$t('myAccountManageUsersDetail.components.pageBudget.successMessage'))
        this.$emit('change')
      } catch (e) {
        if (e.code === ErrorCode.INVALID_FIELDS) {
          showErrorMessage(this.$t('general.invalidFieldsMessage'))
          this.showFieldErrors(e.fieldErrors)
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }

      this.isEditUserInProcess = false
    },

    /**
     * Show the field errors
     *
     * @param {any[]} [fieldErrors] - Field errors
     */
    showFieldErrors (fieldErrors) {
      this.resetFieldErrors()
      for (let fieldname in fieldErrors) {
        const message = fieldErrors[fieldname]
        if (fieldname === EditUserBudgetFields.RESPONSIVE_USER_ID) {
          this.formErrors.responsiveUserId = message
        } else if (fieldname === EditUserBudgetFields.BUDGET_YEAR) {
          this.formErrors.budgetYear = message
        } else if (fieldname === EditUserBudgetFields.BUDGET_MONTH) {
          this.formErrors.budgetMonth = message
        } else if (fieldname === EditUserBudgetFields.BUDGET_WEEK) {
          this.formErrors.budgetWeek = message
        } else if (fieldname === EditUserBudgetFields.BUDGET_DAY) {
          this.formErrors.budgetDay = message
        } else if (fieldname === EditUserBudgetFields.BUDGET_ORDER) {
          this.formErrors.budgetOrder = message
        }
      }
    },

    /**
     * Reset the field errors
     */
    resetFieldErrors () {
      this.formErrors.responsiveUserId = ''
      this.formErrors.budgetYear = ''
      this.formErrors.budgetMonth = ''
      this.formErrors.budgetWeek = ''
      this.formErrors.budgetDay = ''
      this.formErrors.budgetOrder = ''
    },
  },
}
</script>

