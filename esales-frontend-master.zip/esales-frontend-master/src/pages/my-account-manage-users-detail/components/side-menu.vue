<template>
  <div class="row">
    <!-- Menu for < LG -->
    <div class="col-12 order-2 order-lg-1 mb-3">
      <div class="rounded bg-primary text-white p-3 d-lg-none">
        <div class="form-group">
          <h4>{{ $t('myAccountManageUsersDetail.components.sideMenu.header') }}</h4>
          <select
            :value="page"
            class="form-control custom-select"
            @change="onSelectChange">
            <option
              value="page-user-data">
              {{ $t('myAccountManageUsersDetail.components.sideMenu.userData') }}
            </option>
            <option
              value="page-password">
              {{ $t('myAccountManageUsersDetail.components.sideMenu.password') }}
            </option>
            <option
              v-if="user.userId !== app.user.userId"
              value="page-permissions">
              {{ $t('myAccountManageUsersDetail.components.sideMenu.permissions') }}
            </option>
            <option
              v-if="user.shopAccesses"
              value="page-shop-accesses">
              {{ $t('myAccountManageUsersDetail.components.sideMenu.shopAccesses') }}
            </option>
            <option
              v-if="user.catalogues"
              value="page-catalogues">
              {{ $t('myAccountManageUsersDetail.components.sideMenu.catalogues') }}
            </option>
            <option
              v-if="user.enableEditOwnBudget"
              value="page-budget">
              {{ $t('myAccountManageUsersDetail.components.sideMenu.budget') }}
            </option>
          </select>
        </div>
      </div>

      <!-- Menu for > LG -->
      <div class="list-group d-none d-lg-block">
        <a
          :class="{'active' : page == 'page-user-data'}"
          class="list-group-item list-group-item-action"
          href="#"
          @click.prevent="openPage('page-user-data')">
          <i class="fas fa-user fa-fw" />&nbsp;
          {{ $t('myAccountManageUsersDetail.components.sideMenu.userData') }}
        </a>
        <a
          :class="{'active' : page == 'page-password'}"
          class="list-group-item list-group-item-action"
          href="#"
          @click.prevent="openPage('page-password')">
          <i class="fas fa-key fa-fw" />&nbsp;
          {{ $t('myAccountManageUsersDetail.components.sideMenu.password') }}
        </a>
        <a
          v-if="user.userId !== app.user.userId"
          :class="{'active' : page == 'page-permissions'}"
          class="list-group-item list-group-item-action"
          href="#"
          @click.prevent="openPage('page-permissions')">
          <i class="fas fa-shield-alt fa-fw" />&nbsp;
          {{ $t('myAccountManageUsersDetail.components.sideMenu.permissions') }}
        </a>
        <a
          v-if="user.shopAccesses"
          :class="{'active' : page == 'page-shop-accesses'}"
          class="list-group-item list-group-item-action"
          href="#"
          @click.prevent="openPage('page-shop-accesses')">
          <i class="fas fa-shopping-basket fa-fw" />&nbsp;
          {{ $t('myAccountManageUsersDetail.components.sideMenu.shopAccesses') }}
        </a>
        <a
          v-if="user.catalogues"
          :class="{'active' : page == 'page-catalogues'}"
          class="list-group-item list-group-item-action"
          href="#"
          @click.prevent="openPage('page-catalogues')">
          <i class="fas fa-book fa-fw" />&nbsp;
          {{ $t('myAccountManageUsersDetail.components.sideMenu.catalogues') }}
        </a>
        <a
          v-if="user.enableEditOwnBudget"
          :class="{'active' : page == 'page-budget'}"
          class="list-group-item list-group-item-action"
          href="#"
          @click.prevent="openPage('page-budget')">
          <i class="far fa-money-bill-alt fa-fw" />&nbsp;
          {{ $t('myAccountManageUsersDetail.components.sideMenu.budget') }}
        </a>
      </div>
    </div>

    <!-- Benutzer sperren/entsperren, Benutzer löschen -->
    <div class="col-12 order-1 order-lg-2 mb-3 mb-lg-0">
      <!-- Benutzer aktiveren -->
      <button
        v-if="!user.isActivated"
        type="button"
        class="btn btn-block btn-secondary mb-1"
        @click="activateUser">
        <i class="fas fa-toggle-on fa-fw" />&nbsp;
        {{ $t('myAccountManageUsersDetail.components.sideMenu.activateUser.title') }}
      </button>

      <!-- Kundenanschreiben -->
      <template v-if="user.hasInitialPassword && user.isActivated">
        <a
          :href="letterDownloadUri"
          class="btn btn-block btn-secondary mb-1 text-truncate"
          title="Kundenanschreiben anzeigen">
          <i class="fas fa-file-pdf fa-fw" />&nbsp;
          {{ $t('myAccountManageUsersDetail.components.sideMenu.showUserLetter') }}
        </a>
        <button
          v-if="user.emailAddress"
          type="button"
          class="btn btn-block btn-secondary mb-1 text-truncate"
          title="Kundenanschreiben versenden"
          @click="sendLetter">
          <i class="fas fa-envelope fa-fw" />&nbsp;
          {{ $t('myAccountManageUsersDetail.components.sideMenu.sendUserLetter.sendTitle') }}
        </button>
      </template>

      <!-- Benutzer sperren/entsperren (Master können sich nicht selbst sperren/entsperren) -->
      <template v-if="!(user.isMaster && user.userId === app.user.userId)">
        <!-- Benutzer entsperren -->
        <button
          v-if="user.isLocked"
          type="button"
          class="btn btn-block btn-secondary mb-1"
          @click="unlockUser">
          <i class="fas fa-unlock fa-fw" />
          {{ $t('myAccountManageUsersDetail.components.sideMenu.unlockUser.true.title') }}
        </button>

        <!-- Benutzer sperren -->
        <button
          v-else
          type="button"
          class="btn btn-block btn-secondary mb-1"
          @click="lockUser">
          <i class="fas fa-lock fa-fw" />
          {{ $t('myAccountManageUsersDetail.components.sideMenu.unlockUser.false.title') }}
        </button>
      </template>

      <!-- Benutzer löschen -->
      <button
        v-if="!user.isMaster"
        type="button"
        class="btn btn-block btn-secondary"
        @click="deleteUser">
        <i class="fas fa-trash-alt fa-fw" />&nbsp;
        {{ $t('myAccountManageUsersDetail.components.sideMenu.deleteUser.title') }}
      </button>
    </div>
  </div>
</template>

<script>
import { confirmDialog, showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { activateUser, sendLetter, lockUser, unlockUser, deleteUser, getLetterDownloadUri } from '@scripts/modules/useradm'

export default {
  props: {
    user: {
      type: Object,
      required: true,
    },
    page: {
      type: String,
      required: true,
    },
  },

  data () {
    return {
      letterDownloadUri: getLetterDownloadUri(this.user.userId),
    }
  },

  methods: {
    openPage (page) {
      this.$emit('navigate', page)
    },

    onSelectChange (e) {
      this.openPage(e.target.value)
    },

    async activateUser () {
      if (await confirmDialog(
        this.$t('myAccountManageUsersDetail.components.sideMenu.activateUser.title'),
        this.$t('myAccountManageUsersDetail.components.sideMenu.activateUser.confirm', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}),
        {
          type: 'warning',
          buttonConfirmText: '<i class="fas fa-toggle-on fa-fw"></i> ' + this.$t('myAccountManageUsersDetail.components.sideMenu.activateUser.action'),
          buttonCancelText: '<i class="fas fa-times fa-fw"></i> ' + this.$t('general.cancel'),
        },
      )) {
        try {
          await activateUser(this.user.userId)
          showSuccessMessage(this.$t('myAccountManageUsersDetail.components.sideMenu.activateUser.success', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}))
          this.$emit('change')
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },

    async sendLetter () {
      if (await confirmDialog(
        this.$t('myAccountManageUsersDetail.components.sideMenu.sendUserLetter.sendTitle'),
        this.$t('myAccountManageUsersDetail.components.sideMenu.sendUserLetter.confirm', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId, emailAddress: this.user.emailAddress}),
        {
          type: 'info',
          buttonConfirmText: '<i class="fas fa-envelope fa-fw"></i> ' + this.$t('myAccountManageUsersDetail.components.sideMenu.sendUserLetter.action'),
          buttonCancelText: '<i class="fas fa-times fa-fw"></i> ' + this.$t('general.cancel'),
        },
      )) {
        try {
          await sendLetter(this.user.userId)
          this.$t('myAccountManageUsersDetail.components.sideMenu.sendUserLetter.success', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId})
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },

    async unlockUser () {
      if (await confirmDialog(
        this.$t('myAccountManageUsersDetail.components.sideMenu.unlockUser.true.title'),
        this.$t('myAccountManageUsersDetail.components.sideMenu.unlockUser.true.confirm', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}),
        {
          type: 'warning',
          buttonConfirmText: '<i class="fas fa-unlock fa-fw"></i> ' + this.$t('myAccountManageUsersDetail.components.sideMenu.unlockUser.true.action'),
          buttonCancelText: '<i class="fas fa-times fa-fw"></i> ' + this.$t('general.cancel'),
        },
      )) {
        try {
          await unlockUser(this.user.userId)
          showSuccessMessage(this.$t('myAccountManageUsersDetail.components.sideMenu.unlockUser.true.success', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}))
          this.$emit('change')
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },

    async lockUser () {
      if (await confirmDialog(
        this.$t('myAccountManageUsersDetail.components.sideMenu.unlockUser.false.title'),
        this.$t('myAccountManageUsersDetail.components.sideMenu.unlockUser.false.confirm', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}),
        {
          type: 'warning',
          buttonConfirmText: '<i class="fas fa-lock fa-fw"></i> ' + this.$t('myAccountManageUsersDetail.components.sideMenu.unlockUser.false.action'),
          buttonCancelText: '<i class="fas fa-times fa-fw"></i> ' + this.$t('general.cancel'),
        },
      )) {
        try {
          await lockUser(this.user.userId)
          showSuccessMessage(this.$t('myAccountManageUsersDetail.components.sideMenu.unlockUser.false.success', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}))
          this.$emit('change')
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },

    async deleteUser () {
      if (await confirmDialog(
        this.$t('myAccountManageUsersDetail.components.sideMenu.deleteUser.title'),
        this.$t('myAccountManageUsersDetail.components.sideMenu.deleteUser.confirm', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}),
        {
          type: 'danger',
          buttonConfirmText: '<i class="fas fa-trash-alt fa-fw"></i> ' + this.$t('myAccountManageUsersDetail.components.sideMenu.deleteUser.action'),
          buttonCancelText: '<i class="fas fa-times fa-fw"></i> ' + this.$t('general.cancel'),
        },
      )) {
        try {
          await deleteUser(this.user.userId)
          showSuccessMessage(this.$t('myAccountManageUsersDetail.components.sideMenu.deleteUser.success', {firstName: this.user.firstName, lastName: this.user.lastName, userId: this.user.userId}))
          this.$emit('delete')
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },
  },
}
</script>
