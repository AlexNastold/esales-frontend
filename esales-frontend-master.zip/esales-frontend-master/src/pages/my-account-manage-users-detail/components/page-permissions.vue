<template>
  <div class="page rounded p-lg-3">
    <h2 class="m-0 mb-3">
      <i class="fas fa-shield-alt fa-fw mr-1 d-inline-block d-lg-none" />
      {{ $t('myAccountManageUsersDetail.components.pagePermission.title') }}
    </h2>

    <form
      novalidate
      @submit.prevent="saveUserData">
      <div class="row">
        <!-- Auflistung Berechtigungen -->
        <div
          v-for="permission in permissions"
          :key="permission.permission"
          class="col-12 col-lg-6 col-xl-3">
          <div
            v-if="!permission.editable"
            :title="$t('myAccountManageUsersDetail.components.pagePermission.permissionNotEditableMessage')"
            class="custom-control custom-checkbox mb-3 d-block"
            data-toggle="tooltip">
            <input
              :id="`checkbox-useradm-edit-permission-${permission.permission}`"
              v-model="permission.active"
              :disabled="!permission.editable"
              type="checkbox"
              class="custom-control-input">
            <label
              :for="`checkbox-useradm-edit-permission-${permission.permission}`"
              class="custom-control-label">
              {{ permission.name }} <i class="fas fa-info" />
            </label>
          </div>

          <div
            v-else
            class="custom-control custom-checkbox mb-3 d-block">
            <input
              :id="`checkbox-useradm-edit-permission-${permission.permission}`"
              v-model="permission.active"
              :disabled="!permission.editable"
              type="checkbox"
              class="custom-control-input">
            <label
              :for="`checkbox-useradm-edit-permission-${permission.permission}`"
              class="custom-control-label">
              {{ permission.name }}
            </label>
          </div>
        </div>
      </div>

      <!-- Button Speichern -->
      <div class="mt-3">
        <!-- Button Mobile -->
        <div class="d-lg-none">
          <button
            type="submit"
            class="btn btn-block btn-primary mb-1">
            <app-icon-state
              :is-loading="isEditUserInProcess"
              icon="fas fa-save" />
            {{ $t('general.save') }}
          </button>
        </div>

        <!-- Button Desktop -->
        <div class="d-none d-lg-block text-right">
          <button
            type="submit"
            class="btn btn-primary">
            <app-icon-state
              :is-loading="isEditUserInProcess"
              icon="fas fa-save" />
            {{ $t('general.save') }}
          </button>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
import { redirect } from '@scripts/helper/redirect'
import { createFlashMessage } from '@scripts/helper/flash-messages'
import { confirmDialog } from '@scripts/modules/dialogs'
import { editUserPermissions } from '@scripts/modules/useradm'
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  props: {
    user: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      isEditUserInProcess: false,
      permissions: this.user.permissions.map((permission) => Object.assign({}, permission)),
    }
  },

  computed: {
    isOwnUser () {
      return this.user.userId === this.app.user.userId
    },
  },

  watch: {
    user () {
      this.permissions = this.user.permissions.map((permission) => Object.assign({}, permission))
    },
  },

  mounted () {
    $(this.$el).find('[data-toggle="tooltip"]').tooltip({ placement: 'top' })
  },

  methods: {
    async saveUserData () {
      this.isEditUserInProcess = true

      if (await this.confirmOwnUserEdit()) {
        try {
          const activatedPermissions = this.permissions
            .filter((permission) => permission.editable && permission.active)
            .map((permission) => permission.permission)

          await editUserPermissions(this.user.userId, activatedPermissions)


          if (this.isOwnUser) {
            createFlashMessage(this.$t('myAccountManageUsersDetail.components.pagePermission.successMessage'), 'success')
            redirect('login')
          } else {
            showSuccessMessage(this.$t('myAccountManageUsersDetail.components.pagePermission.successMessage'))
            this.isEditUserInProcess = false
            this.$emit('change')
          }
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
          this.isEditUserInProcess = false
        }
      } else {
        this.isEditUserInProcess = false
      }
    },

    async confirmOwnUserEdit () {
      if (!this.isOwnUser) {
        return true
      }

      return await confirmDialog(
        this.$t('myAccountManageUsersDetail.components.pagePermission.confirmTitle'),
        this.$t('myAccountManageUsersDetail.components.pagePermission.confirmMessage'),
        {
          type: 'warning',
          buttonConfirmText: '<i class="fas fa-save fa-fw"></i> ' + this.$t('general.save'),
          buttonCancelText: '<i class="fas fa-times fa-fw"></i> ' + this.$t('general.cancel'),
        },
      )
    },
  },
}
</script>

