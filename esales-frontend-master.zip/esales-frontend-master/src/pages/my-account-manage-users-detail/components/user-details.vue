<template>
  <div class="border rounded bg-light p-3">
    <div class="row">
      <!-- Benutzerkennung, Name -->
      <div class="col-12 col-sm-6 col-lg-3">
        <div class="font-size-lg font-weight-bold">
          {{ user.firstName }} {{ user.lastName }}
        </div>
        <small class="d-block text-muted">
          {{ $t('myAccountManageUsersDetail.components.userDetails.title') }}: {{ user.userId }}
        </small>
      </div>

      <!-- Kundennummer, Alias -->
      <div class="col-12 col-sm-6 col-lg-3 mt-2 mt-sm-0">
        <div class="row">
          <div class="col-12 col-xl-6 text-muted">
            {{ $t('myAccountManageUsersDetail.components.userDetails.costumerId') }}
          </div>
          <div class="col-12 col-xl-6  mb-1">
            {{ user.kunnr }}
          </div>

          <div class="col-12 col-xl-6 text-muted">
            {{ $t('myAccountManageUsersDetail.components.userDetails.alias') }}
          </div>
          <div class="col-12 col-xl-6">
            {{ user.userAlias }}
          </div>
        </div>
      </div>

      <!-- Gesperrt, AGB bestätigt -->
      <div class="col-12 col-sm-6 col-lg-3 mt-2 mt-lg-0">
        <div class="row">
          <div class="col-12 col-xl-6 text-muted">
            {{ $t('myAccountManageUsersDetail.components.userDetails.locked.title') }}
          </div>
          <div class="col-12 col-xl-6 mb-1">
            <i
              :class="user.isLocked ? 'fa-lock' : 'fa-unlock'"
              class="fas fa-fw" />&nbsp;
            <span v-if="user.isLocked">
              {{ $t('myAccountManageUsersDetail.components.userDetails.locked.true') }}
            </span>
            <span v-else>
              {{ $t('myAccountManageUsersDetail.components.userDetails.locked.false') }}
            </span>
          </div>

          <div class="col-12 col-xl-6 text-muted">
            {{ $t('myAccountManageUsersDetail.components.userDetails.acceptedTerms.title') }}
          </div>
          <div class="col-12 col-xl-6">
            <i
              :class="user.didAcceptTerms ? 'fa-gavel' : 'fa-times'"
              class="fas fa-fw" />&nbsp;
            <span v-if="user.didAcceptTerms">
              {{ $t('myAccountManageUsersDetail.components.userDetails.acceptedTerms.true') }}
            </span>
            <span v-else>
              {{ $t('myAccountManageUsersDetail.components.userDetails.acceptedTerms.false') }}
            </span>
          </div>
        </div>
      </div>

      <!-- Selbstregistriert, Anschreiben versendet -->
      <div class="col-12 col-sm-6 col-lg-3 mt-2 mt-lg-0">
        <div class="row">
          <div class="col-12 col-xl-5 text-muted">
            {{ $t('myAccountManageUsersDetail.components.userDetails.selfRegistered.title') }}
          </div>
          <div class="col-12 col-xl-7 mb-1">
            <i
              :class="user.isSelfRegistered ? 'fa-check' : 'fa-times'"
              class="fas fa-fw" />&nbsp;
            <span v-if="user.isSelfRegistered">
              {{ $t('myAccountManageUsersDetail.components.userDetails.selfRegistered.true') }}
            </span>
            <span v-else>
              {{ $t('myAccountManageUsersDetail.components.userDetails.selfRegistered.false') }}
            </span>
          </div>

          <div class="col-12 col-xl-5 text-muted">
            {{ $t('myAccountManageUsersDetail.components.userDetails.userLetter.title') }}
          </div>
          <div class="col-12 col-xl-7 mb-1">
            <i
              :class="user.letterSent ? 'fa-envelope' : 'fa-times'"
              class="fas fa-fw" />&nbsp;
            <span v-if="user.letterSent">
              {{ $t('myAccountManageUsersDetail.components.userDetails.userLetter.true') }}
            </span>
            <span v-else>
              {{ $t('myAccountManageUsersDetail.components.userDetails.userLetter.false') }}
            </span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    user: {
      type: Object,
      required: true,
    },
  },
}
</script>
