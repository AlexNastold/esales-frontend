<template>
  <div class="page rounded p-lg-3">
    <h2 class="m-0 mb-3">
      <i class="fas fa-key fa-fw mr-1 d-inline-block d-lg-none" />
      {{ $t('myAccountManageUsersDetail.components.pagePassword.title') }}
    </h2>

    <form
      novalidate
      @submit.prevent="saveUserData">
      <div class="row">
        <!-- Initiales Passwort -->
        <div class="col-12 mb-2">
          <div class="custom-control custom-checkbox">
            <input
              id="checkbox-useradm-edit-password-initial"
              v-model="formFields.isInitial"
              type="checkbox"
              class="custom-control-input">
            <label
              for="checkbox-useradm-edit-password-initial"
              class="custom-control-label">
              {{ $t('myAccountManageUsersDetail.components.pagePassword.initial') }}
            </label>
          </div>
        </div>

        <!-- Neues Passwort -->
        <div class="col-12 col-lg-6">
          <div class="form-group">
            <label for="password">
              {{ $t('myAccountManageUsersDetail.components.pagePassword.new') }} <span class="required" />
            </label>
            <input
              id="password"
              v-model="formFields.password"
              :class="{ 'is-invalid': formErrors.password }"
              :disabled="formFields.isInitial"
              type="password"
              class="form-control"
              placeholder="Neues Passwort eingeben">
            <div
              v-if="formErrors.password"
              class="invalid-feedback"
              v-html="formErrors.password" />
          </div>
        </div>

        <!-- Neues Passwort bestätigen -->
        <div class="col-12 col-lg-6">
          <div class="form-group">
            <label for="password-confirmation">
              {{ $t('myAccountManageUsersDetail.components.pagePassword.confirmNew') }} <span class="required" />
            </label>
            <input
              id="password-confirmation"
              v-model="formFields.passwordConfirm"
              :class="{ 'is-invalid': formErrors.passwordConfirm }"
              :disabled="formFields.isInitial"
              type="password"
              class="form-control"
              placeholder="Neues Passwort bestätigen">
            <div
              v-if="formErrors.passwordConfirm"
              class="invalid-feedback"
              v-html="formErrors.passwordConfirm" />
          </div>
        </div>

        <app-form-required-hint class="col-12" />
      </div>

      <!-- Button Speichern -->
      <div class="mt-3">
        <!-- Buttons Mobile -->
        <div class="d-lg-none">
          <button
            type="submit"
            class="btn btn-block btn-primary mb-1">
            <app-icon-state
              :is-loading="isEditUserInProcess"
              icon="fas fa-save" />
            {{ $t('general.save') }}
          </button>
        </div>

        <!-- Buttons Desktop -->
        <div class="d-none d-lg-block text-right">
          <button
            type="submit"
            class="btn btn-primary">
            <app-icon-state
              :is-loading="isEditUserInProcess"
              icon="fas fa-save" />
            {{ $t('general.save') }}
          </button>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
import { editUserPassword, EditUserPasswordFields } from '@scripts/modules/useradm'
import { showErrorMessage, showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'

export default {
  props: {
    user: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      isEditUserInProcess: false,

      formFields: {
        isInitial: this.user.hasInitialPassword,
        password: '',
        passwordConfirm: '',
      },

      formErrors: {
        password: '',
        passwordConfirm: '',
      },
    }
  },

  methods: {
    async saveUserData () {
      this.isEditUserInProcess = true

      try {
        await editUserPassword(
          this.user.userId,
          this.formFields.isInitial,
          this.formFields.password,
          this.formFields.passwordConfirm,
        )

        this.resetFieldErrors()

        showSuccessMessage(this.$t('myAccountManageUsersDetail.components.pagePassword.successMessage'))
        this.formFields.password = ''
        this.formFields.passwordConfirm = ''
        this.$emit('change')
      } catch (e) {
        if (e.code === ErrorCode.INVALID_FIELDS) {
          showErrorMessage(this.$t('general.invalidFieldsMessage'))
          this.showFieldErrors(e.fieldErrors)
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }

      this.isEditUserInProcess = false
    },


    /**
     * Show the field errors
     *
     * @param {any} [fieldErrors] - Field errors
     */
    showFieldErrors (fieldErrors) {
      this.resetFieldErrors()
      for (const fieldname in fieldErrors) {
        if (Object.prototype.hasOwnProperty.call(fieldErrors, fieldname)) {
          const message = fieldErrors[fieldname]
          if (fieldname === EditUserPasswordFields.PASSWORD) {
            this.formErrors.password = message.join('<br>')
          } else if (fieldname === EditUserPasswordFields.PASSWORD_CONFIRM) {
            this.formErrors.passwordConfirm = message.join('<br>')
          }
        }
      }
    },

    /**
     * Reset the field errors
     */
    resetFieldErrors () {
      this.formErrors.password = ''
      this.formErrors.passwordConfirm = ''
    },
  },
}
</script>

