<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-manage-users-detail">
      <!-- Header -->
      <my-account-header
        :headline="$t('myAccountManageUsersDetail.manageUsers')"
        page="manage-users" />

      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item">
            <a href="my-account-manage-users">
              {{ $t('myAccountManageUsersDetail.manageUsers') }}
            </a>
          </li>
          <li
            v-if="isLoading"
            class="breadcrumb-item">
            <app-loading-spinner class="d-inline-block" />
          </li>
          <li
            v-else-if="!user"
            class="breadcrumb-item active text-danger">
            {{ $t('myAccountManageUsersDetail.notFoundBreadcrumb') }}
          </li>
          <li
            v-else
            class="breadcrumb-item active">
            {{ user.firstName }} {{ user.lastName }}
          </li>
        </ol>

        <!-- Ladeanzeige -->
        <app-loading-box v-if="isLoading" />

        <app-box-oops
          v-else-if="!user"
          link-title="Zurück zur Übersicht"
          link-href="my-account-manage-users">
          {{ $t('myAccountManageUsersDetail.notFoundMessage') }}
        </app-box-oops>

        <template v-else>
          <!-- User-Details -->
          <user-details
            :user="user"
            class="mb-3" />

          <div class="row">
            <div class="col-12 col-lg-3">
              <side-menu
                :user="user"
                :page="activePage"
                @navigate="setActivePage"
                @change="loadUser"
                @delete="onUserDelete" />
            </div>
            <div class="col-12 col-lg-9">
              <!-- Seite Benutzerdaten -->
              <page-user-data
                v-show="activePage == 'page-user-data'"
                :user="user"
                @change="loadUser" />

              <!-- Seite Passwort -->
              <page-password
                v-show="activePage == 'page-password'"
                :user="user"
                @change="loadUser" />

              <!-- Seite Berechtigungen -->
              <page-permissions
                v-if="user.userId !== app.user.userId"
                v-show="activePage == 'page-permissions'"
                :user="user"
                @change="loadUser" />

              <!-- Seite Web-Shops -->
              <page-shop-accesses
                v-if="user.shopAccesses"
                v-show="activePage == 'page-shop-accesses'"
                :user="user"
                @change="loadUser" />

              <!-- Seite Kataloge -->
              <page-catalogues
                v-if="user.catalogues"
                v-show="activePage == 'page-catalogues'"
                :user="user"
                @change="loadUser" />

              <!-- Seite Budget & Umsatz -->
              <page-budget
                v-if="user.enableEditOwnBudget"
                v-show="activePage == 'page-budget'"
                :user="user"
                @change="loadUser" />
            </div>
          </div>
        </template>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { redirect } from '@scripts/helper/redirect'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { updateUrlQueryString } from '@scripts/helper/urlUpdate'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'
import { getUser } from '@scripts/modules/useradm'

import MyAccountHeader from '@components/pages/my-account/header.vue'

import PageBudget from './components/page-budget.vue'
import PageCatalogues from './components/page-catalogues.vue'
import PagePassword from './components/page-password.vue'
import PagePermissions from './components/page-permissions.vue'
import PageShopAccesses from './components/page-shop-accesses.vue'
import PageUserData from './components/page-user-data.vue'
import SideMenu from './components/side-menu.vue'
import UserDetails from './components/user-details.vue'

export default {
  components: {
    'my-account-header': MyAccountHeader,

    'page-budget': PageBudget,
    'page-catalogues': PageCatalogues,
    'page-password': PagePassword,
    'page-permissions': PagePermissions,
    'page-shop-accesses': PageShopAccesses,
    'page-user-data': PageUserData,
    'side-menu': SideMenu,
    'user-details': UserDetails,
  },

  data () {
    return {
      activePage: getQueryParameter('page') || 'page-user-data',
      isLoading: true,
      user: void 0,
      userId: getQueryParameter('id'),
    }
  },

  watch: {
    activePage (newValue) {
      updateUrlQueryString({ id: this.userId, page: newValue })
    },
  },

  created () {
    this.setPageTitle(this.$t('myAccountManageUsersDetail.title'))
    this.loadUser()
  },

  methods: {
    setActivePage (page) {
      this.activePage = page
    },

    async loadUser () {
      try {
        this.user = await getUser(this.userId)
        this.setPageTitle(this.$t('myAccountManageUsersDetail.titleDetail', {
          firstName: this.user.firstName,
          lastName: this.user.lastName,
        }))
        this.isLoading = false
      } catch (e) {
        if (e.code === ErrorCode.NOT_FOUND) {
          // Ist okay, nur nicht "this.user" setzen
          this.user = void 0
          this.setPageTitle(this.$t('myAccountManageUsersDetail.notFoundTitle'))
          this.isLoading = false
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },

    onUserDelete () {
      redirect('my-account-manage-users')
    },
  },
}
</script>

<style lang="scss" src="./my-account-manage-users-detail.scss"></style>
