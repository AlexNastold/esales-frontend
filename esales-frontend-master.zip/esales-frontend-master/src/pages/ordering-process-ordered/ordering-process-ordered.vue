<!-- @TRANSLATE -->
<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-ordering-process-ordered">
      <div class="container">
        <!-- Process-Bar -->
        <process-bar step="ordered" />

        <!-- Ladestatus -->
        <app-loading-box v-if="isLoading" />

        <!-- Fehler -->
        <app-box-error v-else-if="error">
          <h3>{{ $t('orderingProcess.errorOccured') }}</h3>
          {{ $t('orderingProcess.errorTryAgainLater') }}
        </app-box-error>

        <!-- Anfrage & Bestellung -->
        <template v-else>
          <h1
            class="headline"
            v-text="lastOrder.isInquiry ? $t('orderingProcess.inquirySuccessful') : $t('orderingProcess.orderSuccessful')" />

          <app-box-success>
            <template v-if="lastOrder.isInquiry">
              <h4>{{ $t('orderingProcess.thanksForInquiry') }}</h4>
              {{ $t('orderingProcess.inquiryWillBeProcessed') }}
              <p class="text-muted">
                {{ $t('orderingProcess.inquiryNumber') }}: {{ lastOrder.number }}
              </p>
            </template>
            <template v-else>
              <h4>{{ $t('orderingProcess.thanksForOrder') }}</h4>
              {{ $t('orderingProcess.orderWillBeProcessed') }}
              <p class="text-muted">
                {{ $t('orderingProcess.orderNumber') }}: {{ lastOrder.number }}
              </p>
            </template>

            <!-- Desktop Buttons -->
            <div class="d-none d-md-block">
              <a
                v-if="app.user.hasPermission('SHOW_NET_PRICE')"
                :href="downloadUriNet"
                class="btn btn-primary">
                <i class="fas fa-print fa-fw" />
                <span v-text="lastOrder.isInquiry ? $t('orderingProcess.printInquiry') : $t('orderingProcess.printOrder')" />
                ({{ $t('orderingProcess.withNetPrices') }})
              </a>

              <a
                :class="app.user.hasPermission('SHOW_NET_PRICE') ? 'btn-secondary' : 'btn-primary'"
                :href="downloadUriRetail"
                class="btn">
                <i class="fas fa-print fa-fw" />
                <span v-text="lastOrder.isInquiry ? $t('orderingProcess.printInquiry') : $t('orderingProcess.printOrder')" />
                <span v-if="app.user.hasPermission('SHOW_NET_PRICE')">
                  ({{ $t('orderingProcess.withoutNetPrices') }})
                </span>
              </a>
            </div>

            <!-- Mobile Buttons -->
            <div class="d-md-none">
              <a
                v-if="app.user.hasPermission('SHOW_NET_PRICE')"
                :href="downloadUriNet"
                class="btn btn-primary btn-block mb-1">
                <i class="fas fa-print fa-fw" />
                <span v-text="lastOrder.isInquiry ? 'Anfrage drucken' : 'Bestellung drucken'" />
                ({{ $t('orderingProcess.withNetPrices') }})
              </a>

              <a
                :class="app.user.hasPermission('SHOW_NET_PRICE') ? 'btn-secondary' : 'btn-primary'"
                :href="downloadUriRetail"
                class="btn btn-block">
                <i class="fas fa-print fa-fw" />
                <span v-text="lastOrder.isInquiry ? 'Anfrage drucken' : 'Bestellung drucken'" />
                <span v-if="app.user.hasPermission('SHOW_NET_PRICE')">
                  ({{ $t('orderingProcess.withoutNetPrices') }})
                </span>
              </a>
            </div>
          </app-box-success>
        </template>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { getLastOrder, getLastOrderDownloadUri } from '@scripts/modules/basket'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

import ProcessBarComponent from '@components/pages/ordering-process/process-bar.vue'

export default {
  components: {
    'process-bar': ProcessBarComponent,
  },

  data () {
    return {
      error: false,
      isLoading: true,
      lastOrder: void 0,

      downloadUriNet: getLastOrderDownloadUri(true),
      downloadUriRetail: getLastOrderDownloadUri(),
    }
  },

  created () {
    this.loadLastOrder()
  },

  methods: {
    async loadLastOrder () {
      try {
        this.lastOrder = await getLastOrder()
        this.setPageTitle(this.lastOrder.isInquiry ? this.$t('orderingProcess.pageTitleInquirySuccessful') : this.$t('orderingProcess.pageTitleOrderSuccessful'))
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
