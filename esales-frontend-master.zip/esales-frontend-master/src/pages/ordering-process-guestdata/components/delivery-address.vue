<template>
  <div class="col-12 col-lg-6">
    <div class="card mb-3">
      <div class="card-header">
        <div class="custom-control custom-checkbox">
          <input
            id="deliveryAddressCheckbox"
            v-model="deliveryAddressIsDeviant"
            type="checkbox"
            class="custom-control-input"
            @change="$emit('onDeviantDeliveryAddressChanged', deliveryAddressIsDeviant)">
          <label
            class="custom-control-label"
            for="deliveryAddressCheckbox">{{ $t('orderingProcessGuestData.deliveryAddress.checkboxLabel') }}</label>
        </div>
      </div>
      <div
        v-if="deliveryAddressIsDeviant"
        class="card-body">
        <!-- Anrede -->
        <div class="form-group">
          <label for="titleDeliveryAddress">
            {{ $t('orderingProcessGuestData.deliveryAddress.title') }}
          </label>
          <select
            id="titleDeliveryAddress"
            v-model="formDeliveryAddress.title"
            class="form-control custom-select">
            <option
              v-for="title in titles"
              :key="title.key"
              :value="title.key"
              v-text="title.label" />
          </select>
        </div>
        <!-- Vorname und Nachname -->
        <div class="form-row">
          <div class="form-group col-sm-6">
            <label for="lastnameDeliveryAddress">
              {{ $t('orderingProcessGuestData.deliveryAddress.lastName') }} <span class="required" />
            </label>
            <input
              id="lastnameDeliveryAddress"
              v-model="formDeliveryAddress.lastname"
              :class="{ 'is-invalid': formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_LASTNAME] }"
              :placeholder="$t('orderingProcessGuestData.deliveryAddress.lastNamePlaceholder')"
              type="text"
              class="form-control"
              maxlength="35">
            <div
              v-if="formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_LASTNAME]"
              class="invalid-feedback"
              v-html="formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_LASTNAME]" />
          </div>
          <div class="form-group col-sm-6">
            <label for="firstnameDeliveryAddress">
              {{ $t('orderingProcessGuestData.deliveryAddress.firstName') }}
            </label>
            <input
              id="firstnameDeliveryAddress"
              v-model="formDeliveryAddress.firstname"
              :placeholder="$t('orderingProcessGuestData.deliveryAddress.firstNamePlaceholder')"
              type="text"
              class="form-control"
              maxlength="35">
          </div>
        </div>
        <!-- Straße und Hausnummer-->
        <div class="form-group">
          <label for="streetDeliveryAddress">
            {{ $t('orderingProcessGuestData.deliveryAddress.street') }}  <span class="required" />
          </label>
          <input
            id="streetDeliveryAddress"
            v-model="formDeliveryAddress.street"
            :class="{ 'is-invalid': formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_STREET] }"
            :placeholder="$t('orderingProcessGuestData.deliveryAddress.streetPlaceholder')"
            type="text"
            class="form-control"
            maxlength="35">
          <div
            v-if="formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_STREET]"
            class="invalid-feedback"
            v-html="formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_STREET]" />
        </div>
        <!-- Postleitzahl und Ort -->
        <div class="form-row">
          <div class="form-group col-sm-3">
            <label for="zipcodeDeliveryAddress">
              {{ $t('orderingProcessGuestData.deliveryAddress.zipcode') }}  <span class="required" />
            </label>
            <input
              id="zipcodeDeliveryAddress"
              v-model="formDeliveryAddress.zipcode"
              :class="{ 'is-invalid': formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_ZIPCODE] }"
              :placeholder="$t('orderingProcessGuestData.deliveryAddress.zipcodePlaceholder')"
              type="text"
              class="form-control"
              maxlength="10">
            <div
              v-if="formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_ZIPCODE]"
              class="invalid-feedback"
              v-html="formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_ZIPCODE]" />
          </div>
          <div class="form-group col-sm-9">
            <label for="cityDeliveryAddress">
              {{ $t('orderingProcessGuestData.deliveryAddress.city') }} <span class="required" />
            </label>
            <input
              id="cityDeliveryAddress"
              v-model="formDeliveryAddress.city"
              :class="{ 'is-invalid': formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_CITY] }"
              :placeholder="$t('orderingProcessGuestData.deliveryAddress.cityPlaceholder')"
              type="text"
              class="form-control"
              maxlength="35">
            <div
              v-if="formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_CITY]"
              class="invalid-feedback"
              v-html="formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_CITY]" />
          </div>
        </div>
        <!-- Land -->
        <div class="form-group">
          <label for="countryDeliveryAddress">
            {{ $t('orderingProcessGuestData.deliveryAddress.country') }} <span class="required" />
          </label>
          <select
            id="countryDeliveryAddress"
            v-model="formDeliveryAddress.country"
            :class="{ 'is-invalid': formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_COUNTRY] }"
            class="form-control custom-select">
            <option
              v-for="country in countries"
              :key="country.key"
              :value="country.key"
              v-text="country.label" />
          </select>
          <div
            v-if="formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_COUNTRY]"
            class="invalid-feedback"
            v-html="formErrors[OrderDataErrorFields.DELIVERY_ADDRESS_COUNTRY]" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { OrderDataErrorFields } from '@scripts/modules/ordering-process-guestdata'

export default {
  props: {
    countries: {
      type: Array,
      required: true,
    },
    titles: {
      type: Array,
      required: true,
    },
    formDeliveryAddress: {
      type: Object,
      required: true,
    },
    formErrors: {
      type: Object,
      required: true,
    },
    deviantDeliveryAddress: {
      type: Boolean,
      required: true,
    },
  },
  data () {
    return {
      OrderDataErrorFields,

      deliveryAddressIsDeviant: this.deviantDeliveryAddress,
    }
  },
}
</script>
