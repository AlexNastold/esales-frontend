<template>
  <div class="col-12">
    <div class="card mb-3">
      <div class="card-header">
        {{ $t('orderingProcessGuestData.contact.header') }}
      </div>
      <div class="card-body">
        <!-- Email Adresse -->
        <div class="form-group">
          <label for="email">
            {{ $t('orderingProcessGuestData.contact.email') }} <span class="required" />
          </label>
          <input
            id="email"
            v-model="formContact.email"
            :class="{ 'is-invalid': formErrors[OrderDataErrorFields.CONTACT_EMAIL_ADDRESS] }"
            :placeholder="$t('orderingProcessGuestData.contact.emailPlaceholder')"
            type="email"
            class="form-control"
            maxlength="70">
          <div
            v-if="formErrors[OrderDataErrorFields.CONTACT_EMAIL_ADDRESS]"
            class="invalid-feedback"
            v-html="formErrors[OrderDataErrorFields.CONTACT_EMAIL_ADDRESS]" />
        </div>
        <!-- Telefonnummer -->
        <div class="form-group">
          <label for="telephone">
            {{ $t('orderingProcessGuestData.contact.phone') }} <span class="required" />
          </label>
          <input
            id="telephone"
            v-model="formContact.phone"
            :class="{ 'is-invalid': formErrors[OrderDataErrorFields.CONTACT_PHONE] }"
            :placeholder="$t('orderingProcessGuestData.contact.phonePlaceholder')"
            type="text"
            class="form-control"
            maxlength="30">
          <div
            v-if="formErrors[OrderDataErrorFields.CONTACT_PHONE]"
            class="invalid-feedback"
            v-html="formErrors[OrderDataErrorFields.CONTACT_PHONE]" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { OrderDataErrorFields } from '@scripts/modules/ordering-process-guestdata'
export default {
  props: {
    formContact: {
      type: Object,
      required: true,
    },
    formErrors: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      OrderDataErrorFields,
    }
  },
}
</script>
