<template>
  <div class="col-12 col-lg-6">
    <div class="card mb-3">
      <div class="card-header">
        {{ $t('orderingProcessGuestData.companyAddress.header') }}
      </div>
      <div class="card-body">
        <!-- Anrede -->
        <div class="form-group">
          <label for="titlefirstnameCompany">
            {{ $t('orderingProcessGuestData.companyAddress.title') }}
          </label>
          <select
            id="titlefirstnameCompany"
            v-model="formCompany.title"
            class="form-control custom-select">
            <option
              v-for="title in titles"
              :key="title.key"
              :value="title.key"
              v-text="title.label" />
          </select>
        </div>
        <!-- Vor und Nachname -->
        <div class="form-row">
          <div class="form-group col-sm-6">
            <label for="lastnameCompany">
              {{ $t('orderingProcessGuestData.companyAddress.lastName') }} <span class="required" />
            </label>
            <input
              id="lastnameCompany"
              v-model="formCompany.lastname"
              :class="{ 'is-invalid': formErrors[OrderDataErrorFields.COMPANY_ADDRESS_LASTNAME] }"
              :placeholder="$t('orderingProcessGuestData.companyAddress.lastNamePlaceholder')"
              type="text"
              class="form-control"
              maxlength="35">
            <div
              v-if="formErrors[OrderDataErrorFields.COMPANY_ADDRESS_LASTNAME]"
              class="invalid-feedback"
              v-html="formErrors[OrderDataErrorFields.COMPANY_ADDRESS_LASTNAME]" />
          </div>
          <div class="form-group col-sm-6">
            <label for="firstnameCompany">
              {{ $t('orderingProcessGuestData.companyAddress.firstName') }}
            </label>
            <input
              id="firstnameCompany"
              v-model="formCompany.firstname"
              :placeholder="$t('orderingProcessGuestData.companyAddress.firstNamePlaceholder')"
              type="text"
              class="form-control"
              maxlength="35">
          </div>
        </div>
        <!-- Kundennummer -->
        <div>
          <div class="form-group">
            <label for="customerNumberCompany">
              {{ $t('orderingProcessGuestData.companyAddress.customerNumber') }}
            </label>
            <input
              id="customerNumberCompany"
              v-model="formCompany.customerId"
              :placeholder="$t('orderingProcessGuestData.companyAddress.customerNumberPlaceholder')"
              type="text"
              class="form-control"
              maxlength="10">
          </div>
        </div>
        <!-- Straße und Hausnummer-->
        <div class="form-group">
          <label for="street">
            {{ $t('orderingProcessGuestData.companyAddress.street') }}  <span class="required" />
          </label>
          <input
            id="street"
            v-model="formCompany.street"
            :class="{ 'is-invalid': formErrors[OrderDataErrorFields.COMPANY_ADDRESS_STREET] }"
            :placeholder="$t('orderingProcessGuestData.companyAddress.streetPlaceholder')"
            type="text"
            class="form-control"
            maxlength="35">
          <div
            v-if="formErrors[OrderDataErrorFields.COMPANY_ADDRESS_STREET]"
            class="invalid-feedback"
            v-html="formErrors[OrderDataErrorFields.COMPANY_ADDRESS_STREET]" />
        </div>
        <!-- Postleitzahl und Ort -->
        <div class="form-row">
          <div class="form-group col-sm-3">
            <label for="zipcodeCompany">
              {{ $t('orderingProcessGuestData.companyAddress.zipcode') }}  <span class="required" />
            </label>
            <input
              id="zipcodeCompany"
              v-model="formCompany.zipcode"
              :class="{ 'is-invalid': formErrors[OrderDataErrorFields.COMPANY_ADDRESS_ZIPCODE] }"
              :placeholder="$t('orderingProcessGuestData.companyAddress.zipcodePlaceholder')"
              type="text"
              class="form-control"
              maxlength="10">
            <div
              v-if="formErrors[OrderDataErrorFields.COMPANY_ADDRESS_ZIPCODE]"
              class="invalid-feedback"
              v-html="formErrors[OrderDataErrorFields.COMPANY_ADDRESS_ZIPCODE]" />
          </div>
          <div class="form-group col-sm-9">
            <label for="cityCompany">
              {{ $t('orderingProcessGuestData.companyAddress.city') }} <span class="required" />
            </label>
            <input
              id="cityCompany"
              v-model="formCompany.city"
              :class="{ 'is-invalid': formErrors[OrderDataErrorFields.COMPANY_ADDRESS_CITY] }"
              :placeholder="$t('orderingProcessGuestData.companyAddress.cityPlaceholder')"
              type="text"
              class="form-control"
              maxlength="35">
            <div
              v-if="formErrors[OrderDataErrorFields.COMPANY_ADDRESS_CITY]"
              class="invalid-feedback"
              v-html="formErrors[OrderDataErrorFields.COMPANY_ADDRESS_CITY]" />
          </div>
        </div>
        <!-- Land -->
        <div class="form-group">
          <label for="countryCompany">
            {{ $t('orderingProcessGuestData.companyAddress.country') }} <span class="required" />
          </label>
          <select
            id="countryCompany"
            v-model="formCompany.country"
            :class="{ 'is-invalid': formErrors[OrderDataErrorFields.COMPANY_ADDRESS_COUNTRY] }"
            class="form-control custom-select">
            <option
              v-for="country in countries"
              :key="country.key"
              :value="country.key"
              v-text="country.label" />
          </select>
          <div
            v-if="formErrors[OrderDataErrorFields.COMPANY_ADDRESS_COUNTRY]"
            class="invalid-feedback"
            v-html="formErrors[OrderDataErrorFields.COMPANY_ADDRESS_COUNTRY]" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { OrderDataErrorFields } from '@scripts/modules/ordering-process-guestdata'

export default {
  props: {
    formCompany: {
      type: Object,
      required: true,
    },
    formErrors: {
      type: Object,
      required: true,
    },
    countries: {
      type: Array,
      required: true,
    },
    titles: {
      type: Array,
      required: true,
    },
  },

  data () {
    return {
      OrderDataErrorFields,
    }
  },
}
</script>
