<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-ordering-process-guestdata">
      <div class="container">
        <process-bar
          step="guest"
          :disable-next-steps="true" />
        <h1 class="headline">
          {{ $t('orderingProcessGuestData.header') }}
        </h1>
        <!-- Ladeanzeige -->
        <app-loading-box v-if="isLoading" />
        <form
          v-else
          @submit.prevent="saveOrderData">
          <div
            v-show="errorMessage"
            class="alert alert-danger"
            role="alert"
            v-html="errorMessage" />

          <div class="row">
            <!-- Kontaktdaten -->
            <contact
              :form-contact="orderData.contact"
              :form-errors="formErrors" />

            <!-- Firmenanschrift -->
            <company-address
              :countries="countries"
              :form-company="orderData.companyAddress"
              :form-errors="formErrors"
              :titles="titles" />

            <!-- Lieferanschrift -->
            <delivery-address
              :countries="countries"
              :deviant-delivery-address="orderData.deviantDeliveryAddress"
              :form-delivery-address="orderData.deliveryAddress"
              :form-errors="formErrors"
              :titles="titles"
              @onDeviantDeliveryAddressChanged="onDeviantDeliveryAddressChanged" />
          </div>

          <div class="row mt-4 mb-2 mt-lg-3">
            <div class="col-12">
              <div class="custom-control custom-checkbox">
                <input
                  id="privacy"
                  v-model="orderData.privacyStatement"
                  :class="{ 'is-invalid': formErrors[OrderDataErrorFields.PRIVACY_STATEMENT] }"
                  class="custom-control-input"
                  type="checkbox">
                <label
                  class="custom-control-label"
                  for="privacy"
                  v-html="$t('orderingProcessGuestData.privacyStatement')" />
                <div
                  v-if="formErrors[OrderDataErrorFields.PRIVACY_STATEMENT]"
                  class="invalid-feedback"
                  v-html="formErrors[OrderDataErrorFields.PRIVACY_STATEMENT]" />
              </div>
            </div>
          </div>

          <app-form-required-hint />

          <!-- Buttons Mobile -->
          <div class="d-block d-lg-none">
            <button
              :disabled="isValidationInProcess"
              type="submit"
              class="btn btn-block btn-primary mt-3">
              <app-icon-state
                :is-loading="isValidationInProcess"
                icon="fas fa-shopping-cart fa-fw" />
              {{ $t('orderingProcessGuestData.buttonProceedToCheckout') }}
            </button>
            <a
              href="basket"
              class="btn btn-block btn-secondary mt-1">
              <i class="fas fa-arrow-left fa-fw" />
              {{ $t('orderingProcessGuestData.buttonBack') }}
            </a>
          </div>
          <!--  Buttons Desktop -->
          <div class="d-none d-lg-block text-right">
            <a
              href="basket"
              class="btn btn-secondary">
              <i class="fas fa-arrow-left fa-fw" />
              {{ $t('orderingProcessGuestData.buttonBack') }}
            </a>
            <button
              :disabled="isValidationInProcess"
              type="submit"
              class="btn btn-primary">
              <app-icon-state
                :is-loading="isValidationInProcess"
                icon="fas fa-shopping-cart fa-fw" />
              {{ $t('orderingProcessGuestData.buttonProceedToCheckout') }}
            </button>
          </div>
        </form>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import CompanyAddress from './components/company-address.vue'
import Contact from './components/contact.vue'
import DeliveryAddress from './components/delivery-address.vue'
import ProcessBarComponent from '@components/pages/ordering-process/process-bar.vue'

import { getOrderData, saveOrderData, OrderDataErrorFields } from '@scripts/modules/ordering-process-guestdata'
import { ErrorCode } from '@scripts/modules/errors'
import { pageSettingsOrderingProccessGuestUser } from '@scripts/app/settings'
import { redirect } from '@scripts/helper/redirect'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  components: {
    Contact,
    'company-address': CompanyAddress,
    'delivery-address': DeliveryAddress,
    'process-bar': ProcessBarComponent,
  },
  data () {
    return {
      isLoading: true,
      isValidationInProcess: false,

      errorMessage: '',

      titles: pageSettingsOrderingProccessGuestUser.titles,
      countries: pageSettingsOrderingProccessGuestUser.countries,

      orderData: {},

      formErrors: {},
      OrderDataErrorFields,

    }
  },
  created () {
    this.setPageTitle(this.$t('orderingProcessGuestData.title'))
    this.getOrderData()
  },
  methods: {
    async getOrderData () {
      try {
        this.orderData = await getOrderData()
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
      this.isLoading = false
    },
    async saveOrderData () {
      this.isValidationInProcess = true

      this.errorMessage = ''
      this.formErrors = {}

      try {
        await saveOrderData(this.orderData)
        this.isValidationInProcess = false
        redirect('checkout')
      } catch (e) {
        this.isValidationInProcess = false
        if (e.code === ErrorCode.INVALID_FIELDS) {
          this.errorMessage = this.$t('general.invalidFieldsMessage')
          this.formErrors = e.fieldErrors
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },

    onDeviantDeliveryAddressChanged (deviantDeliveryAddress) {
      this.orderData.deviantDeliveryAddress = deviantDeliveryAddress
    },
  },
}
</script>

<style lang="scss" src="./ordering-process-guestdata.scss"></style>

<style lang="scss" scoped>
@import '~styles/definitions/all';

</style>
