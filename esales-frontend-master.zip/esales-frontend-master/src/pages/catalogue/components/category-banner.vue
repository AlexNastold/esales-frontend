<template>
  <div
    :class="{ 'no-image': !image }"
    class="category-banner-wrapper">
    <template v-if="image">
      <app-loading-spinner
        v-if="!isImageLoaded"
        class="loader" />
      <transition name="fade">
        <img
          v-show="isImageLoaded"
          :src="src"
          :alt="heading"
          @load="onLoad"
          @error="onError">
      </transition>
    </template>
    <h1 class="category-banner-text h3">
      {{ heading }}
    </h1>
  </div>
</template>

<script>
import { getArticleImageUrl, getNoImageUrl } from '@scripts/modules/images'

export default {
  props: {
    heading: {
      type: String,
      required: true,
    },
    image: {
      type: String,
      required: true,
    },
  },

  data () {
    return {
      isImageLoaded: false,
      tmpSrc: getArticleImageUrl(this.image),
    }
  },

  computed: {
    src: {
      get () {
        return this.tmpSrc
      },
      set (newValue) {
        const newSrc = this.$options.filters.articleImage(newValue)
        if (newSrc !== this.tmpSrc) {
          this.tmpSrc = newSrc
        }
      },
    },
  },

  watch: {
    image (newValue) {
      this.src = newValue
    },
  },

  methods: {
    onLoad () {
      this.isImageLoaded = true
    },
    onError () {
      this.src = getNoImageUrl(),
      this.isImageLoaded = true
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.category-banner-wrapper {
  position: relative;
  overflow: hidden;
  height: auto;
  text-align: center;
  max-height: 160px;

  @include media-breakpoint-up(sm) {
    max-height: 240px;
    line-height: 240px;
  }

  @include media-breakpoint-up(lg) {
    max-height: 300px;
    line-height: 300px;
  }

  .loader {
    padding: #{map-get($spacers, 5)} 0;

    @include media-breakpoint-up(sm) {
      padding: 0;
    }
  }

  img {
    height: auto;
    width: 100%;
    vertical-align: middle;

    @include media-breakpoint-up(sm) {
      position: relative;
      margin: -50% auto;
    }
  }

  .category-banner-text {
    position: absolute;
    line-height: initial;
    left: 0;
    bottom: 1rem;
    padding: 1rem 1.5rem;
    margin: 0;
    background-color: transparentize($gray-200, .1);
    font-size: $h5-font-size;

    @include media-breakpoint-up(sm) {
      font-size: $h3-font-size;
    }
  }

  &.no-image {
    text-align: left;
    line-height: initial !important;

    .category-banner-text {
      position: initial;
      display: inline-block;
    }
  }
}
</style>
