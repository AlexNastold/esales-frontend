<template>
  <div>
    <app-loading-box v-if="isLoading" />
    <div
      v-else
      class="clearfix">
      <div class="row">
        <!-- Auflistung Kategorien -->
        <div
          v-for="category in categoriesToDisplay"
          :key="category.id"
          class="col-12 col-md-6 col-lg-4 col-xl-3 mb-3">
          <category-tile
            :hierarchy-node="category"
            @togglefilter="toggleFilter" />
        </div>

        <!-- Mehr Kategorien anzeigen -->
        <div
          v-if="!showAllCategories && categoriesToDisplay.length < categories.length"
          class="col-12 col-md-6 col-lg-4 col-xl-3 mb-3">
          <category-tile
            :hierarchy-node="showAllNode"
            class="show-more-tile"
            @togglefilter="showAllCategories = true" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { getDeepestActiveHierarchyFilter } from '@scripts/modules/search'

import CategoryTile from './category-tile.vue'

export default {
  components: {
    'category-tile': CategoryTile,
  },

  props: {
    filterData: {
      type: Object,
      required: true,
    },
    isLoading: {
      type: Boolean,
      default: true,
    },
  },

  data () {
    return {
      visibleAmount: 8,
      showAllCategories: false,
      showAllNode: {
        constraints: '',
        field: '',
        hits: 0,
        id: 'dummy',
        image: require('@src/images/icons/ellipsis-h.png'),
        isActive: false,
        label: 'Weitere Kategorien',
        level: 0,
        markedForActivation: false,
        parend: void 0,
        sub: [],
        type: 'DUMMY',
        value: '',
      },
    }
  },

  computed: {
    activeCategory () {
      let activeCategory
      this.filterData.values.some((filter) => {
        if (filter.isActive) {
          activeCategory = getDeepestActiveHierarchyFilter(filter)
          return true
        }
        return false
      })
      return activeCategory
    },
    isCategoryFilterActive () {
      return this.activeCategory !== undefined
    },
    categories () {
      if (this.isCategoryFilterActive) {
        return this.activeCategory.sub
      }
      return this.filterData.values
    },
    categoriesToDisplay () {
      if (this.showAllCategories) {
        return this.categories
      } else {
        return this.categories.slice(0, this.visibleAmount)
      }
    },
  },

  methods: {
    toggleFilter (id, event) {
      this.$emit('togglefilter', id, event)
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.show-more-tile {

  /deep/ {
    .card-img-top {
      width: auto;
    }

    .card-body {
      text-align: center !important;
      color: $font-color;
    }

    .text-muted {
      visibility: hidden;
    }
  }
}
</style>
