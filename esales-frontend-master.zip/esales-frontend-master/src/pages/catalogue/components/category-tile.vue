<template>
  <div
    v-show="visible"
    class="border rounded cursor-pointer component-root"
    @click.prevent="toggleFilter(hierarchyNode.id , $event)">
    <!-- Kategorie Bild -->
    <div class="d-flex align-items-center justify-content-center border-bottom py-1">
      <div class="category-tile-image-wrapper d-flex align-items-center justify-content-center">
        <app-loading-spinner
          v-if="!isImageLoaded"
          class="py-3" />
        <transition name="fade">
          <img
            v-show="isImageLoaded"
            :src="src"
            :alt="hierarchyNode.label"
            @load="onImageLoad"
            @error="onImageError">
        </transition>
      </div>
    </div>

    <div class="px-3 py-1 category-caption">
      <!-- Name -->
      <div
        :title="hierarchyNode.label"
        class="text-truncate font-weight-bold">
        {{ hierarchyNode.label }}
      </div>

      <!-- Anzahl Artikel -->
      <div class="text-muted small">
        {{ $t('catalogue.components.categoryTile.article', { count: hierarchyNode.hits }) }}
      </div>
    </div>
  </div>
</template>

<script>
import { getArticleImageUrl, getNoImageUrl } from '@scripts/modules/images'

export default {
  props: {
    hierarchyNode: {
      type: Object,
      required: true,
    },
    visible: {
      type: Boolean,
      default: true,
    },
  },

  data () {
    return {
      src: getArticleImageUrl(this.hierarchyNode.image),
      isImageLoaded: false,
    }
  },

  computed: {
    hasSub () {
      return this.hierarchyNode.sub.length
    },
  },

  methods: {
    toggleFilter (id, event) {
      this.$emit('togglefilter', id, event)
    },
    onImageLoad () {
      this.isImageLoaded = true
    },
    onImageError () {
      this.src = getNoImageUrl()
      this.isImageLoaded = true
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.component-root {

  &:hover {
    .category-caption {
      text-decoration: underline;
    }
  }

  .category-tile-image-wrapper {
    height: $category-tile-image-wrapper-size;
    width: $category-tile-image-wrapper-size;

    @include media-breakpoint-up(md) {
      height: $category-tile-image-wrapper-size-md;
      width: $category-tile-image-wrapper-size-md;
    }

    img {

      // Fix centering of images inside flex container in IE11.
      // See https://stackoverflow.com/questions/36822370/flexbox-on-ie11-image-stretched-for-no-reason
      flex-shrink: 0;
      height: auto;
      max-height: 100%;
      max-width: 100%;
      width: auto;
    }
  }

}
</style>
