<template>
  <nav aria-label="breadcrumb">
    <ol
      :class="breadcrumbClass"
      class="breadcrumb">
      <li class="breadcrumb-item">
        <a
          href="#"
          @click.prevent="resetCategoryFilters">
          {{ $t('catalogue.components.categoryBreadcrumb.allArticles') }}
        </a>
      </li>
      <li
        v-for="category in categoriesForBreadcrumb"
        :key="category.id"
        :class="{'active': category === activeCategory}"
        :aria-current="category === activeCategory ? 'page' : ''"
        class="breadcrumb-item">
        <a
          v-if="!(category === activeCategory)"
          href="#"
          @click.prevent="activateFilter(category)">
          {{ category.label }}
        </a>
        <template v-else>
          {{ category.label }}
        </template>
      </li>
    </ol>
  </nav>
</template>

<script>
import { getDeepestActiveHierarchyFilter, getParentFilters } from '@scripts/modules/search'

export default {
  props: {
    filterData: {
      type: Object,
      required: true,
    },
    breadcrumbClass: {
      type: String,
      default: 'border-0 m-0 p-0',
    },
  },

  computed: {
    activeCategory () {
      let activeCategory
      this.filterData.values.some((filter) => {
        if (filter.isActive) {
          activeCategory = getDeepestActiveHierarchyFilter(filter)
          return true
        }
        return false
      })
      return activeCategory
    },
    isCategoryFilterActive () {
      return this.activeCategory !== undefined
    },
    categoriesForBreadcrumb () {
      const breadcrumbFilters = []

      if (this.isCategoryFilterActive) {
        breadcrumbFilters.push(...getParentFilters(this.activeCategory), this.activeCategory)
      }

      return breadcrumbFilters
    },
  },

  methods: {
    activateFilter (filter) {
      this.$emit('activatefilter', filter)
    },
    resetCategoryFilters () {
      this.$emit('resetcategoryfilters')
    },
  },
}
</script>
