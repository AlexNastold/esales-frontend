<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-catalogue">
      <div class="container">
        <!-- Breadcrumb -->
        <category-breadcrumb
          v-if="filters.pivots && filters.pivots.length"
          :breadcrumb-class="'border-bottom'"
          :filter-data="filters.pivots[0]"
          class="mb-2"
          @activatefilter="activateFilter"
          @resetcategoryfilters="resetCategoryFilters" />

        <div class="row">
          <!-- Kategorie Banner Mobile -->
          <div class="col-12 d-md-none mb-3">
            <category-banner
              :heading="categoryHeading"
              :image="categoryImage" />
          </div>

          <!-- Auflistung Kategorien Desktop -->
          <div class="col-12 col-md-4 col-lg-3 mb-3 mb-md-0">
            <h3 class="d-none d-md-block mb-3">
              {{ $t('catalogue.categories') }}
            </h3>
            <category-filter
              v-if="filters.pivots && filters.pivots.length"
              :filter-data="filters.pivots[0]"
              :is-loading="isLoading"
              @activatefilter="activateFilter"
              @togglefilter="toggleFilter"
              @resetcategoryfilters="resetCategoryFilters" />
          </div>

          <div class="col-12 col-md-8 col-lg-9">
            <!-- Kategorie Banner Desktop -->
            <div class="d-none d-md-block">
              <category-banner
                :heading="categoryHeading"
                :image="categoryImage"
                class="mb-3" />
            </div>

            <!-- Kategorien -->
            <category-tiles
              v-if="hasSubCategories"
              :filter-data="filters.pivots[0]"
              :is-loading="isLoading"
              class="mb-3"
              @togglefilter="toggleFilter" />

            <!-- Filter -->
            <search-filters
              v-if="showFilters"
              :filters="filters"
              :is-loading="isLoading"
              @applyfilter="applyFilters"
              @resetallfilters="resetAllFilters" />

            <!-- Aktive Filter -->
            <active-filters
              v-if="showFilters"
              :filters="filters"
              :ignore-hierachy-filters="true"
              class="mb-3"
              @search="search" />

            <!-- Filterergebnisse -->
            <template v-if="showSearchResults">
              <div class="d-flex flex-column flex-sm-row align-items-sm-center justify-content-sm-end mb-3">
                <div class="mr-2">
                  {{ $t('catalogue.sortBy.translation') }}
                </div>
                <div class="options">
                  <select
                    v-model="searchOptions.sort"
                    class="form-control custom-select"
                    @change="search">
                    <option value="score desc">
                      {{ $t('catalogue.relevance') }}
                    </option>
                    <option value="price asc">
                      {{ $t('catalogue.sortBy.price.asc') }}
                    </option>
                    <option value="price desc">
                      {{ $t('catalogue.sortBy.price.desc') }}
                    </option>
                    <option value="maktx1 asc">
                      {{ $t('catalogue.sortBy.alphabet.asc') }}
                    </option>
                    <option value="maktx1 desc">
                      {{ $t('catalogue.sortBy.alphabet.desc') }}
                    </option>
                  </select>
                </div>
              </div>

              <!-- Ergebnisse -->
              <search-results
                :search-results="searchResults"
                :is-filtered="!!activeFilters.length"
                :is-loading="isLoading"
                pitcher="catalogue"
                class="mb-3"
                @resetfilters="resetAllFilters" />

              <div class="d-flex flex-column flex-sm-row align-items-sm-center mb-3">
                <div class="mr-2">
                  {{ $t('catalogue.resultsPerPage') }}
                </div>
                <div>
                  <select
                    v-model="searchOptions.rows"
                    class="form-control custom-select"
                    @change="search">
                    <option value="12">
                      12
                    </option>
                    <option value="24">
                      24
                    </option>
                    <option value="48">
                      48
                    </option>
                  </select>
                </div>
              </div>

              <app-pagination
                v-if="numberOfPages > 1"
                :disabled="isLoading"
                :pages="numberOfPages"
                :current-page="currentPage"
                class="d-flex justify-content-center mb-3"
                @change="onPageChange" />
            </template>

            <!-- Topseller -->
            <div v-if="showTopsellers">
              <h3 class="mb-3">
                {{ $t('catalogue.showTopsellers') }}
              </h3>

              <!-- Auflistung Topseller -->
              <div class="list-group">
                <div
                  v-for="article in topsellers"
                  :key="article.matnr"
                  class="list-group-item">
                  <app-article-item
                    :article="article"
                    pitcher="topseller"
                    size="medium" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { getQueryParameter } from '@scripts/helper/urlParams'
import { setUrlChangeHandler, updateUrlQueryString } from '@scripts/helper/urlUpdate'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import {
  activateFilter,
  activateMarkedFilters,
  findFilter,
  getActiveFilters,
  getDeepestActiveHierarchyFilter,
  getParsedResponse,
  parseFilterString,
  resetAllFilters,
  resetHierarchyFilters,
  serializeActiveFilters,
  toggleFilter,
} from '@scripts/modules/search'

import HierarchyFilterComponent from '../search/components/search-filter-type-hierarchy.vue'
import ActiveFiltersComponent from '../search/components/search-filters-active.vue'
import FilterComponent from '../search/components/search-filters.vue'
import ResultComponent from '../search/components/search-results.vue'

import CategoryBreadcrumb from './components/category-breadcrumb.vue'
import CategoryImage from './components/category-banner.vue'
import CategoryTiles from './components/category-tiles.vue'

import { getTopsellers, TopsellerType } from '@scripts/modules/topseller'

import I18n from '@scripts/modules/i18n'

export default {
  components: {
    'active-filters': ActiveFiltersComponent,
    'category-breadcrumb': CategoryBreadcrumb,
    'category-filter': HierarchyFilterComponent,
    'category-banner': CategoryImage,
    'category-tiles': CategoryTiles,
    'search-filters': FilterComponent,
    'search-results': ResultComponent,
  },

  props: {
    defaultQuery: {
      default: '',
      type: String,
    },
    hasFuzzySearch: {
      default: true,
      type: Boolean,
    },
    hasInstantSearch: { // ToDo: Muss noch eingebaut werden
      default: false,
      type: Boolean,
    },
    searchInputSelector: {
      default: 'input[name=q]',
      type: String,
    },
  },

  data () {
    return {
      currentPage: 0,
      customSearchInput: void 0,
      filters: {},
      isLoading: false,
      numberOfHits: 0,
      numberOfPages: 0,
      query: getQueryParameter('q') || this.defaultQuery,
      searchOptions: {
        fq: getQueryParameter('fq') || void 0,
        fuzzy: this.hasFuzzySearch,
        rows: getQueryParameter('rows') ? parseInt(getQueryParameter('rows'), 10) : 12,
        sort: getQueryParameter('sort') || 'score desc',
        start: getQueryParameter('start') ? parseInt(getQueryParameter('start'), 10) : 0,
      },
      searchResults: [],
      topsellers: void 0,
    }
  },

  computed: {
    activeFilters () {

      // Wenn beim Laden der Seite der fq-Parameter übergeben wird,
      // wird dieser für die Suchanfrage verwendet.
      if (!Object.keys(this.filters).length) {
        return parseFilterString(this.searchOptions.fq || '')
      }

      const activeFilters = getActiveFilters(this.filters)

      // Wenn ein Filter per fq-Parameter übergeben wird,
      // der Filterwert aber nicht existiert, trotzdem verwenden
      // -> Keine Treffer anzeigen statt Topsellern
      if (this.searchOptions.fq) {
        const urlFilters = parseFilterString(this.searchOptions.fq)
        urlFilters.forEach((urlFilter) => {
          if (!findFilter(urlFilter.field, urlFilter.values[0], this.filters)) {
            activeFilters.push({
              field: urlFilter.field,
              values: [urlFilter.values[0]],
            })
          }
        })
      }

      return activeFilters
    },
    activeCategory () {

      let activeCategory = void 0

      if (this.filters && this.filters.pivots && this.filters.pivots.length) {
        this.filters.pivots[0].values.forEach((pivotFilter) => {
          if (pivotFilter.isActive) {
            activeCategory = getDeepestActiveHierarchyFilter(pivotFilter)
          }
        })
      }
      return activeCategory
    },
    categoryHeading () {
      if (this.activeCategory) {
        return this.activeCategory.label
      } else {
        return I18n.t('catalogue.components.categoryBreadcrumb.allArticles')
      }
    },
    categoryImage () {
      let categoryImage = ''
      if (this.activeCategory) {
        if (this.activeCategory.headerImage) {
          categoryImage = this.activeCategory.headerImage
        }
      } else {
        categoryImage = require('./images/category-banners/default.png')
      }
      return categoryImage
    },
    hasSubCategories () {
      if (this.activeCategory) {
        return !!this.activeCategory.sub.length
      } else {
        return !!(
          this.filters && this.filters.pivots && this.filters.pivots.length && this.filters.pivots[0].values.length
        )
      }
    },
    showSearchResults () {
      return !!(this.query || this.searchOptions.fq)
    },
    showFilters () {
      return !!(this.query || this.searchOptions.fq)
    },
    showTopsellers () {
      return !this.showSearchResults
    },

    // Computed value that observes multiple data properties
    // for easier watching
    // See https://github.com/vuejs/vue/issues/844#issuecomment-265315349
    urlQueryString () {
      return this.query, this.activeFilters, Date.now()
    },
  },

  watch: {
    urlQueryString () {
      this.setPropertiesToUrl(true)
    },
    showTopsellers (val) {
      if (val === true) {
        this.loadTopsellers()
      }
    },
  },

  created () {
    this.setPageTitle('Katalog')
  },

  async mounted () {
    if (this.searchInputSelector) {
      this.customSearchInput = document.querySelector(this.searchInputSelector)
    }

    if (this.customSearchInput) {

      // Two-Way-Data-Binding simulieren
      this.customSearchInput.value = this.query
      this.$watch(
        function () {
          return this.query
        },
        function (newValue) {
          this.customSearchInput.value = newValue
        },
      )
      this.customSearchInput.addEventListener('input', () => {
        this.query = this.customSearchInput.value
      }, false)

      // Submit-Event abbrechen und Suche ausführen
      if (this.customSearchInput.form) {
        this.customSearchInput.form.addEventListener('submit', (event) => {
          event.preventDefault()
          event.stopImmediatePropagation()
          this.search()
        }, false)
      }

      this.setPropertiesToUrl(false)

      // Beim Navigieren über Browser-Back/-Forward die Suchparameter aus der URL übernehmen
      setUrlChangeHandler(this.updatePropertiesFromUrl)
    }

    const page = this.searchOptions.start ? Math.floor(this.searchOptions.start / this.searchOptions.rows) : 0
    await this.search(page)

    if (this.showTopsellers) {
      this.loadTopsellers()
    }
  },

  methods: {
    async search (page = 0) {
      try {
        this.isLoading = true

        const response = await getParsedResponse(this.query, this.activeFilters, {
          categoriesOnly: !this.query && !this.activeFilters.length ? true : false,
          fuzzy: this.searchOptions.fuzzy,
          rows: this.searchOptions.rows,
          sort: this.searchOptions.sort,
          start: page * this.searchOptions.rows,
          userCatalogue: true,
        })
        this.searchResults = response.searchResults
        this.filters = response.filters
        this.numberOfHits = response.numberOfHits
        this.searchOptions.start = response.start
        this.searchOptions.rows = response.rows ? response.rows : this.searchOptions.rows
        this.numberOfPages = response.numberOfPages
        this.currentPage = response.currentPage

        if (this.activeCategory) {
          this.setPageTitle(this.activeCategory.label)
        } else {
          this.setPageTitle('Katalog')
        }

        this.isLoading = false
      } catch (e) {
        this.isLoading = false
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
    async loadTopsellers () {
      if (!this.topsellers) {
        const data = await getTopsellers(TopsellerType.SHOP, { amount: 20 }) // @TODO Fehler abfangen
        this.topsellers = data.topsellers
      }
    },
    onPageChange (page) {
      this.search(page)
    },
    toggleFilter (id) {
      toggleFilter(id, this.filters)
      this.search()
    },
    activateFilter (filter) {
      activateFilter(filter)
      this.search()
    },
    applyFilters () {
      activateMarkedFilters(this.filters)
      this.search()
    },
    resetCategoryFilters () {
      resetHierarchyFilters(this.filters)
      this.search()
    },
    resetAllFilters () {
      resetAllFilters(this.filters)
      this.searchOptions.fq = void 0
      this.search()
    },
    setPropertiesToUrl (push = true) {
      this.searchOptions.fq = this.activeFilters ? serializeActiveFilters(this.activeFilters) : void 0

      updateUrlQueryString({
        fq: this.searchOptions.fq,
        q: this.query ? this.query : void 0,
        rows: this.searchOptions.rows > 0 ? this.searchOptions.rows : void 0,
        sort: this.searchOptions.sort !== 'score desc' ? this.searchOptions.sort : void 0,
        start: this.searchOptions.start > 0 ? this.searchOptions.start : void 0,
      }, {pushState: push})
    },
    updatePropertiesFromUrl () {
      this.query = getQueryParameter('q') || this.defaultQuery,

      this.searchOptions.fq = getQueryParameter('fq') || void 0
      this.searchOptions.fuzzy = this.hasFuzzySearch
      this.searchOptions.rows = getQueryParameter('rows') ? parseInt(getQueryParameter('rows'), 10) : 12
      this.searchOptions.sort = getQueryParameter('sort') || 'score desc'
      this.searchOptions.start = getQueryParameter('start') ? parseInt(getQueryParameter('start'), 10) : 0

      this.filters = {}
      this.search()
    },
  },
}
</script>
