/* eslint-disable sort-imports */
import PageComponent from '@src/pages/service-contact/service-contact.vue'
import setup from '@scripts/core/setup'
setup(PageComponent)
