<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-service-contact">
      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="service">
              {{ $t('service.dashboard.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('serviceContact.page.breadcrumb') }}
          </li>
        </ol>

        <h1 class="headline">
          {{ $t('serviceContact.page.headline') }}
        </h1>

        <div
          v-show="errorMessage"
          class="alert alert-danger"
          role="alert"
          v-html="errorMessage" />

        <app-box-success v-if="isSent">
          <h2>{{ $t('serviceContact.page.success.headline') }}</h2>
          {{ $t('serviceContact.page.success.message') }}<br>

          <a
            href="service"
            class="btn btn-secondary mt-3">
            {{ $t('serviceContact.page.success.buttonBack') }}
          </a>
        </app-box-success>

        <div
          v-else
          class="row">
          <!-- Kontaktformular -->
          <div class="col-12 col-md-8 col-lg-9 order-2 order-md-1">
            <h3 class="m-0 mb-3">
              {{ $t('serviceContact.page.formHeadline') }}
            </h3>

            <form @submit.prevent="sendMail">
              <!-- Email -->
              <div class="form-group">
                <label>
                  {{ $t('serviceContact.page.fields.email') }}
                  <span class="required" />
                </label>
                <input
                  v-model="formEmail"
                  :class="{'is-invalid': formErrors[MailToClerkFieldErrors.EMAIL]}"
                  :placeholder="$t('serviceContact.page.fields.emailPlaceholder')"
                  type="text"
                  class="form-control">
                <div
                  v-if="formErrors[MailToClerkFieldErrors.EMAIL]"
                  class="invalid-feedback"
                  v-html="formErrors[MailToClerkFieldErrors.EMAIL]" />
              </div>

              <!-- Phone -->
              <div class="form-group">
                <label>
                  {{ $t('serviceContact.page.fields.phone') }}
                </label>
                <input
                  v-model="formPhone"
                  :placeholder="$t('serviceContact.page.fields.phonePlaceholder')"
                  type="text"
                  class="form-control">
              </div>

              <!-- Betreff -->
              <div class="form-group">
                <label>
                  {{ $t('serviceContact.page.fields.subject') }}
                  <span class="required" />
                </label>
                <input
                  v-model="formSubject"
                  :class="{'is-invalid': formErrors[MailToClerkFieldErrors.SUBJECT]}"
                  :placeholder="$t('serviceContact.page.fields.subjectPlaceholder')"
                  type="text"
                  class="form-control"
                  autofocus>
                <div
                  v-if="formErrors[MailToClerkFieldErrors.SUBJECT]"
                  class="invalid-feedback"
                  v-html="formErrors[MailToClerkFieldErrors.SUBJECT]" />
              </div>

              <!-- Nachricht -->
              <div class="form-group">
                <label>
                  {{ $t('serviceContact.page.fields.message') }}
                  <span class="required" />
                </label>
                <textarea
                  v-model="formMessage"
                  :class="{'is-invalid': formErrors[MailToClerkFieldErrors.MESSAGE]}"
                  :placeholder="$t('serviceContact.page.fields.messagePlaceholder')"
                  class="form-control"
                  rows="5" />
                <div
                  v-if="formErrors[MailToClerkFieldErrors.MESSAGE]"
                  class="invalid-feedback"
                  v-html="formErrors[MailToClerkFieldErrors.MESSAGE]" />
              </div>

              <!-- Kopie an mich senden -->
              <div
                v-if="canSendCopy"
                class="custom-control custom-checkbox d-flex align-items-center">
                <input
                  id="service-contact-checkbox-send-copy"
                  v-model="formSendCopy"
                  type="checkbox"
                  class="custom-control-input">
                <label
                  class="custom-control-label"
                  for="service-contact-checkbox-send-copy">
                  {{ $t('serviceContact.page.fields.copy') }}
                </label>
              </div>

              <app-form-required-hint class="my-2" />

              <!-- Absenden Button -->
              <div class="d-md-flex justify-content-end">
                <!-- Button Mobile -->
                <div class="d-md-none">
                  <button
                    :disabled="isProcessing"
                    type="submit"
                    class="btn btn-block btn-primary">
                    <app-icon-state
                      :is-loading="isProcessing"
                      icon="fas fa-paper-plane" />
                    {{ $t('serviceContact.page.actions.send') }}
                  </button>
                </div>

                <!-- Button Desktop -->
                <div class="d-none d-md-block">
                  <button
                    :disabled="isProcessing"
                    type="submit"
                    class="btn btn-primary">
                    <app-icon-state
                      :is-loading="isProcessing"
                      icon="fas fa-paper-plane" />
                    {{ $t('serviceContact.page.actions.send') }}
                  </button>
                </div>
              </div>
            </form>
          </div>

          <!-- Ansprechpartner -->
          <div class="col-12 col-md-4 col-lg-3 order-1 order-mb-2 text-md-center mb-3 mb-md-0">
            <h3 class="m-0 mb-3">
              {{ $t('serviceContact.page.clerkHeadline') }}
            </h3>

            <!-- Bild Sachbearbetier -->
            <div
              v-if="app.user.contactPerson.picture"
              :style="`background-image: url('${$options.filters.externalImage(app.user.contactPerson.picture)}')`"
              class="clerk-image bg-white rounded-circle mx-auto mb-3" />

            <!-- Name -->
            <div class="font-weight-bold font-size-lg text-center mb-2">
              {{ app.user.contactPerson.title }} {{ app.user.contactPerson.lastName }}
            </div>

            <!-- E-Mail Adresse -->
            <div
              v-if="app.user.contactPerson.emailAddress"
              class="text-center mb-1">
              <a
                :href="`mailto:${app.user.contactPerson.emailAddress}`"
                class="icon-link">
                <i class="fas fa-envelope fa-fw" />
                <span class="text">
                  {{ app.user.contactPerson.emailAddress }}
                </span>
              </a>
            </div>

            <!-- Telefonnummer -->
            <div
              v-if="app.user.contactPerson.phone"
              class="text-center mb-1">
              <a
                :href="`tel:${app.user.contactPerson.phone}`"
                class="icon-link">
                <i class="fas fa-phone fa-fw" />
                <span class="text">
                  {{ app.user.contactPerson.phone }}
                </span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { MailToClerkFieldErrors, sendMailToClerk } from '@scripts/modules/service'
import { ErrorCode } from '@scripts/modules/errors'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  data () {
    return {
      isProcessing: false,
      isSent: false,

      errorMessage: '',

      formMessage: '',
      formSendCopy: true,
      formEmail: '',
      formPhone: '',
      formSubject: '',
      formErrors: {},
      MailToClerkFieldErrors,
    }
  },

  computed: {
    canSendCopy () {
      return true
    },
  },

  created () {
    this.setPageTitle(this.$t('serviceContact.page.title'))
    this.formEmail = this.app.user.emailAddress
    this.formPhone = this.app.user.phone
  },

  methods: {
    async sendMail () {
      if (this.isProcessing) {
        return
      }

      this.isProcessing = true
      this.formErrors = ''
      this.errorMessage = ''
      try {
        await sendMailToClerk(
          this.formEmail,
          this.formPhone,
          this.formSubject,
          this.formMessage,
          this.canSendCopy ? this.formSendCopy : false,
        )
        this.isSent = true
      } catch (e) {
        if (e.code === ErrorCode.INVALID_FIELDS) {
          this.errorMessage = this.$t('general.invalidFieldsMessage')
          this.formErrors = e.fieldErrors
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
      this.isProcessing = false
    },
    resetForm () {
      this.formMessage = ''
      this.formSendCopy = true
      this.formSubject = ''
    },
  },
}
</script>

<style lang="scss" src="./service-contact.scss"></style>
