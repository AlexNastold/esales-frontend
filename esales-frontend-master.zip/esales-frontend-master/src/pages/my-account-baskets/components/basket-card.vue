<template>
  <div class="card h-100">
    <!-- Warenkorb aktiv -->
    <div
      class="card-badge"
      :class="{'inactive': !basket.active}"
      @click="activateBasket(basket)">
      <i
        v-if="basket.active"
        :title="$t('myAccountBaskets.components.basketCard.activeBasketBadgeTooltip')"
        class="fas fa-shopping-cart fa-fw"
        data-toggle="tooltip"
        data-placement="top" />
      <i
        v-else
        :title="$t('myAccountBaskets.components.basketCard.setActive')"
        class="fas fa-shopping-cart fa-fw"
        data-toggle="tooltip"
        data-placement="top" />
    </div>

    <!-- Name, Bestellnummer, Anzahl Positionen -->
    <div class="card-body">
      <!-- Name -->
      <template v-if="basket.active">
        <a
          href="basket"
          class="font-weight-bold font-size-lg text-dark">
          {{ basket.name }}
        </a>
      </template>
      <template v-else>
        <div class="font-weight-bold font-size-lg mb-1">
          {{ basket.name }}
        </div>
      </template>

      <!-- Bestellnummer -->
      <div class="mt-1">
        <span class="text-muted">
          {{ $t('myAccountBaskets.components.basketCard.orderNumberLabel') }}:
        </span>
        {{ basket.kommi }}
      </div>

      <!-- Anzahl Positionen -->
      <div class="small mt-1">
        {{ $t('myAccountBaskets.components.basketCard.amountPositions', { count: basket.numPos }) }}
      </div>
    </div>

    <!-- Aktivieren / Löschen Buttons -->
    <div class="card-footer text-right">
      <!-- Button ändern -->
      <a
        :href="`my-account-baskets-edit?id=${encodeURIComponent(basket.name)}`"
        class="btn btn-secondary">
        <i class="fas fa-edit fa-fw" />
      </a>

      <!-- Button löschen -->
      <button
        :disabled="basket.active"
        type="button"
        class="btn btn-secondary"
        @click="deleteBasket(basket)">
        <i class="fas fa-trash-alt fa-fw" />
      </button>
    </div>
  </div>
</template>

<script>
import { confirmDialog, showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { deleteBasket, setBasketActive } from '@scripts/modules/basket'

export default {
  props: {
    basket: {
      type: Object,
      required: true,
    },
  },

  mounted () {
    $(this.$el).find('[data-toggle="tooltip"]').tooltip({ placement: 'top' })
  },

  methods: {
    async activateBasket (basket) {
      try {
        await setBasketActive(basket.name)
        showSuccessMessage(this.$t('myAccountBaskets.components.basketCard.setActiveSuccessMessage', {
          basketName: basket.name,
        }))
        this.$emit('activate')
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },

    async deleteBasket (basket) {
      if (await confirmDialog(
        this.$t('myAccountBaskets.components.basketCard.deleteBasketConfirmTitle'),
        this.$t('myAccountBaskets.components.basketCard.deleteBasketConfirmMessage', {
          basketName: basket.name,
        }),
        {
          type: 'danger',
          buttonConfirmText: `
            <i class="fas fa-trash-alt fa-fw"></i>
            ${this.$t('myAccountBaskets.components.basketCard.deleteBasketConfirmButtonOk')}
          `,
          buttonCancelText: `
            <i class="fas fa-times fa-fw"></i>
            ${this.$t('general.cancel')}
          `,
        },
      )) {
        try {
          await deleteBasket(basket.name)
          showSuccessMessage(this.$t('myAccountBaskets.components.basketCard.deleteBasketSuccessMessage', {
            basketName: basket.name,
          }))
          this.$emit('delete')
        } catch (e) {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.card-badge {
  position: absolute;
  height: 50px;
  width: 50px;
  overflow: hidden;
  right: 0;

  &::before {
    position: absolute;
    content: '';
    cursor: pointer;
    background: $my-account-baskets-color;
    top: -35px;
    right: -35px;
    height: 70px;
    width: 70px;
    transform: rotateZ(-45deg);
  }
  &.inactive::before {
    background: white;
    border: 1px solid $my-account-baskets-color;
  }

  i {
    color: white;
    position: absolute;
    right: 7px;
    top: 7px;
    z-index: 1;
    cursor: pointer;
  }

  &.inactive i {
    color: $my-account-baskets-color;
  }
}
</style>
