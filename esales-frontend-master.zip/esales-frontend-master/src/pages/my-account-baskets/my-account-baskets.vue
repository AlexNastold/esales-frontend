<template>
  <div>
    <!-- Header -->
    <app-layout-header />

    <!-- Navigation -->
    <app-layout-navigation />

    <main class="page-my-account-baskets">
      <!-- My Account Header -->
      <my-account-header
        :headline="$t('myAccountBaskets.headline')"
        page="baskets" />

      <div class="container">
        <!-- Breadcrumb -->
        <ol class="breadcrumb mb-3">
          <li class="breadcrumb-item">
            <a href="my-account">
              {{ $t('myAccount.breadcrumb') }}
            </a>
          </li>
          <li class="breadcrumb-item active">
            {{ $t('myAccountBaskets.breadcrumb') }}
          </li>
        </ol>

        <app-loading-box v-if="isLoading" />
        <template v-else>
          <h3 class="mb-3">
            {{ $t('myAccountBaskets.listHeadline', { count: numberOfBaskets }) }}
          </h3>

          <div class="row">
            <!-- Warenkorb anlegen -->
            <div class="col-12 col-md-6 col-lg-4 col-xl-3 mb-3">
              <a
                href="my-account-baskets-create"
                class="rounded d-flex align-items-center justify-content-center h-100 p-3 add-new-basket">
                <div class="text-center">
                  <div class="text-muted mb-3">
                    <i class="fas fa-plus fa-2x fa-fw" />
                  </div>
                  <strong class="text-dark">
                    {{ $t('myAccountBaskets.addBasket') }}
                  </strong>
                </div>
              </a>
            </div>

            <!-- Auflistung Warenkörbe -->
            <div
              v-for="basket in baskets"
              :key="basket.id"
              class="col-12 col-md-6 col-lg-4 col-xl-3 mb-3">
              <basket-card
                :basket="basket"
                @activate="getBaskets"
                @delete="getBaskets" />
            </div>
          </div>
        </template>
      </div>
    </main>

    <!-- Footer -->
    <app-layout-footer />
  </div>
</template>

<script>
import { getBaskets } from '@scripts/modules/basket'
import { showErrorMessage } from '@scripts/modules/dialogs'

import MyAccountHeader from '@components/pages/my-account/header.vue'

import BasketCard from './components/basket-card.vue'


export default {
  components: {
    'basket-card': BasketCard,
    'my-account-header': MyAccountHeader,
  },

  data () {
    return {
      baskets: [],
      isBasketsLoading: true,
      isLoading: true,

      newBasketActivate: false,
      newBasketName: '',
      newBasketOrderText: '',
    }
  },

  computed: {
    numberOfBaskets () {
      return this.baskets.length
    },
  },

  created () {
    this.setPageTitle(this.$t('myAccountBaskets.title'))

    this.getBaskets()
  },

  methods: {
    async getBaskets () {
      try {
        const data = await getBaskets()
        this.baskets = data.multibaskets
      } catch (e) {
        console.error(e)
        showErrorMessage(e.message)
      }
      this.isLoading = false
    },
  },
}
</script>

<style lang="scss" src="./my-account-baskets.scss"></style>
