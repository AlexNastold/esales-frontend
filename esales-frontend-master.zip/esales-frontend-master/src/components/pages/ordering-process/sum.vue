<template>
  <div class="basket-sum rounded bg-light p-3 mb-3">
    <div class="row">
      <div class="col-12 d-lg-flex justify-content-end">
        <div class="inner">
          <!-- Summe Brutto, Summe Netto -->
          <div class="value underlined mb-1">
            <div
              v-if="app.user.hasPermission('SHOW_NET_PRICE')"
              class="row mb-1">
              <div class="col">
                Summe UVP
              </div>
              <div class="col-auto text-right">
                {{ secondaryPrice.sum | price }}
                {{ secondaryPrice.currency | currency }}
              </div>
            </div>
            <div class="row font-weight-bold mb-1">
              <div class="col">
                Summe
              </div>
              <div class="col-auto text-right">
                {{ primaryPrice.sum | price }}
                {{ primaryPrice.currency | currency }}
              </div>
            </div>
          </div>

          <!-- MwSt Brutto, MwSt Netto -->
          <div class="value underlined mb-1">
            <div
              v-if="app.user.hasPermission('SHOW_NET_PRICE')"
              class="row mb-1">
              <div class="col">
                {{ secondaryPrice.taxRate }}% MwSt. UVP
              </div>
              <div class="col-auto text-right">
                {{ secondaryPrice.taxes | price }}
                {{ secondaryPrice.currency | currency }}
              </div>
            </div>
            <div class="row font-weight-bold mb-1">
              <div class="col">
                {{ primaryPrice.taxRate }}% MwSt.
              </div>
              <div class="col-auto text-right">
                {{ primaryPrice.taxes | price }}
                {{ primaryPrice.currency | currency }}
              </div>
            </div>
          </div>

          <!-- Gesamt Brutto, Gesamt Netto -->
          <div class="total-price">
            <div
              v-if="app.user.hasPermission('SHOW_NET_PRICE')"
              class="row mb-1">
              <div class="col">
                Gesamt UVP
              </div>
              <div class="col-auto text-right">
                {{ secondaryPrice.sumInclTaxes | price }}
                {{ secondaryPrice.currency | currency }}
              </div>
            </div>
            <div class="row text-primary font-weight-bold mb-1">
              <div class="col">
                Gesamt
              </div>
              <div class="col-auto text-right">
                {{ primaryPrice.sumInclTaxes | price }}
                {{ primaryPrice.currency | currency }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    sum: {
      type: Object,
      required: true,
    },
  },

  computed: {
    primaryPrice () {
      if (this.app.user.hasPermission('SHOW_NET_PRICE')) {
        return this.sum.netPrice
      }
      return this.sum.retailPrice
    },
    secondaryPrice () {
      if (this.app.user.hasPermission('SHOW_NET_PRICE')) {
        return this.sum.retailPrice
      }
      return 0
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

// Summenbildung Warenkorb ###################################################################################################################
.basket-sum {

  .inner {
    @include media-breakpoint-up(lg) {
      width: 35%;
    }

    .value {
      &.underlined {
        border-bottom: 1px solid #9b9b9b;
      }
    }

    .total-price {
      font-family: $font-family-headline;
      font-size: $font-size-lg;
      color: $primary-price-color;
    }
  }
}
</style>
