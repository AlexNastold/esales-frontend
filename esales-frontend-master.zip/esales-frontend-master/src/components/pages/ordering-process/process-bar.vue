<template>
  <ul
    v-if="app.state.orderVariant !== OrderVariant.SAP"
    class="component-process-bar mb-4"
    :class="{guest: app.user.isGuest}">
    <li :class="{ active: isActive(steps.basket) }">
      <a
        :aria-disabled="disableStep(steps.basket)"
        :class="{ 'disabled': disableStep(steps.basket) }"
        :href="getHref(steps.basket)"
        class="btn btn-link">
        <i class="fas fa-shopping-cart fa-fw" />
        <span class="text d-none d-md-block">
          {{ $t('basket.components.processBar.basket') }}
        </span>
      </a>
    </li>
    <li
      v-if="app.user.isGuest"
      :class="{ active: isActive(steps.guest) }">
      <a
        :aria-disabled="disableStep(steps.guest)"
        :class="{ 'disabled': disableStep(steps.guest) }"
        :href="getHref(steps.guest)"
        class="btn btn-link">
        <i class="fas fa-user fa-fw" />
        <span class="text d-none d-md-block">
          {{ $t('basket.components.processBar.guestData') }}
        </span>
      </a>
    </li>
    <li :class="{ active: isActive(steps.checkout) }">
      <a
        :aria-disabled="disableStep(steps.basket)"
        :class="{ 'disabled': disableStep(steps.checkout) }"
        :href="getHref(steps.checkout)"
        class="btn btn-link">
        <i class="fas fa-euro-sign" />
        <span class="text d-none d-md-block">
          {{ $t('basket.components.processBar.checkout') }}
        </span>
      </a>
    </li>
    <li :class="{ active: isActive(steps.ordered) }">
      <a
        :class="{ 'disabled btn btn-link': disableStep(steps.ordered) }"
        :aria-disabled="disableStep(steps.basket)">
        <i class="fas fa-check-circle" />
        <span class="text d-none d-md-block">
          {{ $t('basket.components.processBar.ordered') }}
        </span>
      </a>
    </li>
  </ul>
</template>

<script>

import { OrderVariant } from '@scripts/modules/basket'

export default {
  props: {
    step: {
      type: String,
      default: '',
    },
    disableNextSteps: {
      type: Boolean,
      default: false,
    },
  },

  data () {
    return {
      OrderVariant,
      steps: {
        basket: {key: 'basket', link: 'basket', requiresLogin: false, requiredPermissions: []},
        guest: {key: 'guest', link: 'ordering-process-guestdata', requiresLogin: false, requiredPermissions: []},
        checkout: {key: 'checkout', link: 'checkout', requiresLogin: false, requiredPermissions: ['BASKET_ORDER']},
        ordered: {key: 'ordered', link: '', requiresLogin: false, requiredPermissions: ['BASKET_ORDER']},
      },
    }
  },

  methods: {
    isActive (step) {
      return this.step === step.key
    },
    isNextStep (step) {
      switch (this.step) {
        case this.steps.basket.key:
          return step === this.steps.guest || step === this.steps.checkout || step === this.steps.ordered
        case this.steps.guest.key:
          return step === this.steps.checkout || step === this.steps.ordered
        case this.steps.checkout.key:
          return step === this.steps.ordered
        default:
          return false
      }
    },
    hasPermission (step) {
      if (step.requiredPermissions.length === 0) {
        return true
      }
      return this.app.user.hasPermission(step.requiredPermissions)
    },
    disableStep (step) {
      if (this.app.user.isLoggedIn) {
        return !this.hasPermission(step) || (this.disableNextSteps ? this.isNextStep(step) : false)
      } else  {
        return (this.disableNextSteps ? this.isNextStep(step) : false)
      }
    },
    getHref (step) {
      if (step.requiresLogin && !this.app.user.isLoggedIn) {
        return `login?redirecturl=${encodeURIComponent(step.link)}`
      }
      return step.link
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

$items: 3;
$itemsIsGuest: 4;

.component-process-bar {
  @include clearfix;

  clear: both;
  font-size: 1rem;
  list-style-type: none;
  margin: 0 -1px;
  padding: 0;
  width: 100%;

  li {
    background: $process-bar-item-background-color;
    color: #232323;
    float: left;
    height: $process-bar-height;
    position: relative;
    width: calc((100% - #{($items - 1) * $process-bar-margin-between}) / #{$items});

    &:not(:first-child) {
      &::before {
        border-bottom: ($process-bar-height / 2) solid transparent;
        border-left: 17px solid #fff;
        border-top: ($process-bar-height / 2) solid transparent;
        content: '';
        left: 0;
        position: absolute;
        top: 0;
      }
    }

    &:not(:last-child) {
      margin-right: $process-bar-margin-between;

      &::after {
        border-bottom: ($process-bar-height / 2) solid transparent;
        border-left: 17px solid $process-bar-item-background-color;
        border-top: ($process-bar-height / 2) solid transparent;
        content: '';
        left: 100%;
        position: absolute;
        top: 0;
        z-index: 1;
      }
    }

    &.active {
      background: $process-bar-active-item-background-color;


      @if (lightness($process-bar-active-item-background-color) > 50%) {
        color: $font-color;
      } @else {
        color: white;
      }

      &::after {
        border-left-color: $process-bar-active-item-background-color;
      }
    }

    a {
      align-items: center;
      color: inherit;
      display: flex;
      font-size: inherit;
      height: 100%;
      justify-content: center;
      text-decoration: none;
      width: 100%;

      i {
        margin-left: 17px;
      }
    }

    @include media-breakpoint-up(md) {
      height: $process-bar-height-md;

      &:not(:first-child) {
        &::before {
          border-bottom: ($process-bar-height-md / 2) solid transparent;
          border-top: ($process-bar-height-md / 2) solid transparent;
        }
      }

      &:not(:last-child) {
        &::after {
          border-bottom: ($process-bar-height-md / 2) solid transparent;
          border-top: ($process-bar-height-md / 2) solid transparent;
        }
      }

      a {
        i {
          margin-right: 3px;
        }
      }
    }
  }
  &.guest > li {
    width: calc((100% - #{($itemsIsGuest - 1) * $process-bar-margin-between}) / #{$itemsIsGuest});
  }
}
</style>
