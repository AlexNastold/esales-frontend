<template>
  <!-- Zusatzinformationen -->
  <div
    v-if="!position.partList.isPartListArticle || position.partList.isHead"
    :class="{'ml-5' : position.partList.isPartListArticle && !position.partList.isHead}"
    class="mt-3">
    <!-- Referenz-Beleg -->
    <template v-if="position.referenceDocument">
      <div class="mb-2">
        {{ position.referenceDocument.documentType | documentTypeTitle }}
        <a
          :href="documentReferenceLink"
          :title="$t('basket.components.positionItem.referenceDocumentLinkTitle')"
          class="reference icon-link">
          <i class="fas fa-file fa-fw" />
          <span class="text">
            {{ position.referenceDocument.documentIdDisplay }}
          </span>
        </a>
        - {{ $t('general.position') }} {{ position.referenceDocument.documentPosnrDisplay }}
      </div>
    </template>

    <!-- Wunschlieferdatum -->
    <template v-if="!position.hasError && app.user.hasPermission('BASKET_POSITION_DATE') && flags.canHaveDesiredDeliveryDate">
      <div class="d-block d-sm-inline-block mr-sm-1">
        <i class="fas fa-calendar-alt fa-fw" />
        <span
          v-html="$t('basket.components.positionItem.desiredDeliveryDate', {
            date: $options.filters.date(position.desiredDeliveryDate),
          })" />
      </div>
      <!-- Platzhalter für spezifischen Content -->
      <slot name="delivery-date-addition" />
    </template>

    <!-- Positionstext -->
    <template v-if="!position.hasError && position.customerText && app.user.hasPermission('BASKET_POSITION_TEXT') && flags.canHaveCustomerText">
      <div class="d-md-flex mt-2">
        <div class="d-block d-sm-inline-block text-nowrap">
          <i class="far fa-comment" />
          {{ $t('basket.components.positionItem.positionText') }}&nbsp;
        </div>
        <div class="d-block d-sm-inline-block mr-sm-1 text-break">
          {{ position.customerText }}
        </div>
        <!-- Platzhalter für spezifischen Content -->
        <slot name="position-text-addition" />
      </div>
    </template>
  </div>
</template>

<script>
import { getDocumentReferenceLink } from '@scripts/modules/documents'

export default {
  props: {
    position: {
      type: Object,
      required: true,
    },
    flags: {
      type: Object,
      required: true,
    },
  },

  computed: {
    documentReferenceLink () {
      if (!this.position.referenceDocument) {
        return void 0
      }

      return getDocumentReferenceLink(
        this.position.referenceDocument.documentType,
        this.position.referenceDocument.documentId,
      )
    },
  },
}
</script>

