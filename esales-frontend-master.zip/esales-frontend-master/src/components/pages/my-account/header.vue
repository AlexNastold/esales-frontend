<template>
  <div
    :class="page"
    class="my-account-header mb-3">
    <div class="d-block d-md-none">
      <div
        class="user-meta"
        @click="toggleMobileMenu">
        <div class="container">
          <div class="d-flex align-items-center">
            <!-- Benutzerinformationen Mobil -->
            <div>
              <strong>{{ app.user.lastName }} {{ app.user.firstName }}</strong><br>
              <small>
                {{ $t('myAccount.userMeta.customerNumber') }}: {{ app.user.kunnr }}<br>
                <span
                  v-if="app.user.alias"
                  class="text-muted">
                  {{ $t('myAccount.userMeta.userId') }}: {{ app.user.alias }} ({{ app.user.userId | removeLeadingZeros }})
                </span>
                <span
                  v-else
                  class="text-muted">
                  {{ $t('myAccount.userMeta.userId') }}: {{ app.user.userId | removeLeadingZeros }}
                </span>
              </small>
            </div>

            <!-- Menu Mobil -->
            <div class="ml-auto d-block d-md-none">
              <i
                v-if="isMobileMenuOpen"
                class="fas fa-angle-up fa-fw p-3 text-primary" />
              <i
                v-else
                class="fas fa-angle-down fa-fw p-3 text-primary" />
            </div>
          </div>
        </div>
      </div>
      <div class="d-block d-md-none">
        <my-account-menu
          v-show="isMobileMenuOpen"
          :page="page"
          :colors="true" />
      </div>
    </div>
    <div class="d-block d-md-none">
      <div class="container">
        <div class="text-white text-center py-4">
          <h2 class="m-0">
            {{ headline }}
          </h2>
        </div>
      </div>
    </div>
    <div class="container d-none d-md-block">
      <div class="row">
        <div class="col d-flex align-items-center text-white">
          <h1 class="m-0">
            {{ headline }}
          </h1>
        </div>
        <div class="col-md-5 col-lg-4 col-xl-3">
          <!-- Benutzerinformationen Desktop -->
          <div
            :class="page"
            class="user-meta d-flex align-items-center p-3">
            <div>
              <strong>{{ app.user.lastName }} {{ app.user.firstName }}</strong><br>
              <small>
                {{ $t('myAccount.userMeta.customerNumber') }}: {{ app.user.kunnr }}<br>
                <span v-if="app.user.alias">
                  {{ $t('myAccount.userMeta.userId') }}: {{ app.user.alias }} ({{ app.user.userId | removeLeadingZeros }})
                </span>
                <span v-else>
                  {{ $t('myAccount.userMeta.userId') }}: {{ app.user.userId | removeLeadingZeros }}
                </span>
              </small>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MyAccountMenu from '@components/pages/my-account/menu.vue'

export default {
  components: {
    'my-account-menu': MyAccountMenu,
  },

  props: {
    page: {
      type: String,
      default: void 0,
    },
    headline: {
      type: String,
      default: '',
    },
  },

  data () {
    return {
      isMobileMenuOpen: false,
    }
  },

  methods: {
    toggleMobileMenu () {
      this.isMobileMenuOpen = !this.isMobileMenuOpen
    },
  },
}
</script>

