<template>
  <div
    :class="{ 'with-colors': colors }"
    class="my-account-menu">
    <ul>
      <!-- Logout -->
      <li>
        <a
          href="#"
          class="text-primary"
          @click.prevent="logout">
          <i class="fas fa-sign-out-alt fa-fw" />&nbsp;
          {{ $t('layoutNavigation.menu.logout') }}
        </a>
      </li>

      <!-- Dashboard -->
      <li :class="{active: page === 'dashboard'}">
        <a
          href="my-account"
          class="dashboard">
          <i class="fas fa-user fa-fw" />&nbsp;
          {{ $t('myAccount.menuTitle') }}
        </a>
      </li>

      <!-- Listen -->
      <li
        v-if="app.user.hasPermission('LISTS')"
        :class="{active: page === 'lists'}">
        <a
          href="my-account-lists"
          class="lists">
          <i class="fas fa-file-alt fa-fw" />&nbsp;
          {{ $t('myAccountLists.list.menuTitle') }}
        </a>
      </li>

      <!-- Topseller -->
      <li
        v-if="app.user.hasPermission('TOPSELLER_PERSONAL')"
        :class="{active: page === 'my-topsellers'}">
        <a
          href="my-account-topsellers"
          class="my-topsellers">
          <i class="fas fa-chart-line fa-fw" />&nbsp;
          {{ $t('myAccountTopseller.menuTitle') }}
        </a>
      </li>
      <li
        v-else-if="app.user.hasPermission('TOPSELLER_CUSTOMER')"
        :class="{active: page === 'topsellers-customer-number'}">
        <a
          href="my-account-topsellers-customer"
          class="my-topsellers">
          <i class="fas fa-chart-line fa-fw" />&nbsp;
          {{ $t('myAccountTopseller.menuTitle') }}
        </a>
      </li>

      <!-- Belege -->
      <template v-if="app.user.hasPermission('DOCUMENTS')">
        <li :class="{active: page === 'documents'}">
          <a
            href="my-account-documents"
            class="documents">
            <i class="fas fa-folder-open fa-fw" />&nbsp;
            {{ $t('myAccountDocuments.menuTitle') }}
          </a>
        </li>
        <!-- Belege Bestellungen -->
        <li
          v-if="app.user.hasPermission('DOCUMENTS_AUFTRAG')"
          class="sub">
          <a
            :href="`my-account-documents?doctype=${encodeURIComponent(DocumentType.AUFTRAG)}`"
            class="documents">
            {{ DocumentType.AUFTRAG | documentTypeTitlePlural }}
          </a>
        </li>
        <!-- Belege Angebote -->
        <li
          v-if="app.user.hasPermission('DOCUMENTS_ANGEBOT')"
          class="sub">
          <a
            :href="`my-account-documents?doctype=${encodeURIComponent(DocumentType.ANGEBOT)}`"
            class="documents">
            {{ DocumentType.ANGEBOT | documentTypeTitlePlural }}
          </a>
        </li>
        <!-- Belege Hauptabrufe -->
        <li
          v-if="app.user.hasPermission('DOCUMENTS_HAUPTABRUF')"
          class="sub">
          <a
            :href="`my-account-documents?doctype=${encodeURIComponent(DocumentType.HAUPTABRUF)}`"
            class="documents">
            {{ DocumentType.HAUPTABRUF | documentTypeTitlePlural }}
          </a>
        </li>
        <!-- Blege Rechnungen -->
        <li
          v-if="app.user.hasPermission('DOCUMENTS_RECHNUNG')"
          class="sub">
          <a
            :href="`my-account-documents?doctype=${encodeURIComponent(DocumentType.RECHNUNG)}`"
            class="documents">
            {{ DocumentType.RECHNUNG | documentTypeTitlePlural }}
          </a>
        </li>
        <li class="sub">
          <a
            href="my-account-documents"
            class="d-flex align-items-center documents">
            {{ $t('myAccountDocuments.menuTitleFurtherDocs') }}
            <i class="fas fa-angle-right fa-fw ml-auto" />
          </a>
        </li>
      </template>

      <!-- Zuletzte angesehen Artikel -->
      <li
        v-if="app.user.hasPermission('LAST_SEEN_ARTICLES')"
        :class="{active: page === 'last-articles'}">
        <a
          href="my-account-last-articles"
          class="last-articles">
          <i class="fas fa-history fa-fw" />&nbsp;
          {{ $t('myAccountLastArticles.list.menuTitle') }}
        </a>
      </li>

      <!-- Warenkörbe -->
      <li
        v-if="app.user.hasPermission('BASKETS_MANAGE')"
        :class="{active: page === 'baskets'}">
        <a
          href="my-account-baskets"
          class="baskets">
          <i class="fas fa-shopping-cart fa-fw" />&nbsp;
          {{ $t('myAccountBaskets.list.menuTitle') }}
        </a>
      </li>

      <!-- Benutzer wechseln -->
      <li
        v-if="app.user.isAdma"
        class="highlight">
        <a
          href="login-adma">
          <i class="fas fa-user-secret fa-fw" />&nbsp;
          {{ $t('loginAdma.menuTitle') }}
        </a>
      </li>
    </ul>
  </div>
</template>

<script>
import { redirect } from '@scripts/helper/redirect'
import { logout } from '@scripts/modules/auth'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { DocumentType } from '@scripts/modules/documents'

export default {
  props: {
    page: {
      type: String,
      default: '',
    },
    colors: {
      type: Boolean,
      default: false,
    },
  },

  data () {
    return {
      DocumentType,
    }
  },

  methods: {
    async logout () {
      try {
        await logout()
        redirect('login')
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>
