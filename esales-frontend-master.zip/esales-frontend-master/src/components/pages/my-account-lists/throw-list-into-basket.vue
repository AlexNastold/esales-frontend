<template>
  <div>
    <button
      :class="buttonClass"
      :disabled="isProcessing"
      type="button"
      class="btn"
      @click="onClick">
      <app-icon-state
        :is-loading="isProcessing"
        icon="fas fa-shopping-cart" />
      <span v-if="!isIconOnly">
        {{ $t('myAccountLists.detail.actions.addListToBasket') }}
      </span>
    </button>

    <!-- Auswahldialog Warenkorb -->
    <dialog-basket-selection
      v-if="isModalOpen"
      @select="onBasketSelect"
      @hidden="isModalOpen = false" />
  </div>
</template>

<script>
import { getBaskets } from '@scripts/modules/basket'
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { throwList } from '@scripts/modules/lists'
import { AddToBasketMode } from '@scripts/modules/user-settings'

import DialogBasketSelection from '@components/dialogs/DialogBasketSelection.vue'

export default {
  components: {
    'dialog-basket-selection': DialogBasketSelection,
  },

  props: {
    isIconOnly: {
      type: Boolean,
      default: false,
    },
    buttonClass: {
      type: String,
      default: 'btn-primary',
    },
    list: {
      type: Object,
      required: true,
    },
  },

  data () {
    return {
      baskets: [],

      isProcessing: false,
      isModalOpen: false,
    }
  },

  methods: {
    async onClick () {
      switch (this.app.user.settings.addToBasketMode) {
        // Immer Dialog öffnen
        case AddToBasketMode.OPEN_DIALOG_ALWAYS:
          this.isModalOpen = true
          break

        // Dialog nur öffnen, wenn es mehr als eine Warenkorb gibt
        case AddToBasketMode.OPEN_DIALOG_MULTIPLE_BASKETS:
          try {
            this.baskets = (await getBaskets()).multibaskets

            if (this.baskets.length > 1) {
              this.isModalOpen = true
            } else {
              this.addToBasket()
            }
          } catch (e) {
            console.error(e)
            showTechnicalErrorMessage()
          }
          break

        // Dialgo niemals öffnen
        case AddToBasketMode.OPEN_DIALOG_NEVER:
          this.addToBasket()
          break
      }
    },

    onBasketSelect (basket) {
      this.addToBasket(basket)
    },

    async addToBasket (basket) {
      this.isProcessing = true

      try {
        if (basket) {
          await throwList(this.list.id, basket.name)
          showSuccessMessage(this.$t('myAccountDocuments.list.listHasBeenThrownToBasket', { basketName: basket.name }))
        } else {
          await throwList(this.list.id)
          showSuccessMessage(this.$t('myAccountDocuments.list.listHasBeenThrown'))
        }
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.isProcessing = false
    },
  },
}
</script>

