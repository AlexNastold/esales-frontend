<template>
  <div
    :class="statusClass"
    class="badge badge-pill py-1 d-lg-inline-block d-xl-inline-block">
    {{ statusText }}
  </div>
</template>

<script>
import { DocumentStatus, getDocumentStatusTitle } from '@scripts/modules/documents'

export default {
  props: {
    status: {
      type: String,
      default: void 0,
    },
  },

  computed: {
    statusText () {
      return getDocumentStatusTitle(this.status)
    },
    statusClass () {
      switch (this.status) {
        case DocumentStatus.OPEN: return 'status-open'
        case DocumentStatus.PARTLY_COMPLETED: return 'status-partly-done'
        case DocumentStatus.COMPLETED: return 'status-done'
        case DocumentStatus.CANCELED: return 'status-canceled'
        default: return 'status-unknown'
      }
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.status-open {
  background: $status-open-background-color;
  color: $status-open-color;
}

.status-partly-done {
  background: $status-partly-done-background-color;
  color: $status-partly-done-color;
}

.status-done {
  background: $status-done-background-color;
  color: $status-done-color;
}

.status-canceled {
  background: $status-canceled-background-color;
  color: $status-canceled-color;
}

.status-unknown {
  background: $status-unknown-background-color;
  color: $status-unkown-color;
}
</style>
