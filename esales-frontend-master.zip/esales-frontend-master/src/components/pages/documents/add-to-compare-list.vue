<template>
  <div>
    <button
      type="button"
      class="btn btn-block btn-tertiary d-md-none">
      <i class="fas fa-plus fa-fw" />
      {{ $t('myAccountDocuments.components.compareList.addDocument') }}
    </button>
    <button
      type="button"
      class="btn btn-tertiary d-none d-md-inline-block">
      <i class="fas fa-plus fa-fw" />
      {{ $t('myAccountDocuments.components.compareList.addDocument') }}
    </button>
  </div>
</template>
