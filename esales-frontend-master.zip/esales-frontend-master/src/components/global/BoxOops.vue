<template>
  <div class="text-center p-5">
    <i class="fas fa-fire fa-7x mb-2 text-danger" /><br>
    <span
      class="headline text-uppercase"
      v-html="$t('components.boxOops.headline')" />
    <div class="p-2">
      <span class="text-muted">
        {{ $t('components.boxOops.description') }}
      </span>
      <div class="mt-2 mt-md-0 font-weight-bold">
        <slot />
      </div>
    </div>
    <div
      v-if="linkTitle"
      class="mt-2">
      <a
        :href="linkHref"
        class="btn btn-outline-danger text-uppercase">
        {{ linkTitle }}
      </a>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    linkTitle: {
      default: void 0,
      type: String,
    },
    linkHref: {
      default: void 0,
      type: String,
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.headline {
  font-size: 2.5rem;

  @include media-breakpoint-up(md) {
      font-size: 5rem;
  }
}
</style>

