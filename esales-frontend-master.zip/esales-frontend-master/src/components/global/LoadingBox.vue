<template>
  <div class="component-page-loading d-flex align-items-center justify-content-center">
    <app-loading-spinner v-if="visible" />
  </div>
</template>

<script>
export default {
  props: {
    delay: {
      default: 100,
      type: Number,
    },
  },

  data () {
    return {
      visible: this.delay ? false : true,
    }
  },

  created () {
    if (this.delay) {
      setTimeout(() => this.visible = true, this.delay)
    }
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.component-page-loading {
  color: $text-muted;
  height: 150px;
}
</style>

