<template>
  <component
    :is="component"
    :article="article"
    :additional-data="additionalData"
    :is-additional-data-loading="isAdditionalDataLoading"
    :has-error="hasError"
    :pitcher="pitcher"
    :error-message="errorMessage"
    @amountChange="(newAmount) => $emit('amountChange', newAmount)"
    @updatedList="(listId) => $emit('updatedList', listId)">
    <div slot="buttons-after-amount">
      <slot name="buttons-after-amount" />
    </div>
    <div slot="buttons">
      <slot name="buttons" />
    </div>
  </component>
</template>

<script>
import { getSingleAdditionalArticleData } from '@scripts/modules/additional-article-data'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

import ArticleItemListLarge from './article-item/ArticleItemListLarge.vue'
import ArticleItemListMedium from './article-item/ArticleItemListMedium.vue'
import ArticleItemTile from './article-item/ArticleItemTile.vue'

export default {
  props: {
    article: {
      required: true,
      type: Object,
    },
    pitcher: {
      required: true,
      type: String,
    },
    size: {
      default: 'large',
      validator (value) {
        return value === 'large' || value === 'medium'
      },
      type: String,
    },
    type: {
      default: 'list',
      type: String,
      validator (value) {
        return value === 'list' || value === 'tile'
      },
    },
  },

  data () {
    return {
      additionalData: void 0,
      errorMessage: '',
      hasError: false,
      isAdditionalDataLoading: true,
    }
  },

  computed: {
    component () {
      if (this.type === 'tile') {
        return ArticleItemTile
      }
      if (this.size === 'medium') {
        return ArticleItemListMedium
      }
      return ArticleItemListLarge
    },
  },

  async created () {
    try {
      this.additionalData = await getSingleAdditionalArticleData(this.article.matnr)
      this.hasError = this.additionalData.hasError
      this.errorMessage = this.additionalData.error
      this.isAdditionalDataLoading = false
    } catch (e) {
      console.error(e)
      showTechnicalErrorMessage()
    }
  },
}
</script>
