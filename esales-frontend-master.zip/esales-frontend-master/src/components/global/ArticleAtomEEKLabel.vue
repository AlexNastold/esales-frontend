<template>
  <div
    v-if="eekIcon && classes.length == 1"
    class="component-eek-label">
    <img
      :src="eekIcon"
      class="eek-icon"
      :alt="$t('general.eekLogo')">
  </div>
  <div
    v-else-if="eekIcon && classes.length > 1"
    ref="tooltip"
    :title="eekTooltip"
    class="component-eek-label">
    <img
      :src="eekIcon"
      class="eek-icon"
      :alt="$t('general.eekLogo')">
  </div>
</template>

<script>
import { getEEKIconUrl, getEEKUrlByClasses } from '@scripts/modules/eek'
import I18n from '@scripts/modules/i18n'

export default {
  props: {
    classes: {
      default () {
        return []
      },
      type: Array,
    },
  },

  computed: {
    eekIcon () {
      return getEEKUrlByClasses(this.classes)
    },
    eekTooltip () {
      if (this.classes.length > 1) {
        const rows = this.classes.map(this.getHtmlForClass)
        return rows.length ? `<div class="container">${rows.join('')}</div>` : void 0
      }
      return void 0
    },
    tooltipTemplate () {
      return `<div class="tooltip component-eek-label-tooltip" role="tooltip">
              <div class="arrow"></div>
              <div class="tooltip-inner"></div>
            </div>
          `
    },
  },

  watch: {
    eekTooltip () {
      $(this.$refs.tooltip).tooltip('dispose')

      // Tooltip asynchron initialisieren, da DOM asynchron geändert wird (Vue)
      setTimeout(() => {
        $(this.$refs.tooltip).tooltip({
          html: true,
          placement: 'bottom',
          template: this.tooltipTemplate,
        })
      }, 200)
    },
  },

  mounted () {
    $(this.$refs.tooltip).tooltip({
      html: true,
      placement: 'bottom',
      template: this.tooltipTemplate,
    })
  },

  beforeDestroy () {
    $(this.$refs.tooltip).tooltip('dispose')
  },

  methods: {
    getHtmlForClass (eekClass) {
      return `<div class="row">
        <div class="col-3"><img class="eek-icon" src="${getEEKIconUrl(eekClass.class)}" alt="${I18n.t('general.eekLogo')}" /></div>
        <div class="col-9 text text-truncate">${eekClass.text}</div>
      </div>`
    },
  },
}
</script>

<style lang="scss" scoped>
.component-eek-label {
  height: 20px;

  .eek-icon {
    height: 100%;
  }
}
</style>

<!-- Tooltip darf nicht scoped sein, da er im body hängt -->
<style lang="scss">
.component-eek-label-tooltip {
  width: auto;

  .tooltip-inner {
    text-align: left;

    .eek-icon {
      display: block;
      height: 16px;
    }
  }
}
</style>


