<template>
  <span
    ref="additionalMaterialCategoriesTooltip"
    :title="title"
    class="badge badge-info p-1">
    <i
      class="fas fa-cogs" />
    {{ $t( 'general.additionalArticles' ) }}
  </span>
</template>

<script>
export default {
  props: {
    additionalMaterialCategories: {
      required: true,
      type: Array,
    },
  },

  computed: {
    title () {
      return this.additionalMaterialCategories
        .map((category) => category.label)
        .join('<br>')
    },
  },

  watch: {
    title () {
      $(this.$refs.additionalMaterialCategoriesTooltip).tooltip('dispose')

      // Tooltip asynchron initialisieren, da DOM asynchron geändert wird (Vue)
      setTimeout(() => {
        $(this.$refs.additionalMaterialCategoriesTooltip).tooltip({
          placement: 'bottom',
          html: true,
        })
      }, 200)
    },
  },

  mounted () {
    $(this.$refs.additionalMaterialCategoriesTooltip).tooltip({
      placement: 'bottom',
      html: true,
    })
  },

  beforeDestroy () {
    $(this.$refs.additionalMaterialCategoriesTooltip).tooltip('dispose')
  },
}
</script>
