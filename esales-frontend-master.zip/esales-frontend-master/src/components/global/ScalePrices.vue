<template>
  <table
    :class="{ 'table-striped': striped }"
    class="table table-sm">
    <thead>
      <tr>
        <th class="td-inline pr-3 border-top-0">
          {{ $t('general.amount') }}
        </th>
        <th class="text-right border-top-0">
          <span>{{ priceText }}</span>
        </th>
      </tr>
    </thead>
    <tbody>
      <tr
        v-for="(price, index) in prices"
        :key="index">
        <td class="td-inline pr-3">
          {{ $t('article.components.additionalInformation.scaledPrices.from') }} {{ price.quantity | sapNumber(omitUnnecessaryDecimals = true) }} {{ price.volumeUnit }}
        </td>
        <td class="text-right">
          <strong>
            {{ price.price | price }} {{ price.currency | replaceCurrencyWithSign }} / {{ price.costUnit | sapNumber(omitUnnecessaryDecimals = true) }} {{ price.volumeUnit }}
          </strong>
        </td>
      </tr>
    </tbody>
  </table>
</template>

<script>
export default {
  props: {
    prices: {
      required: true,
      type: Array,
    },
    priceLabel: {
      default: '',
      type: String,
    },
    striped: {
      default: true,
      type: Boolean,
    },
  },

  computed: {
    priceText () {
      return this.priceLabel || this.$t('article.components.additionalInformation.scaledPrices.price')
    },
  },
}
</script>
