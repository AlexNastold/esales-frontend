<template>
  <input
    ref="query"
    v-model="searchQuery"
    :placeholder="typeof placeholder !== 'undefined' ? placeholder : $t('components.formInputProductSearch.placeholderDefault')"
    :disabled="isDisabled"
    type="input"
    @focus="focus"
    @keyup.enter="close">
</template>

<script>
import I18n from '@scripts/modules/i18n'
import { axiosBackend } from '@scripts/core/axios'
import { debounce } from 'throttle-debounce'
import { detailLink } from '@scripts/helper/generateLink'
import { redirect } from '@scripts/helper/redirect'

export default {
  props: {
    maxItems: {
      default: 5,
      type: Number,
    },
    placeholder: {
      default: void 0,
      type: String,
    },
    value: {
      default: '',
      type: String,
    },
    isDisabled: {
      default: false,
      type: Boolean,
    },
  },

  data () {
    return {
      searchQuery: this.value,
    }
  },

  watch: {
    searchQuery (value) {
      this.$emit('input', value)
      this.$emit('searchQueryChanged', value)
    },
  },

  mounted () {
    this.initAutocomplete()
  },

  beforeDestroy () {
    const $searchInput = $(this.$refs.query)
    try {
      $searchInput.typeahead('destroy')
    } catch (e) {
      // Ist okay
    }
  },

  methods: {
    initAutocomplete () {
      const $searchInput = $(this.$refs.query)
      // eslint-disable-next-line @typescript-eslint/no-this-alias
      const that = this

      let response = {}
      $searchInput.typeahead({
        hint: false,
        minLength: 3,
      }, {
        async: true,
        display: 'term',
        limit: Infinity,
        name: 'search-suggest-dataset',
        templates: {
          header: `<h6 class="m-2">
                    ${I18n.t('components.formInputProductSearch.searchSuggest')}
                  </h6>`,
          notFound: `<h6 class="m-2">
                      ${I18n.t('components.formInputProductSearch.searchSuggest')}
                     </h6>
                     <div class="tt-notfound">
                      ${I18n.t('components.formInputProductSearch.noResults')}
                     </div>`,
          pending () {
            return `<h6 class="m-2">
                      ${I18n.t('components.formInputProductSearch.searchSuggest')}
                    </h6>
                    <div class="tt-pending">
                      <i class="fas fa-circle-notch fa-spin fa-fw"></i>
                    </div>`
          },
        },
        source: debounce(500, async (query, syncResults, asyncResults) => {
          try {
            const result = await axiosBackend.get('webservices/search.ws', { params: {
              handler: 'SUGGEST',
              query,
            }})
            response = result
            asyncResults(result.suggest.searchSuggestions[query.replace(/\s+/g, ' ').trim()].suggestions)
          } catch (e) {
            console.error(e)
            // Im Fehlerfall ein leeres Ergebnis zurückgeben
            asyncResults([])
          }
        }),
      }, {
        async: true,
        display: 'maktx1',
        limit: Infinity,
        name: 'product-suggest-dataset',
        source: debounce(500, async (query, syncResults, asyncResults) => {
          try {
            const result = await axiosBackend.get('webservices/search.ws', { params: {
              fuzzy: true,
              handler: 'SEARCH',
              fq: this.$store.getters.getActiveCategory.filterQuery,
              query,
              rows: this.maxItems,
            }})

            response = result

            asyncResults(result.response.docs)
          } catch (e) {
            console.error(e)
            // Im Fehlerfall ein leeres Ergebnis zurückgeben
            asyncResults([])
          }
        }),
        templates: {
          header: `<h6 class="m-2">
                    ${I18n.t('components.formInputProductSearch.productSuggest')}
                  </h6>`,
          notFound: `<h6 class="m-2">
                       ${I18n.t('components.formInputProductSearch.productSuggest')}
                     </h6>
                    <div class="tt-notfound">
                      ${I18n.t('components.formInputProductSearch.noResults')}
                    </div>`,
          pending () {
            return `<h6 class="m-2">
                      ${I18n.t('components.formInputProductSearch.productSuggest')}
                    </h6>
                    <div class="tt-pending">
                      <i class="fas fa-circle-notch fa-spin fa-fw"></i>
                    </div>`
          },
          suggestion (item) {
            const $suggestion = $(`
              <div class="container">
                <div class="row">
                  <div class="col-auto">
                    <div class="image-wrapper d-flex justify-content-center align-items-center">
                      <img src="${that.$options.filters.articleImage(item.picture)}" alt="${that.$t('components.formInputProductSearch.productImage')}" />
                    </div>
                  </div>
                  <div class="col py-1">
                    <div class="text">${item.name}</div>
                    <div class="matnr text-muted small">${item.bismt} ${that.getEAN(item)}</div>
                    <div class="matnr text-muted small">${item.supplier?item.supplier:''} ${that.getSupplierMatnr(item)}</div>
                  </div>
                </div>
              </div>
            `)
            $suggestion.mark(item._query, {
              className: 'tt-highlight',
              element: 'span',
            })
            return $suggestion.get(0).outerHTML
          },
          footer (data) {
            if ((response.response.numFound - data.suggestions.length) > 0) {
              return `
              <div class="tt-footer text-right p-2">
                <a class="btn btn-primary" href="search?q=${$searchInput.val()}" role="button">
                  ${response.response.numFound - data.suggestions.length} ${I18n.t('components.formInputProductSearch.moreResults')}
                </a>
              </div>
            `
            }
          },
        },
      })

      $searchInput.on('typeahead:select typeahead:autocomplete', (e, selectedItem) => {
        if (Object.prototype.hasOwnProperty.call(selectedItem, 'bismt')) {
          redirect(detailLink(selectedItem.matnr, selectedItem.maktx1, selectedItem.maktx2))
        } else {
          redirect('search', {
            q: selectedItem.term,
            fq: this.$store.getters.getActiveCategory ? this.$store.getters.getActiveCategory.filterQuery : '',
          })
        }
      })
    },

    getEAN (item) {
      return item.ean11 !== '' ? '// ' + item.ean11 : ''
    },

    getSupplierMatnr (item) {
      return item.supplier_matnr !== '' ? '// ' + item.supplier_matnr : ''
    },

    focus () {
      const $searchInput = $(this.$refs.query)
      if (this.value === '') {
        this.searchQuery = $searchInput.val()
      }
      $searchInput.focus()
    },

    close () {
      const $searchInput = $(this.$refs.query)
      $searchInput.typeahead('close')
    },
  },
}
</script>