<template>
  <!-- OLTP nicht verfügbar -->
  <transition name="oltp">
    <div
      v-if="shouldBeDisplayed"
      class="bg-danger text-white text-center p-2">
      <i class="fas fa-exclamation-triangle fa-fw" />
      <strong>{{ $t('layoutHeader.oltpMessageTitle') }}</strong>
      <small>{{ $t('layoutHeader.oltpMessage') }}</small>
    </div>
  </transition>
</template>

<script>
export default {
  computed: {
    shouldBeDisplayed () {
      return !this.app.state.app.isOltpAvailable
    },
  },
}
</script>


<style lang="scss" scoped>
.oltp-leave-active {
  transition: max-height 0.2s ease-in-out;
  overflow: hidden;
}
.oltp-enter-active,
.oltp-leave {
  max-height: 100px;
}
.oltp-enter,
.oltp-leave-active {
  max-height: 0;
}
</style>
