<template>
  <header>
    <notifications classes="vue-notification-esales" />
    <div class="container">
      <!-- Logo -->
      <div class="py-2 py-md-4 logo-wrapper">
        <a href="index">
          <!-- Logo Mobile -->
          <img
            :src="logoSmall"
            class="logo d-md-none"
            alt="fis-gmbh-logo">

          <!-- Logo Desktop -->
          <img
            :src="logoLarge"
            class="logo d-none d-md-inline-block"
            alt="fis-gmbh-logo">
        </a>
      </div>
    </div>
  </header>
</template>

<script>
// eslint-disable-next-line @typescript-eslint/no-var-requires
const logoLarge = require('@src/images/logo-large-harolds.png')
// eslint-disable-next-line @typescript-eslint/no-var-requires
const logoSmall = require('@src/images/logo-small-harolds.png')

export default {
  data () {
    return {
      logoLarge,
      logoSmall,
    }
  },
}
</script>
