<template>
  <header
    :class="{'sticky-top-md': isHeaderSticky }">
    <!-- Oltp nicht verfügbar -->
    <oltp-message />
    <notifications classes="vue-notification-esales" />

    <!-- Logo, Suchleiste, Listen-Icon, Warenkorb -->
    <div class="searchbar">
      <div class="container">
        <div class="row py-2 py-md-2">
          <!-- Logo -->
          <div class="col-auto">
            <a
              href="index"
              class="logo-wrapper d-block">
              <!-- Logo Mobile -->
              <img
                :src="logoSmall"
                class="logo d-lg-none"
                alt="fis-gmbh-logo">

              <!-- Logo Desktop -->
              <img
                :src="logoLarge"
                class="logo d-none d-lg-block"
                alt="fis-gmbh-logo">
            </a>
          </div>

          <!-- Suchleiste -->
          <div class="col mt-md-2">
            <form
              v-if="app.user.hasPermission('SEARCH')"
              ref="searchForm"
              :action="action">
              <input
                type="hidden"
                name="fq"
                :value="$store.getters.getActiveCategory.filterQuery">
              <div class="input-group flex-nowrap">
                <div
                  v-if="categories.length > 0"
                  class="d-none d-md-block dropdown input-group-prepend">
                  <button
                    id="globalSearchCategoryDropdown"
                    data-filterquery=""
                    class="btn btn-secondary dropdown-toggle"
                    type="button"
                    data-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                    v-html="$store.getters.getActiveCategory.label.length <= 25 ? $store.getters.getActiveCategory.label : $store.getters.getActiveCategory.label.substr(0,20) + '...'" />
                  <div
                    class="dropdown-menu"
                    aria-labelledby="globalSearchCategoryDropdown">
                    <a
                      class="dropdown-item"
                      href="#"
                      @click="selectCategory(void 0)"
                      v-html="$t('components.formInputProductSearch.allCategories')" />
                    <a
                      v-for="category in categories"
                      :key="category.label"
                      class="dropdown-item"
                      href="#"
                      @click="selectCategory(category)"
                      v-html="category.label" />
                  </div>
                </div>
                <app-form-input-product-search-global
                  ref="formInputProductSearch"
                  class="form-control"
                  name="q"
                  @searchQueryChanged="checkSearchQuery" />
                <div class="input-group-append">
                  <app-scan-button
                    :scan-options="{'page':'search'}"
                    @success="onScanSuccess" />
                  <button
                    type="submit"
                    class="btn btn-primary">
                    <i class="fas fa-search fa-fw" />
                  </button>
                </div>
              </div>
            </form>
          </div>

          <!-- Listen -->
          <div
            v-if="app.user.hasPermission('LISTS')"
            class="col-auto d-none d-lg-block mt-2">
            <a
              href="my-account-lists"
              class="lists font-size-sm d-block">
              <i class="fas fa-file-alt" />
              <span class="text">
                {{ $t('myAccountLists.list.menuTitle') }}
              </span>
            </a>
          </div>

          <!-- Warenkorb -->
          <div class="col-auto d-none d-md-block mt-2">
            <a
              href="basket"
              class="basket font-size-sm d-block">
              <i class="fas fa-shopping-cart" />
              <transition name="fade">
                <span
                  class="badge badge-pill badge-primary">
                  {{ $store.getters.getAmountBasketPositions }}
                </span>
              </transition>
              <span class="text">
                {{ $t('basket.menuTitle') }}
              </span>
            </a>
          </div>
        </div>
      </div>
    </div>
  </header>
</template>

<script>
import { redirect } from '@scripts/helper/redirect'

import OltpMessage from './OltpMessage'

import { getShopCategories } from '@scripts/modules/shop-categories'

import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

import { setActiveCatalogueCategoryToStore } from '@scripts/modules/search'

// eslint-disable-next-line @typescript-eslint/no-var-requires
const logoLarge = require('@src/images/logo-large-harolds.png')
// eslint-disable-next-line @typescript-eslint/no-var-requires
const logoSmall = require('@src/images/logo-small-harolds.png')

export default {
  components: {
    'oltp-message': OltpMessage,
  },

  props: {
    isHeaderSticky: {
      default: true,
      type: Boolean,
    },
  },

  data () {
    return {
      logoLarge,
      logoSmall,
      categories: [],
      maxCategories: 10,
      action: 'catalogue',
    }
  },

  created () {
    this.loadCategories()
  },

  methods: {
    checkSearchQuery (value) {
      if (!(value)) {
        this.action = 'catalogue'
      } else {
        this.action = 'search'
      }
    },
    async loadCategories () {
      try {
        const { categories } = await getShopCategories(this.maxCategories)
        this.categories = categories
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },

    selectCategory (category) {
      setActiveCatalogueCategoryToStore(true, category ? {
        filterQuery: category.filterQuery,
        label: category.label,
      } : void 0)
    },

    onScanSuccess (text) {
      redirect('search', {
        q: text,
      })
    },
  },
}
</script>

<style lang="scss" scoped>
  @import '~styles/definitions/all';
    .sticky-top-md {
      @include media-breakpoint-up(md) {
        position: -webkit-sticky;
        position: sticky;
        top: 0;
        z-index: $bootstrap-zindex-sticky;
      }
    }
</style>
