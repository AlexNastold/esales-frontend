<!--
Diese Komponente nicht mit "v-model" verwenden,
da das Property "value" zu einer SAP-Nummer konvertiert wird

Benutzer tippt: 1
Event input triggert mit 1
Property value wird durch v-model auf 1 gesetzt
Wert wird zu SAP-Nummer 1,00 konvertiert
Im Feld steht 1,00 (ohne dass der Benutzer ,00 getippt hat)
-->
<template>
  <input
    v-if="isPrice"
    :value="value | price"
    type="text"
    @input.self="onInput">
  <input
    v-else
    :value="value | sapNumber"
    type="text"
    @input.self="onInput">
</template>

<script>
import { numberToSapNumber, sapNumberToNumber, numberToSapCurrency } from '@scripts/helper/sapFormat'

export default {
  props: {
    fallback: {
      default: void 0,
      type: Number,
    },
    isPrice: {
      default: false,
      type: Boolean,
    },
    value: {
      default: 0,
      type: Number,
    },
  },

  data () {
    return {
      sapValue: this.isPrice ? numberToSapCurrency(this.value) : numberToSapNumber(this.value),
    }
  },

  computed: {
    jsValue () {
      return sapNumberToNumber(this.sapValue)
    },
  },

  watch: {
    value (newValue) {
      this.sapValue = this.isPrices ? numberToSapCurrency(newValue) : numberToSapNumber(newValue)
    },
  },

  methods: {
    onInput (e) {
      this.sapValue = e.target.value
      this.$emit('input', this.jsValue, this.sapValue)
    },
  },
}
</script>
