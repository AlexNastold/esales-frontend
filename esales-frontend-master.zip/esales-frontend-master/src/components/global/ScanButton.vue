<template>
  <span>
    <button
      :class="buttonClass"
      :tabindex="tabindex"
      :disabled="isDisabled"
      type="button"
      class="btn"
      @click="onClick">
      <app-icon-state
        :is-loading="isModalOpen"
        icon="fas fa-barcode" />
    </button>
    <!-- Scandialog -->
    <dialog-scan
      v-if="isModalOpen"
      @success="onScanSuccess"
      @hidden="isModalOpen = false" />
  </span>
</template>

<script>
import DialogScan from '@components/dialogs/DialogScan.vue'
import browserStore from '@scripts/core/browserStore'

export default {
  components: {
    'dialog-scan': DialogScan,
  },

  props: {
    buttonClass: {
      default: 'btn-light',
      type: String,
    },
    isDisabled: {
      default: false,
      type: Boolean,
    },
    scanOptions: {
      default: void 0,
      type: Object,
    },
    tabindex: {
      default: void 0,
      type: Number,
    },
  },

  data () {
    return {
      isModalOpen: false,
    }
  },

  methods: {
    onClick () {
      this.isModalOpen = browserStore.get('InAppBrowser') === true ? false : true
    },

    onScanSuccess (text) {
      this.$emit('success', text)
    },
  },
}
</script>
