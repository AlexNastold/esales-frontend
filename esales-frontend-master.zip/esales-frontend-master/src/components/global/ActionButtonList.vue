<template>
  <span>
    <button
      :class="buttonClass"
      :disabled="disabled || isProcessing"
      :title="$t('general.actionButtons.addToListButtonLabel')"
      type="button"
      class="btn"
      @click="onClick">
      <app-icon-state
        :is-loading="isProcessing"
        icon="fas fa-file-alt" />
      <span v-if="!isIconOnly">
        {{ $t('general.actionButtons.addToListButtonLabel') }}
      </span>
    </button>

    <!-- Auswahldialog Warenkorb -->
    <dialog-list-selection
      v-if="isModalOpen"
      @select="onListSelect"
      @hidden="isModalOpen = false" />
  </span>
</template>

<script>
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { addArticleToList } from '@scripts/modules/lists'

import DialogListSelection from '@components/dialogs/DialogListSelection.vue'

export default {
  components: {
    'dialog-list-selection': DialogListSelection,
  },

  props: {
    amount: {
      default: 1,
      type: Number,
    },
    buttonClass: {
      default: 'btn-secondary',
      type: String,
    },
    disabled: {
      default: false,
      type: Boolean,
    },
    isIconOnly: {
      default: false,
      type: Boolean,
    },
    matnr: {
      required: true,
      type: String,
    },
  },

  data () {
    return {
      lists: [],

      isModalOpen: false,
      isProcessing: false,
    }
  },

  methods: {
    async onClick () {
      this.isModalOpen = true
    },

    onListSelect (list) {
      this.addToList(list)
    },

    async addToList (list) {
      this.isProcessing = true

      try {
        await addArticleToList(list.id, this.matnr, this.amount)
        showSuccessMessage(this.$t('general.actionButtons.addToSpecificListSuccessMessage', {basketName: list.name}))
        this.$emit('updated', list.id)
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.isProcessing = false
    },
  },
}
</script>
