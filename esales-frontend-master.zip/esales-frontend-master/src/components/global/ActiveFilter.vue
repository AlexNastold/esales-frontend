<template>
  <button
    :class="`btn-outline-${type}`"
    type="button"
    class="btn btn-sm mb-1 mr-1 d-flex align-items-center"
    @click="onClick">
    <span
      :class="typeof value !== 'undefined' ? 'with-colon' : ''"
      class="label">
      {{ label }}
    </span> <!-- Keinen Zeilenumbruch, da sonst ein Leerzeichen vor dem Doppelpunkt ist -->
    <span class="value text-truncate ml-1">
      {{ value }}
    </span>
    <i class="fas fa-times fa-fw ml-1" />
  </button>
</template>

<script>
export default {
  props: {
    label: {
      required: true,
      type: String,
    },
    type: {
      default: 'primary',
      type: String,
    },
    value: {
      default: void 0,
      type: String,
    },
  },

  methods: {
    onClick (e) {
      this.$emit('click', e)
    },
  },
}
</script>

<style lang="scss" scoped>
button {
  .label {

    &.with-colon {
      &:after {
        content: ':';
      }
    }
  }

  .value {
    max-width: 150px;
  }
}
</style>
