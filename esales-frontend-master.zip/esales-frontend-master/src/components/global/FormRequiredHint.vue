<template>
  <div class="small">
    <span v-html="$t('components.formRequiredHint.description')" />
  </div>
</template>
