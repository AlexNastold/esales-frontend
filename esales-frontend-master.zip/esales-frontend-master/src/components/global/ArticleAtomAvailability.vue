<template>
  <div class="component-availability text-truncate">
    <app-loading-spinner v-if="isLoading" />
    <div
      v-else
      :class="className">
      {{ text }}
      <a
        v-if="showAdditionalInfo"
        ref="availabilityPopover"
        class="availability-popover"
        :class="className"
        tabindex="0"
        role="button"
        data-toggle="popover"
        data-trigger="focus"
        :title="text"
        :data-content="popoverText">
        <i class="fas fa-info-circle fa-fw" />
      </a>
    </div>
  </div>
</template>

<script>
import moment from 'moment'
import { AvailabilityFlag } from '@scripts/modules/additional-article-data'

import I18n from '@scripts/modules/i18n'

export default {
  props: {
    availability: {
      default () {
        return {}
      },
      type: Object,
    },
    isLoading: {
      default: false,
      type: Boolean,
    },
  },

  computed: {
    className () {
      if (this.availability) {
        switch (this.availability.availabilityFlag) {
          case AvailabilityFlag.AVAILABLE:
            return 'in-stock'
          case AvailabilityFlag.SHORTLY_AVAILABLE:
            return 'deliverable'
          case AvailabilityFlag.NOT_AVAILABLE:
            return 'not-available'
        }
      }
      return ''
    },
    text () {
      if (this.availability) {
        switch (this.availability.availabilityFlag) {
          case AvailabilityFlag.AVAILABLE:
            return I18n.t('general.availabilityTexts.isAvailable')
          case AvailabilityFlag.SHORTLY_AVAILABLE:
            return I18n.t('general.availabilityTexts.shortlyAvailable')
          case AvailabilityFlag.NOT_AVAILABLE:
            return I18n.t('general.availabilityTexts.notAvailable')
        }
      }
      return ''
    },
    showAdditionalInfo () {
      return this.availability
        && (this.availability.shortly
          || this.availability.directly
          || this.availability.replenishmentDate)
    },
    popoverText () {
      let newText = ''
      if (this.availability) {
        if (this.availability.directly) {
          newText = `${newText}${I18n.t('general.availabilityTexts.infoDirectlyAvailable', { amount: this.availability.directly, vkme: this.availability.unit })}<br>`
        }
        if (this.availability.shortly) {
          newText = `${newText}${I18n.t('general.availabilityTexts.infoShortlyAvailable', { amount: this.availability.shortly, vkme: this.availability.unit })}<br>`
        }
        if (this.availability.replenishmentDate) {
          const formatedDate = moment(new Date(this.availability.replenishmentDate)).format('DD.MM.YYYY')
          newText = `${newText}${I18n.t('general.availabilityTexts.infoReplenishmentDate', { date: formatedDate })}<br>`
        }
      }
      return newText
    },
  },
  watch: {
    popoverText () {
      $(this.$refs.availabilityPopover).popover('dispose')

      // Popover asynchron initialisieren, da DOM asynchron geändert wird (Vue)
      setTimeout(() => {
        $(this.$refs.availabilityPopover).popover({
          html: true,
          container: 'body',
        })
      }, 200)
    },
  },
  mounted () {
    $(this.$refs.availabilityPopover).popover({
      html: true,
      container: 'body',
    })
  },
  beforeDestroy () {
    $(this.$refs.additionalMaterialCategoriesTooltip).tooltip('dispose')
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.component-availability {

  .in-stock,
  .deliverable,
  .not-available {
    animation: fadeIn .2s ease-in;
    animation-fill-mode: forwards;
    font-weight: bold;
    opacity: 0;
  }

  .in-stock {
    color: $availability-color-in-stock;
  }

  .deliverable {
    color: $availability-color-deliverable;
  }

  .not-available {
    color: $availability-color-not-available;
  }

  .availability-popover {
    cursor: pointer;
  }
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}
</style>


