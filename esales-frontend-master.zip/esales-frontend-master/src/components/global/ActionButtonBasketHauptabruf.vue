<template>
  <div>
    <button
      :class="buttonClass"
      :disabled="disabled || isProcessing"
      :title="$t('general.actionButtons.addToHauptabrufButtonTitle')"
      type="button"
      class="btn"
      @click="onClick">
      <app-icon-state
        :is-loading="isProcessing"
        icon="fas fa-shopping-cart" />
      <span v-if="!isIconOnly">
        {{ $t('general.actionButtons.addToHauptabrufButtonLabel') }}
      </span>
    </button>

    <!-- Auswahldialog Warenkorb -->
    <dialog-basket-selection
      v-if="isModalOpen"
      @select="onBasketSelect"
      @hidden="isModalOpen = false" />
  </div>
</template>

<script>
import { addPositionToBasket, getBaskets } from '@scripts/modules/basket'
import { showSuccessMessage, showErrorMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { AddToBasketMode } from '@scripts/modules/user-settings'

import DialogBasketSelection from '@components/dialogs/DialogBasketSelection.vue'

export default {
  components: {
    'dialog-basket-selection': DialogBasketSelection,
  },

  props: {
    amount: {
      default: 1,
      type: Number,
    },
    buttonClass: {
      default: 'btn-secondary',
      type: String,
    },
    disabled: {
      default: false,
      type: Boolean,
    },
    documentId: {
      default: void 0,
      type: String,
    },
    documentPosnr: {
      default: void 0,
      type: String,
    },
    documentType: {
      default: 0,
      type: Number,
    },
    isIconOnly: {
      default: false,
      type: Boolean,
    },
    matnr: {
      required: true,
      type: String,
    },
  },

  data () {
    return {
      baskets: [],

      isModalOpen: false,
      isProcessing: false,
    }
  },

  methods: {
    async onClick () {
      switch (this.app.user.settings.addToBasketMode) {
        // Immer Dialog öffnen
        case AddToBasketMode.OPEN_DIALOG_ALWAYS:
          this.isModalOpen = true
          break

        // Dialog nur öffnen, wenn es mehr als eine Warenkorb gibt
        case AddToBasketMode.OPEN_DIALOG_MULTIPLE_BASKETS:
          try {
            this.baskets = (await getBaskets()).multibaskets

            if (this.baskets.length > 1) {
              this.isModalOpen = true
            } else {
              this.addToBasket()
            }
          } catch (e) {
            console.error(e)
            showTechnicalErrorMessage()
          }
          break

        // Dialgo niemals öffnen
        case AddToBasketMode.OPEN_DIALOG_NEVER:
          this.addToBasket()
          break
      }
    },

    onBasketSelect (basket) {
      this.addToBasket(basket)
    },

    async addToBasket (basket) {
      this.isProcessing = true

      const documentOptions = {
        docId: this.documentId,
        docPosnr: this.documentPosnr,
        docType: this.documentType,
      }

      try {
        if (basket) {
          await addPositionToBasket(this.matnr, this.amount, 'documents', {
            basketName: basket.name,
            ...documentOptions,
            asZHA: true,
          })

          showSuccessMessage(this.$t('general.actionButtons.addToSpecificHauptabrufSuccessMessage', {basketName: basket.name}))
        } else {
          await addPositionToBasket(this.matnr, this.amount, 'documents', {
            ...documentOptions,
            asZHA: true,
          })

          showSuccessMessage(this.$t('general.actionButtons.addToHauptabrufSuccessMessage'))
        }
      } catch (e) {
        console.error(e)
        showErrorMessage(e.message) // @TODO: Wirklich die Errormessage anzeigen (evtl. showTechnicalErrorMessage verwenden) -> Prüfen, welche Meldungen hier kommen können
      }

      this.isProcessing = false
    },
  },
}
</script>
