<template>
  <div class="rounded bg-light p-3 component-sum">
    <div class="row">
      <div class="col-12 d-lg-flex justify-content-end">
        <div class="inner">
          <!-- Summe Brutto, Summe Netto -->
          <div class="border-bottom mb-1">
            <div
              v-if="shouldDisplayNetPrice"
              class="row mb-1">
              <div class="col">
                {{ $t('components.articleListSum.sumNetto') }}
              </div>
              <div class="col-auto text-right">
                {{ secondaryPrice.sum | price }}
                {{ secondaryPrice.currency | currency }}
              </div>
            </div>
            <div class="row font-weight-bold mb-1">
              <div class="col">
                {{ $t('components.articleListSum.sum') }}
              </div>
              <div class="col-auto text-right">
                {{ primaryPrice.sum | price }}
                {{ primaryPrice.currency | currency }}
              </div>
            </div>
          </div>

          <!-- MwSt Brutto, MwSt Netto -->
          <div class="border-bottom mb-1">
            <div
              v-if="shouldDisplayNetPrice"
              class="row mb-1">
              <div class="col">
                {{ $t('components.articleListSum.taxRateNetto', { taxRate: secondaryPrice.taxRate }) }}
              </div>
              <div class="col-auto text-right">
                {{ secondaryPrice.taxes | price }}
                {{ secondaryPrice.currency | currency }}
              </div>
            </div>
            <div class="row font-weight-bold mb-1">
              <div class="col">
                {{ $t('components.articleListSum.taxRate', { taxRate: primaryPrice.taxRate }) }}
              </div>
              <div class="col-auto text-right">
                {{ primaryPrice.taxes | price }}
                {{ primaryPrice.currency | currency }}
              </div>
            </div>
          </div>

          <!-- Gesamt Brutto, Gesamt Netto -->
          <div class="total-price">
            <div
              v-if="shouldDisplayNetPrice"
              class="row mb-1">
              <div class="col">
                {{ $t('components.articleListSum.totalNetto') }}
              </div>
              <div class="col-auto text-right">
                {{ secondaryPrice.sumInclTaxes | price }}
                {{ secondaryPrice.currency | currency }}
              </div>
            </div>
            <div class="row font-weight-bold font-size-lg primary-price">
              <div class="col">
                {{ $t('components.articleListSum.total') }}
              </div>
              <div class="col-auto text-right">
                {{ primaryPrice.sumInclTaxes | price }}
                {{ primaryPrice.currency | currency }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import user, { Permission } from '@scripts/app/user'

export default {
  props: {
    sum: {
      required: true,
      type: Object,
    },
  },

  computed: {
    shouldDisplayNetPrice () {
      return  user.hasPermission(Permission.SHOW_NET_PRICE) && this.app.state.oltpAvailable
    },
    primaryPrice () {
      if (this.shouldDisplayNetPrice) {
        return this.sum.netPrice
      }
      return this.sum.retailPrice
    },
    secondaryPrice () {
      if (this.shouldDisplayNetPrice) {
        return this.sum.retailPrice
      }
      return 0
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.component-sum {
  .inner {
    @include media-breakpoint-up(lg) {
      width: 400px;
    }

    .total-price {
      font-family: $font-family-headline;
    }

    .primary-price {
      color: $primary-price-color;
    }
  }
}
</style>
