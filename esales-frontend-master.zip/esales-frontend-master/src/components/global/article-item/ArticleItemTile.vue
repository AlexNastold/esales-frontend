<template>
  <div class="bg-light d-flex align-items-stretch flex-column h-100 p-3">
    <!-- Artikelbild -->
    <!-- Ohne Fehler: Bild verlinken -->
    <a
      v-if="!hasError"
      :href="detailLink(article.matnr, article.maktx, article.maktx2)">
      <div class="image-wrapper d-flex align-items-center align-self-stretch justify-content-center mb-2">
        <img
          :src="article.image | articleImage"
          :alt="article.maktx">
      </div>
    </a>
    <!-- Mit Fehler: Bild nicht verlinken -->
    <div
      v-else
      class="image-wrapper d-flex align-items-center align-self-stretch justify-content-center mb-2">
      <img
        :src="article.image | articleImage"
        :alt="article.maktx">
    </div>

    <!-- Artikelinformationen -->
    <div class="mb-2">
      <!-- EEK-Label -->
      <app-article-atom-eek-label
        v-if="app.settings.eek.listIconsActive && article.eek"
        :classes="article.eek"
        class="float-right pl-1" />

      <!-- Artikelname -->
      <div class="font-weight-bold font-size-lg">
        <!-- Ohne Fehler: Artikelname verlinken -->
        <a
          v-if="!hasError"
          :href="detailLink(article.matnr, article.maktx, article.maktx2)"
          class="text-dark text-break">
          {{ article.maktx }}
          {{ article.maktx2 }}
        </a>
        <!-- Mit Fehler: Artikelname nicht verlinken -->
        <span
          v-else
          class="text-dark text-break">
          {{ article.maktx }}
          {{ article.maktx2 }}
        </span>
      </div>

      <!-- Artikelnummer -->
      <div class="text-muted">
        <small>{{ $t('general.articleNumberShort') }} {{ article.matnrDisplay }}</small>
      </div>

      <!-- Verfügbarkeit -->
      <app-article-atom-availability
        v-if="app.user.hasPermission('SHOW_AVAILABILITY') && !hasError"
        :is-loading="isAdditionalDataLoading"
        :availability="additionalData && additionalData.availability"
        class="mt-2" />

      <!-- Artikel-Badges -->
      <app-article-badges
        :is-loading="isAdditionalDataLoading"
        :already-purchased="additionalData && additionalData.alreadyPurchased"
        :additional-material-categories="article.additionalMaterialCategories"
        class="mt-1" />

      <!-- Fehlermeldung -->
      <div
        v-if="hasError"
        class="text-danger">
        <i class="fas fa-exclamation-triangle" />
        {{ errorMessage }}
      </div>
    </div>

    <!-- Preise (bei Fehler ausblenden)  -->
    <app-article-atom-prices
      v-if="!hasError"
      :retail-price="additionalData && additionalData.retailPrice"
      :net-price="additionalData && additionalData.netPrice"
      :is-price-loading="isAdditionalDataLoading"
      class="mt-auto text-right" />

    <!-- Menge, Werfen (bei Fehler deaktivieren) -->
    <div
      v-if="app.user.hasPermission('BASKET_ADD_ARTICLES')"
      class="d-flex mt-2">
      <app-form-input-quantity
        v-model="amount"
        :unit="article.unitFormatted"
        :stepsize="article.stepsize"
        :disabled="hasError"
        width="auto" />

      <app-action-button-basket
        :is-icon-only="true"
        :matnr="article.matnr"
        :amount="amount"
        :disabled="hasError"
        :pitcher="pitcher"
        class="ml-1" />
    </div>
  </div>
</template>

<script>
import { detailLink } from '@scripts/helper/generateLink'
export default {
  props: {
    additionalData: {
      default: void 0,
      type: Object,
    },
    article: {
      required: true,
      type: Object,
    },
    errorMessage: {
      default: '',
      type: String,
    },
    hasError: {
      default: false,
      type: Boolean,
    },
    isAdditionalDataLoading: {
      required: true,
      type: Boolean,
    },
    pitcher: {
      required: true,
      type: String,
    },
  },

  data () {
    return {
      amount: this.article.amount?this.article.amount:this.article.quantity,
      detailLink,
    }
  },

  watch: {
    amount (newAmount) {
      this.$emit('amountChange', newAmount)
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';
.image-wrapper {
  height: $article-tile-image-height;
  width: 100%;

  img {
    height: auto;
    max-height: 100%;
    max-width: 100%;
    width: auto;
  }
}
</style>
