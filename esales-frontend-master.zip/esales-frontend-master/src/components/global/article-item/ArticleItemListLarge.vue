<template>
  <div class="row">
    <!-- Artikelbild, Artikelname, Artikelnummer, EEK-Label, Verfügbarkeit -->
    <div class="col-12 col-lg-5 col-xl-6">
      <div class="row">
        <!-- Artikelbild -->
        <div class="col-auto">
          <!-- Ohne Fehler: Bild verlinken -->
          <a
            v-if="!hasError"
            :href="detailLink(article.matnr, article.maktx, article.maktx2)">
            <div class="article-image-wrapper d-flex align-items-center justify-content-center">
              <img
                :src="article.image | articleImage"
                :alt="article.maktx">
            </div>
          </a>
          <!-- Mit Fehler: Bild nicht verlinken -->
          <div
            v-else
            class="article-image-wrapper d-flex align-items-center justify-content-center">
            <img
              :src="article.image | articleImage"
              :alt="article.maktx">
          </div>
        </div>

        <!-- Artikelinformationen -->
        <div class="col">
          <!-- EEK-Label -->
          <app-article-atom-eek-label
            v-if="app.settings.eek.listIconsActive && article.eek"
            :classes="article.eek"
            class="float-right pl-1" />

          <!-- Artikelname -->
          <div class="font-weight-bold font-size-lg">
            <!-- Ohne Fehler: Artikelname verlinken -->
            <a
              v-if="!hasError"
              :href="detailLink(article.matnr, article.maktx, article.maktx2)"
              class="text-dark text-break">
              {{ article.maktx }}
              {{ article.maktx2 }}
            </a>
            <!-- Mit Fehler: Artikelname nicht verlinken -->
            <span
              v-else
              class="text-dark text-break">
              {{ article.maktx }}
              {{ article.maktx2 }}
            </span>
          </div>

          <!-- Artikelnummer -->
          <div class="text-muted">
            <small>{{ $t('general.articleNumberShort') }} {{ article.matnrDisplay }}</small>
          </div>

          <!-- Verfügbarkeit (bei Fehler ausblenden) -->
          <app-article-atom-availability
            v-if="app.user.hasPermission('SHOW_AVAILABILITY') && !hasError"
            :is-loading="isAdditionalDataLoading"
            :availability="additionalData && additionalData.availability"
            class="mt-2" />

          <!-- Artikel-Badges -->
          <app-article-badges
            :is-loading="isAdditionalDataLoading"
            :already-purchased="additionalData && additionalData.alreadyPurchased"
            :additional-material-categories="article.additionalMaterialCategories"
            class="mt-1" />

          <!-- Fehlermeldung -->
          <div
            v-if="hasError"
            class="text-danger">
            <i class="fas fa-exclamation-triangle fa-fw" />
            {{ errorMessage }}
          </div>
        </div>
      </div>
    </div>

    <!-- Preise, Menge, Werfen, Buttons -->
    <div class="col-12 col-lg-7 col-xl-6">
      <div class="row">
        <!-- Preise (bei Fehler ausblenden) -->
        <div class="col-12 col-md text-right mt-2 mt-lg-0">
          <app-article-atom-prices
            v-if="!hasError"
            :retail-price="additionalData && additionalData.retailPrice"
            :net-price="additionalData && additionalData.netPrice"
            :is-price-loading="isAdditionalDataLoading" />
        </div>

        <!-- Menge, Werfen (bei Fehler deaktivieren) -->
        <div
          v-if="app.user.hasPermission(['BASKET_ADD_ARTICLES', 'LISTS', 'COMPARISON', 'LABELS'])"
          class="col-12 col-md-auto d-flex align-items-center justify-content-end mt-2 mt-lg-0">
          <div class="d-flex">
            <app-form-input-quantity
              v-model="amount"
              :unit="article.unitFormatted"
              :stepsize="article.stepsize"
              :disabled="hasError" />

            <!-- Slot für Buttons nach dem Mengenfeld -->
            <slot name="buttons-after-amount" />

            <app-action-button-basket
              v-if="app.user.hasPermission('BASKET_ADD_ARTICLES')"
              :is-icon-only="true"
              :matnr="article.matnr"
              :amount="amount"
              :pitcher="pitcher"
              :disabled="hasError"
              class="ml-1" />
          </div>
        </div>

        <!-- Buttons -->
        <div
          v-if="app.user.hasPermission(['LISTS', 'COMPARISON', 'LABELS']) || $slots.buttons"
          class="col-12 d-flex justify-content-end mt-2">
          <!-- Auf die Liste -->
          <app-action-button-list
            v-if="app.user.hasPermission('LISTS')"
            :is-icon-only="true"
            :matnr="article.matnr"
            :amount="amount"
            :disabled="hasError"
            @updated="(listId) => $emit('updatedList', listId)" />

          <!-- Zum Produktvergleich hinzufügen   -->
          <app-action-button-comparison
            v-if="app.user.hasPermission('COMPARISON')"
            :is-icon-only="true"
            :matnr="article.matnr"
            :disabled="hasError"
            class="ml-1" />

          <!-- Zu Etiketten hinzufügen -->
          <app-action-button-label
            v-if="app.user.hasPermission('LABELS')"
            :is-icon-only="true"
            :matnr="article.matnr"
            :amount="amount"
            :disabled="hasError"
            class="ml-1" />

          <!-- Platzhalter für spezifische Buttons -->
          <slot name="buttons" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import { detailLink } from '@scripts/helper/generateLink'

export default {
  props: {
    additionalData: {
      default: void 0,
      type: Object,
    },
    article: {
      required: true,
      type: Object,
    },
    errorMessage: {
      default: '',
      type: String,
    },
    hasError: {
      default: false,
      type: Boolean,
    },
    isAdditionalDataLoading: {
      required: true,
      type: Boolean,
    },
    pitcher: {
      required: true,
      type: String,
    },
  },

  data () {
    return {
      amount: this.article.amount?this.article.amount:this.article.quantity,
      detailLink,
    }
  },

  watch: {
    amount (newAmount) {
      this.$emit('amountChange', newAmount)
    },
  },
}
</script>
