import ActionButtonBasket from './ActionButtonBasket.vue'
import ActionButtonBasketHauptabruf from './ActionButtonBasketHauptabruf.vue'
import ActionButtonBasketMultiple from './ActionButtonBasketMultiple.vue'
import ActionButtonComparison from './ActionButtonComparison.vue'
import ActionButtonLabel from './ActionButtonLabel.vue'
import ActionButtonList from './ActionButtonList.vue'
import ActiveFilter from './ActiveFilter.vue'
import AdditionalMaterialBadge from './AdditionalMaterialBadge.vue'
import ArticleAtomAvailability from './ArticleAtomAvailability.vue'
import ArticleAtomEEKLabel from './ArticleAtomEEKLabel.vue'
import ArticleAtomEEKLabels from './ArticleAtomEEKLabels.vue'
import ArticleAtomPrices from './ArticleAtomPrices.vue'
import ArticleAtomPricesBasket from './ArticleAtomPricesBasket.vue'
import ArticleBadges from './ArticleBadges.vue'
import ArticleItem from './ArticleItem.vue'
import ArticleListSum from './ArticleListSum.vue'
import ArticleSlider from './ArticleSlider.vue'
import BoxEmptyList from './BoxEmptyList.vue'
import BoxError from './BoxError.vue'
import BoxOops from './BoxOops.vue'
import BoxSuccess from './BoxSuccess.vue'
import CampaignPreview from './CampaignPreview.vue'
import FormInputDatepicker from './FormInputDatepicker.vue'
import FormInputNumberFormatted from './FormInputNumberFormatted.vue'
import FormInputProductSearch from './FormInputProductSearch.vue'
import FormInputProductSearchGlobal from './FormInputProductSearchGlobal.vue'
import FormInputQuantity from './FormInputQuantity.vue'
import FormRequiredHint from './FormRequiredHint.vue'
import IconState from './IconState.vue'
import LayoutFooter from './LayoutFooter.vue'
import LayoutHeader from './LayoutHeader.vue'
import LayoutNavigation from './LayoutNavigation.vue'
import LoadingBox from './LoadingBox.vue'
import LoadingSpinner from './LoadingSpinner.vue'
import Pagination from './Pagination.vue'
import ScalePrices from './ScalePrices.vue'
import ScanButton from './ScanButton.vue'

const components = {
  ActionButtonBasket,
  ActionButtonBasketHauptabruf,
  ActionButtonBasketMultiple,
  ActionButtonComparison,
  ActionButtonLabel,
  ActionButtonList,
  ActiveFilter,
  AdditionalMaterialBadge,
  ArticleAtomAvailability,
  ArticleAtomPrices,
  ArticleAtomPricesBasket,
  ArticleBadges,
  ArticleItem,
  ArticleListSum,
  ArticleSlider,
  BoxEmptyList,
  BoxError,
  BoxOops,
  BoxSuccess,
  CampaignPreview,
  FormInputDatepicker,
  FormInputNumberFormatted,
  FormInputProductSearch,
  FormInputProductSearchGlobal,
  FormInputQuantity,
  FormRequiredHint,
  IconState,
  LayoutFooter,
  LayoutHeader,
  LayoutNavigation,
  LoadingBox,
  LoadingSpinner,
  Pagination,
  ScalePrices,
  ScanButton,
  // Name eek-labels manually else they would be named e.g. `article-atom-e-e-k-label`
  'article-atom-eek-label': ArticleAtomEEKLabel,
  'article-atom-eek-labels': ArticleAtomEEKLabels,
}

export default components
