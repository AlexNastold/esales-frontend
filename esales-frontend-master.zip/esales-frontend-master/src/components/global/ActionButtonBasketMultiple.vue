<template>
  <div>
    <button
      :class="buttonClass"
      :disabled="disabled || isProcessing"
      :title="$t('general.actionButtons.addToBasketMultipleButtonLabel')"
      type="button"
      class="btn"
      @click="onClick">
      <app-icon-state
        :is-loading="isProcessing"
        icon="fas fa-shopping-cart" />
      <span v-if="!isIconOnly">
        {{ $t('general.actionButtons.addToBasketMultipleButtonLabel') }}
      </span>
    </button>

    <!-- Auswahldialog Warenkorb -->
    <dialog-basket-selection
      v-if="isModalOpen"
      @select="onBasketSelect"
      @hidden="isModalOpen = false" />
  </div>
</template>

<script>
import { addPositionsToBasket, getBaskets } from '@scripts/modules/basket'
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { AddToBasketMode } from '@scripts/modules/user-settings'

import DialogBasketSelection from '@components/dialogs/DialogBasketSelection.vue'

export default {
  components: {
    'dialog-basket-selection': DialogBasketSelection,
  },

  props: {
    articles: {
      required: true,
      type: Array,
    },
    buttonClass: {
      default: 'btn-primary',
      type: String,
    },
    disabled: {
      default: false,
      type: Boolean,
    },
    isIconOnly: {
      default: false,
      type: Boolean,
    },
    pitcher: {
      required: true,
      type: String,
    },
  },

  data () {
    return {
      baskets: [],

      isModalOpen: false,
      isProcessing: false,
    }
  },

  methods: {
    async onClick () {
      switch (this.app.user.settings.addToBasketMode) {

        // Immer Dialog öffnen
        case AddToBasketMode.OPEN_DIALOG_ALWAYS:
          this.isModalOpen = true
          break

        // Dialog nur öffnen, wenn es mehr als einen Warenkorb gibt
        case AddToBasketMode.OPEN_DIALOG_MULTIPLE_BASKETS:
          try {
            this.baskets = (await getBaskets()).multibaskets

            if (this.baskets.length > 1) {
              this.isModalOpen = true
            } else {
              this.addToBasket()
            }
          } catch (e) {
            console.error(e)
            showTechnicalErrorMessage()
          }
          break

        // Dialgo niemals öffnen
        case AddToBasketMode.OPEN_DIALOG_NEVER:
          this.addToBasket()
          break
      }
    },

    onBasketSelect (basket) {
      this.addToBasket(basket)
    },

    async addToBasket (basket) {
      this.isProcessing = true

      try {
        if (basket) {
          await addPositionsToBasket(this.articles, this.pitcher, { basketName: basket.name })
          showSuccessMessage(this.$t('general.actionButtons.addToSpecificBasketMultipleSuccessMessage', {count: this.articles.length, basketName: basket.name}) + `<br><br>
            <a href="basket" class="icon-link text-white">
              <i class="fas fa-shopping-cart fa-fw"></i>
              <span class="text text-underline">${this.$t('general.actionButtons.addToBasketLinkLabel')}</span>
            </a>
          `)
        } else {
          await addPositionsToBasket(this.articles, this.pitcher)
          showSuccessMessage(this.$t('general.actionButtons.addToBasketMultipleSuccessMessage', {count: this.articles.length}) + `<br><br>
            <a href="basket" class="icon-link text-white">
              <i class="fas fa-shopping-cart fa-fw"></i>
              <span class="text text-underline">${this.$t('general.actionButtons.addToBasketLinkLabel')}</span>
            </a>
          `)
        }
        this.$emit('success')
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.isProcessing = false
    },
  },
}
</script>
