<template>
  <div
    ref="articlesSlider"
    class="article-recommendation-slider">
    <a
      v-for="(article, index) in articles"
      :key="index"
      :href="detailLink(article.matnr, article.maktx, article.maktx2)"
      class="article">
      <div class="article-image my-1">
        <img
          :src="article.image | articleImage"
          :alt="article.maktx">
      </div>
      <div class="article-name text-center font-weight-bold mb-1">
        {{ article.maktx }}
      </div>
      <div class="article-number text-center text-muted mb-1">
        {{ $t('general.articleNumberShort') }}: {{ article.matnrDisplay }}
      </div>
    </a>
  </div>
</template>

<script>
import { detailLink } from '@scripts/helper/generateLink'

export default {
  props: {
    articles: {
      default () {
        return []
      },
      required: false,
      type: Array,
    },
  },

  data () {
    return {
      detailLink,
    }
  },

  mounted () {
    $(this.$refs.articlesSlider).slick({
      arrows: true,
      infinite: false,
      responsive: [
        {
          breakpoint: 1400,
          settings: {
            slidesToScroll: 4,
            slidesToShow: 4,
          },
        },
        {
          breakpoint: 992,
          settings: {
            slidesToScroll: 3,
            slidesToShow: 3,
          },
        },
        {
          breakpoint: 768,
          settings: {
            slidesToScroll: 2,
            slidesToShow: 2,
          },
        },
        {
          breakpoint: 576,
          settings: {
            slidesToScroll: 1,
            slidesToShow: 1,
          },
        },
      ],
      slidesToScroll: 6,
      slidesToShow: 6,
    })
  },

  beforeDestroy () {
    $(this.$refs.articlesSlider).slick('unslick')
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.article-recommendation-slider {
  margin-bottom: 30px;
  padding: 0 35px;

  .slick-dots {
    bottom: -30px;
    position: initial;
  }

  // Slider Dark arrows
  .slick-prev,
  .slick-next {

    &::before {
      color: #232323;
    }
  }

  .slick-prev {
    left: 0;

    &::before {
      content: '\F053';
      font-family: 'Font Awesome 5 Free';
      font-size: 30px;
      font-weight: 900;
    }
  }

  .slick-next {
    right: 0;

    &::before {
      content: '\F054';
      font-family: 'Font Awesome 5 Free';
      font-size: 30px;
      font-weight: 900;
    }
  }

  // Article Slider item
  .article {
    color: $black;
    margin: 0 5px;
    text-decoration: none;

    &:hover {
      background: #f5f5f5;
    }

    .article-image {
      align-items: center;
      display: flex;
      height: 100px;
      justify-content: center;
      width: 100%;

      img {
        height: auto;
        max-height: 100%;
        max-width: 100%;
        width: auto;
      }
    }

    .article-name {
      height: 3em;
      overflow: hidden;

      &:hover {
        text-decoration: underline;
      }
    }
  }
}
</style>
