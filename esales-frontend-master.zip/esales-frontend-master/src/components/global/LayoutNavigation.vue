<template>
  <layout-navigation-before-login v-if="(!app.user.isLoggedIn && !app.settings.autoGuestActive) || app.state.kioskMode" />
  <layout-navigation-after-login
    v-else
    :is-article-menu-open="isArticleMenuOpen" />
</template>

<script>
import LayoutNavigationBeforeLogin from './layout-navigation/LayoutNavigationBeforeLogin.vue'
import LayoutNavigationAfterLogin from './layout-navigation/LayoutNavigationAfterLogin.vue'

export default {
  components: {
    'layout-navigation-before-login': LayoutNavigationBeforeLogin,
    'layout-navigation-after-login': LayoutNavigationAfterLogin,
  },

  props: {
    isArticleMenuOpen: {
      default: false,
      type: Boolean,
    },
  },
}
</script>
