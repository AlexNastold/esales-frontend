<template>
  <button
    :class="buttonClass"
    :disabled="isProcessing"
    :title="$t('general.actionButtons.addToLabelsButtonLabel')"
    type="button"
    class="btn"
    @click="addToLabels">
    <app-icon-state
      :is-loading="isProcessing"
      icon="fas fa-tag" />
    <span v-if="!isIconOnly">
      {{ $t('general.actionButtons.addToLabelsButtonLabel') }}
    </span>
    <span
      v-if="isInLabels"
      class="badge">
      <i class="fas fa-check fa-fw" />
    </span>
  </button>
</template>

<script>
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { addLabel } from '@scripts/modules/labels'


export default {
  props: {
    amount: {
      default: 1,
      type: Number,
    },
    buttonClass: {
      default: 'btn-secondary',
      type: String,
    },
    isIconOnly: {
      default: false,
      type: Boolean,
    },
    matnr: {
      required: true,
      type: String,
    },
  },

  data () {
    return {
      isProcessing: false,
    }
  },

  computed: {
    isInLabels () {
      if (this.$store.getters.getMaterialsInLabels)  {
        return this.$store.getters.getMaterialsInLabels.find((material) => material === this.matnr) ? true : false
      } else {
        return false
      }
    },
  },
  methods: {
    async addToLabels () {
      this.isProcessing = true

      try {
        await addLabel(this.matnr, this.amount)
        showSuccessMessage(`
          ${this.$t('general.actionButtons.addToLabelsSuccessMessage')}<br><br>
          <a href="labels" class="icon-link text-white">
            <i class="fas fa-tags fa-fw"></i>
            <span class="text text-underline">${this.$t('general.actionButtons.addToLabelsLinkLabel')}</span>
          </a>
        `)
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.isProcessing = false
    },
  },
}
</script>

<style lang="scss" scoped>
.btn {
  position: relative;
  .badge {
    position: absolute;
    font-size: .8em;
    right: -4px;
  }
}
</style>
