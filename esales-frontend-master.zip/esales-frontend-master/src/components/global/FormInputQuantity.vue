<template>
  <div
    :class="{disabled: disabled}"
    :style="{'min-width':'160px', 'width': width}"
    class="input-group quantity-input">
    <div class="input-group-prepend">
      <button
        :disabled="disabled || isMin()"
        :class="`btn ${btnType} px-2`"
        type="button"
        tabindex="-1"
        @click="decrease">
        <i
          class="fas fa-minus fa-fw"
          style="font-size: 0.7em" />
      </button>
    </div>
    <input
      ref="quantityInput"
      :key="rerenderKey"
      :disabled="disabled"
      :placeholder="placeholderTranslated"
      :value="rawValue"
      type="text"
      class="form-control text-center border-right-0 px-1"
      :maxlength="maxLength"
      @input="(e) => rawValue = e.target.value"
      @keydown.up="increase"
      @keydown.down="decrease"
      @keydown.enter="emitEnterPressed">
    <div class="input-group-append">
      <span class="input-group-text text-muted bg-white pr-2 pl-0 border-left-0">
        {{ unitTranslated }}
      </span>
      <button
        :disabled="disabled || isMax()"
        :class="`btn ${btnType} px-2`"
        type="button"
        tabindex="-1"
        @click="increase">
        <i
          class="fas fa-plus fa-fw"
          style="font-size: 0.7em" />
      </button>
    </div>
  </div>
</template>

<script>
import { numberToSapNumber, sapNumberToNumber } from '@scripts/helper/sapFormat'
import { getSignificantDigitCount } from '@scripts/helper/formatNumber'
import I18n from '@scripts/modules/i18n'
import { applicationSettings } from '@scripts/app/settings'

export default {
  props: {
    disabled: {
      default: false,
      type: Boolean,
    },
    maxLength: {
      default: String(applicationSettings.maxQuantity).length,
      type: Number,
    },
    max: {
      default: applicationSettings.maxQuantity,
      type: Number,
    },
    min: {
      default: 0,
      type: Number,
    },
    placeholder: {
      default: '',
      type: String,
    },
    shouldEmitOnMount: {
      default: true,
      type: Boolean,
    },
    stepsize: {
      default: 1,
      type: Number,
      validator: (value) => value > 0,
    },
    unit: {
      default: '',
      type: String,
    },
    value: {
      default: 1,
      type: Number,
    },
    width: {
      default: '160px',
      type: String,
    },
    btnType: {
      default: 'btn-secondary',
      type: String,
    },
    forceMax: {
      default: false,
      type: Boolean,
    },
  },

  data () {
    return {
      rawValue: numberToSapNumber(this.value, {omitUnnecessaryDecimals: this.value % 1 === 0}),
      // Wird verwendet, um beim Klick auf die + / - Buttons das Input Feld komplett neu zu rendern (Problem tritt bei iOS auf iPhone / iPad auf)
      rerenderKey: 0,
    }
  },

  computed: {
    numericInput () {
      if (typeof this.rawValue === 'undefined' || (typeof this.rawValue === 'string' && this.rawValue.length === 0)) {
        return 0
      }
      let convertedNumber = sapNumberToNumber(String(this.rawValue))
      if (!Number.isNaN(convertedNumber)) {
        return convertedNumber
      }
      return void 0
    },
    significantDigits () {
      return getSignificantDigitCount(this.stepsize)
    },
    unitTranslated () {
      return !this.unit ? I18n.t('components.formInputQuantity.unitDefault') : this.unit
    },
    placeholderTranslated () {
      return !this.placeholder ? I18n.t('components.formInputQuantity.placeholderDefault') : this.placeholder
    },
  },

  watch: {
    value (val) {
      if (val !== this.numericInput) {
        this.setValue(val)
      }
      if (this.forceMax && val > this.max) {
        this.setValue(this.max)
      }
    },
    numericInput () {
      this.emitChange()
    },
  },

  mounted  () {

    // Select text when focusing input for easier change
    this.$refs.quantityInput.addEventListener('focus', function () {
      this.select()
    }, false)

    if (this.shouldEmitOnMount) {
      this.emitChange()
    }
  },

  methods: {
    isMin () {
      return this.numericInput <= this.min
    },
    isMax () {
      return this.numericInput >= this.max
    },
    increase () {
      let calculatedValue = 0
      do {
        calculatedValue += this.stepsize
      } while (parseFloat(calculatedValue.toFixed(this.significantDigits)) <= (this.numericInput || 0))

      if (calculatedValue > this.max) {
        this.setValue(this.max)
      } else {
        this.setValue(calculatedValue)
      }
      this.rerenderKey = Math.random()
    },
    decrease () {
      let calculatedValue = 0
      do {
        calculatedValue += this.stepsize
      } while (parseFloat(calculatedValue.toFixed(this.significantDigits)) < (this.numericInput || 0))

      calculatedValue -= this.stepsize

      if (calculatedValue < this.min) {
        this.setValue(this.min)
      } else {
        this.setValue(calculatedValue)
      }
      this.rerenderKey = Math.random()
    },
    setValue (value) {
      if (value === 0) {
        this.rawValue = void 0
      } else {
        this.rawValue = numberToSapNumber(value, {omitUnnecessaryDecimals: this.stepsize % 1 === 0})
      }
    },
    emitChange () {
      this.$emit('input', this.numericInput)
    },
    emitEnterPressed () {
      this.$emit('enter')
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

button {
  touch-action: manipulation;
}

.quantity-input {
  &.disabled {
    cursor: ban;
  }

  input:not([type="radio"]),
  input:not([type="checkbox"]) {
    -webkit-appearance: none;
    border-radius: 0;
  }

  input[type="text"] {
    background: $input-bg !important;
    opacity: $btn-disabled-opacity;
  }

  .input-group-text {
    opacity: $btn-disabled-opacity;
  }

}
</style>

