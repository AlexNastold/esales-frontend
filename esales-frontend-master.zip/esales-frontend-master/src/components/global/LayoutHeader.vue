<template>
  <layout-header-before-login v-if="(!app.user.isLoggedIn && !app.settings.autoGuestActive) || app.state.kioskMode" />
  <layout-header-after-login
    v-else
    :is-header-sticky="isHeaderSticky" />
</template>

<script>
import LayoutHeaderBeforeLogin from './layout-header/LayoutHeaderBeforeLogin.vue'
import LayoutHeaderAfterLogin from './layout-header/LayoutHeaderAfterLogin.vue'

export default {
  components: {
    'layout-header-before-login': LayoutHeaderBeforeLogin,
    'layout-header-after-login': LayoutHeaderAfterLogin,
  },
  props: {
    isHeaderSticky: {
      default: true,
      type: Boolean,
    },
  },
}
</script>
