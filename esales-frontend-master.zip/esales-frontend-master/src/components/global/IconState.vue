<template>
  <i
    v-if="isLoading"
    :class="[iconLoading, fixedWidth ? 'fa-fw' : '']" />
  <i
    v-else
    :class="[icon, fixedWidth ? 'fa-fw' : '']" />
</template>

<script>
export default {
  props: {
    fixedWidth: {
      default: true,
      type: Boolean,
    },
    icon: {
      required: true,
      type: String,
    },
    iconLoading: {
      default: 'fas fa-circle-notch fa-spin fa-fw',
      type: String,
    },
    isLoading: {
      default: false,
      type: Boolean,
    },
  },
}
</script>
