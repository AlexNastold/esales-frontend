<template>
  <div class="component-error-box d-flex align-items-center justify-content-center">
    <div>
      <svg
        class="checkmark"
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 52 52">
        <circle
          class="checkmark__circle"
          cx="26"
          cy="26"
          r="25"
          fill="none" />
        <path
          class="checkmark__check"
          fill="none"
          d="M16 16 36 36 M36 16 16 36" />
      </svg>
      <div class="text mt-3">
        <slot />
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
@import '~styles/definitions/all';

$size: 100;
$curve: cubic-bezier(0.650, 0.000, 0.450, 1.000);

.component-error-box {
  height: 300px;

  .checkmark {
    width: $size * 1px;
    height: $size * 1px;
    border-radius: 50%;
    display: block;
    stroke-width: 2;
    stroke: #fff;
    stroke-miterlimit: 10;
    margin: 0 auto;
    box-shadow: inset 0px 0px 0px $red;
    animation: fill .4s ease-in-out .4s forwards, scale .3s ease-in-out .9s both;
  }

  .checkmark__circle {
    stroke-dasharray: 166;
    stroke-dashoffset: 166;
    stroke-width: 2;
    stroke-miterlimit: 10;
    stroke: $red;
    fill: none;
    animation: stroke .6s $curve forwards;
  }

  .checkmark__check {
    transform-origin: 50% 50%;
    stroke-dasharray: floor($size / 1.16);
    stroke-dashoffset: floor($size / 1.16);
    animation: stroke .3s $curve .8s forwards;
  }

  @keyframes stroke {
    100% {
      stroke-dashoffset: 0;
    }
  }

  @keyframes scale {
    0%, 100% {
      transform: none;
    }
    50% {
      transform: scale3d(1.1, 1.1, 1);
    }
  }

  @keyframes fill {
    100% {
      box-shadow: inset 0px 0px 0px (($size / 1.86) * 1px) $red;
    }
  }

  .text {
    text-align: center;
  }
}
</style>
