<template>
  <a
    :class="`size-${size}`"
    :href="`campaign?id=${encodeURIComponent(campaign.id)}`"
    class="campaign-list-item">
    <div
      :style="`background-image: url(${$options.filters.externalImage(campaign.banner)})`"
      class="image" />
    <div class="infos p-2 p-md-3">
      <h3 class="text-uppercase mb-1">
        {{ campaign.name }}
      </h3>
      <div class="slogan">
        {{ campaign.slogan }}
      </div>
      <small class="valid-to">
        {{ $t('campaigns.preview.validTo', { date: campaign.validTo }) }}
      </small>
    </div>
  </a>
</template>

<script>
export default {
  props: {
    campaign: {
      required: true,
      type: Object,
    },
    size: {
      default: 'medium',
      type: String,
      validator (value) {
        return value === 'medium' || value === 'small'
      },
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.campaign-list-item {
  color: $campaign-header-infos-color;
  cursor: pointer;
  display: block;
  overflow: hidden;
  position: relative;

  &.size-small {
    height: $campaign-list-item-height-small;
  }

  &.size-medium {
    height: $campaign-list-item-height-medium;
  }

  .image {
    background-position: center center;
    background-size: cover;
    height: 100%;
    transition: transform 1s ease-in-out, filter 1s ease-in-out;
    width: 100%;
  }

  .infos {
    background: transparentize($campaign-header-infos-background, .1);
    bottom: 0;
    left: 0;
    position: absolute;
    right: 0;
    transition: background .2s ease-in-out;

    .slogan {
      font-weight: 500;
    }

    .valid-to {
      color: $campaign-header-infos-valid-to-color;
    }
  }

  &:hover {
    .infos {
      background: $campaign-header-infos-background-hover;

      @if (lightness($campaign-header-infos-background-hover) > 50%) {
        color: $font-color;
      } @else {
        color: white;
      }

      .valid-to {
        @if (lightness($campaign-header-infos-background-hover) > 50%) {
          color: $campaign-header-infos-valid-to-color;
        } @else {
          color: darken(white, 10%);
        }
      }
    }

    .image {
      transform: scale(1.05);
    }
  }
}
</style>
