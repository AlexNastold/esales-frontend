<template>
  <button
    :class="buttonClass"
    :disabled="isProcessing"
    :title="$t('general.actionButtons.addToComparisonButtonLabel')"
    type="button"
    class="btn"
    @click="addToComparison">
    <app-icon-state
      :is-loading="isProcessing"
      icon="fas fa-balance-scale" />
    <span v-if="!isIconOnly">
      {{ $t('general.actionButtons.addToComparisonButtonLabel') }}
    </span>
    <span
      v-if="isInComparison"
      class="badge">
      <i class="fas fa-check fa-fw" />
    </span>
  </button>
</template>

<script>
import { addToComparison } from '@scripts/modules/comparison'
import { showSuccessMessage, showTechnicalErrorMessage, showWarningMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'

export default {
  props: {
    buttonClass: {
      default: 'btn-secondary',
      type: String,
    },
    isIconOnly: {
      default: false,
      type: Boolean,
    },
    matnr: {
      required: true,
      type: String,
    },
  },

  data () {
    return {
      isProcessing: false,
    }
  },

  computed: {
    isInComparison () {
      if (this.$store.getters.getMaterialsInComparison) {
        return this.$store.getters.getMaterialsInComparison.find((material) => material === this.matnr) ? true : false
      } else {
        return false
      }
    },
  },

  methods: {
    async addToComparison () {
      this.isProcessing = true

      try {
        await addToComparison(this.matnr)
        showSuccessMessage(`
          ${this.$t('general.actionButtons.addToComparisonSuccessMessage')}<br><br>
          <a href="product-comparison" class="icon-link text-white">
            <i class="fas fa-balance-scale fa-fw"></i>
            <span class="text text-underline">${this.$t('general.actionButtons.addToComparisonLinkLabel')}</span>
          </a>
        `)
      } catch (e) {
        if (e.code === ErrorCode.ALREADY_IN_COMPARISON) {
          showWarningMessage(this.$t('general.actionButtons.addToComparisonErrorMessageExists'))
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }

      this.isProcessing = false
    },
  },
}
</script>

<style lang="scss" scoped>
.btn {
  position: relative;
  .badge {
    position: absolute;
    font-size: .8em;
    right: -4px;
}
}
</style>
