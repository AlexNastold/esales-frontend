<template>
  <div class="empty-list text-dark text-center m-4">
    <div class="icon mb-4">
      <i
        :class="icon"
        class="fa-fw" />
    </div>
    <div class="text text-dark">
      <h2>{{ headline }}</h2>
      <slot />
    </div>
  </div>
</template>

<script>
export default {
  props: {
    headline: {
      required: true,
      type: String,
    },
    icon: {
      required: true,
      type: String,
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.empty-list {
  overflow: hidden;

  .icon {
    font-size: 80px;
    line-height: 1em;
    opacity: 0.2;
    padding: 10px 0;

    @include media-breakpoint-up(md) {
      font-size: 120px;
      padding: 20px 0;
    }
  }

  .text {
    h2 {
      font-family: $font-family-headline;
    }
  }
}
</style>
