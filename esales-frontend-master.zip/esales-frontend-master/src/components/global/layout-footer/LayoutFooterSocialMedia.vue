<template>
  <div>
    <h4 class="headline text-white mb-3">
      {{ $t('layoutFooter.footerSocialMedia.headline') }}
    </h4>

    <!-- Auflistung Social Media Links -->
    <ul class="list-unstyled">
      <!-- Facebook -->
      <li
        v-if="app.settings.socialMedia.facebook"
        class="py-1">
        <a
          :href="app.settings.socialMedia.facebook"
          target="_blank"
          class="icon-link">
          <i class="fab fa-facebook fa-fw" />
          <span class="text">
            Facebook
          </span>
        </a>
      </li>

      <!-- Twitter -->
      <li
        v-if="app.settings.socialMedia.twitter"
        class="py-1">
        <a
          :href="app.settings.socialMedia.twitter"
          target="_blank"
          class="icon-link">
          <i class="fab fa-twitter fa-fw" />
          <span class="text">
            Twitter
          </span>
        </a>
      </li>

      <!-- Google+ -->
      <li
        v-if="app.settings.socialMedia.googleplus"
        class="py-1">
        <a
          :href="app.settings.socialMedia.googleplus"
          target="_blank"
          class="icon-link">
          <i class="fab fa-google-plus fa-fw" />
          <span class="text">
            Google+
          </span>
        </a>
      </li>

      <!-- YouTube -->
      <li
        v-if="app.settings.socialMedia.youtube"
        class="py-1">
        <a
          :href="app.settings.socialMedia.youtube"
          target="_blank"
          class="icon-link">
          <i class="fab fa-youtube fa-fw" />
          <span class="text">
            YouTube
          </span>
        </a>
      </li>

      <!-- Instagram -->
      <li
        v-if="app.settings.socialMedia.instagram"
        class="py-1">
        <a
          :href="app.settings.socialMedia.instagram"
          target="_blank"
          class="icon-link">
          <i class="fab fa-instagram fa-fw" />
          <span class="text">
            Instagram
          </span>
        </a>
      </li>

      <!-- LinkedIn -->
      <li
        v-if="app.settings.socialMedia.linkedin"
        class="py-1">
        <a
          :href="app.settings.socialMedia.linkedin"
          target="_blank"
          class="icon-link">
          <i class="fab fa-linkedin fa-fw" />
          <span class="text">
            LinkedIn
          </span>
        </a>
      </li>
    </ul>
  </div>
</template>
