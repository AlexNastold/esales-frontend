<template>
  <!-- Sprache -->
  <div class="location">
    <!-- Überschrift -->
    <h5 class="headline text-white mb-3">
      {{ $t('layoutFooter.footerLanguage.headline') }}
    </h5>

    <!-- Anzeige aktuelle Sprache -->
    <div class="mb-2">
      <span :class="`flag-icon flag-icon-${getLanguageIconClassAffix(activeLanguage.languageIso)} mr-1`" />
      <span class="text">
        {{ activeLanguage.label }}
      </span>
    </div>

    <!-- Link Sprachauswahl-Dialog öffnen -->
    <a
      href="#"
      class="icon-link"
      @click.prevent="openLanguageModal">
      <i class="fas fa-globe fa-fw" />
      <span class="text">
        {{ $t('layoutFooter.footerLanguage.chooseLanguage') }}
      </span>
    </a>



    <!-- Sprachauswahl Dialog -->
    <dialog-language-selection ref="languageModal" />
  </div>
</template>

<script>
import { getLanguageIconClassAffix } from '@scripts/modules/language'

import DialogLanguageSelection from '@components/dialogs/DialogLanguageSelection.vue'

export default {
  components: {
    'dialog-language-selection': DialogLanguageSelection,
  },

  computed: {
    activeLanguage () {
      return this.app.settings.languages.find((language) => language.isActive)
    },
  },

  methods: {
    getLanguageIconClassAffix,

    openLanguageModal () {
      this.$refs.languageModal.show()
    },
  },
}
</script>
