<template>
  <div>
    <h4 class="headline text-white mb-3">
      {{ $t('layoutFooter.footerService.headline') }}
    </h4>

    <ul class="list-unstyled">
      <!-- Übersicht -->
      <li class="py-1">
        <a href="service">
          {{ $t('serviceFaq.page.overview') }}
        </a>
      </li>

      <!-- FAQ -->
      <li
        v-if="app.user.hasPermission('SERVICE_FAQ')"
        class="py-1">
        <a href="service-faq">
          {{ $t('serviceFaq.page.footerLinkLabel') }}
        </a>
      </li>

      <!-- Downloads -->
      <li
        v-if="app.user.hasPermission('SERVICE_DOWNLOADS')"
        class="py-1">
        <a href="service-downloads">
          {{ $t('serviceDownloads.page.footerLinkLabel') }}
        </a>
      </li>


      <!-- Produkte -->
      <li
        v-if="app.user.hasPermission('SERVICE_FORM_UNLISTED_ARTICLES')"
        class="py-1">
        <a href="service-not-listed-products">
          {{ $t('serviceNotListedProducts.page.footerLinkLabel') }}
        </a>
      </li>

      <!-- Handbuch -->
      <li
        v-if="app.settings.manualPath"
        class="py-1">
        <a
          :href="app.settings.manualPath"
          target="_blank">
          {{ $t('serviceManual.page.footerLinkLabel') }}
        </a>
      </li>

      <!-- Kontakt -->
      <li
        v-if="app.user.hasPermission('SERVICE_CONTACT')"
        class="py-1">
        <a href="service-contact">
          {{ $t('serviceContact.page.footerLinkLabel') }}
        </a>
      </li>

      <!-- Teamviewer -->
      <li
        v-if="app.pageSettings.teamViewerLink"
        class="py-1">
        <a :href="app.pageSettings.teamViewerLink">
          {{ $t('service.dashboard.cards.teamViewerTitle') }}
        </a>
      </li>
    </ul>
  </div>
</template>
