<template>
  <div>
    <h4 class="headline text-white mb-3">
      {{ $t('layoutFooter.footerPayment.headline') }}
    </h4>

    <!-- Auflistung Zahlungsarten -->
    <div class="payment-icons">
      <template v-for="(paymentMethod, paymentMethodIndex) in paymentMethods">
        <img
          v-for="(icon, iconIndex) in paymentMethod.icons"
          :key="`${paymentMethodIndex}-${iconIndex}`"
          :src="icon"
          :title="paymentMethod.label"
          :alt="paymentMethod.label">
      </template>
    </div>
  </div>
</template>

<script>
import { applicationSettings } from '@scripts/app/settings'
import { getPaymentIcons } from '@scripts/modules/payment'

// eslint-disable-next-line @typescript-eslint/no-var-requires
const paymentIconRechnung = require('@src/images/payment-icons/invoice.png')

export default {
  computed: {
    paymentMethods () {
      if (applicationSettings.payment.active) {
        // Wenn Zahlungsdienstleister aktiviert ist, werden die Zahlungsarten angezeigt
        return applicationSettings.payment.paymentMethods.reduce((paymentMethods, paymentMethod) => {
          paymentMethods.push({
            icons: getPaymentIcons(applicationSettings.payment.provider, paymentMethod.key),
            label: paymentMethod.label,
          })
          return paymentMethods
        }, [])
      } else {
        // Wenn Zahlungsdienstleister deaktiviert ist, wird nur Rechnung angezeigt
        return [{ label: 'Rechnung', icons: [paymentIconRechnung] }]
      }
    },
  },
}
</script>
