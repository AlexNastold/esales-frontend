<template>
  <!-- Rechtliches / Links -->
  <div>
    <!-- Überschrift -->
    <h4 class="headline text-white mb-3">
      {{ $t('layoutFooter.footerLinks.headline') }}
    </h4>

    <ul class="list-unstyled">
      <!-- AGB -->
      <li class="py-1">
        <a href="terms">
          {{ $t('terms.footerLinkLabel') }}
        </a>
      </li>

      <!-- Datenschutz -->
      <li class="py-1">
        <a href="privacy">
          {{ $t('privacy.footerLinkLabel') }}
        </a>
      </li>

      <!-- Nutzungsbedingungen -->
      <li class="py-1">
        <a href="terms-of-use">
          {{ $t('termsOfUse.footerLinkLabel') }}
        </a>
      </li>

      <!-- Einwilligungserklärung -->
      <li class="py-1">
        <a href="consent-declaration">
          {{ $t('consentDeclaration.footerLinkLabel') }}
        </a>
      </li>

      <!-- Impressum -->
      <li class="py-1">
        <a href="imprint">
          {{ $t('imprint.footerLinkLabel') }}
        </a>
      </li>
    </ul>
  </div>
</template>
