<template>
  <div>
    <button
      :class="buttonClass"
      :disabled="disabled || $store.getters.getAddToBasketIsProcessing"
      :title="$t('general.actionButtons.addToBasketButtonLabel')"
      type="button"
      class="btn"
      @click="onClick">
      <app-icon-state
        :is-loading="$store.getters.getAddToBasketIsProcessing"
        icon="fas fa-shopping-cart" />
      <span v-if="!isIconOnly">
        {{ $t('general.actionButtons.addToBasketButtonLabel') }}
      </span>
      <span
        v-if="isInBasket"
        class="badge">
        <i class="fas fa-check fa-fw" />
      </span>
    </button>

    <!-- Auswahldialog Warenkorb -->
    <dialog-basket-selection
      v-if="isModalOpen"
      @select="onBasketSelect"
      @hidden="isModalOpen = false" />
  </div>
</template>

<script>
import { addPositionToBasket, getBaskets } from '@scripts/modules/basket'
import { showSuccessMessage, showErrorMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { AddToBasketMode } from '@scripts/modules/user-settings'
import { store } from '@scripts/core/setup/vuex'
import DialogBasketSelection from '@components/dialogs/DialogBasketSelection.vue'

export default {
  components: {
    'dialog-basket-selection': DialogBasketSelection,
  },

  props: {
    amount: {
      default: 1,
      type: Number,
    },
    buttonClass: {
      default: 'btn-primary',
      type: String,
    },
    disabled: {
      default: false,
      type: Boolean,
    },
    documentId: {
      default: void 0,
      type: String,
    },
    documentPosnr: {
      default: void 0,
      type: String,
    },
    documentType: {
      default: 0,
      type: Number,
    },
    isIconOnly: {
      default: false,
      type: Boolean,
    },
    matnr: {
      required: true,
      type: String,
    },
    pitcher: {
      required: true,
      type: String,
    },
  },

  data () {
    return {
      baskets: [],
      isModalOpen: false,
    }
  },

  computed: {
    isInBasket () {
      if (this.$store.getters.getMaterialsInBasket) {
        return this.$store.getters.getMaterialsInBasket.find((material) => material === this.matnr) ? true : false
      } else {
        return false
      }
    },
  },

  methods: {
    async onClick () {
      switch (this.app.user.settings.addToBasketMode) {
        // Immer Dialog öffnen
        case AddToBasketMode.OPEN_DIALOG_ALWAYS:
          this.isModalOpen = true
          break

        // Dialog nur öffnen, wenn es mehr als eine Warenkorb gibt
        case AddToBasketMode.OPEN_DIALOG_MULTIPLE_BASKETS:
          try {
            this.baskets = (await getBaskets()).multibaskets

            if (this.baskets.length > 1) {
              this.isModalOpen = true
            } else {
              this.addToBasket()
            }
          } catch (e) {
            console.error(e)
            showTechnicalErrorMessage()
          }
          break

        // Dialgo niemals öffnen
        case AddToBasketMode.OPEN_DIALOG_NEVER:
          this.addToBasket()
          break
      }
    },

    onBasketSelect (basket) {
      this.addToBasket(basket)
    },

    async addToBasket (basket) {
      store.dispatch('updateAddToBasketIsProcessing', true)

      const documentOptions = {
        docId: this.documentId,
        docPosnr: this.documentPosnr,
        docType: this.documentType,
      }

      try {
        if (basket) {
          await addPositionToBasket(this.matnr, this.amount, this.pitcher, { basketName: basket.name, ...documentOptions })
          showSuccessMessage(this.$t('general.actionButtons.addToSpecificBasketSuccessMessage', {basketName: basket.name}) + `<br><br>
            <a href="basket" class="icon-link text-white">
              <i class="fas fa-shopping-cart fa-fw"></i>
              <span class="text text-underline">${this.$t('general.actionButtons.addToBasketLinkLabel')}</span>
            </a>
          `)
        } else {
          await addPositionToBasket(this.matnr, this.amount, this.pitcher, documentOptions)
          showSuccessMessage(this.$t('general.actionButtons.addToBasketSuccessMessage') + `<br><br>
            <a href="basket" class="icon-link text-white">
              <i class="fas fa-shopping-cart fa-fw"></i>
              <span class="text text-underline">${this.$t('general.actionButtons.addToBasketLinkLabel')}</span>
            </a>
          `)
        }
        this.$emit('success')
      } catch (e) {
        console.error(e)
        showErrorMessage(e.message) // @TODO: Wirklich die Errormessage anzeigen (evtl. showTechnicalErrorMessage verwenden) -> Prüfen, welche Meldungen hier kommen können
      }

      store.dispatch('updateAddToBasketIsProcessing', false)
    },
  },
}
</script>

<style lang="scss" scoped>
.btn {
  position: relative;
  .badge {
    position: absolute;
    font-size: .8em;
    right: -4px;
  }
}
</style>
