<template>
  <div>
    <div
      v-for="eekClass in classes"
      :key="eekClass.id"
      class="d-flex align-items-center mb-1">
      <img
        :src="getEEKIconUrl(eekClass.class)"
        :alt="$t('general.eekLogo')"
        class="eek-icon mr-2">
      <div
        :title="eekClass.text"
        class="text">
        {{ eekClass.text }}
      </div>
    </div>
  </div>
</template>

<script>
import { getEEKIconUrl } from '@scripts/modules/eek'

export default {
  props: {
    classes: {
      default () {
        return []
      },
      type: Array,
    },
  },

  methods: {
    getEEKIconUrl,
  },
}
</script>

<style lang="scss" scoped>

.eek-icon {
  height: 20px;
  width: auto;
}

</style>


