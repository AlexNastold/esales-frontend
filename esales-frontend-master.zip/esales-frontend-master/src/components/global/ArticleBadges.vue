<template>
  <app-loading-spinner v-if="isLoading" />
  <div v-else>
    <!-- Bereits gekauft -->
    <span
      v-if="alreadyPurchased"
      class="badge badge-info already-purchased p-1 mt-1">
      <i
        class="fas fa-box-open" />
      {{ $t('general.alreadyPurchased') }}
    </span>
    <!-- Zusatzartikel -->
    <app-additional-material-badge
      v-if="additionalMaterialCategories.length"
      :additional-material-categories="additionalMaterialCategories"
      class="mt-1" />
  </div>
</template>

<script>
export default {
  props: {
    isLoading: {
      default: false,
      type: Boolean,
    },
    alreadyPurchased: {
      default: false,
      type: Boolean,
    },
    additionalMaterialCategories: {
      required: true,
      type: Array,
    },
  },
}
</script>

<style lang="scss" scoped>

.already-purchased {
  animation: fadeIn .2s ease-in;
  animation-fill-mode: forwards;
  opacity: 0;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

</style>
