<template>
  <div class="component-article-atoms-prices">
    <!-- Preise mit Nettopreisberechtigung -->
    <div
      v-if="app.user.hasPermission('SHOW_NET_PRICE')">
      <!-- Bruttopreis  -->
      <div class="secondary-price text-muted">
        <div v-if="!isPriceLoading">
          <div v-if="retailPrice.price">
            <span class="uvp">
              {{ $t('components.articleAtomPrices.uvp') }}
            </span>
            <span class="price">
              {{ retailPrice.price | price }} {{ retailPrice.currency | replaceCurrencyWithSign }}
            </span>
            <span class="unit text-muted">
              / {{ retailPrice.costUnit | sapNumber }} {{ retailPrice.volumeUnit }}
            </span>
          </div>
          <div v-else>
            <span class="price">
              {{ $t('components.articleAtomPrices.priceOnRequest') }}
            </span>
          </div>
        </div>
        <div
          v-else
          class="loading">
          <app-loading-spinner />
        </div>
      </div>

      <!-- Nettopreis  -->
      <div class="primary-price">
        <div
          v-if="!isPriceLoading"
          class="content">
          <div v-if="netPrice.price">
            <span class="price">
              {{ netPrice.price | price }} {{ netPrice.currency | replaceCurrencyWithSign }}
            </span>
            <span class="unit text-muted">
              / {{ netPrice.costUnit | sapNumber }} {{ netPrice.volumeUnit }}
            </span>
          </div>
          <div v-else>
            <span class="price">
              {{ $t('components.articleAtomPrices.priceOnRequest') }}
            </span>
          </div>
        </div>
        <div
          v-else
          class="loading">
          <app-loading-spinner />
        </div>
      </div>
    </div>

    <!-- Preise ohne Nettopreisberechtigung -->
    <div
      v-else
      class="primary-price">
      <div v-if="!isPriceLoading">
        <div v-if="retailPrice.price">
          <span class="price">
            {{ retailPrice.price | price }} {{ retailPrice.currency | replaceCurrencyWithSign }}
          </span>
          <span class="unit text-muted">
            / {{ retailPrice.costUnit | sapNumber }} {{ retailPrice.volumeUnit }}
          </span>
        </div>
        <div v-else>
          <span class="price">
            {{ $t('components.articleAtomPrices.priceOnRequest') }}
          </span>
        </div>
      </div>
      <div
        v-else
        class="loading">
        <app-loading-spinner />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    isPriceLoading: {
      default: false,
      type: Boolean,
    },
    netPrice: {
      default: void 0,
      type: Object,
    },
    retailPrice: {
      default: void 0,
      type: Object,
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.component-article-atoms-prices {
  font-family: $font-family-headline;

  .secondary-price {
    font-size: .75rem;

    .price {
      text-decoration: line-through;
    }
  }

  .primary-price {

    .content {
      animation: fadeIn .2s ease-in;
      animation-fill-mode: forwards;
      height: 35px;
      opacity: 0;
    }

    .loading {
      align-items: center;
      display: flex;
      height: 35px;
      justify-content: flex-end;
    }

    .price {
      color: $primary-price-color;
      font-size: 1.5rem;
      font-weight: bold;
    }

    .unit {
      font-size: .75rem;
    }
  }
}
</style>
