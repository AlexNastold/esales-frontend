<template>
  <footer
    v-if="app.state.orderVariant !== OrderVariant.SAP">
    <div
      class="scroll-to-top"
      @click="scrollToTop">
      <i class="fas fa-angle-up fa-fw" />
    </div>
    <div class="content text-center text-sm-left pt-5">
      <div class="container">
        <div class="row">
          <!-- Social Media -->
          <div
            v-if="!app.state.kioskMode"
            class="col-12 col-sm-6 col-lg-3 mb-4">
            <layout-footer-social-media />
          </div>

          <!-- Zahlungsarten -->
          <div
            v-if="!app.state.kioskMode"
            class="col-12 col-sm-6 col-lg-3 mb-4">
            <layout-footer-payment />
          </div>

          <!-- Service -->
          <div class="col-12 col-sm-6 col-lg-3 mb-4">
            <layout-footer-service v-if="app.user.isLoggedIn && !app.state.kioskMode " />
            <layout-footer-language />
          </div>

          <!-- Rechtliches -->
          <div class="col-12 col-sm-6 col-lg-3 mb-4">
            <layout-footer-links />
          </div>
        </div>
      </div>
    </div>
    <div class="copyright font-size-xs text-center">
      <strong>
        <i class="far fa-copyright fa-fw" />
        {{ year }} {{ copyrightText }}.
      </strong>
      {{ $t('layoutFooter.allRightsReserved') }}
    </div>
  </footer>
</template>

<script>
import moment from 'moment'

import { applicationSettings } from '@scripts/app/settings'

import LayoutFooterLanguage from './layout-footer/LayoutFooterLanguage.vue'
import LayoutFooterLinks from './layout-footer/LayoutFooterLinks.vue'
import LayoutFooterPayment from './layout-footer/LayoutFooterPayment.vue'
import LayoutFooterService from './layout-footer/LayoutFooterService.vue'
import LayoutFooterSocialMedia from './layout-footer/LayoutFooterSocialMedia.vue'

import { OrderVariant } from '@scripts/modules/basket'

export default {
  components: {
    'layout-footer-language': LayoutFooterLanguage,
    'layout-footer-links': LayoutFooterLinks,
    'layout-footer-payment': LayoutFooterPayment,
    'layout-footer-service': LayoutFooterService,
    'layout-footer-social-media': LayoutFooterSocialMedia,
  },

  data () {
    return {
      copyrightText: applicationSettings.footer.copyright,
      year: moment().format('YYYY'),
      OrderVariant,
    }
  },

  methods: {
    scrollToTop () {
      window.scrollTo(0, 0)
    },
  },
}
</script>
