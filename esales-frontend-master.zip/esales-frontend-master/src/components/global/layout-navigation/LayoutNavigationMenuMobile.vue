<template>
  <div
    :class="{ open: isMenuOpen }"
    class="menu-mobile d-md-none">
    <!-- Backdrop -->
    <div
      ref="backdrop"
      class="backdrop"
      @click="closeMenu" />

    <!-- Menu -->
    <div
      ref="menu"
      class="menu">
      <!-- Menu Info Header -->
      <div class="menu-info-header-background">
        <div class="menu-info-header p-3 text-white">
          <!-- Schließen Button -->
          <div
            class="menu-close p-3"
            @click="closeMenu">
            <i class="fas fa-times fa-fw fa-lg" />
          </div>

          <!-- Logo -->
          <a
            href="index"
            class="d-flex align-items-center justify-content-center p-1 mx-auto logo">
            <img
              :src="logo"
              alt="fis-gmbh-logo">
          </a>

          <!-- User-Informationen -->
          <template v-if="app.user.isLoggedIn">
            <div class="font-weight-bold font-size-lg mt-3">
              {{ app.user.firstName }} {{ app.user.lastName }}
            </div>
            <div class="small">
              {{ app.user.alias }}
            </div>
          </template>
        </div>
      </div>

      <!-- Auflistung Seiten -->
      <ul class="mb-2">
        <!-- Anmelden -->
        <li v-if="!app.user.isLoggedIn && isLoginButtonVisible">
          <a
            href="login">
            <i class="fas fa-user fa-fw" />&nbsp;
            {{ $t('login.menuTitle') }}
          </a>
        </li>

        <!-- Abmelden -->
        <li v-if="app.user.isLoggedIn">
          <a
            class="text-primary"
            href="service"
            @click.prevent="logout">
            <i class="fas fa-sign-out-alt fa-fw" />&nbsp;
            {{ $t('layoutNavigation.menu.logout') }}
          </a>
        </li>

        <!-- Benutzer wechseln -->
        <li
          v-if="app.user.isAdma"
          class="highlight">
          <a
            href="login-adma">
            <i class="fas fa-user-secret fa-fw" />&nbsp;
            {{ $t('loginAdma.menuTitle') }}
          </a>
        </li>

        <!-- Mein Konto -->
        <li
          v-if="app.user.isLoggedIn">
          <a href="my-account">
            <i class="fas fa-user fa-fw" />&nbsp;
            {{ $t('myAccount.menuTitle') }}
          </a>
        </li>

        <!-- Aktionen -->
        <li v-if="app.user.hasPermission('CAMPAIGNS')">
          <a href="campaigns">
            <i class="fas fa-percent fa-fw" />&nbsp;
            {{ $t('campaigns.list.menuTitle') }}
          </a>
        </li>

        <!-- Produktvergleich -->
        <li v-if="app.user.hasPermission('COMPARISON')">
          <a
            href="product-comparison"
            class="d-flex align-items-center">
            <i class="fas fa-balance-scale fa-fw" />&nbsp;
            {{ $t('productComparison.list.menuTitle') }}
            <span class="badge badge-pill badge-dark py-1 ml-auto">
              {{ $store.getters.getAmountComparison }}
            </span>
          </a>
        </li>

        <!-- Etiketten -->
        <li v-if="app.user.hasPermission('LABELS')">
          <a
            href="labels"
            class="d-flex align-items-center">
            <i class="fas fa-tags fa-fw" />&nbsp;
            {{ $t('labels.list.menuTitle') }}
            <span class="badge badge-pill badge-dark py-1 ml-auto">
              {{ $store.getters.getAmountLabels }}
            </span>
          </a>
        </li>

        <!-- Bestellmatrix -->
        <li v-if="app.user.hasPermission('ORDERMATRIX')">
          <a href="ordermatrix">
            <i class="fas fa-table fa-fw" />&nbsp;
            {{ $t('ordermatrix.detail.menuTitle') }}
          </a>
        </li>

        <!-- Oxomi Portal -->
        <li v-if="app.settings.oxomi.active && app.settings.oxomi.options.portal">
          <a
            href="#"
            @click.prevent="openOxomiPortal">
            <i class="fas fa-book-open fa-fw" />&nbsp;
            {{ $t('oxomi.openPortalMenuTitle') }}
          </a>
        </li>

        <!-- Katalog -->
        <template v-if="app.user.hasPermission('CATALOGUE')">
          <li>
            <a href="catalogue">
              <i class="fas fa-sitemap fa-fw" />&nbsp;
              {{ $t('catalogue.menuTitle') }}
            </a>
          </li>
          <li v-if="isCategoriesLoading">
            <app-loading-spinner class="my-3 text-center" />
          </li>
          <template v-else>
            <li
              v-for="(category, index) in categoriesToDisplay"
              :key="index"
              class="sub">
              <a :href="`catalogue?fq=${encodeURIComponent(category.filterQuery)}`">
                {{ category.label }}
              </a>
            </li>
          </template>
          <li
            v-if="categoriesAmountAll > amountOfCategoriesToDisplay"
            class="sub">
            <a
              href="catalogue"
              class="d-flex align-items-center">
              {{ $t('layoutNavigation.menu.furtherCategories') }}
              <i class="fas fa-angle-right fa-fw ml-auto" />
            </a>
          </li>
        </template>
      </ul>

      <!-- Nettoswitch -->
      <div
        v-if="app.user.isLoggedIn && isNettoswitchVisible && app.user.hasPermission('TOGGLE_NET_PRICE')"
        class="px-3 my-3">
        <a
          href="#"
          class="icon-link"
          @click.prevent="showNetPriceSwitchDialog">
          <template v-if="app.user.isNetPriceEnabled">
            <i class="fas fa-toggle-on fa-fw" />&nbsp;
            <span class="text">
              {{ $t('nettoSwitch.hideLabel') }}
            </span>
          </template>
          <template v-else>
            <i class="fas fa-toggle-off fa-fw" />&nbsp;
            <span class="text">
              {{ $t('nettoSwitch.showLabel') }}
            </span>
          </template>
        </a>
      </div>

      <!-- Social Media, Sprache, Rechtliches -->
      <div class="px-3 my-2">
        <!-- Social Media -->
        <div class="text-center mb-1">
          <a
            v-if="app.settings.socialMedia.facebook"
            :href="app.settings.socialMedia.facebook"
            class="text-dark">
            <i class="fab fa-facebook fa-fw p-1 mx-1" />
          </a>
          <a
            v-if="app.settings.socialMedia.twitter"
            :href="app.settings.socialMedia.twitter"
            class="text-dark">
            <i class="fab fa-twitter fa-fw p-1 mx-1" />
          </a>
          <a
            v-if="app.settings.socialMedia.googleplus"
            :href="app.settings.socialMedia.googleplus"
            class="text-dark">
            <i class="fab fa-google-plus fa-fw p-1 mx-1" />
          </a>
          <a
            v-if="app.settings.socialMedia.youtube"
            :href="app.settings.socialMedia.youtube"
            class="text-dark">
            <i class="fab fa-youtube fa-fw p-1 mx-1" />
          </a>
          <a
            v-if="app.settings.socialMedia.instagram"
            :href="app.settings.socialMedia.instagram"
            class="text-dark">
            <i class="fab fa-instagram fa-fw p-1 mx-1" />
          </a>
          <a
            v-if="app.settings.socialMedia.linkedin"
            :href="app.settings.socialMedia.linkedin"
            class="text-dark">
            <i class="fab fa-linkedin fa-fw p-1 mx-1" />
          </a>
        </div>

        <!-- Sprache -->
        <div class="mb-2">
          <!-- Anzeige aktuelle Sprache -->
          <div class="mb-1 d-flex align-items-center">
            <span :class="`flag-icon flag-icon-${getLanguageIconClassAffix(activeLanguage.languageIso)} mr-1`" />
            <span class="text">
              {{ activeLanguage.label }}
            </span>
          </div>

          <!-- Link Sprachauswahl-Dialog öffnen -->
          <a
            href="#"
            class="icon-link py-1"
            @click.prevent="openLanguageModal">
            <i class="fas fa-globe fa-fw" />
            <span class="text">
              {{ $t('layoutFooter.footerLanguage.chooseLanguage') }}
            </span>
          </a>
        </div>

        <!-- Rechtliches -->

        <!-- AGB -->
        <a
          href="terms"
          class="text-muted py-1">
          {{ $t('terms.footerLinkLabel') }}
        </a>
        |
        <!-- Datenschutz -->
        <a
          href="privacy"
          class="text-muted py-1">
          {{ $t('privacy.footerLinkLabel') }}
        </a>
        |
        <!-- Impressum -->
        <a
          href="imprint"
          class="text-muted py-1">
          {{ $t('imprint.footerLinkLabel') }}
        </a>
        <br>
        <!-- Nutzungsbedingungen -->
        <a
          href="terms-of-use"
          class="text-muted py-1">
          {{ $t('termsOfUse.footerLinkLabel') }}
        </a>
        <br>
        <!-- Einwilligungserklärung -->
        <a
          href="consent-declaration"
          class="text-muted py-1">
          {{ $t('consentDeclaration.footerLinkLabel') }}
        </a>
      </div>
    </div>

    <!-- Sprachauswahl Dialog -->
    <dialog-language-selection ref="languageModal" />
  </div>
</template>

<script>
import { getLanguageIconClassAffix } from '@scripts/modules/language'
import { redirect } from '@scripts/helper/redirect'
import { logout } from '@scripts/modules/auth'
import { showNetPriceSwitchDialog } from '@scripts/modules/nettoswitch'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { setOxomiConfiguration, openPortal } from '@scripts/modules/oxomi'

import DialogLanguageSelection from '@components/dialogs/DialogLanguageSelection.vue'

// eslint-disable-next-line @typescript-eslint/no-var-requires
const logo = require('@src/images/logo-large-harolds.png')

export default {
  components: {
    'dialog-language-selection': DialogLanguageSelection,
  },

  props: {
    categories: {
      required: true,
      type: Array,
    },
    categoriesAmountAll: {
      required: true,
      type: Number,
    },
    isCategoriesLoading: {
      required: true,
      type: Boolean,
    },
    isLoginButtonVisible: {
      default: true,
      type: Boolean,
    },
    isNettoswitchVisible: {
      default: true,
      type: Boolean,
    },
  },

  data () {
    return {
      isMenuOpen: false,
      logo,
    }
  },

  computed: {
    activeLanguage () {
      return this.app.settings.languages.find((language) => language.isActive)
    },
    /**
     * Anzahl der Katalogkategorien, die angezeigt werden
     *
     * Feste Anzahl, da im mobilen Menu genug Platz ist.
     * Sollten aber auch nicht zu viele sein, daher hier die maximale Anzahl.
     */
    amountOfCategoriesToDisplay () {
      return 5
    },
    categoriesToDisplay () {
      return this.categories.slice(0, this.amountOfCategoriesToDisplay)
    },
  },

  methods: {
    getLanguageIconClassAffix,
    openMenu () {
      this.isMenuOpen = true
    },
    closeMenu () {
      this.isMenuOpen = false
    },
    async logout () {
      try {
        await logout()
        redirect('index')
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
    openOxomiPortal () {
      setOxomiConfiguration(this.app.settings.oxomi)
      openPortal()
    },
    showNetPriceSwitchDialog,
    openLanguageModal () {
      this.$refs.languageModal.show()
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.menu-info-header-background {
  background-position: center center;
  background-size: cover;
  background-image: url('../../../images/mobile-menu-bg.png');
}

.logo {
  height: 60px;

  img {
    height: auto;
    max-height: 100%;
    max-width: 100%;
    width: auto;
  }
}

.menu-info-header {
  position: relative;
  background: rgba($dark, 0.9);

  .menu-close {
    position: absolute;
    right: 0;
    top: 0;
  }
}
</style>
