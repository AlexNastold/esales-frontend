<template>
  <nav
    v-if="app.state.orderVariant !== OrderVariant.SAP"
    class="app-navigation">
    <div class="container">
      <!-- Navbar Desktop -->
      <layout-navigation-navbar-desktop
        :is-article-menu-open="isArticleMenuOpen"
        :is-categories-loading="isCategoriesLoading"
        :categories="categories"
        :categories-amount-all="categoriesAmountAll" />

      <!-- Navbar mobile -->
      <layout-navigation-navbar-mobile
        :is-categories-loading="isCategoriesLoading"
        :categories="categories"
        :categories-amount-all="categoriesAmountAll" />
    </div>
  </nav>
</template>

<script>
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { getShopCategories } from '@scripts/modules/shop-categories.ts'

import LayoutNavigationNavbarDesktop from './LayoutNavigationNavbarDesktopAfterLogin.vue'
import LayoutNavigationNavbarMobile from './LayoutNavigationNavbarMobileAfterLogin.vue'

import { OrderVariant } from '@scripts/modules/basket'

export default {
  components: {
    'layout-navigation-navbar-desktop': LayoutNavigationNavbarDesktop,
    'layout-navigation-navbar-mobile': LayoutNavigationNavbarMobile,
  },

  props: {
    isArticleMenuOpen: {
      default: false,
      type: Boolean,
    },
    isLoginButtonVisible: {
      default: true,
      type: Boolean,
    },
    isNettoswitchVisible: {
      default: true,
      type: Boolean,
    },
  },

  data () {
    return {
      categories: [],
      categoriesAmountAll: 0,
      isCategoriesLoading: true,
      OrderVariant,
    }
  },

  async created () {
    try {
      const { categories, amountAll } = await getShopCategories(10)
      this.categories = categories
      this.categoriesAmountAll = amountAll
      this.isCategoriesLoading = false
    } catch (e) {
      console.error(e)
      showTechnicalErrorMessage()
    }
  },
}
</script>
