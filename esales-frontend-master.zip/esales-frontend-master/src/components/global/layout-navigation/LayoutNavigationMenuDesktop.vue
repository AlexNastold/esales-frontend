<template>
  <div>
    <ul>
      <!-- Aktionen -->
      <li v-if="shouldDisplayCampaigns">
        <a href="campaigns">
          <i class="fas fa-percent fa-fw" />&nbsp;
          {{ $t('campaigns.list.menuTitle') }}
        </a>
      </li>

      <!-- Produktvergleich -->
      <li v-if="shouldDisplayComparison">
        <a
          href="product-comparison"
          class="d-flex align-items-center">
          <i class="fas fa-balance-scale fa-fw" />&nbsp;
          {{ $t('productComparison.list.menuTitle') }}
          <span class="badge badge-pill badge-dark py-1 ml-auto">
            {{ $store.getters.getAmountComparison }}
          </span>
        </a>
      </li>

      <!-- Etiketten -->
      <li v-if="shouldDisplayLabel">
        <a
          href="labels"
          class="d-flex align-items-center">
          <i class="fas fa-tags fa-fw" />&nbsp;
          {{ $t('labels.list.menuTitle') }}
          <span class="badge badge-pill badge-dark py-1 ml-auto">
            {{ $store.getters.getAmountLabels }}
          </span>
        </a>
      </li>

      <!-- Ordermatrix -->
      <li v-if="shouldDisplayOrdermatrix">
        <a href="ordermatrix">
          <i class="fas fa-table fa-fw" />&nbsp;
          {{ $t('ordermatrix.detail.menuTitle') }}
        </a>
      </li>

      <!-- Oxomi Portal -->
      <li v-if="shouldDisplayOxomiPortal">
        <a
          href="#"
          @click.prevent="openOxomiPortal">
          <i class="fas fa-book-open fa-fw" />&nbsp;
          {{ $t('oxomi.openPortalMenuTitle') }}
        </a>
      </li>

      <!-- Katalog -->
      <template v-if="app.user.hasPermission('CATALOGUE')">
        <li>
          <a href="catalogue">
            <i class="fas fa-sitemap fa-fw" />&nbsp;
            {{ $t('catalogue.menuTitle') }}
          </a>
        </li>
        <li v-if="isCategoriesLoading">
          <app-loading-spinner
            :style="{height: `${amountOfCategoriesToDisplay * 41}px`}"
            class="d-flex align-items-center justify-content-center" /> <!-- 41px is the size of an menu item on desktop -->
        </li>
        <template v-else>
          <li
            v-for="(category, index) in categoriesToDisplay"
            :key="index"
            class="sub">
            <a :href="`catalogue?fq=${encodeURIComponent(category.filterQuery)}`">
              {{ category.label }}
            </a>
          </li>
        </template>
        <li
          v-if="categoriesAmountAll > amountOfCategoriesToDisplay"
          class="sub">
          <a
            href="catalogue"
            class="d-flex align-items-center">
            {{ $t('layoutNavigation.menu.furtherCategories') }}
            <i class="fas fa-angle-right fa-fw ml-auto" />
          </a>
        </li>
      </template>
    </ul>
  </div>
</template>

<script>
import { setOxomiConfiguration, openPortal } from '@scripts/modules/oxomi'

export default {
  props: {
    categories: {
      required: true,
      type: Array,
    },
    categoriesAmountAll: {
      required: true,
      type: Number,
    },
    isCategoriesLoading: {
      required: true,
      type: Boolean,
    },
  },

  computed: {
    shouldDisplayTopsellers () {
      return this.app.user.hasPermission('TOPSELLER_SHOP')
    },
    shouldDisplayCampaigns () {
      return this.app.user.hasPermission('CAMPAIGNS')
    },
    shouldDisplayOrdermatrix () {
      return this.app.user.hasPermission('ORDERMATRIX')
    },
    shouldDisplayOxomiPortal () {
      return this.app.settings.oxomi.active && this.app.settings.oxomi.options.portal
    },
    shouldDisplayComparison () {
      return this.app.user.hasPermission('COMPARISON')
    },
    shouldDisplayLabel () {
      return this.app.user.hasPermission('LABELS')
    },
    /**
     * Anzahl der Katalogkategorien, die angezeigt werden
     *
     * Die Anzahl ist abhängig von anderen Menupunkten
     * z.B. wenn Produktvergleich nicht angezeigt wird,
     * wird eine Katalogkategorie mehr angezeigt
     */
    amountOfCategoriesToDisplay () {
      let categoriesAmount = 7
      if (!this.shouldDisplayTopsellers) {
        categoriesAmount++
      }
      if (!this.shouldDisplayCampaigns) {
        categoriesAmount++
      }
      if (!this.shouldDisplayOrdermatrix) {
        categoriesAmount++
      }
      if (!this.shouldDisplayOxomiPortal) {
        categoriesAmount++
      }
      if (!this.shouldDisplayComparison) {
        categoriesAmount++
      }
      if (!this.shouldDisplayLabel) {
        categoriesAmount++
      }

      return categoriesAmount
    },
    categoriesToDisplay () {
      return this.categories.slice(0, this.amountOfCategoriesToDisplay)
    },
  },

  methods: {
    openOxomiPortal () {
      setOxomiConfiguration(this.app.settings.oxomi)
      openPortal()
    },
  },
}
</script>
