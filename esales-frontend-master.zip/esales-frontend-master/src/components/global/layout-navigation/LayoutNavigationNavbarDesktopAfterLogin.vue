<template>
  <div class="navbar-desktop d-none d-md-block">
    <div class="row d-flex align-items-center">
      <!-- Menu Produkte -->
      <div class="col-4 col-lg-3">
        <div
          :class="{ 'open-on-large-screens': isArticleMenuOpen, open: isArticleMenuOpenedByUser }"
          class="articles nav-dropdown-menu"
          @click.stop>
          <!-- Navigation Dropdown Button -->
          <a
            class="nav-dropdown-button"
            @click.prevent="toggleArticleMenu">
            <i class="fas fa-list-ul fa-fw" />&nbsp;
            {{ $t('layoutNavigation.navbarDesktop.buttonArticleMenu') }}
            <i class="fas fa-angle-down fa-fw nav-dropdown-icon" />
          </a>

          <!-- Desktop Menu -->
          <div class="menu">
            <layout-navigation-menu-desktop
              :is-categories-loading="isCategoriesLoading"
              :categories="categories"
              :categories-amount-all="categoriesAmountAll" />
          </div>
        </div>
      </div>

      <!-- Vorteile -->
      <div class="col small text-muted text-uppercase d-none d-xl-flex justify-content-center">
        <div
          v-for="(advantage, index) in app.settings.header.advantageTexts"
          :key="index"
          class="benefit mx-2">
          <i :class="`${advantage.icon} fa-fw`" />
          {{ advantage.text }}
        </div>
      </div>

      <!-- Nettopreise ausblenden / einblenden -->
      <div class="col-2 col-lg-2 col-xl-1 offset-2 offset-lg-4 offset-xl-0 small d-none d-md-flex align-items-center">
        <a
          v-if="app.user.isLoggedIn && isNettoswitchVisible && app.user.hasPermission('TOGGLE_NET_PRICE')"
          href="#"
          class="icon-link d-flex align-items-center text-white"
          @click.prevent="showNetPriceSwitchDialog">
          <template v-if="app.user.isNetPriceEnabled">
            <i class="fas fa-toggle-on fa-fw fa-lg mr-2" />
            <span class="text">
              {{ $t('nettoSwitch.hideLabel') }}
            </span>
          </template>
          <template v-else>
            <i class="fas fa-toggle-off fa-fw fa-lg mr-2" />
            <span class="text">
              {{ $t('nettoSwitch.showLabel') }}
            </span>
          </template>
        </a>
      </div>

      <!-- Mein Konto Menu -->
      <div class="col-4 col-lg-3 col-xl-2 ml-auto">
        <!-- Benutzer eingeloggt, Menu Dropdown Button anzeigen -->
        <div
          v-if="app.user.isLoggedIn"
          :class="{ open: isMyAccountMenuOpenedByUser }"
          class="my-account nav-dropdown-menu"
          @click.stop>
          <a
            href="#"
            class="nav-dropdown-button"
            @click.prevent="toggleMyAccountMenu">
            <i class="fas fa-user fa-fw" />&nbsp;
            {{ $t('account.menuTitle') }}
            <i class="fas fa-angle-down fa-fw nav-dropdown-icon" />
          </a>
          <div class="menu">
            <my-account-menu :colors="true" />
          </div>
        </div>

        <!-- Kein Benutzer angemeldet, Anmelden Link anzeigen -->
        <div v-else>
          <a
            v-if="!app.user.isLoggedIn && isLoginButtonVisible"
            :href="loginLink"
            class="my-account nav-button"
            @click.prevent="gotoLoginPage">
            <i class="fas fa-user fa-fw" />&nbsp;
            {{ $t('login.menuTitle') }}
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { filterParameters } from '@scripts/helper/nextPageAfterLogin'
import { redirect } from '@scripts/helper/redirect'
import { showNetPriceSwitchDialog } from '@scripts/modules/nettoswitch'

import MyAccountMenu from '@components/pages/my-account/menu.vue'
import LayoutNavigationMenuDesktop from './LayoutNavigationMenuDesktop.vue'

export default {
  components: {
    'layout-navigation-menu-desktop': LayoutNavigationMenuDesktop,
    'my-account-menu': MyAccountMenu,
  },

  props: {
    categories: {
      required: true,
      type: Array,
    },
    categoriesAmountAll: {
      required: true,
      type: Number,
    },
    isArticleMenuOpen: {
      default: false,
      type: Boolean,
    },
    isCategoriesLoading: {
      required: true,
      type: Boolean,
    },
    isLoginButtonVisible: {
      default: true,
      type: Boolean,
    },
    isNettoswitchVisible: {
      default: true,
      type: Boolean,
    },
  },

  data () {
    return {
      isArticleMenuOpenedByUser: false,
      isMyAccountMenuOpenedByUser: false,

      // Achtung: Der Link ist vom Zeitpunkt des Seitenaufrufes!
      // Auf dem Login-Button liegt die JavaScript-Methode gotoLoginPage
      // welche die Redirecturl mitgibt, die zum Zeitpunkt des Klicks gültig ist
      // Für Rechtsklick -> im neuen Tab ist der nicht aktuelle Link ausreichend
      loginLink: `login?redirecturl=${encodeURIComponent(filterParameters(location.href))}`,
    }
  },

  mounted () {
    // Close menus when the user click somewhere else
    document.addEventListener('click', this.closeMenus.bind(this))
  },

  methods: {
    toggleArticleMenu () {
      this.isArticleMenuOpenedByUser = !this.isArticleMenuOpenedByUser

      // Close other menus when this account was opened
      if (this.isArticleMenuOpenedByUser) {
        this.isMyAccountMenuOpenedByUser = false
      }
    },
    toggleMyAccountMenu () {
      this.isMyAccountMenuOpenedByUser = !this.isMyAccountMenuOpenedByUser

      // Close other menus when this account was opened
      if (this.isMyAccountMenuOpenedByUser) {
        this.isArticleMenuOpenedByUser = false
      }
    },
    closeMenus () {
      this.isArticleMenuOpenedByUser = false
      this.isMyAccountMenuOpenedByUser = false
    },
    showNetPriceSwitchDialog,


    gotoLoginPage () {
      redirect('login', {
        redirecturl: location.href,
      })
    },
  },
}
</script>
