<template>
  <nav
    v-if="app.state.orderVariant !== OrderVariant.SAP"
    class="app-navigation">
    <div class="container">
      <!-- Navbar Desktop -->
      <layout-navigation-navbar-desktop />

      <!-- Navbar mobile -->
      <layout-navigation-navbar-mobile />
    </div>
  </nav>
</template>

<script>
import LayoutNavigationNavbarDesktop from './LayoutNavigationNavbarDesktopBeforeLogin.vue'
import LayoutNavigationNavbarMobile from './LayoutNavigationNavbarMobileBeforeLogin.vue'

import { OrderVariant } from '@scripts/modules/basket'

export default {
  components: {
    'layout-navigation-navbar-desktop': LayoutNavigationNavbarDesktop,
    'layout-navigation-navbar-mobile': LayoutNavigationNavbarMobile,
  },
  data () {
    return {
      OrderVariant,
    }
  },
}
</script>
