<template>
  <div>
    <!-- Navbar -->
    <div class="navbar-mobile text-center small d-md-none">
      <div class="row">
        <!-- Login -->
        <div class="offset-9 col-3">
          <a
            href="login"
            class="d-block">
            <i class="fas fa-user fa-fw" />
            <span class="text">
              {{ $t('login.menuTitle') }}
            </span>
          </a>
        </div>
      </div>
    </div>
  </div>
</template>
