<template>
  <div>
    <!-- Navbar -->
    <div class="navbar-mobile text-center small d-md-none">
      <div class="row">
        <!-- Menu-Button -->
        <div class="col-3">
          <a
            href="#"
            class="d-block"
            @click.prevent="openMenu">
            <i class="fas fa-bars fa-fw" />
            {{ $t('layoutNavigation.navbarMobile.openMenu') }}
          </a>
        </div>

        <!-- Listen -->
        <div class="col-3">
          <a
            v-if="app.user.hasPermission('LISTS')"
            href="my-account-lists"
            class="d-block">
            <i class="fas fa-file-alt fa-fw" />
            <span class="text">
              {{ $t('myAccountLists.list.menuTitle') }}
            </span>
          </a>
        </div>

        <!-- Meine Konto, Login -->
        <div class="col-3">
          <!-- Mein Konto -->
          <a
            v-if="app.user.isLoggedIn"
            href="my-account"
            class="d-block">
            <i class="fas fa-user fa-fw" />
            <span class="text">
              {{ $t('myAccount.menuTitle') }}
            </span>
          </a>
          <!-- Anmelden -->
          <a
            v-if="!app.user.isLoggedIn && isLoginButtonVisible"
            :href="loginLink"
            class="d-block"
            @click.prevent="gotoLoginPage">
            <i class="fas fa-user fa-fw" />
            <span class="text">
              {{ $t('login.menuTitle') }}
            </span>
          </a>
        </div>

        <!-- Warenkorb -->
        <div class="col-3">
          <a
            href="basket"
            class="d-block basket">
            <div class="basket-icon-wrapper d-inline-block">
              <i class="fas fa-shopping-cart fa-fw" />
              <transition name="fade">
                <span
                  class="badge badge-pill badge-primary">
                  {{ $store.getters.getAmountBasketPositions }}
                </span>
              </transition>
            </div>
            <br>
            <span class="text">
              {{ $t('basket.menuTitle') }}
            </span>
          </a>
        </div>
      </div>
    </div>

    <!-- Menu -->
    <layout-navigation-menu-mobile
      ref="mobileMenu"
      :is-categories-loading="isCategoriesLoading"
      :categories="categories"
      :categories-amount-all="categoriesAmountAll" />
  </div>
</template>

<script>
import { filterParameters } from '@scripts/helper/nextPageAfterLogin'
import { redirect } from '@scripts/helper/redirect'

import LayoutNavigationMenuMobile from './LayoutNavigationMenuMobile.vue'

export default {
  components: {
    'layout-navigation-menu-mobile': LayoutNavigationMenuMobile,
  },

  props: {
    categories: {
      required: true,
      type: Array,
    },
    categoriesAmountAll: {
      required: true,
      type: Number,
    },
    isCategoriesLoading: {
      required: true,
      type: Boolean,
    },
    isLoginButtonVisible: {
      default: true,
      type: Boolean,
    },
    isNettoswitchVisible: {
      default: true,
      type: Boolean,
    },
  },

  data () {
    return {
      // Achtung: Der Link ist vom Zeitpunkt des Seitenaufrufes!
      // Auf dem Login-Button liegt die JavaScript-Methode gotoLoginPage
      // welche die Redirecturl mitgibt, die zum Zeitpunkt des Klicks gültig ist
      // Für Rechtsklick -> im neuen Tab ist der nicht aktuelle Link ausreichend
      loginLink: `login?redirecturl=${encodeURIComponent(filterParameters(location.href))}`,
    }
  },

  methods: {
    openMenu () {
      this.$refs.mobileMenu.openMenu()
    },

    gotoLoginPage () {
      redirect('login', {
        redirecturl: location.href,
      })
    },
  },
}
</script>
