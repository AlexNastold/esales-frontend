<template>
  <div class="navbar-desktop d-none d-md-block">
    <div class="row">
      <!-- Vorteile -->
      <div class="col small text-muted text-uppercase d-none d-lg-flex justify-content-center align-items-center">
        <div
          v-for="(advantage, index) in app.settings.header.advantageTexts"
          :key="index"
          class="benefit mx-2">
          <i :class="`${advantage.icon} fa-fw`" />
          {{ advantage.text }}
        </div>
      </div>

      <!-- Login -->
      <div class="col-4 col-lg-3 col-xl-2 offset-8 offset-lg-0">
        <a
          href="login"
          class="my-account nav-button">
          <i class="fas fa-user fa-fw" />&nbsp;
          {{ $t('login.menuTitle') }}
        </a>
      </div>
    </div>
  </div>
</template>
