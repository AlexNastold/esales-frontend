<template>
  <input
    ref="query"
    v-model="searchValue"
    :placeholder="typeof placeholder !== 'undefined' ? placeholder : $t('components.formInputProductSearch.placeholderDefault')"
    :disabled="isDisabled"
    type="input"
    @focus="focus"
    @keyup.enter="close">
</template>

<script>
import { axiosBackend } from '@scripts/core/axios'
import { debounce } from 'throttle-debounce'
import I18n from '@scripts/modules/i18n'

export default {
  props: {
    maxItems: {
      default: 10,
      type: Number,
    },
    placeholder: {
      default: void 0,
      type: String,
    },
    value: {
      default: '',
      type: String,
    },
    isDisabled: {
      default: false,
      type: Boolean,
    },
    display: {
      default: 'bismt',
      type: String,
    },
  },

  data () {
    return {
      searchValue: this.value,
    }
  },

  watch: {
    value (value) {
      try {
        $(this.$refs.query).typeahead('val', value)
      } catch (e) {
        // Ist okay
      }
    },
    searchValue (value) {
      this.$emit('input', value)
    },
    isDisabled (value) {
      if (value === true) {
        this.searchValue = ''
      }
    },
  },

  mounted () {
    this.initAutocomplete()
  },

  beforeDestroy () {
    const $searchInput = $(this.$refs.query)
    try {
      $searchInput.typeahead('destroy')
    } catch (e) {
      // Ist okay
    }
  },

  methods: {
    initAutocomplete () {
      const $searchInput = $(this.$refs.query)
      // eslint-disable-next-line @typescript-eslint/no-this-alias
      const that = this

      let response = {}
      $searchInput.typeahead({
        minLength: 3,
        hint: false,
      }, {
        async: true,
        display: this.display,
        limit: Infinity,
        name: 'my-dataset',
        source: debounce(500, async (query, syncResults, asyncResults) => {
          try {
            const result = await axiosBackend.get('webservices/search.ws', { params: {
              fuzzy: true,
              handler: 'SEARCH',
              query,
              rows: this.maxItems,
            }})

            response = result

            asyncResults(result.response.docs)
          } catch (e) {
            console.error(e)
            // Im Fehlerfall ein leeres Ergebnis zurückgeben
            asyncResults([])
          }
        }),
        templates: {
          notFound: `<div class="tt-notfound">
                      ${I18n.t('components.formInputProductSearch.noResults')}
                    </div>`,
          pending () {
            return '<div class="tt-pending"><i class="fas fa-circle-notch fa-spin fa-fw"></i></div>'
          },
          suggestion (item) {
            const $suggestion = $(`
              <div class="container">
                <div class="row">
                  <div class="col-auto">
                    <div class="image-wrapper d-flex justify-content-center align-items-center">
                      <img src="${that.$options.filters.articleImage(item.picture)}" alt="${that.$t('components.formInputProductSearch.productImage')}" />
                    </div>
                  </div>
                  <div class="col py-1">
                    <div class="text">${item.maktx1}</div>
                    <div class="matnr text-muted small">${item.bismt} ${that.getEAN(item)}</div>
                  </div>
                </div>
              </div>
            `)
            $suggestion.mark(item._query, {
              className: 'tt-highlight',
              element: 'span',
            })
            return $suggestion.get(0).outerHTML
          },
          footer (data) {
            return `
              <div class="tt-footer text-right small p-1 text-muted">
                ${I18n.t('components.formInputProductSearch.resultFooter', { length: data.suggestions.length, numFound: response.response.numFound, qtime: response.responseHeader.QTime})}
              </div>
            `
          },
        },
      })

      $searchInput.on('typeahead:select typeahead:autocomplete', (e, selectedItem) => {
        this.$emit('select', selectedItem)
        this.$emit('input', selectedItem[ this.display ])
      })
    },

    getEAN (item) {
      return item.ean11 !== '' ? '// ' + item.ean11 : ''
    },

    focus () {
      const $searchInput = $(this.$refs.query)
      if (this.value === '') {
        this.searchValue = $searchInput.val()
      }
      $searchInput.focus()
    },

    close () {
      const $searchInput = $(this.$refs.query)
      $searchInput.typeahead('close')
    },
  },
}
</script>
