<template>
  <div class="prices text-right">
    <template v-if="mode !== 'sum'">
      <app-loading-spinner v-if="isPriceLoading" />
      <div v-else>
        {{ $t('components.articleAtomPricesBasket.retailPrice') }}
        <template v-if="retailPriceSingle.price">
          {{ retailPriceSingle.price | price }}
          {{ retailPriceSingle.currency | currency }}
        </template>
        <template v-else>
          {{ $t('components.articleAtomPricesBasket.onRequest') }}
        </template>
        <small class="text-muted">
          /
          {{ retailPriceSingle.costUnit | sapNumber }}
          {{ retailPriceSingle.volumeUnit }}
        </small>
      </div>
    </template>
    <template v-if="mode !== 'single'">
      <div
        v-if="app.user.hasPermission('SHOW_NET_PRICE')"
        class="secondary-price font-weight-bold">
        <app-loading-spinner v-if="isPriceLoading" />
        <template v-else>
          <span>{{ $t('components.articleAtomPricesBasket.retailPriceTotal') }}</span>
          <template v-if="retailPrice.price">
            {{ retailPrice.price | price }}
            {{ retailPrice.currency | currency }}
          </template>
          <template v-else>
            {{ $t('components.articleAtomPricesBasket.onRequest') }}
          </template>
        </template>
      </div>
      <div
        v-if="app.user.hasPermission('SHOW_NET_PRICE') && app.state.oltpAvailable"
        class="primary-price font-weight-bold">
        <app-loading-spinner v-if="isPriceLoading" />
        <template v-else>
          <span>{{ $t('components.articleAtomPricesBasket.total') }}</span>
          <template v-if="netPrice.priceTotal">
            {{ netPrice.priceTotal | price }}
            {{ netPrice.currency | currency }}
          </template>
          <template v-else>
            {{ $t('components.articleAtomPricesBasket.onRequest') }}
          </template>
        </template>
      </div>
      <div
        v-if="!app.user.hasPermission('SHOW_NET_PRICE')"
        class="primary-price font-weight-bold">
        <app-loading-spinner v-if="isPriceLoading" />
        <template v-else>
          <span>{{ $t('components.articleAtomPricesBasket.total') }}</span>
          <template v-if="retailPrice.price">
            {{ retailPrice.price | price }}
            {{ retailPrice.currency | currency }}
          </template>
          <template v-else>
            {{ $t('components.articleAtomPricesBasket.onRequest') }}
          </template>
        </template>
      </div>
    </template>
  </div>
</template>

<script>
export default {
  props: {
    isPriceLoading: {
      default: false,
      type: Boolean,
    },
    mode: {
      default: 'both',
      type: String,
      validator (value) {
        return value === 'both' || value === 'single' || value === 'sum'
      },
    },
    netPrice: {
      default: void 0,
      type: Object,
    },
    retailPrice: {
      default: void 0,
      type: Object,
    },
    retailPriceSingle: {
      default: void 0,
      type: Object,
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.prices {
  font-family: $font-family-headline;

  .primary-price {
    font-size: $font-size-lg;
    color: $primary-price-color;
  }
}
</style>

