<template>
  <div class="component-pagination">
    <div class="d-flex">
      <button
        :disabled="disabled || currentPage === 0"
        type="button"
        class="btn btn-secondary"
        @click="previous">
        <i class="fas fa-caret-left fa-fw" />
      </button>
      <div class="form-group mt-0 mb-0 ml-2 mr-2">
        <select
          :disabled="disabled"
          class="custom-select"
          @change="onSelect">
          <option
            v-for="n in pages"
            :key="n"
            :value="n - 1"
            :selected="(n - 1) === currentPage">
            {{ $t('components.pagination.pageNFromPages', { n: n, pages: pages}) }}
          </option>
        </select>
      </div>
      <button
        :disabled="disabled || currentPage === (pages - 1)"
        type="button"
        class="btn btn-secondary"
        @click="next">
        <i class="fas fa-caret-right fa-fw" />
      </button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    currentPage: {
      default: 0,
      type: Number,
    },
    disabled: {
      default: false,
      type: Boolean,
    },
    pages: {
      required: true,
      type: Number,
    },
  },

  methods: {
    previous () {
      window.scrollTo(0, 0)
      this.changePage(this.currentPage - 1)
    },

    next () {
      window.scrollTo(0, 0)
      this.changePage(this.currentPage + 1)
    },

    onSelect (e) {
      window.scrollTo(0, 0)
      this.changePage(e.target.value)
    },

    changePage (page) {
      this.$emit('change', page)
    },
  },
}
</script>
