<template>
  <div
    ref="datepicker"
    class="input-group flex-wrap date"
    @changeDate="updateDate">
    <input
      :class="{ 'is-invalid': errorMessage }"
      :placeholder="placeholder"
      type="text"
      class="form-control"
      @change="updateDate">
    <div class="input-group-append input-group-addon">
      <span class="input-group-text">
        <i class="fas fa-calendar-alt fa-fw" />
      </span>
    </div>
    <div
      v-if="errorMessage"
      class="invalid-feedback w-100"
      v-html="errorMessage" />
  </div>
</template>

<script>
import { applicationSettings } from '@scripts/app/settings'

export default {
  props: {
    endDate: {
      default: void 0,
      type: Date,
    },
    errorMessage: {
      default: '',
      type: String,
    },
    format: {
      default: applicationSettings.dateFormatDatepicker,
      type: String,
    },
    placeholder: {
      default: '',
      type: String,
    },
    startDate: {
      default: void 0,
      type: Date,
    },
    value: {
      default: void 0,
      type: Date,
    },
  },

  watch: {
    value (newValue) {
      $(this.$refs.datepicker).datepicker('update', newValue)
    },
    startDate (newValue) {
      $(this.$refs.datepicker).datepicker('setStartDate', newValue)
    },
    endDate (newValue) {
      $(this.$refs.datepicker).datepicker('setEndDate', newValue)
    },
  },

  mounted () {
    $(this.$refs.datepicker)
      .datepicker({
        autoclose: true,
        format: this.format,
        inline: false,
        language: this.app.user.languageIso.toLowerCase(),
        orientation: 'auto bottom',
        todayBtn: 'linked',
        todayHighlight: true,
      })
      .datepicker('setDate', this.value)
      .datepicker('setStartDate', this.startDate)
      .datepicker('setEndDate', this.endDate)
      .on('changeDate', this.updateDate.bind(this))
  },

  methods: {
    updateDate () {
      const date = $(this.$refs.datepicker).datepicker('getDate')
      this.$emit('input', date)
    },
  },
}
</script>
