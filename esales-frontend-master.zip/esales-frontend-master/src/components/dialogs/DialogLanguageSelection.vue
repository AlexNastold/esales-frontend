<template>
  <div
    ref="modal"
    class="modal fade"
    tabindex="-1"
    role="dialog">
    <div
      class="modal-dialog"
      role="document">
      <div class="modal-content">
        <div class="modal-header bg-primary text-light">
          <h5 class="modal-title">
            {{ $t('components.dialogs.languageSelection.title') }}
          </h5>
          <button
            type="button"
            class="close"
            data-dismiss="modal">
            <span>&times;</span>
          </button>
        </div>
        <div class="modal-body locales">
          <a
            v-for="language in app.settings.languages"
            :key="language.key"
            href="#"
            class="text-decoration-none text-dark d-flex align-items-center py-2"
            @click.prevent="changeLanguage(language.language)">
            <span :class="`flag-icon flag-icon-${getLanguageIconClassAffix(language.languageIso)} flag-icon-squared`" />
            <span class="text">
              {{ language.label }}
            </span>
            <span
              v-if="language.isActive"
              class="badge badge-pill badge-primary ml-2 p-1">
              {{ $t('components.dialogs.languageSelection.badgeActive') }}
            </span>
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { changeLanguage, getLanguageIconClassAffix } from '@scripts/modules/language'
import { reload } from '@scripts/helper/redirect'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  methods: {
    getLanguageIconClassAffix,

    show () {
      $(this.$refs.modal).modal('show')
    },

    async changeLanguage (sapLanguage) {
      try {
        await changeLanguage(sapLanguage)
        reload()
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.locales {
  a {

    &:hover {
      .text {
        color: theme-color('primary');
        text-decoration: underline;
      }
    }
  }

  .flag-icon {
    background-size: cover;
    border-radius: 100%;
    box-shadow: 0 0 5px rgba(0, 0, 0, .5);
    height: 1.5rem;
    margin-right: 15px;
    width: 1.5rem;
  }
}
</style>

