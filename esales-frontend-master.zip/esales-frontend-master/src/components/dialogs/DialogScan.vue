<template>
  <b-modal
    ref="modal"
    :header-close-label="$t('general.dialogCloseLabel')"
    :visible="true"
    :no-enforce-focus="true"
    :title="$t('components.dialogs.scan.title')"
    class="modal-no-padding"
    header-bg-variant="primary"
    header-text-variant="white"
    ok-variant="secondary"
    ok-only
    @hidden="$emit('hidden')"
    @ok.prevent="hideDialog">
    <div
      v-if="isLoading"
      class="text-center py-5">
      <app-loading-spinner />
    </div>

    <div v-show="!isLoading">
      <div v-show="hasBrowserCameraApiSupport && !errorMessage">
        <!-- Button Kamera deaktiveren / aktiveren -->
        <div class="text-center mt-1 mb-3">
          <button
            type="button"
            class="btn btn-secondary"
            :class="{active: format === 'barcode'}"
            @click="selectFormat('barcode')">
            <i class="fas fa-barcode" />
            {{ $t('components.dialogs.scan.buttonBarcode') }}
          </button>
          <button
            type="button"
            class="btn btn-secondary"
            :class="{active: format === 'qrcode'}"
            @click="selectFormat('qrcode')">
            <i class="fas fa-qrcode" />
            {{ $t('components.dialogs.scan.buttonQRCode') }}
          </button>
        </div>

        <!-- Kamerabild -->
        <div
          v-if="format !== ''"
          :class="{'mb-1': isCameraActive, 'mb-3': !isCameraActive}"
          class="videoWrapper px-3">
          <!-- Kamera aktiviert -->
          <div
            v-show="isCameraActive"
            class="videoStreamContainer">
            <video
              id="video"
              autoplay="false" />
          </div>


          <!-- Kamera deaktiviert -->
          <div
            v-if="!isCameraActive"
            class="border rounded">
            <app-box-empty-list
              :headline="$t('components.dialogs.scan.cameraDeactivated')"
              icon="fas fa-camera-retro">
              {{ $t('components.dialogs.scan.cameraDeactivatedDescription') }}
            </app-box-empty-list>
          </div>
        </div>
      </div>

      <div
        v-if="!hasBrowserCameraApiSupport"
        class="p-3">
        <span v-html="$t('components.dialogs.scan.browsernotSupported.description')" />
        <ul class="list-unstyled">
          <li>
            <i class="fab fa-chrome" />
            <a
              href="https://www.google.com/chrome"
              target="_blank">
              {{ $t('components.dialogs.scan.browsernotSupported.googleChrome') }}
            </a>
          </li>
          <li>
            <i class="fab fa-firefox" />
            <a
              href="https://www.mozilla.org/firefox"
              target="_blank">
              {{ $t('components.dialogs.scan.browsernotSupported.mozillaFirefox') }}
            </a>
          </li>
        </ul>
      </div>

      <div
        v-if="errorMessage"
        class="alert alert-danger m-3"
        role="alert">
        {{ errorMessage }}
      </div>
    </div>

    <!-- Abbrechen-Button // b-modal hat Attribut ok-only, ok-variant auf secondary gesetzt - somit OK-Button modifiziert zu Abbrechen-Button -->
    <template slot="modal-ok">
      <i class="fas fa-times fa-fw" />
      {{ $t('general.cancel') }}
    </template>
  </b-modal>
</template>

<script>

/* globals ZXing */

import { confirmDialog } from '@scripts/modules/dialogs'

export default {
  data () {
    return {
      errorMessage: void 0,
      hasBrowserCameraApiSupport: false,
      isCameraActive: false,
      isLoading: true,
      codeReader: void 0,
      format: '',
    }
  },

  mounted () {
    if (this.hasRequiredApis()) {
      this.hasBrowserCameraApiSupport = true
      this.isLoading = false
    } else {
      this.hasBrowserCameraApiSupport = false
      this.isLoading = false
    }
  },

  methods: {
    hasRequiredApis () {
      if (navigator.mediaDevices && typeof navigator.mediaDevices.getUserMedia === 'function') {
        return true
      }
      return false
    },
    selectFormat (format) {
      this.isLoading = true
      this.format = format
      window.setTimeout(()=>{
        this.startScanner()
      }, 200)
    },
    async startScanner () {
      if (this.codeReader) {
        this.codeReader.reset()
      }
      if (this.format === 'qrcode') {
        this.codeReader = new ZXing.BrowserQRCodeReader()
      } else {
        this.codeReader = new ZXing.BrowserBarcodeReader()
      }
      this.startDetecting()
      this.isCameraActive = true
      this.isLoading = false
    },

    async startDetecting () {
      try {
        const result = await this.codeReader.decodeOnceFromVideoDevice(undefined, 'video')
        this.barcodeDetected(result.text, 'EAN')
      } catch (err) {
        if (err.name === 'NotAllowedError') {
          this.isCameraActive = false
        }
      }
    },

    async barcodeDetected (scanResult, format) {
      if (await confirmDialog(
        this.$t('components.dialogs.scan.barocodeRecognizedDialog.title'),
        this.$t('components.dialogs.scan.barocodeRecognizedDialog.description', { code: scanResult, codeFormat: format }),
        {
          buttonCancelText: `<i class="fas fa-barcode fa-fw"></i> ${ this.$t('components.dialogs.scan.barocodeRecognizedDialog.buttonCancel') }`,
          buttonConfirmText: `<i class="fas fa-check fa-fw"></i> ${ this.$t('components.dialogs.scan.barocodeRecognizedDialog.buttonConfirm') }`,
          type: 'info',
        },
      )) {
        this.onBarcodeConfirmed(scanResult)
      } else {
        this.startScanner()
      }
    },

    onBarcodeConfirmed (scanResult) {
      this.$emit('success', scanResult)
      this.hideDialog()
    },

    hideDialog () {
      this.$emit('hidden')
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~styles/definitions/all';

.videoWrapper {
  width: 100%;

  .videoStreamContainer {
    position: relative;

    // The /deep/ selector can be used to make scoped styles
    // work for elements generated at runtime
    // Siehe https://github.com/vuejs/vue-loader/issues/661
    /deep/ {
      > video {
        width: 100%;
        height: 100%;
      }
    }
  }
}
</style>
