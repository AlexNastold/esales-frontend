<template>
  <div>
    <b-modal
      ref="modal"
      :ok-disabled="isProcessing || isLoading"
      :title="$t('components.dialogs.delivery.title')"
      header-bg-variant="primary"
      header-text-variant="white"
      size="lg"
      @ok.prevent="save">
      <app-loading-box v-if="isLoading" />
      <template v-else>
        <form @submit.prevent="save">
          <div class="mb-3">
            <h4 class="mb-3">
              {{ $t('components.dialogs.delivery.deliveryType') }}
            </h4>

            <!-- Lieferung -->
            <div
              class="card rounded d-flex">
              <div class="card-header">
                <div class="custom-control custom-radio">
                  <input
                    :id="`shipment-type-${ShipmentType.DELIVERY}`"
                    v-model="selectedShipmentType"
                    :value="ShipmentType.DELIVERY"
                    name="shipment-type"
                    type="radio"
                    class="custom-control-input"
                    @click="selectedShipmentType = ShipmentType.DELIVERY">
                  <label
                    class="custom-control-label w-100"
                    :for="`shipment-type-${ShipmentType.DELIVERY}`">
                    <i class="fas fa-shipping-fast fa-fw" />
                    {{ $t('components.dialogs.delivery.delivery') }}
                  </label>
                </div>
              </div>
              <!-- Unterarten zur Lieferung -->
              <div
                v-if="selectedShipmentType === ShipmentType.DELIVERY"
                v-show="shippingConditionsToDisplay.length > 1"
                class="card-body">
                <div class="row">
                  <div
                    class="col-lg-6 ml-3">
                    <div
                      v-for="(condition) in shippingConditionsToDisplay"
                      :key="condition.key"
                      class="custom-control custom-radio d-block">
                      <input
                        :id="`shipment-condition-${condition.key}`"
                        v-model="selectedShipmentCondition"
                        :value="condition.key"
                        name="shipment-condition"
                        type="radio"
                        class="custom-control-input"
                        @click="selectedShipmentCondition = condition.key">
                      <label
                        class="custom-control-label"
                        :for="`shipment-condition-${condition.key}`">
                        {{ condition.label }}
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Abholung -->
            <div
              class="card rounded d-flex mt-1">
              <div class="card-header">
                <div class="custom-control custom-radio">
                  <input
                    :id="`shipment-type-${ShipmentType.PICKUP}`"
                    v-model="selectedShipmentType"
                    :value="ShipmentType.PICKUP"
                    name="shipment-type"
                    type="radio"
                    class="custom-control-input"
                    @click="selectedShipmentType = ShipmentType.PICKUP">
                  <label
                    class="custom-control-label w-100"
                    :for="`shipment-type-${ShipmentType.PICKUP}`">
                    <i class="fas fa-dolly fa-fw" />
                    {{ $t('components.dialogs.delivery.pickUp') }}
                  </label>
                </div>
              </div>
              <!-- Unterarten zur Abholung -->
              <div
                v-if="selectedShipmentType === ShipmentType.PICKUP"
                v-show="shippingConditionsToDisplay.length > 1"
                class="card-body">
                <div class="row">
                  <div
                    class="col-lg-6">
                    <div
                      v-for="(condition) in shippingConditionsToDisplay"
                      :key="condition.key"
                      class="custom-control custom-radio d-block">
                      <input
                        :id="`shipment-condition-${condition.key}`"
                        v-model="selectedShipmentCondition"
                        :value="condition.key"
                        name="shipment-condition"
                        type="radio"
                        class="custom-control-input"
                        @click="selectedShipmentCondition = condition.key">
                      <label
                        class="custom-control-label"
                        :for="`shipment-condition-${condition.key}`">
                        {{ condition.label }}
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Lieferart 01 (Abholung) -->
          <div
            v-show="selectedShipmentCondition === ShipmentCondition.PICKUP"
            v-if="shipmentData.shipmentTypes[ShipmentCondition.PICKUP].available">
            <div class="mb-3">
              <h4 class="mb-3">
                {{ $t('components.dialogs.delivery.pickUpDate') }}
              </h4>

              <app-form-input-datepicker
                v-model="form01PickupDate"
                :error-message="formErrors.form01PickupDate"
                :placeholder="$t('components.dialogs.delivery.selectDatePlaceholder')" />
            </div>

            <div class="mb-3">
              <h4 class="mb-3">
                {{ $t('components.dialogs.delivery.pickUpFrom') }}
              </h4>

              <div class="form-group">
                <select
                  v-model="form01Vwerk"
                  :class="{ 'is-invalid': formErrors.form01Vwerk }"
                  class="form-control custom-select">
                  <option :value="void 0">
                    {{ $t('components.dialogs.delivery.pickupFactoryPlaceholder') }}...
                  </option>
                  <option
                    v-for="vkorg in shipmentData.shipmentTypes[ShipmentCondition.PICKUP].vkorgs"
                    :key="`${vkorg.vtweg}-${vkorg.vkorg}-${vkorg.vwerk}`"
                    :value="vkorg.vwerk">
                    {{ vkorg.vtwegText }} ({{ vkorg.vkorg }}, {{ vkorg.vtweg }}, {{ vkorg.vwerk }})
                  </option>
                </select>
                <div
                  v-if="formErrors.form01Vwerk"
                  class="invalid-feedback"
                  v-html="formErrors.form01Vwerk" />
              </div>
            </div>
          </div>

          <!-- Lieferart 02 (Sofortlieferung) -->
          <div
            v-if="shipmentData.shipmentTypes[ShipmentCondition.DELIVERY_IMMEDIATE].available"
            v-show="selectedShipmentCondition === ShipmentCondition.DELIVERY_IMMEDIATE">
            <div class="mb-3">
              <h4 class="mb-3">
                {{ $t('components.dialogs.delivery.deliveryOptions') }}
              </h4>
              <!-- Button Komplettlieferung -->
              <div class="custom-control custom-checkbox d-flex align-items-center">
                <input
                  id="deliverWhenComplete"
                  v-model="form02DeliverWhenComplete"
                  class="custom-control-input"
                  type="checkbox">
                <label
                  class="custom-control-label"
                  for="deliverWhenComplete">
                  {{ $t('components.dialogs.delivery.completeDelivery') }}
                </label>
              </div>
            </div>
          </div>

          <!-- Lieferart 03 (Lieferung) -->
          <div
            v-if="shipmentData.shipmentTypes[ShipmentCondition.DELIVERY].available"
            v-show="selectedShipmentCondition === ShipmentCondition.DELIVERY">
            <div class="mb-3">
              <h4 class="mb-3">
                {{ $t('components.dialogs.delivery.desiredDeliveryDate') }}
              </h4>

              <app-form-input-datepicker
                v-model="form03DeliveryDate"
                :error-message="formErrors.form03DeliveryDate"
                :placeholder="$t('components.dialogs.delivery.selectDatePlaceholder')" />
            </div>
          </div>

          <!-- Adressen -->
          <div
            v-show="selectedShipmentType === ShipmentType.DELIVERY"
            class="delivery-method-delivery-form">
            <div class="mb-3">
              <h4 class="mb-3">
                {{ $t('components.dialogs.delivery.deliveryAddress') }}
              </h4>

              <!-- Adressen durchsuchen -->
              <div class="form-group px-1">
                <div class="input-group">
                  <input
                    v-model="addressFilter"
                    :placeholder="$t('components.dialogs.delivery.searchAddressesPlaceholder')"
                    type="search"
                    class="form-control">
                  <div class="input-group-append">
                    <button
                      class="btn btn-secondary"
                      type="button"
                      @click="addressFilter = ''">
                      <i class="fas fa-times fa-fw" />
                    </button>
                  </div>
                </div>
              </div>

              <!-- Auflistung Adressen -->
              <div class="container">
                <div class="row">
                  <div
                    v-for="address in addressesToDisplay"
                    :key="address.id"
                    class="rounded col-12 col-md-6 col-lg-4 my-1 px-1">
                    <div class="bg-light h-100 p-2">
                      <div class="custom-control custom-radio">
                        <input
                          :id="`delivery-address-${address.id}`"
                          v-model="selectedDeliveryAddress"
                          :value="address.id"
                          type="radio"
                          class="custom-control-input"
                          name="delivery-address">
                        <label
                          :for="`delivery-address-${address.id}`"
                          class="custom-control-label w-100">
                          <strong>{{ address.name1 }} {{ address.name2 }}</strong>
                          <br>
                          <small class="text-muted">
                            <span class="text-nowrap">{{ address.street }},</span>
                            <span class="text-nowrap">{{ address.country }}-{{ address.postalCode }} {{ address.city }}</span>
                          </small>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Abweichende Lieferadresse -->
              <div class="rounded bg-light d-flex p-2 mb-2 mt-3 mx-1">
                <div class="custom-control custom-radio w-100">
                  <input
                    id="delivery-address-custom"
                    v-model="selectedDeliveryAddress"
                    type="radio"
                    class="custom-control-input"
                    name="delivery-address"
                    value="CUSTOM_ADDRESS">
                  <label
                    class="custom-control-label w-100"
                    for="delivery-address-custom">
                    {{ $t('components.dialogs.delivery.customDeliveryAddressLabel') }}
                  </label>
                </div>
              </div>
            </div>

            <div
              v-show="selectedDeliveryAddress === 'CUSTOM_ADDRESS'"
              class="mb-3">
              <h4 class="mb-3">
                {{ $t('components.dialogs.delivery.customDeliveryAddress') }}
              </h4>

              <div class="row">
                <!-- Nachname, Firma -->
                <div class="col-12 col-md-6">
                  <div class="form-group">
                    <label for="lastname-company">
                      {{ $t('components.dialogs.delivery.lastnameCompany') }} <span class="required" />
                    </label>
                    <input
                      id="lastname-company"
                      v-model="formAddressName1"
                      :class="{ 'is-invalid': formErrors.formAddressName1 }"
                      :placeholder="$t('components.dialogs.delivery.lastnameCompanyPlaceholder')"
                      type="text"
                      class="form-control">
                    <div
                      v-if="formErrors.formAddressName1"
                      class="invalid-feedback"
                      v-html="formErrors.formAddressName1" />
                  </div>
                </div>

                <!-- Vorname -->
                <div class="col-12 col-md-6">
                  <div class="form-group">
                    <label for="firstname">
                      {{ $t('components.dialogs.delivery.firstname') }}
                    </label>
                    <input
                      id="firstname"
                      v-model="formAddressName2"
                      :placeholder="$t('components.dialogs.delivery.firstnamePlaceholder')"
                      type="text"
                      class="form-control">
                  </div>
                </div>

                <!-- Land -->
                <div class="col-12 col-md-6">
                  <div class="form-group">
                    <label for="country">
                      {{ $t('components.dialogs.delivery.country') }} <span class="required" />
                    </label>
                    <select
                      id="country"
                      v-model="formAddressCountry"
                      :class="{ 'is-invalid': formErrors.formAddressCountry }"
                      class="form-control custom-select">
                      <option
                        v-for="country in shipmentData.countries"
                        :key="country.key"
                        :value="country.key">
                        {{ country.label }}
                      </option>
                    </select>
                    <div
                      v-if="formErrors.formAddressCountry"
                      class="invalid-feedback"
                      v-html="formErrors.formAddressCountry" />
                  </div>
                </div>

                <!-- Postleitzahl -->
                <div class="col-12 col-md-6">
                  <div class="form-group">
                    <label for="zip-code">
                      {{ $t('components.dialogs.delivery.plz') }}  <span class="required" />
                    </label>
                    <input
                      id="zip-code"
                      v-model="formAddressPostalCode"
                      :class="{ 'is-invalid': formErrors.formAddressPostalCode }"
                      :placeholder="$t('components.dialogs.delivery.plzPlaceholder')"
                      type="text"
                      class="form-control">
                    <div
                      v-if="formErrors.formAddressPostalCode"
                      class="invalid-feedback"
                      v-html="formErrors.formAddressPostalCode" />
                  </div>
                </div>

                <!-- Ort -->
                <div class="col-12 col-md-6">
                  <div class="form-group">
                    <label for="place">
                      {{ $t('components.dialogs.delivery.city') }} <span class="required" />
                    </label>
                    <input
                      id="place"
                      v-model="formAddressCity"
                      :class="{ 'is-invalid': formErrors.formAddressCity }"
                      :placeholder="$t('components.dialogs.delivery.cityPlaceholder')"
                      type="text"
                      class="form-control">
                    <div
                      v-if="formErrors.formAddressCity"
                      class="invalid-feedback"
                      v-html="formErrors.formAddressCity" />
                  </div>
                </div>

                <!-- Straße, Haus-Nr. -->
                <div class="col-12 col-md-6">
                  <div class="form-group">
                    <label for="street-number">
                      {{ $t('components.dialogs.delivery.streetNumber') }} <span class="required" />
                    </label>
                    <input
                      id="street-number"
                      v-model="formAddressStreet"
                      :class="{ 'is-invalid': formErrors.formAddressStreet }"
                      :placeholder="$t('components.dialogs.delivery.streetNumberPlaceholder')"
                      type="text"
                      class="form-control">
                    <div
                      v-if="formErrors.formAddressStreet"
                      class="invalid-feedback"
                      v-html="formErrors.formAddressStreet" />
                  </div>
                </div>

                <app-form-required-hint class="col-12 mt-1" />
              </div>
            </div>
          </div>

          <!-- Ausgeblendeted Submit-Button (zum Abschicken des Formulars mit Enter) -->
          <button
            class="d-none"
            tabindex="-1"
            type="submit" />
        </form>
      </template>


      <template slot="modal-cancel">
        <i class="fas fa-times fa-fw" />
        {{ $t('general.cancel') }}
      </template>

      <template slot="modal-ok">
        <app-icon-state
          :is-loading="isProcessing"
          icon="fas fa-save" />
        {{ $t('general.save') }}
      </template>
    </b-modal>

    <!-- Dialog für Datumsänderungen auf Positionsebene -->
    <dialog-delivery-dates-changed
      v-if="positionDeliveryDateDialog.show"
      :date="positionDeliveryDateDialog.date"
      :positions="positionDeliveryDateDialog.positions"
      @change="$emit('change'); positionDeliveryDateDialog.show = false"
      @finish="positionDeliveryDateDialog.show = false" />
  </div>
</template>

<script>
import { SaveShipmentDataErrorFields, ShipmentCondition, ShipmentType, getShipmentData, saveShipmentData  } from '@scripts/modules/basket'
import { showErrorMessage, showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'
import { dateToSapDate } from '@scripts/helper/sapFormat'
import { matches } from '@scripts/helper/matches'

import DialogDeliveryDatesChanged from './DialogDeliveryDatesChanged.vue'

export default {
  components: {
    'dialog-delivery-dates-changed': DialogDeliveryDatesChanged,
  },

  data () {
    return {
      isLoading: true,
      isProcessing: false,

      ShipmentCondition,
      ShipmentType,

      positionDeliveryDateDialog: {
        date: void 0,
        positions: [],
        show: false,
      },

      shipmentData: void 0,
      form01PickupDate: new Date(),
      form01Vwerk: void 0,
      form02DeliverWhenComplete: false,
      form03DeliveryDate: new Date(),
      formAddressCity: void 0,
      formAddressCountry: void 0,
      formAddressName1: void 0,
      formAddressName2: void 0,
      formAddressPostalCode: void 0,
      formAddressStreet: void 0,
      selectedDeliveryAddress: void 0,
      selectedShipmentCondition: void 0,
      selectedShipmentType: void 0,

      formErrors: {
        form01PickupDate: void 0,
        form01Vwerk: void 0,
        form03DeliveryDate: void 0,
        formAddressCity: void 0,
        formAddressCountry: void 0,
        formAddressName1: void 0,
        formAddressPostalCode: void 0,
        formAddressStreet: void 0,
      },

      addressFilter: '',
    }
  },

  computed: {
    addressesToDisplay () {
      if (this.isLoading) {
        return []
      }
      return this.shipmentData.addresses.filter((address) => {
        if (
          (this.addressFilter && !matches(this.addressFilter, [
            address.name1,
            address.name2,
            address.street,
            address.postalCode,
            address.city,
            address.country,
          ]))
        ) {
          return false
        }
        return true
      })
    },
    activeVwerk () {
      if (!this.shipmentData || !this.shipmentData.shipmentTypes || !this.shipmentData.shipmentTypes[ShipmentCondition.PICKUP]) {
        return void 0
      }
      if (this.shipmentData.shipment.condition === ShipmentCondition.PICKUP) {
        const vkorg = this.shipmentData.shipmentTypes[ShipmentCondition.PICKUP].vkorgs.find((vkorg) => vkorg.active)
        return vkorg ? vkorg.vwerk : void 0
      }
      if (this.shipmentData.shipmentTypes[ShipmentCondition.PICKUP].preferredVwerk) {
        const vkorg = this.shipmentData.shipmentTypes[ShipmentCondition.PICKUP].vkorgs.find((vkorg) => vkorg.vwerk === this.shipmentData.shipmentTypes[ShipmentCondition.PICKUP].preferredVwerk)
        return vkorg ? vkorg.vwerk : void 0
      }
      return void 0
    },
    shippingConditions () {
      if (!this.shipmentData || !this.shipmentData.shipmentTypes) {
        return []
      }
      let shippingConditions = []
      Object.keys(this.shipmentData.shipmentTypes).forEach((key) => {
        if (this.shipmentData.shipmentTypes[key].available) {
          shippingConditions.push({
            key,
            type: this.shipmentData.shipmentTypes[key].type,
            label: this.shipmentData.shipmentTypes[key].label,
          })
        }
      })
      return shippingConditions
    },
    shippingConditionsToDisplay () {
      if (this.isLoading) {
        return []
      }
      return this.shippingConditions.filter((cond)=>cond.type === this.selectedShipmentType)
    },
  },

  watch: {
    selectedShipmentType () {
      this.selectedShipmentCondition = this.shipmentData && this.shipmentData.shipment && this.selectedShipmentType === this.shipmentData.shipment.type ? this.shipmentData.shipment.condition : this.shippingConditionsToDisplay[0].key
    },
  },

  methods: {
    show () {
      this.loadShipmentData()
      this.$refs.modal.show()
    },

    hideDialog () {
      this.$refs.modal.hide()
    },

    /**
     * Lieferdaten laden und anzeigen
     */
    async loadShipmentData () {
      this.isLoading = true

      try {
        this.shipmentData = await getShipmentData()

        // Lieferart
        this.selectedShipmentCondition = this.shipmentData.shipment.condition
        this.selectedShipmentType = this.shipmentData.shipment.type

        // Lieferdatum 01
        this.form01PickupDate = this.shipmentData.shipmentTypes[ShipmentCondition.PICKUP].pickupDate || new Date()

        // Werk 01
        this.form01Vwerk = this.activeVwerk

        // Komplettlieferung 02
        this.form02DeliverWhenComplete = this.shipmentData.shipment.deliverWhenComplete

        // Lieferdatum 03
        this.form03DeliveryDate = this.shipmentData.shipmentTypes[ShipmentCondition.DELIVERY].deliveryDate || new Date()

        // Adresse
        if (this.shipmentData.shipment.address.isDifferent) {
          this.selectedDeliveryAddress = 'CUSTOM_ADDRESS'
        } else {
          this.selectedDeliveryAddress = this.shipmentData.shipment.address.id
        }

        const defaultCountry = this.shipmentData.countries[0] ? this.shipmentData.countries[0].key : void 0
        if (this.shipmentData.shipment.address.isDifferent) {
          const address = this.shipmentData.shipment.address
          this.formAddressName1 = address.name1
          this.formAddressName2 = address.name2
          this.formAddressCountry = address.country ? address.country : defaultCountry
          this.formAddressPostalCode = address.postalCode
          this.formAddressCity = address.city
          this.formAddressStreet = address.street
        } else {
          this.formAddressCountry = defaultCountry
        }

        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },

    async save () {
      if (this.isProcessing || this.isLoading) {
        return
      }

      this.isProcessing = true

      // Fehler zurücksetzen
      this.resetFieldErrors()

      const addressData = this.selectedDeliveryAddress === 'CUSTOM_ADDRESS'
        ? {
          addressCity: this.formAddressCity,
          addressCountry: this.formAddressCountry,
          addressName1: this.formAddressName1,
          addressName2: this.formAddressName2,
          addressPostalCode: this.formAddressPostalCode,
          addressStreet: this.formAddressStreet,
        }
        : {
          addressId: this.selectedDeliveryAddress,
        }

      try {
        const result = await saveShipmentData(this.selectedShipmentCondition, {
          desiredPickupDate: dateToSapDate(this.form01PickupDate),
          desiredDeliveryDate: this.selectedShipmentCondition === ShipmentCondition.DELIVERY ? dateToSapDate(this.form03DeliveryDate) : dateToSapDate(new Date()),
          ...addressData,
          werk: this.form01Vwerk,
          deliverWhenComplete: this.selectedShipmentCondition === ShipmentCondition.DELIVERY_IMMEDIATE ? this.form02DeliverWhenComplete : void 0,
        })

        // Lieferdatum hat sich geändert -> Dialog zum Ändern des Lieferdatums auf Positionsebene anzeigen
        if (result.deliveryDate.hasToBeCheckedAgainstPositions) {
          this.positionDeliveryDateDialog.positions = result.deliveryDate.positions
          this.positionDeliveryDateDialog.date = result.deliveryDate.newDeliveryDate
          this.positionDeliveryDateDialog.show = true
        }

        // Alles okay
        showSuccessMessage(this.$t('basket.components.shipmentData.shipmentDataSaved'))
        this.$emit('change')
        this.hideDialog()
      } catch (e) {
        if (e.code === ErrorCode.INVALID_FIELDS) {
          this.showErrorMessage(e.message, e.fieldErrors)
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }

      this.isProcessing = false
    },

    /**
     * Show the error message / field errors
     *
     * @param {string} [message] - Error message
     * @param {any} [fieldErrors] - Field errors
     */
    showErrorMessage (message, fieldErrors) {
      showErrorMessage(this.$t('general.invalidFieldsMessage'))
      this.showFieldErrors(fieldErrors)
    },

    /**
     * Show the field errors
     *
     * @param {any} [fieldErrors] - Field errors
     */
    showFieldErrors (fieldErrors) {
      this.resetFieldErrors()
      for (const fieldname in fieldErrors) {
        if (Object.prototype.hasOwnProperty.call(fieldErrors, fieldname)) {
          const message = fieldErrors[fieldname]
          if (fieldname === SaveShipmentDataErrorFields.PICKUP_DATE) {
            this.formErrors.form01PickupDate = message
          } else if (fieldname === SaveShipmentDataErrorFields.WERK) {
            this.formErrors.form01Vwerk = message
          } else if (fieldname === SaveShipmentDataErrorFields.DELIVERY_DATE) {
            this.formErrors.form03DeliveryDate = message
          } else if (fieldname === SaveShipmentDataErrorFields.ADDRESS_NAME1) {
            this.formErrors.formAddressName1 = message
          } else if (fieldname === SaveShipmentDataErrorFields.ADDRESS_STREET) {
            this.formErrors.formAddressStreet = message
          } else if (fieldname === SaveShipmentDataErrorFields.ADDRESS_POSTAL_CODE) {
            this.formErrors.formAddressPostalCode = message
          } else if (fieldname === SaveShipmentDataErrorFields.ADDRESS_CITY) {
            this.formErrors.formAddressCity = message
          } else if (fieldname === SaveShipmentDataErrorFields.ADDRESS_COUNTRY) {
            this.formErrors.formAddressCountry = message
          }
        }
      }
    },

    /**
     * Fehler zurücksetzen
     */
    resetFieldErrors () {
      Object.keys(this.formErrors).forEach((key) => this.formErrors[key] = void 0)
    },
  },
}
</script>
