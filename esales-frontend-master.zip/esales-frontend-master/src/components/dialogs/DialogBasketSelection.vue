<template>
  <b-modal
    ref="modal"
    :header-close-label="$t('general.dialogCloseLabel')"
    :visible="true"
    :hide-footer="true"
    :title="$t('components.dialogs.basketSelection.title')"
    class="modal-no-padding"
    header-bg-variant="primary"
    header-text-variant="white"
    @hidden="$emit('hidden')">
    <!-- Beschreibung -->
    <p class="p-3 m-0">
      {{ $t('components.dialogs.basketSelection.description') }}
    </p>

    <!-- Auflistung Warenkörbe -->
    <div
      v-if="isLoading"
      class="text-center py-5">
      <app-loading-spinner />
    </div>

    <div
      v-else
      class="list-group">
      <button
        v-for="basket in baskets"
        :key="basket.id"
        type="button"
        class="list-group-item list-group-item-action d-flex"
        @click="onBasketSelected(basket)">
        <!-- Name, Bestellnummer, Anzahl Positionen -->
        <div class="d-flex pr-2">
          <div class="mt-1 mr-2">
            <i class="fas fa-shopping-cart fa-fw fa-lg" />
          </div>
          <div>
            <div class="font-weight-bold font-size-lg">
              {{ basket.name }}
            </div>
            <div v-if="basket.commission">
              {{ basket.commission }}
            </div>
            <small class="text-muted">
              {{ $t('components.dialogs.basketSelection.numberOfPositions', { count: basket.positions }) }}
            </small>
          </div>
        </div>

        <!-- Badge Warenkorb aktiv -->
        <div class="ml-auto">
          <span
            v-if="basket.active"
            class="badge badge-primary badge-pill">
            {{ $t('components.dialogs.basketSelection.badgeActive') }}
          </span>
        </div>
      </button>
    </div>

    <!-- Neuen Warenkorb anlegen -->
    <form
      v-if="app.user.hasPermission('BASKETS_MANAGE')"
      class="p-3 bg-light"
      novalidate
      @submit.prevent.stop="createNewBasket">
      <div class="form-group mb-0">
        <!-- Label -->
        <label>{{ $t('components.dialogs.basketSelection.createNewBasketForm.label') }}</label>

        <!-- Bezeichnung -->
        <div class="input-group">
          <input
            v-model="newBasketName"
            :class="{'is-invalid': newBasketNameError}"
            :placeholder="$t('components.dialogs.basketSelection.createNewBasketForm.namePlaceholder')"
            type="text"
            class="form-control">
          <div class="input-group-append">
            <!-- Button Hinzufügen -->
            <button
              :disabled="!newBasketName || isBasketCreationInProcess"
              type="submit"
              class="btn btn-primary">
              <app-icon-state
                :is-loading="isBasketCreationInProcess"
                icon="fas fa-plus" />
            </button>
          </div>
          <div
            v-if="newBasketNameError"
            class="invalid-feedback">
            {{ newBasketNameError }}
          </div>
        </div>
      </div>
    </form>
  </b-modal>
</template>

<script>
import { addBasket, getBaskets } from '@scripts/modules/basket'
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { ErrorCode } from '@scripts/modules/errors'

export default {
  data () {
    return {
      isLoading: true,

      baskets: void 0,
      selectedBasket: void 0,

      isBasketCreationInProcess: false,
      newBasketName: '',
      newBasketNameError: '',
    }
  },

  created () {
    this.loadBaskets()
  },

  methods: {
    async loadBaskets () {
      try {
        this.baskets = (await getBaskets()).multibaskets.map((basket) => ({
          active: basket.active,
          commission: basket.kommi,
          name: basket.name,
          positions: basket.numPos,
        }))
        this.selectedBasket = this.baskets.find((basket) => basket.active).id
        this.isLoading = false
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    },

    onBasketSelected (basket) {
      this.$emit('select', basket)
      this.$refs.modal.hide()
    },

    async createNewBasket () {
      if (this.isBasketCreationInProcess) {
        return
      }

      this.isBasketCreationInProcess = true
      this.newBasketNameError = ''

      try {
        const basketName = this.newBasketName
        await addBasket(basketName)
        showSuccessMessage(this.$t('components.dialogs.basketSelection.basketCreated', { basketName }))
        await this.loadBaskets()
        this.newBasketName = ''
      } catch (e) {
        if (e.code === ErrorCode.INVALID_NAME) {
          this.newBasketNameError = this.$t('components.dialogs.basketSelection.basketNameMissing')
        } else if (e.code === ErrorCode.NAME_ALREADY_TAKEN) {
          this.newBasketNameError = this.$t('components.dialogs.basketSelection.basketNameAlreadyExists')
        } else {
          console.error(e)
          showTechnicalErrorMessage()
        }
      }

      this.isBasketCreationInProcess = false
    },
  },
}
</script>
