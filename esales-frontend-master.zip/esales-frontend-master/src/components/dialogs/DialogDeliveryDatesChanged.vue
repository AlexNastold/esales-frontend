<template>
  <b-modal
    v-model="showModal"
    :no-close-on-backdrop="true"
    :ok-disabled="adoptInProcess"
    :title="$t('components.dialogs.deliveryDatesChanged.title')"
    size="lg"
    header-bg-variant="primary"
    header-text-variant="white"
    @hide="finish"
    @cancel="finish"
    @ok="ok">
    <p>
      {{ $t('components.dialogs.deliveryDatesChanged.description') }}
    </p>

    <div class="row py-2 bg-light font-weight-bold mb-2 d-none d-lg-flex">
      <div class="col d-flex align-items-center">
        {{ $t('components.dialogs.deliveryDatesChanged.article') }}
      </div>
      <div class="col-2 d-flex align-items-center justify-content-end">
        {{ $t('components.dialogs.deliveryDatesChanged.amount') }}
      </div>
      <div class="col-2 text-center">
        <span v-html="$t('components.dialogs.deliveryDatesChanged.currentDate')" />
      </div>
      <div class="col-2 text-center">
        <span v-html="$t('components.dialogs.deliveryDatesChanged.newDate')" />
      </div>
    </div>

    <div
      v-for="(position, index) in positions"
      :key="position.posnr"
      class="row mb-3">
      <div class="col">
        <div class="custom-control custom-checkbox m-0 mr-1">
          <input
            :id="`checked-${index}`"
            v-model="checkedStates[index]"
            type="checkbox"
            class="custom-control-input">
          <label
            :for="`checked-${index}`"
            class="custom-control-label">
            <strong class="d-block text-break">
              {{ position.maktx }} {{ position.maktx2 }}
            </strong>
            <small class="text-muted">
              {{ $t('general.articleNumberShort') }} {{ position.matnrDisplay }}
            </small>
          </label>
        </div>
      </div>
      <div class="col-auto col-lg-2 text-right">
        {{ position.amount | sapNumber }} {{ position.volumeUnit }}
      </div>
      <div class="col-12 d-lg-none mb-2" />
      <div class="col-5 col-sm-4 col-lg-2 offset-2 offset-sm-4 offset-lg-0 text-lg-center">
        <label class="d-block d-lg-none mb-0">
          {{ $t('components.dialogs.deliveryDatesChanged.currentDateRAW') }}
        </label>
        <label class="d-block d-lg-none mb-0">
          {{ $t('components.dialogs.deliveryDatesChanged.newDateRAW') }}
        </label>
        <span class="d-none d-lg-block">
          {{ position.deliveryDate | date }}
        </span>
      </div>
      <div class="col-5 col-sm-4 col-lg-2 text-right text-lg-center">
        <span class="d-block d-lg-none">
          {{ position.deliveryDate | date }}
        </span>
        <strong>{{ date | date }}</strong>
      </div>
    </div>

    <p v-html="$t('components.dialogs.deliveryDatesChanged.description2')" />

    <template slot="modal-cancel">
      <i class="fas fa-times fa-fw" />
      {{ $t('components.dialogs.deliveryDatesChanged.noChangeButton') }}
    </template>

    <template slot="modal-ok">
      <app-icon-state
        :is-loading="adoptInProcess"
        icon="fas fa-save" />
      {{ $t('components.dialogs.deliveryDatesChanged.changeMarkedButton') }}
    </template>
  </b-modal>
</template>

<script>
import { adoptDeliveryDateOnPositions } from '@scripts/modules/basket'
import { showTechnicalErrorMessage } from '@scripts/modules/dialogs'

export default {
  props: {
    date: {
      type: Date,
      required: true,
    },
    positions: {
      type: Array,
      default () {
        return []
      },
    },
  },

  data () {
    return {
      checkedStates: this.positions.map(() => true),
      showModal: true,
      adoptInProcess: false,
      alreadyEmittedFinished: false,
    }
  },

  methods: {
    async ok (event) {
      event.preventDefault()
      this.adoptInProcess = true

      try {
        await adoptDeliveryDateOnPositions(
          this.positions
            .filter((position, index) => this.checkedStates[index])
            .map((position) => position.posnr),
        )
        this.$emit('change')
      } catch (e) {
        console.error()
        showTechnicalErrorMessage()
      }

    },
    finish (event) {
      if (event.trigger === 'ok') {
        event.preventDefault()
        return
      }
      if (!this.alreadyEmittedFinished) {
        this.$emit('finish')
        this.alreadyEmittedFinished = true
      }
    },
    setCheckedState (position) {
      position.checked = !position.checked
    },
  },
}
</script>
