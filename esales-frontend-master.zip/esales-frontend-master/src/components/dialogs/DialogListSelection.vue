<template>
  <b-modal
    ref="modal"
    :header-close-label="$t('general.dialogCloseLabel')"
    :visible="true"
    :hide-footer="true"
    :title="$t('components.dialogs.listSelection.title')"
    class="modal-no-padding"
    header-bg-variant="primary"
    header-text-variant="white"
    @hidden="$emit('hidden')">
    <!-- Beschreibung -->
    <p class="p-3 mb-0">
      {{ $t('components.dialogs.listSelection.description') }}
    </p>

    <!-- Auflistung vorhandene Listen -->
    <div
      v-if="isLoading"
      class="text-center py-5">
      <app-loading-spinner />
    </div>

    <div v-else>
      <!-- Keine Listen -->
      <div
        v-if="!lists.length">
        <app-box-empty-list
          :headline="$t('components.dialogs.listSelection.listEmpty')"
          icon="fas fa-file-alt">
          <span v-html="$t('components.dialogs.listSelection.listEmptyDescription')" />
        </app-box-empty-list>
      </div>

      <!-- Auflistung Listen -->
      <div
        v-if="lists.length"
        class="list-group">
        <button
          v-for="list in lists"
          :key="list.id"
          type="button"
          class="list-group-item list-group-item-action d-flex"
          @click="onListSelected(list)">
          <!-- Name, Anzahl Artikel, Erstelldatum -->
          <div class="d-flex pr-2">
            <div class="mt-1 mr-2">
              <i class="fas fa-file-alt fa-fw fa-lg" />
            </div>
            <div>
              <div class="font-weight-bold font-size-lg">
                {{ list.name }}
              </div>
              <div>{{ $t('components.dialogs.listSelection.numberOfArticles', { count: list.articlesAmount}) }}</div>
              <small class="text-muted">
                {{ $t('components.dialogs.listSelection.from') }} {{ list.createdAt | date }}
              </small>
            </div>
          </div>

          <!-- Badge Freigegebene Liste -->
          <div class="ml-auto">
            <span
              v-if="list.isPublic"
              class="badge badge-primary badge-pill p-1">
              <i class="fas fa-users fa-fw" />
              {{ $t('components.dialogs.listSelection.badgeShared') }}
            </span>
          </div>
        </button>
      </div>
    </div>

    <!-- Neue Liste anlegen -->
    <form
      class="p-3 bg-light"
      @submit.prevent.stop="createNewList">
      <div class="form-group mb-0">
        <!-- Label -->
        <label>{{ $t('components.dialogs.listSelection.createNewList.label') }}</label>

        <!-- Bezeichnung -->
        <div class="input-group">
          <input
            v-model="newListName"
            :class="{'is-invalid': newListError}"
            :placeholder="$t('components.dialogs.listSelection.createNewList.namePlaceholder')"
            type="text"
            class="form-control">
          <div class="input-group-append">
            <button
              :disabled=" !newListName || isListCreationInProcess"
              type="submit"
              class="btn btn-primary">
              <app-icon-state
                :is-loading="isListCreationInProcess"
                icon="fas fa-plus" />
            </button>
          </div>
          <div
            v-if="newListError"
            class="invalid-feedback">
            {{ newListError }}
          </div>
        </div>
      </div>
    </form>
  </b-modal>
</template>

<script>
import { showSuccessMessage, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import { createList, getLists } from '@scripts/modules/lists'

export default {
  data () {
    return {
      isLoading: true,

      lists: void 0,
      selectedList: void 0,

      isListCreationInProcess: false,
      newListError: '',
      newListName: '',
    }
  },

  created () {
    this.loadLists()
  },

  methods: {
    async loadLists () {
      this.isLoading = true

      try {
        this.lists = await getLists({onlyOwn: true})
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.isLoading = false
    },

    onListSelected (list) {
      this.$emit('select', list)
      this.$refs.modal.hide()
    },
    async createNewList () {
      if (this.isListCreationInProcess) {
        return
      }

      this.isListCreationInProcess = true
      this.newListError = ''

      try {
        const listName = this.newListName
        await createList(this.newListName)
        showSuccessMessage(this.$t('myAccountDocuments.list.listCreated', { listName }))
        await this.loadLists()
        this.newListName = ''
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }

      this.isListCreationInProcess = false
    },
  },
}
</script>
