import Emitter from 'tiny-emitter/instance'

export enum ShopEvent {
  DOC_COMPARISON_LIST_UPDATED = 'docComparisonListUpdated',
}

export const eventHub = Emitter
export default eventHub
