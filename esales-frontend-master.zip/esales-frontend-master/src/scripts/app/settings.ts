/**
 * In this file the __META__ variable from the server-side script
 * is read, typed, and exported for other scripts
 */

import merge from 'deepmerge'

import { IOxomiConfiguration } from '@scripts/modules/oxomi'
import { OrderVariant } from '@scripts/modules/basket'
import clientMeta from '@src/config/config'

export interface IMetaData {
  user?: {
    sessionId: string,
    isLoggedIn: boolean,
    isGuest?: boolean,
    guestSid?: string,
    isAdma?: boolean,
    agbAccepted?: boolean,
    userId?: string,
    firstName?: string,
    lastName?: string,
    title?: string,
    kunnr?: string,
    kunnrName?: string,
    alias?: string,
    vkorg?: string,
    vtweg?: string,
    sparte?: string,
    werk?: string,
    currency: string,
    language: string,
    languageIso: string,
    emailAddress: string,
    phone: string,
    lastLogin?: Date,
    contactPerson: {
      title: string,
      lastName: string,
      phone: string,
      phoneExtension: string,
      emailAddress: string,
      picture: string,
    },
    isNetPriceEnabled: boolean,
    permissions: string[],
    permissionFlags: { [key: string]: boolean },
    settings: {
      addToBasketMode: 1 | 2 | 3,
    },
  },
  applicationSettings?: {
    serverApplicationPath: string,

    maxQuantity: number,

    autoGuestActive: boolean,

    dateFormat: string,
    dateFormatDatepicker: string,
    timeFormat: string,
    gtmActive: boolean,
    gtmEcommerceActive: boolean,
    gtmContainerID: string,
    gtagActive: boolean,
    gtagEcommerceActive: boolean,
    gtagTrackingID: string,
    gtagAnonymizeIP: boolean,
    eek: {
      listIconsActive: boolean,
    }

    accessories: { [key: string]: string },
    socialMedia: {
      facebook?: string,
      twitter?: string,
      googleplus?: string,
      youtube?: string,
      instagram?: string,
      linkedin?: string,
    },
    payment: {
      active: boolean,
      provider?: string,
      paymentMethods?: {
        key: string,
        label: string,
      }[],
    },
    oxomi: IOxomiConfiguration,
    languages: {
      language: string,
      languageIso: string,
      label: string,
      isActive: boolean,
    }[],
    manualPath: string,
    footer: {
      copyright: string,
    },
    header: {
      advantageTexts: {
        icon?: string,
        text: string,
      }[],
    }

    decimalSeparator: string,
    thousandsSeparator: string,
    decimalPlaces: number,
    decimalPlacesMoney: number,
    defaultQuantity: number | undefined,
    defaultQuantityOnSelect: number | undefined,
    showPartsListItems: boolean,
    sortFiltersBy: string,
    showCategoryImages: boolean,
    categoryImageBasePath: string,
  },
  applicationState?: {
    oltpAvailable: boolean,
    orderVariant: OrderVariant,
    basketAmount: number,
    comparisonAmount: number,
    labelsAmount: number,
    kioskMode: boolean,
  },
  pageSettings?: any
}

const serverMeta = (window as any).__META__ || {}

const dontMerge = (_destination, source) => source.slice(0)
const metaData: IMetaData = merge.all([{}, clientMeta, serverMeta], {
  arrayMerge: dontMerge,
})

if (metaData.user.lastLogin) {
  metaData.user.lastLogin = new Date(metaData.user.lastLogin)
}

export default metaData

export const user = metaData.user
export const applicationSettings = metaData.applicationSettings
export const applicationState = metaData.applicationState
export const pageSettings = metaData.pageSettings

export const pageSettingsLogin: IPageLoginSettings = metaData.pageSettings
export const pageSettingsRegistration: IPageRegistrationSettings = metaData.pageSettings
export const pageSettingsForgotPassword: IForgotPasswordSettings = metaData.pageSettings
export const pageSettingsIndex: IPageSettingsIndex = metaData.pageSettings
export const pageSettingsMyAccountAddressesCreate: IMyAccountAddressesCreateSettings = metaData.pageSettings
export const pageSettingsMyAccountAddressesSapAdd: IMyAccountAddressesSapAddSettings = metaData.pageSettings
export const pageSettingsMyAccountAddressesEdit: IMyAccountAddressesEditSettings = metaData.pageSettings
export const pageSettingsMyAccountManageUsers: IMyAccountManageUsersSettings = metaData.pageSettings
export const pageSettingsMyAccountManageUsersCreate: IMyAccountManageUsersCreateSettings = metaData.pageSettings
export const pageSettingsMyAccountManageUsersEdit: IMyAccountManageUsersEditSettings = metaData.pageSettings
export const pageSettingsMyAccountDocuments: IMyAccountDocumentsSettings = metaData.pageSettings
export const pageSettingsLabels: ILabelsSettings = metaData.pageSettings
export const pageSettingsOrderingProccessGuestUser: IPageOrderingProccessGuestUserSettings = metaData.pageSettings

export interface IPageLoginSettings {
  shopLocked: boolean,
  registrationActive: boolean,
}

export interface IPageRegistrationSettings {
  captchaActive: boolean,
  captchaKey?: string,
  titles: { key: string, label: string }[],
  languages: { key: string, label: string }[],
  currencies: { key: string, label: string }[],
  salesOrganisations: {
    vkorg: string,
    vkorgText: string,
    vtweg: string,
    vtwegText: string,
  }[],
}

export interface IForgotPasswordSettings {
  captchaActive: boolean,
  captchaKey?: string,
  tel: string,
}

export interface IPageSettingsIndex {
  shopArguments: {
    text: string,
    icon: string,
  }[]
}

export interface IMyAccountAddressesCreateSettings {
  countries: { key: string, label: string }[],
}

export interface IMyAccountAddressesSapAddSettings {
  countries: { key: string, label: string }[],
}

export interface IMyAccountAddressesEditSettings {
  countries: { key: string, label: string }[],
}

export interface IMyAccountManageUsersSettings {
  languages: { key: string, label: string }[],
  currencies: { key: string, label: string }[],
}

export interface IMyAccountManageUsersCreateSettings {
  languages: { key: string, label: string }[],
  currencies: { key: string, label: string }[],
  titles: { key: string, label: string }[],
}

export interface IMyAccountManageUsersEditSettings {
  languages: { key: string, label: string }[],
  currencies: { key: string, label: string }[],
  titles: { key: string, label: string }[],
}

export interface IMyAccountDocumentsSettings {
  allowedDocumentTypes: number[],
}

export interface ILabelsSettings {
  labelsHash: string,
  systemId: string,
  operatorName: string,
  serverPath: string,
  labelServiceUri: string,
}

export interface IPageOrderingProccessGuestUserSettings {
  titles: { key: string, label: string }[],
  countries: { key: string, label: string }[],
}

