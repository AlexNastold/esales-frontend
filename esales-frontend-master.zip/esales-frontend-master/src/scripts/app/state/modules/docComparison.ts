import { ShopEvent, eventHub } from '@scripts/app/event-hub'
import browserStore from '@scripts/core/browserStore'
import user from '@scripts/app/user'

const storeKey = `docComparisonList-${user.kunnr}`
const docComparisonState = {
  documents: [],
}

export default docComparisonState

loadList()

// Liste wurde geändert
eventHub.on(ShopEvent.DOC_COMPARISON_LIST_UPDATED, () => {
  saveList()
})

function loadList () {
  docComparisonState.documents = browserStore.get(storeKey, [])
}

function saveList () {
  browserStore.set(storeKey, docComparisonState.documents)
}
