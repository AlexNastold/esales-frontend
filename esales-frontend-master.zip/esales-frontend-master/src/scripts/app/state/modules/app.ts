import { applicationState } from '@scripts/app/settings'

const appState = {
  isOltpAvailable: applicationState.oltpAvailable,
}

export default appState

export function setOltpAvailability (isOltpAvailable: boolean) {
  appState.isOltpAvailable = isOltpAvailable
}
