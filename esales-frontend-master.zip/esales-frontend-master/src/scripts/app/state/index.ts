import appState from './modules/app'
import { applicationState } from '@scripts/app/settings'
import docComparisonState from './modules/docComparison'

const state = {
  app: appState,
  docComparison: docComparisonState,
  kioskMode: applicationState.kioskMode,
  oltpAvailable: applicationState.oltpAvailable,
  orderVariant: applicationState.orderVariant,
}

export default state
