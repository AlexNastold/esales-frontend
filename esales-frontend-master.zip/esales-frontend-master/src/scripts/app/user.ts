import metaData from '@scripts/app/settings'

export enum Permission {
  SHOW_AVAILABILITY = 'SHOW_AVAILABILITY', // Verfürbarkeit anzeigen
  SHOW_NET_PRICE = 'SHOW_NET_PRICE', // Nettopreise anzeigen
  TOGGLE_NET_PRICE = 'TOGGLE_NET_PRICE', // Nettopreise umschalten
  SEARCH = 'SEARCH', // Suche anzeigen
  CATALOGUE = 'CATALOGUE', // Katalog anzeigen

  BASKET_ADD_ARTICLES = 'BASKET_ADD_ARTICLES',
  BASKET_COMMISSION = 'BASKET_COMMISSION',
  BASKET_POSITION_TEXT = 'BASKET_POSITION_TEXT',
  BASKET_POSITION_DATE = 'BASKET_POSITION_DATE',
  BASKET_ORDER = 'BASKET_ORDER',
  BASKET_INQUIRY = 'BASKET_INQUIRY',
  DELIVERY_DATA = 'DELIVERY_DATA',

  DOCUMENTS = 'DOCUMENTS',
  DOCUMENTS_AUFTRAG = 'DOCUMENTS_AUFTRAG',
  DOCUMENTS_ANGEBOT = 'DOCUMENTS_ANGEBOT',
  DOCUMENTS_ANFRAGE = 'DOCUMENTS_ANFRAGE',
  DOCUMENTS_HAUPTABRUF = 'DOCUMENTS_HAUPTABRUF',
  DOCUMENTS_UNTER_VORBEHALT = 'DOCUMENTS_UNTER_VORBEHALT',
  DOCUMENTS_RECHNUNG = 'DOCUMENTS_RECHNUNG',
  DOCUMENTS_GUTSCHRIFT = 'DOCUMENTS_GUTSCHRIFT',
  DOCUMENTS_LADELISTE = 'DOCUMENTS_LADELISTE',
  DOCUMENTS_OFFENE_POSTEN = 'DOCUMENTS_OFFENE_POSTEN',
  DOCUMENTS_BUDGETAUFTRAG = 'DOCUMENTS_BUDGETAUFTRAG',

  ADDRESSES_MANAGE = 'ADDRESSES_MANAGE', // Addressverwaltung
  ADDRESSES_FORM_DELETE_ADDRESS_OLTP = 'ADDRESSES_FORM_DELETE_ADDRESS_OLTP',
  ADDRESSES_FORM_NEW_ADDRESS_OLTP = 'ADDRESSES_FORM_NEW_ADDRESS_OLTP',
  BASKETS_MANAGE = 'BASKETS_MANAGE', // Warenkorbverwaltung
  CAMPAIGNS = 'CAMPAIGNS',
  COMPARISON = 'COMPARISON',
  LABELS = 'LABELS',
  LAST_SEEN_ARTICLES = 'LAST_SEEN_ARTICLES',
  LISTS = 'LISTS',
  ORDERMATRIX = 'ORDERMATRIX',
  SERVICE = 'SERVICE',
  SERVICE_FAQ = 'SERVICE_FAQ',
  SERVICE_DOWNLOADS = 'SERVICE_DOWNLOADS',
  SERVICE_CONTACT = 'SERVICE_CONTACT',
  SERVICE_FORM_UNLISTED_ARTICLES = 'SERVICE_FORM_UNLISTED_ARTICLES',
  SETTINGS = 'SETTINGS',
  TOPSELLER_SHOP = 'TOPSELLER_SHOP',
  TOPSELLER_PERSONAL = 'TOPSELLER_PERSONAL',
  TOPSELLER_CUSTOMER = 'TOPSELLER_CUSTOMER',
  USERS_MANAGE = 'USERS_MANAGE', // Benutzerverwaltung
}

function checkPermission (permission: Permission) {
  if (!Object.values(Permission).includes(permission)) {
    throw new Error(`Unknown permission '${permission}'`)
  }
}

const userInformations = metaData.user

const user = {
  ...userInformations,
  hasPermission (permissions: Permission | Permission[]) {
    if (Array.isArray(permissions)) {
      permissions.forEach(checkPermission)
      return permissions.some((permission) => !!userInformations.permissionFlags[permission])
    }

    checkPermission(permissions)
    return !!userInformations.permissionFlags[permissions]
  },
  permissions: userInformations.permissionFlags,

}

export default user
