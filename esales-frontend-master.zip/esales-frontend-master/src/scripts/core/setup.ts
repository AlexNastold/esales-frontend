import 'core-js'
import 'regenerator-runtime/runtime'

import 'bootstrap/js/dist/alert'
import 'bootstrap/js/dist/button'
import 'bootstrap/js/dist/collapse'
import 'bootstrap/js/dist/dropdown'
import 'bootstrap/js/dist/modal'
import 'bootstrap/js/dist/popover'
import 'bootstrap/js/dist/tab'
import 'bootstrap/js/dist/tooltip'
import 'bootstrap/js/dist/util'

import 'bootstrap-datepicker'
import 'bootstrap-datepicker/dist/locales/bootstrap-datepicker.de.min'
import 'lightgallery'
import 'lightgallery/modules/lg-thumbnail'
import 'lightgallery/modules/lg-zoom'
import 'mark.js/dist/jquery.mark.js'
import 'slick-carousel/slick/slick.min.js'
import 'typeahead.js/dist/typeahead.jquery'

import 'typeface-oswald'

import './polyfills/array'

import 'bootstrap-datepicker/dist/css/bootstrap-datepicker3.min.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

import '@src/styles/app.scss'

import Vue from 'vue'
import setupCookieMessage from './setup/cookieMessage'
import setupDefaults from './setup/defaults'
import setupGtag from './setup/gtag'
import setupGtm from './setup/gtm'
import setupI18n from './setup/i18n'
import setupVue from './setup/vue'
import setupVuex from './setup/vuex'

import I18n from '@scripts/modules/i18n'
import appUser from '@scripts/app/user'

import loadjs from 'loadjs'

import { getFlashMessages, hasFlashMessages } from '@scripts/helper/flash-messages'
import { getQueryParameter } from '@scripts/helper/urlParams'
import { showMessage } from '@scripts/modules/dialogs'

import { store } from './setup/vuex'

setupDefaults()
setupVue()
if (appUser.isLoggedIn || appUser.isGuest) {
  setupVuex()
}
setupGtm()
setupGtag()

// Initialize Root Component
export default async function setup (rootComponent, selector = '#page', props = {}) {

  await setupI18n()
  setupCookieMessage()

  // Load external libraries | type="module" prevents loading in ie11
  loadjs(['vendors/@zxing/library/umd/index.min.js'], {
    before: (path: string, scriptEl: { type: string }) => {
      if (path === 'vendors/@zxing/library/umd/index.min.js') {
        scriptEl.type = 'module'
      }
    },
  })

  // tslint:disable-next-line no-unused-expression
  new Vue({
    el: selector,
    render: (h) => h(rootComponent, {props}),
    store,
  })

  // aktive Kategorie initialisieren
  store.dispatch('updateActiveCategory', {
    filterQuery: '',
    label: I18n.t('components.formInputProductSearch.allCategories'),
    manuallyChanged: false,
  })

  // Redirect-Messages (aus URL) anzeigen
  const redirectMessage = getQueryParameter('redirectMessage')
  const redirectMessageType = getQueryParameter('redirectMessageType')
  if (redirectMessage) {
    showMessage(redirectMessageType as any || 'info', redirectMessage.toString())
  }

  // Flash-Messages anzeigen
  if (hasFlashMessages()) {
    const flashMessages = getFlashMessages()
    flashMessages.forEach((flashMessage) => {
      showMessage(flashMessage.type, flashMessage.message, flashMessage.icon)
    })
  }
}
