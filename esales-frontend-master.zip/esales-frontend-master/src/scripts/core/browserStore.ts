import cookieStorage from 'store/storages/cookieStorage'
import localStorage from 'store/storages/localStorage'
import operationsPlugin from 'store/plugins/operations'
import storeEngine from 'store/src/store-engine'

const store = storeEngine.createStore([
  localStorage,
  cookieStorage,
], [
  operationsPlugin,
])

export default store
