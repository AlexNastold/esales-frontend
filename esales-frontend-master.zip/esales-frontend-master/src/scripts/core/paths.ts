import { applicationSettings } from '../app/settings'

const getServerOrigin = () => {
  const port = location.port ? ':' + location.port : ''
  const origin = `${location.protocol}//${location.hostname}${port}`

  if (/(xed|esr)\.fis-gmbh.de/.test(location.hostname)) {
    return origin
  }

  // Diese Domain wird für Webservice-Requests, zum Auflösen von Bildpfaden usw. verwendet,
  // wenn der Shop unter einer unbekannten Domain (z.B. Localhost) läuft
  return 'https://xed.fis-gmbh.de'
}

export const serverOrigin = getServerOrigin()

const getServerPath = () => {
  const serverApplicationPath = applicationSettings.serverApplicationPath
  const serverApplicationUrl = `${serverOrigin}${serverApplicationPath}/`
  return serverApplicationUrl
}

export const serverPath = getServerPath()
