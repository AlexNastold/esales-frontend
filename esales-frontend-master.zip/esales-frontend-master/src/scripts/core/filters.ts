import moment from 'moment'

import { DocumentStatus, getDocumentStatusTitle, getDocumentTypeTitle } from '@scripts/modules/documents'
import { getArticleImageUrl, getImageUrl } from '@scripts/modules/images'
import { getCurrencySign, replaceCurrencyWithSign } from '@scripts/helper/currencySign'
import { numberToSapCurrency, numberToSapNumber } from '@scripts/helper/sapFormat'
import { applicationSettings } from '@scripts/app/settings'
import { getExternalUrl } from '@scripts/helper/externalUrl'

export default {

  articleImage (image: string): string {
    return getArticleImageUrl(image)
  },

  currency: (value) => {
    if (value) {
      return getCurrencySign(value)
    }
    return value
  },

  date: (value) => {
    if (!value) {
      return ''
    }
    return moment(value).format(applicationSettings.dateFormat)
  },

  datetime: (value) => {
    if (!value) {
      return ''
    }
    return moment(value).format(`${applicationSettings.dateFormat}, ${applicationSettings.timeFormat}`)
  },

  documentStatusTitle (documentStatus: DocumentStatus) {
    return getDocumentStatusTitle(documentStatus)
  },

  documentTypeTitle (documentType) {
    return getDocumentTypeTitle(documentType, false)
  },

  documentTypeTitlePlural (documentType) {
    return getDocumentTypeTitle(documentType, true)
  },

  externalImage (image: string): string {
    return getImageUrl(image)
  },

  externalUrl (url: string): string {
    return getExternalUrl(url)
  },

  lower (value: any): any {
    if (typeof value === 'string') {
      return value.toLowerCase()
    }
    return value
  },

  maxlength (value: any, maxlength: number = 50) {
    if (typeof value === 'string') {
      if (value.length < maxlength) {
        return value
      }
      return `${value.substr(0, (maxlength - 3))}...`
    }
  },

  price: (value) => {
    return numberToSapCurrency(value)
  },

  removeLeadingZeros (value: any): any {
    return value.replace(/^0+/, '')
  },

  replaceCurrencyWithSign: (value) => {
    if (value) {
      return replaceCurrencyWithSign(value)
    }
    return value
  },

  sapNumber: (value, omitUnnecessaryDecimals = false) => {
    return numberToSapNumber(value, {omitUnnecessaryDecimals})
  },

  time: (value) => {
    if (!value) {
      return ''
    }
    return moment(value).format(applicationSettings.timeFormat)
  },

  upper (value: any): any {
    if (typeof value === 'string') {
      return value.toUpperCase()
    }
    return value
  },

} as {
  [key: string]: (value, ...args: any[]) => any,
}
