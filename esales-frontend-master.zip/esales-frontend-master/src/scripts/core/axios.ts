import Axios from 'axios'

import { createFlashMessage } from '@scripts/helper/flash-messages'
import { redirect } from '@scripts/helper/redirect'
import { sapParamsSerializer } from '@scripts/helper/sapParamsSerializer'
import { serverPath } from '@scripts/core/paths'
import { setOltpAvailability } from '@scripts/app/state/modules/app'
import { user } from '@scripts/app/settings'


import I18n from '@scripts/modules/i18n'

export const axiosBackend = Axios.create({
  baseURL: serverPath,
  paramsSerializer: sapParamsSerializer,
  transformRequest: [sapParamsSerializer],
  withCredentials: true,
})

// Statt dem Axios-Response nur die Daten zurück geben
axiosBackend.interceptors.response.use((response) => {
  return response.data
})

// Jeden Webservice nach "oltpNotAvailable" durchsuchen
// Wenn gefunden, dann App-State updaten
axiosBackend.interceptors.response.use((response: any) => {
  if (typeof response === 'object' && response !== null) {
    if (Object.keys(response).includes('oltpNotAvailable')) {
      setOltpAvailability(!response.oltpNotAvailable)
    } else if (Object.keys(response).includes('no_oltp')) {
      setOltpAvailability(!response.no_oltp)
    }
  }
  return response
})

// Wenn ein Webservice "NO_AUTHORIZATION" liefert und der User
// nicht (mehr) eingeloggt ist, auf die Login-Seite redirecten
axiosBackend.interceptors.response.use((response: any) => {
  if (typeof response === 'object' && response !== null) {
    if (response.code === 'NO_AUTHORIZATION' && !user.isLoggedIn) {
      createFlashMessage(I18n.t('general.noAuthorizationGuest'), 'error')
      redirect('login', {
        redirecturl: location.pathname.split('/').pop() || void 0,
      })
      return
    }
  }
  return response
})
