import { applicationSettings } from '@scripts/app/settings'
import loadjs from 'loadjs'

export default function setup () {
  if (applicationSettings.gtmActive && applicationSettings.gtmContainerID) {
    const win = (window as any)
    win.dataLayer = win.dataLayer || []
    win.dataLayer.push({event: 'gtm.js', 'gtm.start': new Date().getTime()})
    loadjs('https://www.googletagmanager.com/gtag/js?id=' + applicationSettings.gtmContainerID)
  }
}
