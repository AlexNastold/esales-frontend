import Vue from 'vue'

import Vuex from 'vuex'

Vue.use(Vuex)

import { getMaterialsInBasket } from '@scripts/modules/basket'
import { getMaterialsInComparison } from '@scripts/modules/comparison'
import { getMaterialsInLabels } from '@scripts/modules/labels'

export const store = new Vuex.Store({
  actions: {
    updateActiveCategory ({ commit }, category) {
      commit('mutateActiveCategory', { category })
    },
    updateAddToBasketIsProcessing ({ commit }, addToBasketIsProcessing) {
      commit('mutateAddToBasketIsProcessing', { addToBasketIsProcessing })
    },
    async updateBasket ({ commit }) {
      const result = await getMaterialsInBasket()

      const amount = result.numberOfArticles
      commit('mutateAmountBasketPositions', { amount })
      const materials = result.materials
      commit('mutateMaterialsInBasket', { materials })
    },
    async updateComparison ({ commit }) {
      const result = await getMaterialsInComparison()

      const amount = result.numberOfArticles
      commit('mutateComparisonAmount', { amount })
      const materials = result.materials
      commit('mutateMaterialsInComparison', { materials })
    },
    async updateLabels ({ commit }) {
      const result = await getMaterialsInLabels()

      const amount = result.numberOfArticles
      commit('mutateLabelsAmount', { amount })
      const materials = result.materials
      commit('mutateMaterialsInLabels', { materials })
    },
  },
  getters: {
    getActiveCategory: (state) => {
      return state.activeCategory
    },
    getAddToBasketIsProcessing: (state) => {
      return state.addToBasketIsProcessing
    },
    getAmountBasketPositions: (state) => {
      return state.amountBasketPositions
    },
    getAmountComparison: (state) => {
      return state.amountComparison
    },
    getAmountLabels: (state) => {
      return state.amountLabels
    },
    getAmountShopCategories: (state) => {
      return state.amountShopCategories
    },
    getMaterialsInBasket: (state) => {
      return state.materialsInBasket
    },
    getMaterialsInComparison: (state) => {
      return state.materialsInComparison
    },
    getMaterialsInLabels: (state) => {
      return state.materialsInLabels
    },
  },
  mutations: {
    mutateActiveCategory (state, data) {
      state.activeCategory = data.category
    },
    mutateAddToBasketIsProcessing (state, data) {
      state.addToBasketIsProcessing = data.addToBasketIsProcessing
    },
    mutateAmountBasketPositions (state, data) {
      state.amountBasketPositions = data.amount
    },
    mutateComparisonAmount (state, data) {
      state.amountComparison = data.amount
    },
    mutateLabelsAmount (state, data) {
      state.amountLabels = data.amount
    },
    mutateMaterialsInBasket (state, data) {
      state.materialsInBasket = data.materials
    },
    mutateMaterialsInComparison (state, data) {
      state.materialsInComparison = data.materials
    },
    mutateMaterialsInLabels (state, data) {
      state.materialsInLabels = data.materials
    },
    mutateShopCategoriesAmount (state, data) {
      state.amountShopCategories = data.amount
    },
  },
  state: {
    activeCategory: {
      filterQuery: '',
      label: '',
      manuallyChanged: false,
    },
    addToBasketIsProcessing: false,
    amountBasketPositions: 0,
    amountComparison: 0,
    amountLabels: 0,
    amountShopCategories: 0,
    materialsInBasket: [],
    materialsInComparison: [],
    materialsInLabels: [],
  },
})

export default async function setup () {
  store.dispatch('updateBasket')
  store.dispatch('updateComparison')
  store.dispatch('updateLabels')
}
