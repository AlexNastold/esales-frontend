/* globals cookieconsent */

import 'cookieconsent/build/cookieconsent.min.css'

import I18n from '@scripts/modules/i18n'

import 'cookieconsent'

export default function setup () {
  // Es gibt Browser-Extension, welche Cookie Popups blockieren
  // Dabei werden die Request (js und css) geblockt
  // Deshalb kann es sein, dass cookieconsent nicht verfügbar ist
  // -> Falls nicht verfügbar, zeigen wir auch nichts an
  if (typeof cookieconsent === 'undefined') {
    return
  }

  cookieconsent.initialise({
    content: {
      dismiss: I18n.t('cookieMessage.dismiss'),
      href: 'privacy',
      link: I18n.t('cookieMessage.learnMore'),
      message: I18n.t('cookieMessage.message'),
      target: '_self',
    },
    palette: {
      button: {
        background: '#f1d600',
      },
      popup: {
        background: '#000',
      },
    },
    theme: 'edgeless',
  })
}
