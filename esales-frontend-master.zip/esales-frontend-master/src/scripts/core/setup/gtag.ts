import I18n from '@scripts/modules/i18n'
import { applicationSettings } from '@scripts/app/settings'
import loadjs from 'loadjs'
import { showSuccessMessage } from '@scripts/modules/dialogs'

export default function setup () {
  if (applicationSettings.gtagActive && applicationSettings.gtagTrackingID) {
    const win = (window as any)
    if (document.cookie.indexOf('ga-disable-' + applicationSettings.gtagTrackingID + '=true') > -1) {
      win['ga-disable-' + applicationSettings.gtagTrackingID] = true
    }
    loadjs('https://www.googletagmanager.com/gtag/js?id=' + applicationSettings.gtagTrackingID)
    win.dataLayer = win.dataLayer || []
    win.gtag = gtag
    win.gtag('js', new Date())
    win.gtag(
      'config',
      applicationSettings.gtagTrackingID,
      {
        anonymize_ip: applicationSettings.gtagAnonymizeIP,
        cookie_flags: 'secure;samesite=none',
        page_path: win.location.pathname.replace(/\([^)]+\)\//, '/').toLowerCase(),
      },
    )
  }
}

function gtag () {
  const win = (window as any)
  // eslint-disable-next-line prefer-rest-params
  win.dataLayer.push(arguments)
}

export function gtagOptout () {
  document.cookie = 'ga-disable-' + applicationSettings.gtagTrackingID +
    '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/'
  window['ga-disable-' + applicationSettings.gtagTrackingID] = true
  showSuccessMessage(I18n.t('privacy.googleAnalyticsWebtrackingDeactivated'))
}
