import Vue from 'vue'

import { BootstrapVue } from 'bootstrap-vue'
import Notifications from 'vue-notification'

import I18n from '@scripts/modules/i18n'

import appSettings from '@scripts/app/settings'
import appState from '@scripts/app/state'
import appUser from '@scripts/app/user'

import filters from '@scripts/core/filters'
import globalComponents from '@components/global'
import { setPageTitle } from '@scripts/helper/setPageTitle'

function camelToDash (str: string) {
  return str
    .replace(/(^[A-Z])/, (first) => first.toLowerCase())
    .replace(/([A-Z])/g, (letter) => `-${letter.toLowerCase()}`)
}

export default function setup () {

  // Disable development warning
  Vue.config.productionTip = false

  // Register components
  Vue.use(BootstrapVue)
  Vue.use(Notifications)

  // Register custom global components (prefixed with `app-`)
  for (const [name, component] of Object.entries(globalComponents)) {
    const componentName = (component as any).name || name
    const componentNameDashed = camelToDash(componentName)
    Vue.component(`app-${componentNameDashed}`, component)
  }

  // Register filters
  for (const [filterName, callback] of Object.entries(filters)) {
    Vue.filter(filterName, callback)
  }

  // Register mixins
  Vue.mixin({
    data () {
      return {
        app: {
          pageSettings: appSettings.pageSettings,
          settings: appSettings.applicationSettings,
          state: appState,
          user: appUser,
        },
      }
    },
    methods: {
      $t: I18n.t.bind(I18n),
      setPageTitle,
    },
  })
}
