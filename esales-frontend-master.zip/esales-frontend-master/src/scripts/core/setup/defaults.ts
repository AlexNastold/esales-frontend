import Axios from 'axios'

export default function setup () {

  // Axios
  Axios.defaults.withCredentials = true
}
