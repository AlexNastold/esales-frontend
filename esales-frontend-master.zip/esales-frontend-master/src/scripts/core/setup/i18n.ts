
import I18n from 'i18next'
import XHR from 'i18next-xhr-backend'

import user from '@scripts/app/user'

import langDE from '@src/lang/de.json'
import langEN from '@src/lang/en.json'
import langFR from '@src/lang/fr.json'
import langIT from '@src/lang/it.json'

function awaitLocale (locale, callback) {
  const func: (file) => any = locale as any
  func((file) => callback(file, {status: '200'}))
}

function loadLocales (url, _options, callback) {
  switch (url) {
    case 'de': { awaitLocale(langDE, callback); break }
    case 'en': { awaitLocale(langEN, callback); break }
    case 'fr': { awaitLocale(langFR, callback); break }
    case 'it': { awaitLocale(langIT, callback); break }
    default: callback(void 0, {status: '404'})
  }
}

export default function setup (): Promise<void> {
  return new Promise((resolve, reject) => {
    I18n
      .use(XHR)
      .init({
        backend: {
          ajax: loadLocales,
          crossDomain: true,
          loadPath: '{{lng}}',
          parse: (data) => data,
          withCredentials: true,
        },
        debug: false,
        fallbackLng: 'de',
        lng: user.languageIso.toLowerCase(),
        saveMissing: true,
      }, (err) => {
        if (err) {
          return reject(err)
        }
        return resolve()
      })
  })
}

I18n.on('missingKey', (lngs, _namespace, key) => {
  console.error(`Missing language key: "${key}" (${lngs})`)
})
