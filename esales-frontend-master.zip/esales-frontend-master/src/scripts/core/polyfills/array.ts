Array.prototype.unique = function () {
  return this.filter((value, index, self) => {
    return self.indexOf(value) === index
  })
}

Array.prototype.pluck = function (key: any, fallback?: any, strictFallbackCompare: boolean = true) {
  return this.map((item) => {
    const useFallback = strictFallbackCompare ? (typeof item[key] === 'undefined') : !item[key]
    return useFallback ? fallback : item[key]
  })
}
