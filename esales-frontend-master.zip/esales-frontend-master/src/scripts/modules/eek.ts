/* eslint-disable @typescript-eslint/no-var-requires */
import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'
import { serverPath } from '@scripts/core/paths'

const iconAppp = require('../../images/eek-icons/Appp.png')
const iconApp = require('../../images/eek-icons/App.png')
const iconAp = require('../../images/eek-icons/Ap.png')
const iconA = require('../../images/eek-icons/A.png')
const iconB = require('../../images/eek-icons/B.png')
const iconC = require('../../images/eek-icons/C.png')
const iconD = require('../../images/eek-icons/D.png')
const iconE = require('../../images/eek-icons/E.png')
const iconF = require('../../images/eek-icons/F.png')
const iconG = require('../../images/eek-icons/G.png')
const iconMultiple = require('../../images/eek-icons/EEK.png')

export interface IArticleEEKItem {
  id: string,
  class: string,
  text: string,
}

export function getEEKIconUrl (eekClass?: string): string | void {
  switch (eekClass) {
    case 'A+++':
      return iconAppp
    case 'A++':
      return iconApp
    case 'A+':
      return iconAp
    case 'A':
      return iconA
    case 'B':
      return iconB
    case 'C':
      return iconC
    case 'D':
      return iconD
    case 'E':
      return iconE
    case 'F':
      return iconF
    case 'G':
      return iconG
    default:
      return void 0
  }
}

export function getEEKUrlByClasses (eekClasses: IArticleEEKItem[] = []): string | void {
  if (eekClasses.length === 1) {
    return getEEKIconUrl(eekClasses[0].class)
  }
  if (eekClasses.length > 1) {
    return iconMultiple
  }
}

/**
 * Generiert EEK-Dokumente
 *
 * @throws {ErrorCode.INVALID_OR_MISSING_PARAMS}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function generateEEKDocuments (
  supplierId: string,
  articleNumber: string,
): Promise<{
  name: string,
  hasData: boolean,
}[]> {
  const data: any = await axiosBackend.post('webservices/article.ws', {
    eek_article_number: articleNumber,
    eek_supplier_id: supplierId,
    event: 'GENERATE_EEK_LABELS',
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'INVALID_GENERATE_LABELS_PARAMS':
        throw new ShopError(ErrorCode.INVALID_OR_MISSING_PARAMS, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

/**
 * Gibt die Download-URL für ein EEK-Dokument zurück
 */
export function getEEKDocumentDownloadUrl (supplierId: string, articleNumber: string, index: number): string {
  return `${serverPath}webservices/article.ws?event=DOWNLOAD_EEK_LABEL` +
    `&eek_supplier_id=${encodeURIComponent(supplierId)}` +
    `&eek_article_number=${encodeURIComponent(articleNumber)}` +
    `&eek_idx=${index}`
}
