
import I18n from 'i18next'

export default I18n
