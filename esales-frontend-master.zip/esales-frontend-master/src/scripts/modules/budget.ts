import { ErrorCode, ShopError } from '@scripts/modules/errors'
import I18n from '@scripts/modules/i18n'
import { axiosBackend } from '@scripts/core/axios'

export enum BudgetType {
  BUDGET_TYPE_YEARLY = '801',
  BUDGET_TYPE_MONTHLY = '802',
  BUDGET_TYPE_WEEKLY= '803',
  BUDGET_TYPE_DAILY = '804',
  BUDGET_TYPE_ORDER = '805',
}

export interface ICheckBudgetResult {
  budgetActive: boolean,
  budgetExceeded?: boolean,
  cancelIfBudgetExceeded?: boolean,
  oltp?: {
    available: boolean,
    cancelIfNotAvailable: boolean,
  },
  responsivePerson?: {
    userId: string,
    fullName: string,
  },
  budgetsExceeded?: {
    type: BudgetType,
    amount?: number,
    currency?: string,
  }[],
}

/**
 * Returns the budget order informations
 */
export async function checkBudget (): Promise<ICheckBudgetResult> {
  const data: any = await axiosBackend.get('webservices/basket.ws', { params: {
    event: 'CHK_BUDGET',
  }})

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE)
  }

  return data.result
}

/**
 * Returns the text for a budget type
 *
 * @param type - Budget type
 */
export function getBudgetText (type: BudgetType) {
  switch (type) {
    case BudgetType.BUDGET_TYPE_YEARLY: return I18n.t('general.budgetTexts.yearly')
    case BudgetType.BUDGET_TYPE_MONTHLY: return I18n.t('general.budgetTexts.monthly')
    case BudgetType.BUDGET_TYPE_WEEKLY: return I18n.t('general.budgetTexts.weekly')
    case BudgetType.BUDGET_TYPE_DAILY: return I18n.t('general.budgetTexts.daily')
    case BudgetType.BUDGET_TYPE_ORDER: return I18n.t('general.budgetTexts.order')
    default: return ''
  }
}
