import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'

const paymentIcons = {
  PAYONE: {
    cc: [
      require('../../images/payment-icons/mastercard.png'),
      require('../../images/payment-icons/visa.png'),
      require('../../images/payment-icons/american-express.png'),
    ],
    cod: require('../../images/payment-icons/cash-on-pickup.png'),
    elv: require('../../images/payment-icons/text-lastschrift.png'),
    rec: require('../../images/payment-icons/text-rechnung.png'),
    sb: require('../../images/payment-icons/sofortueberweisung.png'),
    vor: require('../../images/payment-icons/text-vorkasse.png'),
    wlt: [
      require('../../images/payment-icons/paypal.png'),
    ],
  },
}

/**
 * Returns the payment icon for payment provider + payment method
 *
 * @param paymentProvider - The payment provider
 * @param paymentMethod - The payment method
 */
export function getPaymentIcon (paymentProvider, paymentMethod): string | void {
  const paymentProviderIcons = paymentIcons[paymentProvider]
  if (!paymentProviderIcons) {
    return void 0
  }

  const paymentIcon = paymentProviderIcons[paymentMethod]
  if (!paymentIcon) {
    return void 0
  }

  if (Array.isArray(paymentIcon)) {
    return paymentIcon[0]
  }

  return paymentIcon
}

/**
 * Returns multiple payment icons for payment provider + payment method
 *
 * @param paymentProvider - The payment provider
 * @param paymentMethod - The payment method
 */
export function getPaymentIcons (paymentProvider, paymentMethod): string[] {
  const paymentProviderIcons = paymentIcons[paymentProvider]
  if (!paymentProviderIcons) {
    return []
  }

  const paymentIcon = paymentProviderIcons[paymentMethod]
  if (!paymentIcon) {
    return []
  }

  if (!Array.isArray(paymentIcon)) {
    return [paymentIcon]
  }

  return paymentIcon
}

/**
 * Returns the payment informations
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getPaymentInfo (): Promise<IPaymentInfo> {
  const data: any = await axiosBackend.get('webservices/payment.ws', { params: {
    event: 'GET_PAYMENT_INFO',
    gv_origin_path: window.location.origin + window.location.pathname,
  }})

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

export interface IPaymentInfo {
  clientURL: string,
  cc_types: {name: string, value: string}[],
  mid: string,
  portalid: string,
  api_version: string,
  request: string,
  aid: string,
  clearingtype: string,
  reference: string,
  amount: string,
  currency: string,
  customerid: string,
  firstname: string,
  lastname: string,
  country: string,
  shipping_country: string,
  language: string,
  shipping_firstname: string,
  shipping_lastname: string,
  shipping_street: string,
  shipping_zip: string,
  shipping_city: string,
  email: string,
  responsetype: string,
  successurl: string,
  errorurl: string,
  backurl: string,
  mode: string,
  hash: string,
  hash_cc: string,
  pseudocardpan: string,
  truncatedpan: string
}
