import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'

export enum AddToBasketMode {
  OPEN_DIALOG_ALWAYS = 1,
  OPEN_DIALOG_MULTIPLE_BASKETS = 2,
  OPEN_DIALOG_NEVER = 3,
}

export interface IUserSettings {
  showAvailability: boolean,
  showNetPrice: boolean,

  addToBasketMode: AddToBasketMode,

  orderMailActive: boolean,
  orderMailAddress: string,
  orderMailNetPrice: boolean,
  orderMailCustomActive: boolean,
  orderMailCustomAddress: string,
  orderMailCustomNetPrice: boolean,

  userAlias: string,

  passwordOld: string,
  passwordNew1: string,
  passwordNew2: string,

  deliveryType: string,
  deliveryTypes: {
    id: string,
    label: string,
  }[],
  deliveryPhone: string,
  deliveryLocation: string,
  deliveryLocations: {
    id: string,
    label: string,
  }[],
  deliveryAddressId: string,
  deliveryAddresses: {
    id: string,
    name1: string,
    name2: string,
    street: string,
    postalCode: string,
    city: string,
    country: string,
  }[],

  paymentMethod?: string,
  paymentMethodText?: string,
  paymentMethods?: {
    id: string,
    label: string,
  }[],

  flags: {
    canChangeAvailability: boolean,
    canChangeNetPrice: boolean,
    canChangeDelivery: boolean,
    canChangePayment: boolean,
    canChangeUserAlias: boolean,
    canChangePassword: boolean,
  }
}

/**
 * Returns the user settings
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getUserSettings (): Promise<IUserSettings> {
  const data: any = await axiosBackend.get('webservices/settings.ws', { params: {
    event: 'GET_SETTINGS',
  }})

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

export enum SaveUserSettingsFieldErrors {
  CUSTOM_ORDERMAIL_ADDRESS = 'email2address',
  DELIVERY_ADDRESS = 'delivery-address',
  USER_ALIAS = 'user-alias',
}

export enum ChangePasswordFieldErrors {
  PASSWORD_OLD = 'password',
  PASSWORD_NEW1 = 'password_new1',
  PASSWORD_NEW2 = 'password_new2',
}

export async function saveUserSettings (
  settings: {
    showAvailability?: boolean,
    showNetPrice?: boolean,
    addToBasketMode?: AddToBasketMode,
    orderMailActive?: boolean,
    orderMailNetPrice?: boolean,
    orderMailCustomActive?: boolean,
    orderMailCustomAddress?: string,
    orderMailCustomNetPrice?: boolean,
    deliveryType?: string,
    deliveryPhone?: string,
    deliveryLocation?: string,
    deliveryAddressId?: string,
    paymentMethod?: string,
    userAlias?: string,
  },
  flags: {
    showAvailability?: boolean,
    showNetPrice?: boolean,
    addToBasketMode?: boolean,
    orderMail?: boolean,
    deliveryType?: boolean,
    deliveryAddress?: boolean,
    payment?: boolean,
    userAlias?: boolean,
  },
): Promise<void> {
  const data: any = await axiosBackend.post('webservices/settings.ws', {
    event: 'SAVE_SETTINGS',
    gs_settings_flags: {
      addtobasket_mode: flags.addToBasketMode ? 'X' : void 0,
      automatic_doc_mail: flags.orderMail ? 'X' : void 0,
      avail: flags.showAvailability ? 'X' : void 0,
      delivery_address: flags.deliveryAddress ? 'X' : void 0,
      delivery_type: flags.deliveryType ? 'X' : void 0,
      net: flags.showNetPrice ? 'X' : void 0,
      payment: flags.payment ? 'X' : void 0,
      user_alias: flags.userAlias ? 'X' : void 0,
    },

    gv_addtobasket_mode: settings.addToBasketMode,
    gv_delivery_address: settings.deliveryAddressId,
    gv_delivery_location: settings.deliveryLocation,
    gv_delivery_phonenumber: settings.deliveryPhone,
    gv_delivery_type: settings.deliveryType,
    gv_listoption_avail: settings.showAvailability ? 'X' : void 0,
    gv_listoption_netto: settings.showNetPrice ? 'X' : void 0,
    gv_mail_new_address: settings.orderMailCustomAddress,
    gv_mail_new_flag: settings.orderMailCustomActive ? 'X' : void 0,
    gv_mail_new_netto: settings.orderMailCustomNetPrice ? 'X' : void 0,
    gv_mail_standard_flag: settings. orderMailActive ? 'X' : void 0,
    gv_mail_standard_netto: settings.orderMailNetPrice ? 'X' : void 0,
    gv_payment_method: settings.paymentMethod,
    gv_user_alias: settings.userAlias,

  })

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status === 'WARNING') {
    if (data.use_validator === 'X') {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export async function changePassword (
  oldPassword: string,
  newPassword1: string,
  newPassword2: string,
): Promise<void> {
  const data: any = await axiosBackend.post('webservices/settings.ws', {
    event: 'CHANGE_PASSWORD',
    gv_password_new1: newPassword1,
    gv_password_new2: newPassword2,
    gv_password_old: oldPassword,
  })

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status === 'WARNING') {
    if (data.use_validator === 'X') {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}
