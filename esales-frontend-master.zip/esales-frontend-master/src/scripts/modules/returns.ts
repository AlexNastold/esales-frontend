import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { ShipmentCondition } from '@scripts/modules/basket'
import { axiosBackend } from '@scripts/core/axios'

import { numberToSapNumber } from '@scripts/helper/sapFormat'

/**
 * Liefert Daten für das Zurückgeben von Artikeln einer Bestellung
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.NO_DATA}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getReturnOrderData (
  docid: string,
  matnr: string,
  posnr: string,
): Promise<any> {

  const data: any = await axiosBackend.get('webservices/returns.ws', { params: {
    event: 'GET_RETURN_ORDER_DATA',
    gv_docid: docid,
    gv_matnr: matnr,
    gv_posnr: posnr,
  },
  },
  )
  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    if (data.code === 'NO_DATA') {
      throw new ShopError(ErrorCode.NO_DATA, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }
  if (data.status === 'WARNING') {
    if (data.use_validator === 'X' && data.use_multiple_errors === 'X') {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
  return data
}

export enum ReturnsFieldErrors {
  CITY= 'city',
  ZIPCODE= 'zipcode',
  STREET= 'street',
  NAME1 = 'name1',
  COUNTRY = 'country',
}

/**
 * Legt einen Retouren-Auftrag an
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.NO_DATA}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function returnArticles (
  pickup: boolean,
  country: string,
  zipcode: string,
  street: string,
  city: string,
  name1: string,
  name2: string,
  notice: string,
  articles: {
    posnr: string,
    material: string,
    quantity: number,
    sales_unit: string,
    doc_number: string,
    itm_number: string,
    notice: string,
    return_reason: string,
    return_status: string,
  }[],
) {
  const formData = new FormData()
  if (pickup) {
    formData.append('gs_return_head-ship_cond', ShipmentCondition.PICKUP)
  } else {
    formData.append('gs_return_head-ship_cond', ShipmentCondition.DELIVERY_IMMEDIATE)
  }
  formData.append('gs_return_head-we_land1', country)
  formData.append('gs_return_head-we_ort01', city)
  formData.append('gs_return_head-we_stras', street)
  formData.append('gs_return_head-we_pstlz', zipcode)
  formData.append('gs_return_head-we_name1', name1)
  formData.append('gs_return_head-we_name2', name2)
  formData.append('gv_notice', notice)
  articles.forEach((article, index) => {
    if (article.quantity > 0) {
      formData.append(`gt_return_articles[${index + 1}]-material`, article.material)
      formData.append(`gt_return_articles[${index + 1}]-quantity`, numberToSapNumber(article.quantity))
      formData.append(`gt_return_articles[${index + 1}]-sales_unit`, article.sales_unit)
      formData.append(`gt_return_articles[${index + 1}]-doc_number`, article.doc_number)
      formData.append(`gt_return_articles[${index + 1}]-itm_number`, article.itm_number)
      formData.append(`gt_return_articles[${index + 1}]-remark`, article.notice)
      formData.append(`gt_return_articles[${index + 1}]-return_reason`, article.return_reason)
      formData.append(`gt_return_articles[${index + 1}]-return_status`, article.return_status)
    }
  })

  formData.append('event', 'RETURN')

  const data: any = await axiosBackend.post('webservices/returns.ws', formData)

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    if (data.code === 'NO_DATA') {
      throw new ShopError(ErrorCode.NO_DATA, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status === 'WARNING') {
    if (data.use_validator === 'X') {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data

}
