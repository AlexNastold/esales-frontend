import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { IListArticle } from '@scripts/modules/interfaces'
import { axiosBackend } from '@scripts/core/axios'
import { numberToSapNumber} from '@scripts/helper/sapFormat'
import { store } from '@scripts/core/setup/vuex'

export interface IListListItem {
  id: string,
  name: string,
  articlesAmount: number,
  isPinned: boolean,
  isPublic: boolean,
  isOwnList: boolean,
  owner?: {
    userId: string,
    title: string,
    firstName: string,
    lastName: string,
  },
  canPublish: boolean,
  createdAt: Date,
}

export interface IList extends IListListItem {
  articles: IListListArticle[],
}

export interface IListListArticle extends IListArticle {
  id: string,
}

/**
 * Adds one or more articles to a list
 *
 * @param listId - ID of the list
 * @param {ICreateListArticle[]} articles - Articles to add
 *
 * @throws {ErrorCode.INVALID_OR_MISSING_PARAMS} Missing name
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.NOT_FOUND} List not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function addArticlesToList (listId: string, articles: ICreateListArticle[]): Promise<void> {

  const params = {
    event: 'ADD_ARTICLES',
    it_matnrs: articles.map((article) => {
      return {
        matnr: article.matnr,
        menge: article.quantity ? numberToSapNumber(article.quantity) : 1,
      }
    }),
    iv_list_id: listId,
  }

  const data: any = await axiosBackend.post('webservices/lists.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'LIST_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      case 'INVALID_MATNR':
        throw new ShopError(ErrorCode.INVALID_OR_MISSING_PARAMS, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Adds an article to a list
 *
 * @param listId - ID of the list
 * @param matnr - Matnr
 * @param amount - Amount
 *
 * @throws {ErrorCode.INVALID_OR_MISSING_PARAMS} Missing name
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.NOT_FOUND} List not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function addArticleToList (listId: string, matnr: string, amount: number = 1): Promise<void> {

  const params = {
    event: 'ADD_ARTICLE',
    iv_list_id: listId,
    iv_matnr: matnr,
    iv_menge: numberToSapNumber(amount),
  }

  const data: any = await axiosBackend.post('webservices/lists.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'LIST_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      case 'INVALID_MATNR':
        throw new ShopError(ErrorCode.INVALID_OR_MISSING_PARAMS, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Creates and returns a new list
 *
 * @param name - Name of the list
 * @param {ICreateListOptions} options - Options
 *
 * @throws {ErrorCode.INVALID_OR_MISSING_PARAMS} Missing name
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function createList (
  name: string,
  {
    pin = false,
    publish = false,
  }: {
    pin?: boolean,
    publish?: boolean,
  } = {},
): Promise<IList> {

  const params = {
    event: 'CREATE_LIST',
    iv_name: name,
    iv_pin: pin ? 'X' : void 0,
    iv_publish: publish ? 'X' : void 0,
  }

  const data: any = await axiosBackend.post('webservices/lists.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'MISSING_NAME':
        throw new ShopError(ErrorCode.INVALID_OR_MISSING_PARAMS, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  data.result.createdAt = new Date(data.result.createdAt)
  return data.result
}

export interface ICreateListArticle {
  matnr: string,
  quantity?: number,
}

/**
 * Creates a new list, adds articles to it and returns the new list
 *
 * @param name - Name of the list
 * @param articles - Articles
 *
 * @throws {ErrorCode.INVALID_OR_MISSING_PARAMS} Missing name
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function createListWithArticles (
  name: string,
  articles: ICreateListArticle[],
  {
    pin = false,
    publish = false,
  }: {
    pin?: boolean,
    publish?: boolean,
  } = {},
): Promise<IList> {

  const params = {
    event: 'CREATE_LIST_WITH_ARTICLES',
    it_matnrs: articles.map((article) => {
      return {
        matnr: article.matnr,
        menge: article.quantity ? numberToSapNumber(article.quantity) : 1,
      }
    }),
    iv_name: name,
    iv_pin: pin ? 'X' : void 0,
    iv_publish: publish ? 'X' : void 0,
  }

  const data: any = await axiosBackend.post('webservices/lists.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'MISSING_NAME':
        throw new ShopError(ErrorCode.INVALID_OR_MISSING_PARAMS, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  data.result.createdAt = new Date(data.result.createdAt)
  return data.result
}

/**
 * Creates a new list, adds articles to it and returns the new list
 *
 * @param name - Name of the list
 *
 * @throws {ErrorCode.INVALID_OR_MISSING_PARAMS} Missing name
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function createListFromBasket (
  name: string,
  {
    pin = false,
    publish = false,
  }: {
    pin?: boolean,
    publish?: boolean,
  } = {},
): Promise<IList> {

  const params = {
    event: 'CREATE_LIST_FROM_BASKET',
    iv_name: name,
    iv_pin: pin ? 'X' : void 0,
    iv_publish: publish ? 'X' : void 0,
  }

  const data: any = await axiosBackend.post('webservices/lists.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'MISSING_NAME':
        throw new ShopError(ErrorCode.INVALID_OR_MISSING_PARAMS, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  data.result.createdAt = new Date(data.result.createdAt)
  return data.result
}

/**
 * Deletes a list
 *
 * @param listId - ID of the list
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.NOT_FOUND} List not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function deleteList (listId: string): Promise<void> {

  const params = {
    event: 'DELETE_LIST',
    iv_list_id: listId,
  }

  const data: any = await axiosBackend.post('webservices/lists.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'LIST_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Edits an article in a list
 *
 * @param listId - ID of the list
 * @param articleId - ID of the article
 * @param amount - New amount
 */
export async function editArticleInList (listId: string, articleId: string, amount: number): Promise<void> {

  const params = {
    event: 'EDIT_ARTICLE',
    iv_article_id: articleId,
    iv_list_id: listId,
    iv_menge: numberToSapNumber(amount),
  }

  const data: any = await axiosBackend.post('webservices/lists.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'LIST_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Edits the name of a list
 *
 * @param listId - ID of the list
 * @param name - New name
 *
 * @throws {ErrorCode.INVALID_OR_MISSING_PARAMS} Missing name
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.NOT_FOUND} List not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function editListName (listId: string, name: string): Promise<void> {

  const params = {
    event: 'EDIT_LIST_NAME',
    iv_list_id: listId,
    iv_name: name,
  }

  const data: any = await axiosBackend.post('webservices/lists.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'LIST_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      case 'MISSING_NAME':
        throw new ShopError(ErrorCode.INVALID_OR_MISSING_PARAMS, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Returns all lists for the logged in user
 *
 * @param listId - ID of the list
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.NOT_FOUND} List not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getList (listId: string): Promise<IList> {

  const params = {
    event: 'GET_LIST',
    iv_list_id: listId,
  }

  const data: any = await axiosBackend.get('webservices/lists.ws', { params })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'LIST_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  data.result.createdAt = new Date(data.result.createdAt)
  return data.result
}

/**
 * Returns all lists for the logged in user
 *
 * @param {IGetListsOptions} options - Options
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getLists ({
  onlyOwn = false,
}: {
  onlyOwn?: boolean,
} = {}): Promise<IListListItem[]> {

  const params = {
    event: 'GET_LISTS',
    iv_only_own: onlyOwn ? 'X' : void 0,
  }

  const data: any = await axiosBackend.get('webservices/lists.ws', { params })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result.map((row) => {
    row.createdAt = new Date(row.createdAt)
    return row
  })
}

/**
 * Pins or unpins a list
 *
 * @param listId - ID of the list
 * @param pin - Pin or unpin
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.NOT_FOUND} List not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function pinList (listId: string, pin: boolean = true): Promise<void> {

  const params = {
    event: 'PIN_LIST',
    iv_list_id: listId,
    iv_pin: pin ? 'X' : void 0,
  }

  const data: any = await axiosBackend.post('webservices/lists.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'LIST_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Publishes or unpublishes a list
 *
 * @param listId - ID of the list
 * @param pin - Publish or unpublish
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.NOT_FOUND} List not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function publishList (listId: string, publish: boolean = true): Promise<void> {

  const params = {
    event: 'PUBLISH_LIST',
    iv_list_id: listId,
    iv_publish: publish ? 'X' : void 0,
  }

  const data: any = await axiosBackend.post('webservices/lists.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'LIST_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Removes an article from a list
 *
 * @param listId - ID of the list
 * @param articleId - ID of the article
 */
export async function removeArticleFromList (listId: string, articleId: string): Promise<void> {

  const params = {
    event: 'REMOVE_ARTICLE',
    iv_article_id: articleId,
    iv_list_id: listId,
  }

  const data: any = await axiosBackend.post('webservices/lists.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'LIST_NOT_FOUND':
      case 'DB_ENTRY_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Throws a list into a basket
 *
 * @param listId - ID of the list
 * @param basketName - Name of the basket
 */
export async function throwList (listId: string, basketName?: string): Promise<void> {

  const params = {
    event: 'THROW_LIST',
    iv_list_id: listId,
    iv_multibasket: basketName,
  }

  const data: any = await axiosBackend.post('webservices/lists.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'LIST_NOT_FOUND':
      case 'DB_ENTRY_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  store.dispatch('updateBasket')
}
