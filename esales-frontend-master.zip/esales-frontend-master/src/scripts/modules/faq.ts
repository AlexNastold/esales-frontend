import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'

export interface IFaqCategory {
  id: string,
  name: string,
  faqs: {
    id: string,
    question: string,
    answer: string,
  }[],
}

/**
 * Gibt alle FAQs zurück (alphabetisch nach Kategorie und Frage sortiert)
 *
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 */
export async function getFAQs (): Promise<IFaqCategory[]> {
  const data: any = await axiosBackend.get('webservices/faq.ws', { params: {
    event: 'GET_FAQS',
  }})

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE)
  }

  return data.result
}
