import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { IDocument, IDocumentListItem } from '@scripts/modules/documents'
import { ShopEvent, eventHub  } from '@scripts/app/event-hub'

export function addToDocCompareList (list: IDocumentListItem[], document: IDocumentListItem | IDocument) {
  if (arguments.length < 2) {
    throw Error('Required parameter missing. Check the API')
  }

  // Sicherstellen, dass der Liste nur List-Item-Objekte hinzugefügt werden
  const listItem: IDocumentListItem = ensureListItem(document)

  if (list.find((doc) => doc.documentId === listItem.documentId)) {
    throw new ShopError(ErrorCode.ALREADY_IN_DOC_COMPARISON)
  }

  list.push(listItem)
  eventHub.emit(ShopEvent.DOC_COMPARISON_LIST_UPDATED)
}

export function removeFromDocCompareList (list: IDocumentListItem[], document: IDocumentListItem) {
  if (arguments.length < 2) {
    throw Error('Required parameter missing. Check the API')
  }
  const index = list.findIndex((doc) => doc.documentId === document.documentId)
  list.splice(index, 1)
  eventHub.emit(ShopEvent.DOC_COMPARISON_LIST_UPDATED)
}

export function clearDocCompareList (list: IDocumentListItem[]) {
  if (arguments.length < 1) {
    throw Error('Required parameter missing. Check the API')
  }
  list.splice(0, list.length)
  eventHub.emit(ShopEvent.DOC_COMPARISON_LIST_UPDATED)
}

function ensureListItem (document: IDocumentListItem | IDocument): IDocumentListItem {

  let listItem: IDocumentListItem

  if (isDetailDocument(document)) {
    listItem = {
      createDate: document.documentHead.createDate,
      documentId: document.documentId,
      documentIdDisplay: document.documentIdDisplay,
      documentType: document.documentType,
      documentTypeText: document.documentTypeText,
    }
  } else {
    listItem = document
  }

  return listItem
}

// Zur Laufzeit prüfen, ob das Dokument ein Detail-Dokument ist
// Siehe https://www.typescriptlang.org/docs/handbook/advanced-types.html
function isDetailDocument (document: IDocumentListItem | IDocument): document is IDocument {
  return (document as IDocument).documentHead !== undefined
}
