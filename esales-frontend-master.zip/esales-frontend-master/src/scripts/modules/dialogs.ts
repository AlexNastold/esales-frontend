import I18n from '@scripts/modules/i18n'
import Vue from 'vue'

export const confirmDialogDefaults = {
  buttonCancelText: 'Cancel',
  buttonConfirmText: 'OK',
  type: 'primary',
}

export function confirmDialog (
  title: string,
  text: string,
  {
    type = confirmDialogDefaults.type,
    buttonConfirmText = confirmDialogDefaults.buttonConfirmText,
    buttonCancelText = confirmDialogDefaults.buttonCancelText,
  }: {
    type?: string,
    buttonConfirmText?: string,
    buttonCancelText?: string,
  } = {},
) {
  return new Promise((resolve) => {

    let textClass = 'text-white'
    if (type === 'light' || type === 'white' || type === 'warning') {
      textClass = 'text-dark'
    }

    const markup = `
      <div class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header bg-${type} ${textClass}">
              <h5 class="modal-title">${title}</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p>${text}</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">
                ${buttonCancelText}
              </button>
              <button type="button" class="btn btn-${type}" data-button="ok">
                ${buttonConfirmText}
              </button>
            </div>
          </div>
        </div>
      </div>
    `

    const $element = $(markup)
    const $buttonOk = $element.find('[data-button="ok"]')
    $element.appendTo('body')
    $element.modal('show')

    function ok () {
      resolve(true)
      $element.modal('hide')
    }

    $buttonOk.on('click', ok)
    $(document).on('keyup', (e) => {
      if (e.keyCode === 13) {
        ok()
      }
    })

    $element.on('hide.bs.modal', () => resolve(false))

    $element.on('hidden.bs.modal', () => {
      $(document).off('keyup', ok)
      $element.modal('dispose').remove()
    })
  })
}

export const infoDialogDefaults = {
  buttonText: 'OK',
  type: 'primary',
}

export function infoDialog (
  title: string,
  text: string,
  {
    type = infoDialogDefaults.type,
    buttonText = infoDialogDefaults.buttonText,
  }: {
    type?: string,
    buttonText?: string,
  } = {},
) {
  return new Promise((resolve) => {

    let textClass = 'text-white'
    if (type === 'light' || type === 'white' || type === 'warning') {
      textClass = 'text-dark'
    }

    const markup = `
      <div class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header bg-${type} ${textClass}">
              <h5 class="modal-title">${title}</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p>${text}</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-${type}" data-button="ok">
                ${buttonText}
              </button>
            </div>
          </div>
        </div>
      </div>
    `

    const $element = $(markup)
    const $buttonOk = $element.find('[data-button="ok"]')
    $element.appendTo('body')
    $element.modal('show')

    function ok () {
      resolve(true)
      $element.modal('hide')
    }

    $buttonOk.on('click', ok)
    $(document).on('keyup', (e) => {
      if (e.keyCode === 13) {
        ok()
      }
    })

    $element.on('hide.bs.modal', () => resolve(false))

    $element.on('hidden.bs.modal', () => {
      $(document).off('keyup', ok)
      $element.modal('dispose').remove()
    })
  })
}

export function showMessage (type: string, text: string, icon?: string) {
  let messageIcon = icon
  if (typeof messageIcon === 'undefined') {
    messageIcon = ({
      error: 'fas fa-exclamation-triangle',
      info: 'fas fa-info-circle',
      success: 'fas fa-check',
      warning: 'fas fa-exclamation-triangle',
    })[type]
  }

  return Vue.notify({
    text: `${messageIcon ? `<i class="${messageIcon} fa-fw mr-1"></i> ` : ''}${text}`,
    type: type !== 'info' ? type : '',
  })
}

export function showSuccessMessage (text: string, icon?: string) {
  showMessage('success', text, icon)
}

export function showErrorMessage (text: string, icon?: string) {
  showMessage('error', text, icon)
}

export function showWarningMessage (text: string, icon?: string) {
  showMessage('warn', text, icon)
}

export function showInfoMessage (text: string, icon?: string) {
  showMessage('info', text, icon)
}

export function showTechnicalErrorMessage () {
  return showErrorMessage(
    I18n.t('general.technicalErrorMessage'),
  )
}
