import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'

/**
 * An ordermatrix list item
 */
export interface IClerk {
  emailAddress: string,
  firstName: string,
  lastName: string,
  phone: string,
  phoneExtension: string,
  picture: string,
  title: string,
}

/**
 * Returns a list of ordermatrices optinonally filtered by category
 *
 * @param category - The category to filter for
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getClerk (): Promise<IClerk> {
  const data: any = await axiosBackend.get('webservices/misc.ws', { params: {
    event: 'GET_CLERK',
  }})

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}
