import { confirmDialog, showTechnicalErrorMessage } from '@scripts/modules/dialogs'
import I18n from '@scripts/modules/i18n'
import { createFlashMessage } from '@scripts/helper/flash-messages'
import { reload } from '@scripts/helper/redirect'
import { saveUserSettings } from '@scripts/modules/user-settings'
import user from '@scripts/app/user'

export async function showNetPriceSwitchDialog () {
  if (user.isNetPriceEnabled) {
    if (await confirmDialog(
      I18n.t('nettoSwitch.hideDialogTitle'),
      I18n.t('nettoSwitch.hideDialogMessage'),
      {
        buttonCancelText: `<i class="fas fa-times fa-fw"></i> ${I18n.t('general.cancel')}`,
        buttonConfirmText: `<i class="fas fa-toggle-off fa-fw"></i> ${I18n.t('nettoSwitch.hideDialogButtonLabel')}`,
        type: 'warning',
      },
    )) {
      try {
        await saveUserSettings({ showNetPrice: false }, { showNetPrice: true })
        createFlashMessage(I18n.t('nettoSwitch.hideDialogSuccessMessage'), 'success')
        reload()
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    }
  } else {
    if (await confirmDialog(
      I18n.t('nettoSwitch.showDialogTitle'),
      I18n.t('nettoSwitch.showDialogMessage'),
      {
        buttonCancelText: `<i class="fas fa-times fa-fw"></i> ${I18n.t('general.cancel')}`,
        buttonConfirmText: `<i class="fas fa-toggle-on fa-fw"></i> ${I18n.t('nettoSwitch.showDialogButtonLabel')}`,
        type: 'warning',
      },
    )) {
      try {
        await saveUserSettings({ showNetPrice: true }, { showNetPrice: true })
        createFlashMessage(I18n.t('nettoSwitch.showDialogSuccessMessage'), 'success')
        reload()
      } catch (e) {
        console.error(e)
        showTechnicalErrorMessage()
      }
    }
  }
}
