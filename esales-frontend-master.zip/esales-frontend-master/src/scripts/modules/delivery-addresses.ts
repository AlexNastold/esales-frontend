import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'

export interface IAddress {
  id: string,
  name1: string,
  name2: string,
  street: string,
  postalCode: string,
  city: string,
  country: string,
  isDefaultAddress: boolean,
  isEditable: boolean,
}

export enum DeliveryAddressFieldErrors {
  LASTNAME = 'lastname',
  STREET = 'street',
  ZIPCODE = 'zipcode',
  CITY = 'city',
  COUNTRY = 'country',
}

/**
 * Legt eine Lieferadresse an
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws Request error
 */
export async function addDeliveryAddress (
  name1: string,
  name2: string,
  street: string,
  postalCode: string,
  city: string,
  country: string,
  isDefaultAddress: boolean = false,
): Promise<IAddress> {

  const params = {
    event: 'ADD',
    'is_address-defpa': isDefaultAddress ? 'X' : void 0,
    'is_address-land1': country,
    'is_address-name1': name1,
    'is_address-name2': name2,
    'is_address-ort01': city,
    'is_address-pstlz': postalCode,
    'is_address-stras': street,
  }

  const data: any = await axiosBackend.post('webservices/addresses.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status === 'WARNING') {
    if (data.use_validator === 'X') {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

/**
 * Ändert eine Lieferadresse
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws Request error
 */
export async function editDeliveryAddress (
  id: string,
  name1: string,
  name2: string,
  street: string,
  postalCode: string,
  city: string,
  country: string,
  isDefaultAddress: boolean = false,
): Promise<IAddress> {

  const params = {
    event: 'EDIT',
    'is_address-defpa': isDefaultAddress ? 'X' : void 0,
    'is_address-land1': country,
    'is_address-name1': name1,
    'is_address-name2': name2,
    'is_address-ort01': city,
    'is_address-pstlz': postalCode,
    'is_address-stras': street,
    iv_address_id: id,
  }

  const data: any = await axiosBackend.post('webservices/addresses.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status === 'WARNING') {
    if (data.use_validator === 'X') {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

/**
 * Löscht eine Lieferadresse
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws Request error
 */
export async function deleteDeliveryAddress (id: string): Promise<void> {

  const params = {
    event: 'DELETE',
    iv_address_id: id,
  }

  const data: any = await axiosBackend.post('webservices/addresses.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Gibt eine Lieferadresse zurück
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.NOT_FOUND}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws Request error
 */
export async function getDeliveryAddress (id: string): Promise<IAddress> {
  const data: any = await axiosBackend.get('webservices/addresses.ws', { params: {
    event: 'GET_ADDRESS',
    iv_address_id: id,
  }})

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

/**
 * Gibt alle Lieferadressen zum angemeldeten Benutzer zurück
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws Request error
 */
export async function getDeliveryAddresses (): Promise<IAddress[]> {
  const data: any = await axiosBackend.get('webservices/addresses.ws', { params: {
    event: 'GET_LIST',
  }})

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

/**
 * Setzt eine Lieferadresse als Standardlieferadresse
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws Request error
 */
export async function setDefaultDeliveryAddress (id: string): Promise<void> {
  const data: any = await axiosBackend.post('webservices/addresses.ws', {
    event: 'SET_DEFAULT',
    iv_address_id: id,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Beantragt die Erstellung einer SAP-Lieferadresse
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.INVALID_POSTAL_CODE}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws Request error
 */
export async function createDeliveryAddressSAP (
  name1: string,
  name2: string,
  street: string,
  postalCode: string,
  city: string,
  country: string,
): Promise<void> {
  const data: any = await axiosBackend.post('webservices/addresses.ws', {
    event: 'CREATE_SAP',
    iv_city: city,
    iv_country: country,
    iv_firstname: name2,
    iv_lastname: name1,
    iv_postal_code: postalCode,
    iv_street: street,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'INVALID_POSTAL_CODE':
        throw new ShopError(ErrorCode.INVALID_POSTAL_CODE, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status === 'WARNING') {
    if (data.use_validator === 'X') {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Beantragt die Löschung einer SAP-Lieferadresse
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.INVALID_POSTAL_CODE}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws Request error
 */
export async function deleteDeliveryAddressSAP (
  name1: string,
  name2: string,
  street: string,
  postalCode: string,
  city: string,
  country: string,
): Promise<void> {
  const data: any = await axiosBackend.post('webservices/addresses.ws', {
    event: 'DELETE_SAP',
    iv_city: city,
    iv_country: country,
    iv_firstname: name2,
    iv_lastname: name1,
    iv_postal_code: postalCode,
    iv_street: street,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'INVALID_POSTAL_CODE':
        throw new ShopError(ErrorCode.INVALID_POSTAL_CODE, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}
