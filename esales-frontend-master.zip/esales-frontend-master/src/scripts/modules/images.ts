import { serverOrigin } from '@scripts/core/paths'

// eslint-disable-next-line @typescript-eslint/no-var-requires
const noImage = require('../../images/no-image.png')

export function getImageUrl (image?: string): string {
  if (typeof image === 'string' && image.indexOf('/') === 0) {
    return `${serverOrigin}${image}`
  }
  return image
}

export function getNoImageUrl (): string {
  return noImage
}

export function getArticleImageUrl (image?: string): string {
  if (!image) {
    return getNoImageUrl()
  }
  return getImageUrl(image)
}
