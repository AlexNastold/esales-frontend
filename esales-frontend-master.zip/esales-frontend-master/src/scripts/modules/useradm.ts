import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { dateToSapDate, numberToSapNumber } from '@scripts/helper/sapFormat'
import { axiosBackend } from '@scripts/core/axios'
import { serverPath } from '@scripts/core/paths'

/**
 * An user (user adminstration) list item
 */
export interface IUserListItem {
  userId: string,
  kunnr: string,
  userAlias: string,
  title: string,
  firstName: string,
  lastName: string,
  phone: string,
  fax: string,
  emailAddress: string,
  currency: string,
  language: string,
  vkorg?: string,
  vtweg?: string,
  sparte?: string,
  master: string,
  isMaster: boolean,
  isOciUser: boolean,
  isLocked: boolean,
  lockDate?: Date,
  didAcceptTerms: boolean,
  termsAcceptedDate?: Date,
  lastLoginDate?: Date,
  letterSent: boolean,
  letterSentDate?: Date,
  isSelfRegistered: boolean,
  isActivated: boolean,
  hasInitialPassword: boolean,
  enableEditOwnBudget: boolean,
}

/**
 * An user (user adminstration)
 */
export interface IUser extends IUserListItem {
  permissions: IUserPermission[],
  shopAccesses: IUserShopAccess[],
  catalogues: IUserCatalogue[],
  budget: IUserBudgetInfo,
  sales: IUserSalesInfo,
}

/**
 * Permission
 */
export interface IUserPermission {
  permission: string,
  name: string,
  active: boolean,
  editable: boolean,
}

/**
 * Shop acccess
 */
export interface IUserShopAccess {
  shop: string,
  version: string,
  name: string,
  active: boolean,
  editable: boolean,
}

/**
 * Catalogue
 */
export interface IUserCatalogue {
  id: string,
  description: string,
  language: string,
  currency: string,
  validFrom?: Date,
  validTo?: Date,
  assignments: IUserCatalogueAssignments,
}

/**
 * Catalogue assignments
 */
export interface IUserCatalogueAssignments {
  user: IUserCatalogueAssignment,
  customer: IUserCatalogueAssignment,
}

/**
 * Catalogue assignment
 */
export interface IUserCatalogueAssignment {
  active: boolean,
  validFrom: Date,
  validTo: Date,
  exclusive: boolean,
}

/**
 * Bugdget informations
 */
export interface IUserBudgetInfo {
  active: boolean,
  orderStop: boolean,
  responsiveUserId: string,
  possibleResponsiveUsers: {
    userId: string,
    firstName: string,
    lastName: string,
  }[],
  budgets: IUserBudgets
}

/**
 * User budgets
 */
export interface IUserBudgets {
  year: IUserBudget,
  month: IUserBudget,
  week: IUserBudget,
  day: IUserBudget,
  order: IUserBudget,
}

/**
 * User budget
 */
export interface IUserBudget {
  active: boolean,
  budget: number,
  exceed: number,
}

/**
 * User sales
 */
export interface IUserSalesInfo {
  year: {
    sales: number,
    year: string,
  },
  month: {
    sales: number,
    month: string,
  },
  week: {
    sales: number,
    week: string,
  },
  day: {
    sales: number,
    day?: Date,
  },
  order: {
    sales: number,
    order: string,
  }
}

/**
 * Activates an user
 *
 * @param userId - ID of the user
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} User was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function activateUser (userId: string): Promise<void> {

  const data: any = await axiosBackend.post('webservices/useradm.ws', {
    event: 'ACTIVATE_USER',
    iv_user_id: userId,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'USER_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Checks an alias for an user
 *
 * @param userId - ID of the user
 * @param alias - The alias to check
 *
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function checkAlias (userId: string, alias: string): Promise<{ valid: boolean, errors?: string[] }> {

  const data: any = await axiosBackend.get('webservices/useradm.ws', { params: {
    event: 'CHECK_ALIAS',
    iv_alias: alias,
    iv_user_id: userId,
  } })

  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  // Status: WARNING: Alias ist nicht ok
  if (data.status === 'WARNING') {
    if (data.use_validator !== 'X' && data.use_multiple_errors) {
      return {
        errors: (data.data_ref_as_json['user-edit-alias'] || []).filter((d) => d),
        valid: false,
      }
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return { valid: true }
}

/**
 * Checks a password for an user
 *
 * @param userId - ID of the user
 * @param password - The password
 * @param passwordConfirm - The password confirmation
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} User was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function checkPassword (
  userId: string,
  password: string,
  passwordConfirm: string,
): Promise<{
  valid: boolean,
  errorsPassword?: string[],
  errorsPasswordConfirm?: string[],
}> {

  const data: any = await axiosBackend.get('webservices/useradm.ws', { params: {
    event: 'CHECK_PASSWORD',
    iv_password_new1: password,
    iv_password_new2: passwordConfirm,
    iv_user_id: userId,
  }})

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'USER_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  // Status: WARNING: Passwort ist nicht ok
  if (data.status === 'WARNING') {
    if (data.use_validator === 'X' && data.use_multiple_errors) {
      return {
        errorsPassword: (data.data_ref_as_json['user-edit-password-new1'] || []).filter((d) => d),
        errorsPasswordConfirm: (data.data_ref_as_json['user-edit-password-new2'] || []).filter((d) => d),
        valid: false,
      }
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return { valid: true }
}

export enum CreateUserFields {
  TITLE = 'user-create-anred',
  LASTNAME = 'user-create-name1',
  ALIAS = 'user-create-alias',
  EMAIL_ADDRESS = 'user-create-email',
  PHONE = 'user-create-telf1',
  FAX = 'user-create-fax1',
  LANGUAGE = 'user-create-langu',
  CURRENCY = 'user-create-currency',
}

/**
 * Create an user
 *
 * @returns user id
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function createUser ({
  title,
  firstname,
  lastname,
  alias,
  emailAddress,
  phone,
  fax,
  language,
  currency,
  locked = false,
}: {
  title?: string,
  firstname?: string,
  lastname?: string,
  alias?: string,
  emailAddress?: string,
  phone?: string,
  fax?: string,
  language?: string,
  currency?: string,
  locked?: boolean,
} = {}): Promise<string> {

  const data: any = await axiosBackend.post('webservices/useradm.ws', {
    event: 'CREATE_USER',
    is_user: {
      anred: title,
      currency,
      email: emailAddress,
      fax1: fax,
      langu: language,
      locked: locked ? 'X' : void 0,
      name1: lastname,
      namev: firstname,
      telf1: phone,
      user_alias: alias,
    },
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  // Status: WARNING: Daten wurden nicht richtig oder unvollständig übergeben
  if (data.status === 'WARNING') {
    if (data.use_validator === 'X' && data.use_multiple_errors !== 'X') {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result.user.userId
}

/**
 * Deletes an user
 *
 * @param userId - ID of the user
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} User was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function deleteUser (userId: string) {

  const data: any = await axiosBackend.post('webservices/useradm.ws', {
    event: 'DELETE_USER',
    iv_user_id: userId,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'USER_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Returns the download uri with the initial login data for the given user
 * @param userId - The user id
 */
export function getLetterDownloadUri (userId: string) {
  return `${serverPath}webservices/useradm.ws?event=DOWNLOAD_LETTER&iv_user_id=${encodeURIComponent(userId)}`
}

/**
 * Send the letter with the initial login data to the email address of the given user
 *
 * @param userId - ID of the user
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} User was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function sendLetter (userId: string) {
  const data: any = await axiosBackend.post('webservices/useradm.ws', {
    event: 'SEND_LETTER',
    iv_user_id: userId,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'USER_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export enum EditUserBudgetFields {
  RESPONSIVE_USER_ID = 'user-edit-budget-responsive',
  BUDGET_YEAR = 'user-edit-budget-year-budget',
  BUDGET_MONTH = 'user-edit-budget-month-budget',
  BUDGET_WEEK = 'user-edit-budget-week-budget',
  BUDGET_DAY = 'user-edit-budget-day-budget',
  BUDGET_ORDER = 'user-edit-budget-order-budget',
}

/**
 * Edit an users budget
 *
 * @param userId - ID of the user
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} User was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function editUserBudget (userId, {
  active,
  orderStop,
  responsiveUserId,
  budgetYear,
  budgetYearActive,
  budgetMonth,
  budgetMonthActive,
  budgetWeek,
  budgetWeekActive,
  budgetDay,
  budgetDayActive,
  budgetOrder,
  budgetOrderActive,
}: {
  active: boolean,
  orderStop: boolean,
  responsiveUserId: string,
  budgetYear: number,
  budgetYearActive: boolean,
  budgetMonth: number,
  budgetMonthActive: boolean,
  budgetWeek: number,
  budgetWeekActive: boolean,
  budgetDay: number,
  budgetDayActive: boolean,
  budgetOrder: number,
  budgetOrderActive: boolean,
}): Promise<void> {

  const data: any = await axiosBackend.post('webservices/useradm.ws', {
    event: 'EDIT_BUDGET',
    is_budget: {
      active: active ? 'X' : void 0,
      budget_day: typeof budgetDay === 'number' ? numberToSapNumber(budgetDay) : budgetDay,
      budget_day_act: budgetDayActive ? 'X' : void 0,
      budget_month: typeof budgetMonth === 'number' ? numberToSapNumber(budgetMonth) : budgetMonth,
      budget_month_act: budgetMonthActive ? 'X' : void 0,
      budget_order: typeof budgetOrder === 'number' ? numberToSapNumber(budgetOrder) : budgetOrder,
      budget_order_act: budgetOrderActive ? 'X' : void 0,
      budget_response: responsiveUserId,
      budget_week: typeof budgetWeek === 'number' ? numberToSapNumber(budgetWeek) : budgetWeek,
      budget_week_act: budgetWeekActive ? 'X' : void 0,
      budget_year: typeof budgetYear === 'number' ? numberToSapNumber(budgetYear) : budgetYear,
      budget_year_act: budgetYearActive ? 'X' : void 0,
      order_stop: orderStop ? 'X' : void 0,
    },
    is_budget_numbers: {
      budget_day: typeof budgetDay === 'number' ? numberToSapNumber(budgetDay) : budgetDay,
      budget_month: typeof budgetMonth === 'number' ? numberToSapNumber(budgetMonth) : budgetMonth,
      budget_order: typeof budgetOrder === 'number' ? numberToSapNumber(budgetOrder) : budgetOrder,
      budget_week: typeof budgetWeek === 'number' ? numberToSapNumber(budgetWeek) : budgetWeek,
      budget_year: typeof budgetYear === 'number' ? numberToSapNumber(budgetYear) : budgetYear,
    },
    iv_user_id: userId,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'USER_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  // Status: WARNING: Daten wurden nicht richtig oder unvollständig übergeben
  if (data.status === 'WARNING') {
    if (data.use_validator === 'X' && data.use_multiple_errors !== 'X') {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Edit an users catalogues
 *
 * @param userId - ID of the user
 * @param catalogues - Catalogues to edit
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} User was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function editUserCatalogues (userId: string, catalogues: {
  id: string,
  active: boolean,
  validFrom?: Date,
  validTo?: Date,
  exclusive?: boolean,
}[]): Promise<void> {

  const data: any = await axiosBackend.post('webservices/useradm.ws', {
    event: 'EDIT_CATALOGUES',
    it_catalogues: catalogues.map((catalogue) => ({
      active: catalogue.active ? 'X' : void 0,
      catalog_id: catalogue.id,
      exclusiv_kz: catalogue.exclusive ? 'X' : void 0,
      valid_from: catalogue.validFrom ? dateToSapDate(catalogue.validFrom) : void 0,
      valid_to: catalogue.validTo ? dateToSapDate(catalogue.validTo) : void 0,
    })),
    iv_user_id: userId,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'USER_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export enum EditUserDataFields {
  TITLE = 'user-edit-anred',
  LASTNAME = 'user-edit-name1',
  ALIAS = 'user-edit-alias',
  EMAIL_ADDRESS = 'user-edit-email',
  PHONE = 'user-edit-telf1',
  FAX = 'user-edit-fax1',
  LANGUAGE = 'user-edit-langu',
  CURRENCY = 'user-edit-currency',
}

/**
 * Edit an users informations
 *
 * @param userId - ID of the user
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} User was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function editUserData (userId: string, {
  title,
  firstname,
  lastname,
  alias,
  emailAddress,
  phone,
  fax,
  language,
  currency,
}: {
  title?: string,
  firstname?: string,
  lastname?: string,
  alias?: string,
  emailAddress?: string,
  phone?: string,
  fax?: string,
  language?: string,
  currency?: string,
} = {}): Promise<void> {

  const data: any = await axiosBackend.post('webservices/useradm.ws', {
    event: 'EDIT_USER_DATA',
    'is_user-anred': title,
    'is_user-currency': currency,
    'is_user-email': emailAddress,
    'is_user-fax1': fax,
    'is_user-langu': language,
    'is_user-name1': lastname,
    'is_user-namev': firstname,
    'is_user-telf1': phone,
    'is_user-user_alias': alias,
    'is_user-user_id': userId,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'USER_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  // Status: WARNING: Daten wurden nicht richtig oder unvollständig übergeben
  if (data.status === 'WARNING') {
    if (data.use_validator === 'X' && data.use_multiple_errors !== 'X') {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export enum EditUserPasswordFields {
  PASSWORD = 'user-edit-password-new1',
  PASSWORD_CONFIRM = 'user-edit-password-new2',
}

/**
 * Edit an users password
 *
 * @param userId - ID of the user
 * @param isInitial - Flag, if the password should be an initial password
 * @param password - New password
 * @param passwordConfirm - Confirmation of the new password
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} User was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function editUserPassword (
  userId: string,
  isInitial: boolean,
  password?: string,
  passwordConfirm?: string,
): Promise<void> {

  const data: any = await axiosBackend.post('webservices/useradm.ws', {
    event: 'EDIT_PASSWORD',
    iv_password_initial: isInitial ? 'X' : void 0,
    iv_password_new1: password,
    iv_password_new2: passwordConfirm,
    iv_user_id: userId,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'USER_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  // Status: WARNING: Daten wurden nicht richtig oder unvollständig übergeben
  if (data.status === 'WARNING') {
    if (data.use_validator === 'X' && data.use_multiple_errors) {
      const fieldErrors = Object.keys(data.data_ref_as_json).reduce((acc, val) => {
        acc[val] = (data.data_ref_as_json[val] || []).filter((d) => d)
        return acc
      }, {})

      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, { fieldErrors })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Edit the permissions of an user
 *
 * @param userId - ID of the user
 * @param permissions - Permissions
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} User was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function editUserPermissions (userId: string, permissions: string[] = []): Promise<void> {

  const data: any = await axiosBackend.post('webservices/useradm.ws', {
    event: 'EDIT_PERMISSIONS',
    it_permissions: permissions,
    iv_user_id: userId,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'USER_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Edit the shop accesses of an user
 *
 * @param userId - ID of the user
 * @param shops - Shops
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} User was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function editUserShopAccesses (userId: string, shops: string[] = []): Promise<void> {

  const data: any = await axiosBackend.post('webservices/useradm.ws', {
    event: 'EDIT_SHOP_ACCESS',
    it_shop_accesses: shops,
    iv_user_id: userId,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'USER_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export enum UserListSortDirection {
  ASCENDING = 'asc',
  DESCENDING = 'desc',
}

export enum UserListSortField {
  USER_ID = 'user_id',
  FIRSTNAME = 'namev',
  LASTNAME = 'name1',
  USER_ALIAS = 'user_alias',
  KUNNR = 'kunnr',
  EMAIL_ADDRESS = 'email',
  CURRENCY = 'currency',
  MASTER = 'master',
  FLAG_LOCKED = 'locked',
  FLAG_INITIAL = 'pwd_chg_flag',
  FLAG_SELF_REGISTERED = 'self_reg',
  FLAG_DELETED = 'del_flag',
  VKORG = 'main_vkorg',
  VTWEG = 'main_vtweg',
  SPARTE = 'main_sparte',
}

/**
 * Returns a list of users
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getList ({
  sortField = UserListSortField.USER_ID,
  sortDirection = UserListSortDirection.ASCENDING,
}: {
  sortField?: UserListSortField,
  sortDirection?: UserListSortDirection,
} = {}): Promise<IUserListItem[]> {

  const data: any = await axiosBackend.get('webservices/useradm.ws', { params: {
    event: 'GET_USERS',
    iv_sort_direction: sortDirection,
    iv_sort_field: sortField,
  }})

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result.users.map((user) => {
    if (user.lockDate) {
      user.lockDate = new Date(user.lockDate)
    }
    if (user.termsAcceptedDate) {
      user.termsAcceptedDate = new Date(user.termsAcceptedDate)
    }
    if (user.lastLoginDate) {
      user.lastLoginDate = new Date(user.lastLoginDate)
    }
    if (user.letterSentDate) {
      user.letterSentDate = new Date(user.letterSentDate)
    }
    return user
  })
}

/**
 * Returns an user
 *
 * @param userId - ID of the user
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} User was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getUser (userId: string): Promise<IUser> {

  const data: any = await axiosBackend.get('webservices/useradm.ws', { params: {
    event: 'GET_USER',
    iv_user_id: userId,
  }})

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'USER_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
  const user = data.result

  if (user.lockDate) {
    user.lockDate = new Date(user.lockDate)
  }
  if (user.termsAcceptedDate) {
    user.termsAcceptedDate = new Date(user.termsAcceptedDate)
  }
  if (user.lastLoginDate) {
    user.lastLoginDate = new Date(user.lastLoginDate)
  }
  if (user.letterSentDate) {
    user.letterSentDate = new Date(user.letterSentDate)
  }

  if (user.catalogues) {
    user.catalogues = user.catalogues.map((catalogue) => {
      if (catalogue.validFrom) {
        catalogue.validFrom = new Date(catalogue.validFrom)
      }
      if (catalogue.validTo) {
        catalogue.validTo = new Date(catalogue.validTo)
      }
      if (catalogue.assignments.user.validFrom) {
        catalogue.assignments.user.validFrom = new Date(catalogue.assignments.user.validFrom)
      }
      if (catalogue.assignments.user.validTo) {
        catalogue.assignments.user.validTo = new Date(catalogue.assignments.user.validTo)
      }
      if (catalogue.assignments.customer.validFrom) {
        catalogue.assignments.customer.validFrom = new Date(catalogue.assignments.customer.validFrom)
      }
      if (catalogue.assignments.customer.validTo) {
        catalogue.assignments.customer.validTo = new Date(catalogue.assignments.customer.validTo)
      }
      return catalogue
    })
  }

  if (user.sales && user.sales.day.day) {
    user.sales.day.day = new Date(user.sales.day.day)
  }

  return user
}

/**
 * Locks an user
 *
 * @param userId - ID of the user
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} User was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function lockUser (userId: string): Promise<void> {
  return lockOrUnlockUser(userId, true)
}

/**
 * Unlocks an user
 *
 * @param userId - ID of the user
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} User was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function unlockUser (userId: string): Promise<void> {
  return lockOrUnlockUser(userId, false)
}

/**
 * Locks or unlocks an user
 *
 * @param userId - ID of the user
 * @param lock - Lock / Unlock
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} User was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function lockOrUnlockUser (userId: string, lock: boolean): Promise<void> {

  const data: any = await axiosBackend.post('webservices/useradm.ws', {
    event: 'LOCK_USER',
    iv_lock: lock ? 'X' : void 0,
    iv_user_id: userId,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'USER_NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}
