import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { IListArticle } from '@scripts/modules/interfaces'
import { axiosBackend } from '@scripts/core/axios'

/**
 * An ordermatrix list item
 */
export interface IOrdermatrixListItem {
  id: string,
  name: string,
  isAvailableInUsersLanguage: boolean,
  category?: string,
}

/**
 * Returns a list of ordermatrices optinonally filtered by category
 *
 * @param category - The category to filter for
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getList (category?: string, limit?: number): Promise<{
  ordermatrices: IOrdermatrixListItem[],
  amountAll: number,
}> {
  const data: any = await axiosBackend.get('webservices/ordermatrix.ws', { params: {
    event: 'GET_LIST',
    iv_category: category,
    iv_limit: limit,
  }})

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

export interface IOdermatrix {
  id: string,
  uuid: string,
  name: string,
  isAvailableInUsersLanguage: boolean,
  category?: string,
  header: {
    text: string,
    picture: string,
    columns: string[],
  }
  rows: {
    text: string,
    picture: string,
    columns: {
      article: IListArticle,
      matnr: string,
      matnrDisplay: string,
    }[],
  }[],
}

export interface IOdermatrixRowColumn {
  matnr: string,
  matnrDisplay: string,
}

/**
 * Returns an ordermatrix
 *
 * @param id - Id of the ordermatrix
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} Ordermatrix was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getOrdermatrix (id: string): Promise<IOdermatrix> {
  const data: any = await axiosBackend.get('webservices/ordermatrix.ws', { params: {
    event: 'GET_ORDERMATRIX',
    iv_omat_id: id,
  }})

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (!data.result.id) {
    throw new ShopError(ErrorCode.NOT_FOUND, data.message)
  }

  return data.result
}
