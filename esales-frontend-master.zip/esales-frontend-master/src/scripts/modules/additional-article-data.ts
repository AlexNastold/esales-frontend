import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'
import { numberToSapNumber } from '@scripts/helper/sapFormat'

export enum AvailabilityFlag {
  AVAILABLE = 'available',
  SHORTLY_AVAILABLE = 'shortly-available',
  NOT_AVAILABLE = 'not-available',
}

export interface IAdditionalArticleData {
  matnr: string,
  matnrDisplay: string,
  amount: string,
  materialStatus: string,
  retailPrice: {
    price: number,
    currency: string,
    costUnit: number,
    volumeUnit: string,
  },
  netPrice?: {
    price: number,
    currency: string,
    costUnit: number,
    volumeUnit: string,
  },
  hasError: boolean,
  error?: string,
  availability?: {
    unit: string,
    directly?: number,
    shortly?: number,
    replenishmentDate?: Date,
    availabilityFlag: AvailabilityFlag,
  }
}

export async function getInstantAdditionalArticleData (
  articles: { matnr: string, amount?: number, volumeUnit?: string }[],
  { scalePrices = false }: { scalePrices?: boolean } = {},
): Promise<IAdditionalArticleData[]> {

  const params = {
    articles: [],
    event: 'GET_AVAILABILITIES_AND_PRICES',
    scale_prices: scalePrices ? 'X' : void 0,
  }

  articles.forEach((article) => {
    const amount = typeof article.amount !== 'undefined' ? numberToSapNumber(article.amount) : void 0

    params.articles.push({
      matnr: article.matnr,
      meins: article.volumeUnit,
      menge: amount,
    })
  })

  const data: any = await axiosBackend.post('webservices/materialmaster.ws', params)

  if  (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.results
}

export async function getInstantSingleAdditionalArticleData (matnr: string, amount?: number, volumeUnit?: string) {
  const data: any = await getInstantAdditionalArticleData([{ amount, matnr, volumeUnit }])

  return data[0]
}

let queue = []
const QUEUE_MAX_LENGTH = 10
const QUEUE_MAX_WAIT = 100
let queueTimer = void 0

export function getAdditionalArticleData (
  articles: { matnr: string, amount?: number, volumeUnit?: string }[],
) {
  const promises = articles.map((article) => {
    return getSingleAdditionalArticleData(
      article.matnr,
      article.amount,
      article.volumeUnit,
    )
  })
  return Promise.all(promises)
}

export function getSingleAdditionalArticleData (
  matnr: string, amount?: number, volumeUnit?: string,
) {
  return new Promise((resolve) => {
    if (queue.length === 0) {
      queueTimer = setTimeout(executeQueue, QUEUE_MAX_WAIT)
    }

    queue.push({ amount, callback: resolve, matnr, volumeUnit })

    if (queue.length === QUEUE_MAX_LENGTH) {
      executeQueue()
    }
  })
}

async function executeQueue () {
  clearTimeout(queueTimer)

  const articles = queue
  queue = []

  if (articles.length) {
    const data = await getInstantAdditionalArticleData(articles.map((article) => ({
      amount: article.amount,
      matnr: article.matnr,
      volumeUnit: article.volumeUnit,
    })))

    data.forEach((additionalArticleData, index) => {
      articles[index].callback(additionalArticleData)
    })
  }
}
