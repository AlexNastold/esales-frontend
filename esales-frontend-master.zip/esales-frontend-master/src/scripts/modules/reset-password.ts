import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'

export enum ResetPasswordFieldErrors {
  USERNAME_ALIAS= 'username-alias',
  CUSTOMER_NUMBER = 'customer-number',
  EMAIL = 'email',
}

/**
 * Checks if a token is valid and returns user informations
 *
 * @throws {ErrorCode.USER_INITIAL}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function checkToken (token: string): Promise<{
  isValidToken: boolean,
  doesTokenExist: boolean,
  isTokenExpired: boolean,
  user?: {
    userId: string,
    userAlias: string,
    kunnr: string,
  },
}> {

  const data: any = await axiosBackend.post('webservices/auth.ws', {
    event: 'PASSWORD_RESET_CHECK_TOKEN',
    iv_token: token,
  })

  if (data.status === 'ERROR') {
    if (data.code === 'USER_INITIAL') {
      throw new ShopError(ErrorCode.USER_INITIAL, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return {
    doesTokenExist: data.result.doesTokenExist,
    isTokenExpired: data.result.isTokenExpired,
    isValidToken: data.result.isValidToken,
    user: data.result.user ? {
      kunnr: data.result.user.kunnr,
      userAlias: data.result.user.user_alias,
      userId: data.result.user.user_id,
    } : void 0,
  }
}

/**
 * Initializes an password reset
 *
 * The webservice does not return any errors if the input is wrong
 * to prevent security issues
 *
 * @param userId - ID of the user
 * @param kunnr - Customer number of the user
 * @param emailAddress - Email address of the user
 *
 * @throws {ErrorCode.SHOP_LOCKED}
 * @throws {ErrorCode.CAPTCHA_INVALID}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function resetPassword (userId: string, kunnr: string, emailAddress: string, captcha: string): Promise<void> {

  const params = {
    event: 'PASSWORD_RESET',
    'g-recaptcha-response': captcha,
    iv_email_address: emailAddress,
    iv_kunnr: kunnr,
    iv_user_id_or_alias: userId,
  }

  const data: any = await axiosBackend.post('webservices/auth.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'SHOP_LOCKED':
        throw new ShopError(ErrorCode.SHOP_LOCKED, data.message)
      case 'CAPTCHA_INVALID':
        throw new ShopError(ErrorCode.CAPTCHA_INVALID, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status === 'WARNING') {
    if (data.use_validator === 'X') {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Sets a new password
 *
 * @param token - Token for the password reset
 * @param password - New password
 * @param passwordConfirmation - New password confirmation
 *
 * @throws {ErrorCode.SHOP_LOCKED}
 * @throws {ErrorCode.RESET_PASSWORD_INVALID_TOKEN}
 * @throws {ErrorCode.USER_INITIAL}
 * @throws {ErrorCode.RESET_PASSWORD_INVALID_PASSWORD}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function setNewPassword (token: string, password: string, passwordConfirmation: string): Promise<void> {

  const params = {
    event: 'PASSWORD_RESET_SET_NEW_PASSWORD',
    iv_password_new1: password,
    iv_password_new2: passwordConfirmation,
    iv_token: token,
  }

  const data: any = await axiosBackend.post('webservices/auth.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'SHOP_LOCKED':
        throw new ShopError(ErrorCode.SHOP_LOCKED, data.message)
      case 'INVALID_TOKEN':
        throw new ShopError(ErrorCode.RESET_PASSWORD_INVALID_TOKEN, data.message)
      case 'USER_INITIAL':
        throw new ShopError(ErrorCode.USER_INITIAL, data.message)
      case 'INVALID_PASSWORD':
        throw new ShopError(ErrorCode.RESET_PASSWORD_INVALID_PASSWORD, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}
