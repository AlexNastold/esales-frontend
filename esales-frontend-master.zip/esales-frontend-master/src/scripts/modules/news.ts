import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'

export interface INewsListItem {
  id: string,
  validFrom?: Date,
  validTo?: Date,
  title?: string,
  banner?: string,
}

/**
 * Returns a list of news
 *
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getNewsList (): Promise<{ news: INewsListItem[], fallback: {
  title: string,
  banner: string,
}}> {
  const data: any = await axiosBackend.get('webservices/news.ws', { params: {
    event: 'GET_NEWS_LIST',
  }})

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  // Transform string date to Date objects
  data.result.news = data.result.news.map((newsItem) => {
    if (newsItem.validFrom) {
      newsItem.validFrom = new Date(newsItem.validFrom)
    }
    if (newsItem.validTo) {
      newsItem.validTo = new Date(newsItem.validTo)
    }
    return newsItem
  })

  return data.result
}

export interface INews {
  id: string,
  validFrom?: Date,
  validTo?: Date,
  title?: string,
  banner?: string,
  text?: string,
}

/**
 * Returns a news item
 *
 * @throws {ErrorCode.NOT_FOUND}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getNews (id: string): Promise<INews> {
  const data: any = await axiosBackend.get('webservices/news.ws', { params: {
    event: 'GET_NEWS',
    iv_news_id: id,
  }})

  if (data.status === 'ERROR') {
    if (data.code === 'NOT_FOUND') {
      throw new ShopError(ErrorCode.NOT_FOUND, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  // Transform string date to Date objects
  if (data.result.validFrom) {
    data.result.validFrom = new Date(data.result.validFrom)
  }
  if (data.result.validTo) {
    data.result.validTo = new Date(data.result.validTo)
  }

  return data.result
}
