import { ITrackingOrder } from '@scripts/modules/basket'
import { applicationSettings } from '@scripts/app/settings'

import browserStore from '@scripts/core/browserStore'

export async function gtmSaveOrder (tracking: ITrackingOrder) {
  browserStore.set('gtmOrder', tracking)
}

export async function gtmTrackOrder () {
  const tracking = browserStore.get('gtmOrder')
  try {
    if (applicationSettings.gtmEcommerceActive && tracking) {
      const win = (window as any)
      win.dataLayer.push({
        event: 'order-created',
        transactionAffiliation: document.title,
        transactionId: tracking.docId,
        transactionProducts: tracking.items.map((item) =>
          ({
            category: item.category,
            name: item.texts.trim(),
            price: item.netPrice || item.grossPrice,
            quantity: item.quantity,
            sku: item.partno,
          }),
        ),
        transactionTax: tracking.netTax || tracking.grossTax,
        transactionTotal: tracking.netSum || tracking.grossSum,
      })

      browserStore.remove('gtmOrder')
    }
  } catch (e) {
    console.error(e)
  }
}
