import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { IListArticle } from '@scripts/modules/interfaces'
import { axiosBackend } from '@scripts/core/axios'

export interface ICampaignListItem {
  id: string,
  name: string,
  slogan: string,
  banner: string,
  validFrom?: string,
  validTo?: string,
  promoted: boolean
}

/**
 * Returns a list of available campaigns
 *
 * @param onlyPromoted - Only return promoted campaigns
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getCampaigns (onlyPromoted: boolean = false): Promise<ICampaignListItem[]> {

  const params = {
    event: 'GET_CAMPAIGNS',
    iv_only_promoted: onlyPromoted ? 'X' : void 0,
  }

  const data: any = await axiosBackend.get('webservices/campaigns.ws', { params })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result.campaigns
}

export enum CampaignElementType {
  HEADLINE = 'headline',
  BANNER = 'banner',
  ARTICLE = 'product',
  TEXT = 'text',
}

export interface ICampaign {
  id: string,
  name: string,
  slogan: string,
  banner: string,
  validFrom?: string,
  validTo?: string,
  promoted: boolean
  rows: ICampaignRow[],
}

export interface ICampaignRow {
  row: number,
  elements: ICampaignElement[]
}

export interface ICampaignElement {
  id: string,
  type: CampaignElementType,
  text?: string,
  banner?: string,
  article?: IListArticle,
  width: number,
}

/**
 * Returns a campaign
 *
 * @param campaignId - ID of the campaign
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.NOT_FOUND} Campaign was not found
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getCampaign (campaignId: string): Promise<ICampaign> {

  const params = {
    event: 'GET_CAMPAIGN',
    iv_campaign_id: campaignId,
  }

  const data: any = await axiosBackend.get('webservices/campaigns.ws', { params })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}
