/* --------------------------------------------------------------------------------
      ____  _________________   ________   __  _______  ____  __  ____    ______
     / __ \/ ____/ ____/  _/ | / / ____/  /  |/  / __ \/ __ \/ / / / /   / ____/
    / / / / __/ / /_   / //  |/ / __/    / /|_/ / / / / / / / / / / /   / __/
   / /_/ / /___/ __/ _/ // /|  / /___   / /  / / /_/ / /_/ / /_/ / /___/ /___
  /_____/_____/_/   /___/_/ |_/_____/  /_/  /_/\____/_____/\____/_____/_____/

-------------------------------------------------------------------------------- */

export enum Browser {
  Chrome = 'Chrome',
  OmniWeb = 'OmniWeb',
  Safari = 'Safari',
  Opera = 'Opera',
  iCab = 'iCab',
  Konqueror = 'Konqueror',
  Firefox = 'Firefox',
  Camino = 'Camino',
  Netscape = 'Netscape',
  Explorer = 'Explorer',
  WebKit = 'WebKit',
  Mozilla = 'Mozilla',
}

export enum OS {
  Windows = 'Windows',
  Mac = 'Mac',
  iPhone = 'iPhone', // IPhone/IPod
  iPad = 'iPad',
  Android = 'Android',
  webOS = 'webOS',
  BlackBerry = 'BlackBerry',
  Linux = 'Linux',
}

const dataBrowser: {
  string?: string,
  subString?: string,
  prop?: any,
  identity: Browser,
  versionSearch?: string,
}[] = [
  { identity: Browser.Chrome, string: navigator.userAgent, subString: 'Chrome' },
  { identity: Browser.OmniWeb, string: navigator.userAgent, subString: 'OmniWeb', versionSearch: 'OmniWeb/' },
  { identity: Browser.Safari, string: navigator.vendor, subString: 'Apple', versionSearch: 'Version' },
  { identity: Browser.Safari, string: navigator.userAgent, subString: 'Safari' },
  { identity: Browser.Opera, prop: (window as any).opera, versionSearch: 'Version' },
  { identity: Browser.iCab, string: navigator.vendor, subString: 'iCab' },
  { identity: Browser.Konqueror, string: navigator.vendor, subString: 'KDE' },
  { identity: Browser.Firefox, string: navigator.userAgent, subString: 'Firefox' },
  { identity: Browser.Camino, string: navigator.vendor, subString: 'Camino' },
  { identity: Browser.Netscape, string: navigator.userAgent, subString: 'Netscape'  },
  { identity: Browser.Explorer, string: navigator.userAgent, subString: 'MSIE', versionSearch: 'MSIE' },
  { identity: Browser.WebKit, string: navigator.userAgent, subString: 'WebKit', versionSearch: 'WebKit' },
  { identity: Browser.Mozilla, string: navigator.userAgent, subString: 'Gecko', versionSearch: 'rv' },
  { identity: Browser.Netscape, string: navigator.userAgent, subString: 'Mozilla', versionSearch: 'Mozilla' },
]

const dataOS: {
  string: string,
  subString: string,
  identity: OS,
  versionSearch?: string,
}[] = [
  { identity: OS.Windows, string: navigator.userAgent, subString: 'Windows NT', versionSearch: 'Windows NT' },
  { identity: OS.Windows, string: navigator.platform, subString: 'Win' },
  { identity: OS.Mac, string: navigator.platform, subString: 'Mac' },
  { identity: OS.iPhone, string: navigator.userAgent, subString: 'iPhone' },
  { identity: OS.iPad, string: navigator.userAgent, subString: 'iPad' },
  { identity: OS.Android, string: navigator.userAgent, subString: 'Android', versionSearch: 'Android' },
  { identity: OS.webOS, string: navigator.userAgent, subString: 'webOS' },
  { identity: OS.BlackBerry, string: navigator.userAgent, subString: 'BlackBerry'  },
  { identity: OS.Linux, string: navigator.platform, subString: 'Linux'  },
]

export class Device {
  public readonly browser: string
  public readonly browserVersion?: number
  public readonly os: string
  public readonly osVersion?: number

  constructor () {
    const { browser, browserVersion } = this.detectBrowser()
    this.browser = browser
    this.browserVersion = browserVersion

    const { os, osVersion } = this.detectOs()
    this.os = os
    this.osVersion = osVersion
  }

  /**
   * Detect the browser and its version
   */
  private detectBrowser () {
    let browser: string
    let browserVersion: number

    for (const d of dataBrowser) {
      if ((d.string && d.string.indexOf(d.subString) !== -1) || d.prop) {
        browser = d.identity

        const versionSearchString = d.versionSearch || d.identity
        if (navigator.userAgent.indexOf(versionSearchString) !== -1) {
          const start = navigator.userAgent.indexOf(versionSearchString) + versionSearchString.length + 1
          const versionString = navigator.userAgent.substring(start)
          browserVersion = parseFloat(versionString)
        } else if (navigator.appVersion.indexOf(versionSearchString) !== -1) {
          const start = navigator.appVersion.indexOf(versionSearchString) + versionSearchString.length + 1
          const versionString = navigator.appVersion.substring(start)
          browserVersion = parseFloat(versionString)
        }
        break
      }
    }

    return { browser, browserVersion }
  }

  /**
   * Detect the operating system and its version
   */
  private detectOs () {
    let os: string
    let osVersion: number

    for (const d of dataOS) {
      if (d.string && d.string.indexOf(d.subString) !== -1) {
        os = d.identity

        const versionSearchString = d.versionSearch || d.identity
        if (navigator.userAgent.indexOf(versionSearchString) !== -1) {
          const start = navigator.userAgent.indexOf(versionSearchString) + versionSearchString.length + 1
          const osString = navigator.userAgent.substring(start)
          osVersion = parseFloat(osString)
        } else if (navigator.appVersion.indexOf(versionSearchString) !== -1) {
          const start = navigator.appVersion.indexOf(versionSearchString) + versionSearchString.length + 1
          const osString = navigator.appVersion.substring(start)
          osVersion = parseFloat(osString)
        }
        break
      }
    }

    return { os, osVersion }
  }
}

/* --------------------------------------------------------------------------------
      _____   ____________   __  _______  ____  __  ____    ______
     /  _/ | / /  _/_  __/  /  |/  / __ \/ __ \/ / / / /   / ____/
     / //  |/ // /  / /    / /|_/ / / / / / / / / / / /   / __/
   _/ // /|  // /  / /    / /  / / /_/ / /_/ / /_/ / /___/ /___
  /___/_/ |_/___/ /_/    /_/  /_/\____/_____/\____/_____/_____/

-------------------------------------------------------------------------------- */

const device = new Device()

export default device
