import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'

export enum RegistrationErrorFields {
  KUNNR = 'selfregistration-kunnr',
  TITLE = 'selfregistration-anred',
  LASTNAME = 'selfregistration-name1',
  ALIAS = 'selfregistration-alias',
  EMAIL_ADDRESS = 'selfregistration-email',
  PHONE = 'selfregistration-telf1',
  FAX = 'selfregistration-fax1',
  LANGUAGE = 'selfregistration-langu',
  CURRENCY = 'selfregistration-currency',
  SALES_ORG = 'selfregistration-vkorg-vtweg',
  SAVE_IP_CONFIRM = 'selfregistration-save-ip',
}

export interface IRegisterOptions {
  kunnr?: string,
  title?: string,
  firstname?: string,
  lastname?: string,
  alias?: string,
  emailAddress?: string,
  phone?: string,
  fax?: string,
  language?: string,
  currency?: string,
  vkorg?: string,
  vtweg?: string,
  saveIpAccepted?: boolean,
  captcha?: string,
}

/**
 * Register a new user
 *
 * @return user id
 */
export async function register ({
  kunnr,
  title,
  firstname,
  lastname,
  alias,
  emailAddress,
  phone,
  fax,
  language,
  currency,
  vkorg,
  vtweg,
  saveIpAccepted,
  captcha,
}: IRegisterOptions = {}): Promise<string> {
  const data: any = await axiosBackend.post('webservices/registration.ws', {
    event: 'CREATE_USER',
    'g-recaptcha-response': captcha,
    is_user: {
      anred: title,
      currency,
      email: emailAddress,
      fax1: fax,
      kunnr,
      langu: language,
      main_vkorg: vkorg,
      main_vtweg: vtweg,
      name1: lastname,
      namev: firstname,
      telf1: phone,
      user_alias: alias,
    },
    iv_accept_save_ip_address: saveIpAccepted ? 'X' : void 0,
  })

  if (data.status === 'ERROR') {
    if (data.code === 'CAPTCHA_INVALID') {
      throw new ShopError(ErrorCode.CAPTCHA_INVALID, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status === 'WARNING') {
    if (data.use_validator === 'X' && data.use_multiple_errors) {
      const fieldErrors = Object.keys(data.data_ref_as_json).reduce((acc, val) => {
        acc[val] = (data.data_ref_as_json[val] || []).filter((d) => d)
        return acc
      }, {})

      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, { fieldErrors })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result.user.user_id
}
