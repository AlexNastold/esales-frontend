import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'
import { rewriteUrlsInText } from '@scripts/helper/rewriteUrlsInText'

export enum PageId {
  TERMS_AND_CONDITIONS = 'HTML_TERMS',
  IMPRINT = 'HTML_IMPRINT',
  PRIVACY = 'HTML_PRIVACY',
  TERMSOFUSE = 'HTML_TERMS_OF_USE',
  CONSENTDECLARATION = 'HTML_CONSENT_DECLARATION',
  PRIVACY_GOOGLE_ANALYTICS = 'HTML_PRIVACY_GOOGLE_ANALYTICS',
  FORGOT_PASSWORD = 'HTML_FORGOT_PASSWORD',
  LOGIN = 'HTML_LOGIN',
  MAINTENANCE_MODE = 'MAINTENANCE_MODE',
}

export enum LandingPageSections {
  BENEFITS_1_1 = 'HTML_LANDINGPAGE_BENEFITS_1.1',
  BENEFITS_1_2 = 'HTML_LANDINGPAGE_BENEFITS_1.2',
  BENEFITS_2_1 = 'HTML_LANDINGPAGE_BENEFITS_2.1',
  BENEFITS_2_2 = 'HTML_LANDINGPAGE_BENEFITS_2.2',
  KEYFACTS_1_1 = 'HTML_LANDINGPAGE_KEYFACTS_1.1',
  KEYFACTS_1_2 = 'HTML_LANDINGPAGE_KEYFACTS_1.2',
  KEYFACTS_2_1 = 'HTML_LANDINGPAGE_KEYFACTS_2.1',
  KEYFACTS_2_2 = 'HTML_LANDINGPAGE_KEYFACTS_2.2',
  REGISTRATION = 'HTML_LANDINGPAGE_REGISTRATION',
}

/**
 * Gibt eine HTML-Seite zurück
 *
 * @throws {ErrorCode.NOT_FOUND}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getHtmlContent (
  pageId: PageId | string,
  replaceUrlsInText: boolean = true,
): Promise<{ title: string, html: string }> {
  const data: any = await axiosBackend.get('webservices/htmlcontent.ws', { params: {
    event: 'GET_HTML_CONTENT',
    iv_page_id: pageId,
  }})

  if (data.status === 'ERROR') {
    if (data.code === 'NOT_FOUND') {
      throw new ShopError(ErrorCode.NOT_FOUND, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (replaceUrlsInText) {
    data.result.html = rewriteUrlsInText(data.result.html)
  }

  return data.result
}
