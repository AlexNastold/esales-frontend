import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { IListArticle } from '@scripts/modules/interfaces'
import { axiosBackend } from '@scripts/core/axios'

export interface IGetTopsellersResult {
  paging: {
    pages: number,
    currentPage: number,
    amountPerPage: number,
  },
  topsellers: IListArticle[]
}

export enum TopsellerType {
  SHOP = 1,
  CUSTOMER = 2,
  USER = 3,
}

/**
 * Returns the topsellers
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getTopsellers (type: TopsellerType = TopsellerType.SHOP, {
  sortField,
  sortDirection = 'asc',
  start = 0,
  amount = 10,
}: {
  sortField?: string,
  sortDirection?: string,
  start?: number,
  amount?: number,
} = {}): Promise<IGetTopsellersResult> {

  let event = 'GET_SHOP_TOPSELLERS'
  if (type === TopsellerType.CUSTOMER) {
    event = 'GET_CUSTOMER_TOPSELLERS'
  } else if (type === TopsellerType.USER) {
    event = 'GET_USER_TOPSELLERS'
  }

  const data: any = await axiosBackend.get('webservices/topsellers.ws', { params: {
    event,
    from: start,
    rows: amount,
    sort_dir: sortField ? sortDirection : void 0,
    sort_field: sortField,
  }})

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  const pages = Math.ceil(data.result.amount / data.result.rows)
  const currentPage = Math.floor(data.result.start / data.result.rows)

  const topsellers = data.result.topsellers

  return {
    paging: {
      amountPerPage: data.result.rows,
      currentPage,
      pages,
    },
    topsellers,
  }
}
