import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { IMaterialsInComponentState } from '@scripts/modules/interfaces'
import { axiosBackend } from '@scripts/core/axios'
import { store } from '@scripts/core/setup/vuex'

/**
 * Adds an article to the comparison list
 * @param matnr article number
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.ALREADY_IN_COMPARISON}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 */
export async function addToComparison (matnr: string): Promise<void> {

  const data: any = await axiosBackend.post('webservices/comparison.ws', {
    event: 'ADD_TO_COMPARISON',
    matnr,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'ALREADY_IN_COMPARISON':
        throw new ShopError(ErrorCode.ALREADY_IN_COMPARISON, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  store.dispatch('updateComparison')
}

/**
 * Returns the comparison list
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getComparisonList (): Promise<any> {

  const params = {
    event: 'GET_LIST',
  }

  const data: any = await axiosBackend.get('webservices/comparison.ws', { params })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

/**
 * Returns the number of articles in the comparison list
 * and a list of article numbers of articles in the comparison list
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getMaterialsInComparison (): Promise<IMaterialsInComponentState> {
  const data: any = await axiosBackend.get('webservices/comparison.ws', {params: {event: 'GET_ARTICLES_STATE'}})

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

/**
 * Removes an article from the comparison list
 * @param matnr article number
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 */
export async function removeFromComparison (matnr: string): Promise<void> {

  const data: any = await axiosBackend.post('webservices/comparison.ws', {
    event: 'REMOVE_FROM_COMPARISON',
    it_addto: [{
      matnr,
    }],
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  store.dispatch('updateComparison')
}
