import { ITrackingOrder } from '@scripts/modules/basket'
import { applicationSettings } from '@scripts/app/settings'

import browserStore from '@scripts/core/browserStore'

export async function gtagSaveOrder (tracking: ITrackingOrder) {
  browserStore.set('gtagOrder', tracking)
}

export async function gtagTrackOrder () {
  const tracking = browserStore.get('gtagOrder')
  try {
    if (applicationSettings.gtagEcommerceActive && tracking && typeof gtag === 'function') {
      gtag('event', 'purchase', {
        affiliation: document.title,
        currency: tracking.currency,
        items: tracking.items.map((item) =>
          ({
            brand: item.brand,
            category: item.category,
            id: item.partno,
            list_name: item.pitcher.trim(),
            name: item.texts.trim(),
            price: item.netPrice || item.grossPrice,
            quantity: item.quantity,
          }),
        ),
        tax: tracking.netTax || tracking.grossTax,
        transaction_id: tracking.docId,
        value: tracking.netSum || tracking.grossSum,
      })
      browserStore.remove('gtagOrder')
    }
  } catch (e) {
    console.error(e)
  }
}

export async function gtagTrackViewItem (tracking: any) {
  try {
    if (applicationSettings.gtagEcommerceActive && typeof gtag === 'function') {
      gtag('event', 'view_item', {
        items: [{
          category: tracking.category,
          id: tracking.partno,
          name: tracking.texts,
          quantity: tracking.quantity,
        }],
      })
    }
  } catch (e) {
    console.error(e)
  }
}

export async function gtagTrackPromotionImpression (tracking: any) {
  try {
    if (applicationSettings.gtagEcommerceActive && typeof gtag === 'function') {
      gtag('event', 'view_promotion', {
        promotions: [{
          id: tracking.id,
          name: tracking.name,
        }],
      })
    }
  } catch (e) {
    console.error(e)
  }
}
