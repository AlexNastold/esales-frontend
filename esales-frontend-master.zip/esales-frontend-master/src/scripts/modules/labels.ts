import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { IListArticle, IMaterialsInComponentState } from '@scripts/modules/interfaces'
import { numberToSapNumber, sapNumberToNumber } from '@scripts/helper/sapFormat'
import { axiosBackend } from '@scripts/core/axios'
import { store } from '@scripts/core/setup/vuex'

export interface ILabel {
  article: IListArticle,
  posnr: string,
  posnrDisplay: string,
  quantity: number,
  labelQuantity: number,
}

export interface ILabelArticleAdd {
  matnr: string,
  quantity?: number,
  labelQuantity?: number,
}

export interface ILabelUpdate {
  posnr: string,
  quantity: number,
  labelQuantity: number,
}

/**
 * Fügt ein Etikett hinzu
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export function addLabel (matnr: string, quantity: number = 1, labelQuantity: number = 1): Promise<void> {
  return addLabels([{
    labelQuantity,
    matnr,
    quantity,
  }])
}

/**
 * Fügt mehrere Etiketten hinzu
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function addLabels (articles: ILabelArticleAdd[]): Promise<void> {
  const data: any = await axiosBackend.post('webservices/labels.ws', {
    event: 'ADD_LABELS',
    it_addto: articles.map((article) => {
      const quantity = article.quantity
        ? numberToSapNumber(sapNumberToNumber(article.quantity as any, article.quantity))
        : 1
      const labelQuantity = article.labelQuantity
        ? numberToSapNumber(sapNumberToNumber(article.labelQuantity as any, article.labelQuantity))
        : 1
      return {
        matnr: article.matnr,
        menge: quantity,
        menge2: labelQuantity,
      }
    }),
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  store.dispatch('updateLabels')
}

/**
 * Löscht ein Etikett
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.NOT_FOUND}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function deleteLabel (posnr: string): Promise<void> {
  const data: any = await axiosBackend.post('webservices/labels.ws', {
    event: 'DELETE_LABEL',
    posnr,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  store.dispatch('updateLabels')
}

/**
 * Löscht alle Etiketten
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function deleteAllLabels (): Promise<void> {
  const data: any = await axiosBackend.post('webservices/labels.ws', {
    event: 'DELETE_ALL',
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  store.dispatch('updateLabels')
}

/**
 * Aktualisiert die Mengen der Etiketten
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function updateLabels (labels: ILabelUpdate[]): Promise<void> {
  const data: any = await axiosBackend.post('webservices/labels.ws', {
    event: 'UPDATE_LABELS',
    it_addto: labels.map((label) => {
      const quantity = numberToSapNumber(sapNumberToNumber(label.quantity as any, label.quantity))
      const labelQuantity = numberToSapNumber(sapNumberToNumber(label.labelQuantity as any, label.labelQuantity))
      return {
        doc_itm_number: label.posnr,
        menge: quantity,
        menge2: labelQuantity,
      }
    }),
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Gibt die Etiketten zurück
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getLabels (): Promise<ILabel[]> {
  const data: any = await axiosBackend.get('webservices/labels.ws', { params: {
    event: 'GET_LABELS',
  }})

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

/**
 * Gibt die Anzahl der Etiketten sowie die Artikelnummern der Artikel in Etiketten zurück
 *
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getMaterialsInLabels (): Promise<IMaterialsInComponentState> {
  const data: any = await axiosBackend.get('webservices/labels.ws', {params: {event: 'GET_ARTICLES_STATE'}})

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}
