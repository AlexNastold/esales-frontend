import { ErrorCode, ShopError } from '@scripts/modules/errors'
import I18n from '@scripts/modules/i18n'
import { IAdditionalMaterialCategory } from '@scripts/modules/interfaces'
import { axiosBackend } from '@scripts/core/axios'
import { dateToSapDate } from '@scripts/helper/sapFormat'
import { redirect } from '@scripts/helper/redirect'
import { serverPath } from '@scripts/core/paths'

export enum DocumentType {
  AUFTRAG = 1,
  RECHNUNG = 2,
  OFFENE_POSTEN = 3,
  GUTSCHRIFT = 4,
  ANGEBOT = 5,
  HAUPTABRUF = 6,
  ANFRAGE = 7,
  BUDGETAUFTRAG = 9,
  BELEG_UNTER_VORBEHALT = 10,
  RETURN = 12,
}

export enum DocumentStatus {
  OPEN = 'A',
  PARTLY_COMPLETED = 'B',
  COMPLETED = 'C',
  CANCELED = 'X',
}

export enum DocumentTimespan {
  LAST_WEEK = 2, // Letzte 7 Tage
  LAST_30_DAYS = 3, // Letzte 30 Tage
  LAST_QUARTER = 4, // Letzte 91 Tage
  LAST_HALF_YEAR = 5, // Letzte 183 Tage
  LAST_YEAR = 6, // Letzte 365 Tage
  CUSTOM = 7,
  UNLIMITED = 8,
}

export enum DocumentCustomFilterType {
  DOCUMENT_NUMBER = 2,
  ORDER_NUMBER = 3,
  ARTICLE_NUMBER = 4,
  PROJECT_NAME = 5,
  DELIVERY_RECEIPT_NUMBER = 6,
}

export enum DocumentListSortField {
  CREATE_DATE = 'datum',
  DOCUMENT_NUMBER = 'belegnummer',
  ORDER_NUMBER = 'bestellnummer',  // 1,5,6,7
  STATUS = 'status', // 1,5,6,7
  PROJECT_NAME = 'prbez', // 1,5,6,7
  CREATED_BY = 'name', // 1,5,6,7
  VALID_FROM = 'gueltig_von',  // 1,5,6,7
  VALID_TO = 'gueltig_bis',  // 1,5,6,7
  DUE_DATE = 'fall', // 2,3,4
  BRUTTO_SUM = 'brutto', // 2,3,4
  COMMISSION = 'kommission', // 2,4
}

export enum DocumentListSortDirection {
  ASC = 'asc',
  DESC = 'desc',
}

export interface IDocumentListItem {
  createDate: Date,
  documentId: string,
  documentIdDisplay: string,
  documentType: DocumentType,
  documentTypeText: string,
}

export interface IDocumentListItemAuftrag extends IDocumentListItem {
  status?: DocumentStatus,
  statusText?: string,
  orderNumber: string,
  projectName: string,
  createdBy: string,
}

export interface IDocumentListItemRechunung extends IDocumentListItem {
  dueDate: Date,
  orderNumber: string,
  retailPrice: number,
  currency: string,
}

export interface IDocumentListItemOffenePosten extends IDocumentListItem {
  documentType: DocumentType,
  documentId: string,
  dueDate: Date,
  retailPrice: number,
  currency: string,
}

export interface IDocumentListItemGutschrift extends IDocumentListItem {
  billDate: Date,
  orderNumber: string,
  retailPrice: number,
  currency: string,
}

export interface IDocumentListItemAngebot extends IDocumentListItem {
  orderNumber: string,
  projectName: string,
  createdBy: string,
  validFrom: Date,
  validTo: Date,
}

export interface IDocumentListItemHauptabruf extends IDocumentListItem {
  status?: DocumentStatus,
  statusText?: string,
  orderNumber: string,
  projectName: string,
  createdBy: string,
}

export interface IDocumentListItemAnfrage extends IDocumentListItem {
  status?: DocumentStatus,
  statusText?: string,
  orderNumber: string,
  projectName: string,
  createdBy: string,
}

export interface IDocumentListItemBudgetauftrag extends IDocumentListItem {
  orderNumber: string,
  projectName: string,
  createdBy: string,
  netPrice: number,
  currency: string,
}

export interface IDocumentListItemBelegUnterVorbehalt extends IDocumentListItem {
  orderNumber: string,
  projectName: string,
  createdBy: string,
  netPrice: number,
  currency: string,
}

export interface IDocument {
  documentId: string,
  documentIdDisplay: string,
  documentType: number,
  documentTypeText: string,
  documentName: string,
  documentHead: {
    // 1,2,4,5,6,7,8,10
    orderType: string,

    // 1,5,6,7,8,10
    orderNumber: string,
    deliveryType: string,
    branch: string,
    address: {
      name1: string,
      name2: string,
      street: string,
      houseNumber: string,
      postalCode: string,
      city: string,
      country: string,
    },
    status: string,
    statusText: string,
    createDate: Date,
    desiredDeliveryDate?: Date,
    validTo?: Date,
    createdBy: string,
    projectName: string,
  },
  documentFlow?: {
    level: number,
    id: string,
    documentId: string,
    documentIdDisplay: string,
    documentType: string,
    documentTypeText: string,
    status: string,
    statusText: string,
    date: Date,
    title: string,
    orderType: string,
    isAccessible: boolean,
    isCurrentDocument: boolean,
    isBeforeCurrentDocument: boolean,
  }[],
  documentTexts?: {
    title: string,
    text: string,
  }[],
  documentPositions: {
    posnr: string,
    posnrDisplay: string,
    matnr: string,
    matnrDisplay: string,
    bismt: string,
    description: string,
    image?: string,
    amount: number,
    amountRequested: number,
    amountMax?: number, // 2,3,4,6,10
    unit: string,
    unitFormatted: string,
    status: string,
    statusText: string,
    netPrice?: number,
    currency: string,
    partList: {
      isPartListArticle: boolean,
      isHead: boolean,
      headPosnr?: string,
      headPosnrDisplay?: string,
    },
    additionalMaterialCategories: IAdditionalMaterialCategory[],
    texts: string[],
    flags: {
      isValid: boolean,
      isAvailable: boolean,
      isAmountChangeable: boolean,
    },
    additionalData: {
      deliveryNumber?: string, // 1
      deliveryAmount?: number, // 1
      deliveryDate?: Date, // 1
      orders?: { // 6
        orderNumber: string,
        orderNumberDisplay: string,
        orderAmount: number,
        orderDate: Date,
        documentType: number,
      }[]
      commission?: string, // 1
      scheduledDeliveryDate?: Date, // 1
      salesDocumentId?: string, // 2,3
      salesDocumentIdDisplay?: string, // 2,3
      salesDocumentPosnr?: string, // 2,3
      salesDocumentPosnrDisplay?: string, // 2,3
      alternativePosnr?: string, // 5
      alternativePosnrDisplay?: string, // 5
    },
  }[],
  documentSums: {
    retailPrice: {
      sum: number,
      taxes: number,
      taxRate: number,
      sumInclTaxes: number,
      currency: string,
    },
    netPrice?: {
      sum: number,
      taxes: number,
      sumInclTaxes: number,
      currency: string,
    },
  },
  tracking?: {
    deliveryService: string,
    trackingNumber: string,
    deliveryNumber: string,
    url: string,
  }[],
  remarks: {
    type: 'E' | 'N',
    text: string,
  }[],
  flags: {
    displayHead: boolean,
    displayFlow: boolean,
    displayTexts: boolean,
    hasArchivedDocument: boolean,
    offerToZhaPossible: boolean,
  }
}

/**
 * Returns a list of documents
 *
 * @param documentType - The document type
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getDocumentList<T> (
  documentType: DocumentType,
  {
    documentStatus,
    timespan = DocumentTimespan.LAST_30_DAYS,
    dateFrom,
    dateTo,
    customFilterType,
    customFilterQuery,
    sortField = DocumentListSortField.CREATE_DATE,
    sortDirection = DocumentListSortDirection.DESC,
  }: {
    documentStatus?: DocumentStatus,
    timespan?: DocumentTimespan,
    dateFrom?: Date,
    dateTo?: Date,
    customFilterType?: DocumentCustomFilterType,
    customFilterQuery?: string,
    sortField?: DocumentListSortField,
    sortDirection?: DocumentListSortDirection,
  } = {},
): Promise<{
  hasSum: boolean,
  sum?: number,
  sumCurrency?: string,
  documents: T[],
}> {

  const params = {
    custom_filter_query: customFilterQuery,
    custom_filter_type: customFilterType,
    date_from: dateFrom instanceof Date ? dateToSapDate(dateFrom) : void 0,
    date_to: dateTo instanceof Date ? dateToSapDate(dateTo) : void 0,
    docstatus: documentStatus,
    doctype: documentType,
    event: 'GET_LIST',
    sort_direction: sortDirection,
    sort_field: sortField,
    timespan,
  }

  const data: any = await axiosBackend.get('webservices/docs.ws', { params })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  // Datum konvertieren
  data.result.documents = data.result.documents.map((document) => {
    if (document.createDate) {
      document.createDate = new Date(document.createDate)
    }
    if (document.dueDate) {
      document.dueDate = new Date(document.dueDate)
    }
    if (document.billDate) {
      document.billDate = new Date(document.billDate)
    }
    if (document.validFrom) {
      document.validFrom = new Date(document.validFrom)
    }
    if (document.validTo) {
      document.validTo = new Date(document.validTo)
    }
    return document
  })

  return data.result
}

/**
 * Returns a document
 *
 * @param documentType - Type of the document
 * @param documentd - ID of the document
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.NOT_FOUND}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws Request error
 */
export async function getDocumentDetail (documentType: DocumentType, documentId: string): Promise<IDocument> {
  const data: any = await axiosBackend.get('webservices/docs.ws', { params: {
    docid: documentId,
    doctype: documentType,
    event: 'GET_DETAIL',
  }})

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'NOT_FOUND':
        throw new ShopError(ErrorCode.NOT_FOUND, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  const doc = data.result

  // Convert date
  if (doc.documentHead.createDate) {
    doc.documentHead.createDate = new Date(doc.documentHead.createDate)
  }
  if (doc.documentHead.desiredDeliveryDate) {
    doc.documentHead.desiredDeliveryDate = new Date(doc.documentHead.desiredDeliveryDate)
  }
  if (doc.documentHead.validTo) {
    doc.documentHead.validTo = new Date(doc.documentHead.validTo)
  }
  if (doc.documentFlow && doc.documentFlow.date) {
    doc.documentFlow.date = new Date(doc.documentFlow.date)
  }
  doc.documentPositions = doc.documentPositions.map((position) => {
    if (position.additionalData.deliveryDate) {
      position.additionalData.deliveryDate = new Date(position.additionalData.deliveryDate)
    }
    if (position.additionalData.demandDate) {
      position.additionalData.demandDate = new Date(position.additionalData.demandDate)
    }
    if (position.additionalData.deliveries) {
      position.additionalData.deliveries = position.additionalData.deliveries.map((delivery) => {
        if (delivery.deliveryDate) {
          delivery.deliveryDate = new Date(delivery.deliveryDate)
        }
        return delivery
      })
    }
    return position
  })

  return doc
}

/**
 * Downloads the archived document
 *
 * @param orderType - Order type
 * @param documentId - ID of the document
 */
export function downloadArchivedDocument (orderType: string, documentId: string): void {
  redirect(getArchivedDocumentUri(orderType, documentId))
}

/**
 * Returns the download url to download the archived document
 *
 * @param orderType - Order type
 * @param documentId - ID of the document
 */
export function getArchivedDocumentUri (orderType: string, documentId: string): string {
  return  `${serverPath}webservices/docs.ws?event=GET_ARCHIVED_DOCUMENT` +
    `?auart=${encodeURIComponent(orderType)}` +
    `&docid=${encodeURIComponent(documentId)}`
}

/**
 * Release a budget order
 *
 * @param documentId - ID of the order to release
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function releaseOrder (documentId: string): Promise<void> {
  const data: any = await axiosBackend.post('webservices/docs.ws', {
    docid: documentId,
    event: 'BUDGET_RELEASE_ORDER',
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Reject a budget order
 *
 * @param documentId - ID of the order to reject
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No Authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function rejectOrder (documentId: string): Promise<void> {
  const data: any = await axiosBackend.post('webservices/docs.ws', {
    docid: documentId,
    event: 'BUDGET_REJECT_ORDER',
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export function getDocumentTypeTitle (documentType: DocumentType, plural: boolean = false) {
  let alias = ''
  switch (documentType) {
    case DocumentType.ANFRAGE: alias = 'inquiry'; break
    case DocumentType.ANGEBOT: alias = 'offer'; break
    case DocumentType.AUFTRAG: alias = 'order'; break
    case DocumentType.BELEG_UNTER_VORBEHALT: alias = 'underReserve'; break
    case DocumentType.BUDGETAUFTRAG: alias = 'budgetOrder'; break
    case DocumentType.GUTSCHRIFT: alias = 'credit'; break
    case DocumentType.HAUPTABRUF: alias = 'hauptabruf'; break
    case DocumentType.OFFENE_POSTEN: alias = 'vacant'; break
    case DocumentType.RECHNUNG: alias = 'bill'; break
    case DocumentType.RETURN: alias = 'return'; break
    default: alias = 'other'; break
  }
  return I18n.t(`myAccountDocuments.doctype.${alias}${plural ? '_plural' : ''}`)
}

export function getDocumentStatusTitle (documentStatus: DocumentStatus) {
  switch (documentStatus) {
    case DocumentStatus.OPEN:
      return I18n.t('myAccountDocuments.status.open')
    case DocumentStatus.PARTLY_COMPLETED:
      return I18n.t('myAccountDocuments.status.partlyCompleted')
    case DocumentStatus.COMPLETED:
      return I18n.t('myAccountDocuments.status.completed')
    case DocumentStatus.CANCELED:
      return I18n.t('myAccountDocuments.status.canceled')
    default:
      return I18n.t('myAccountDocuments.status.unknown')
  }
}

export function getDocumentStatusFilterTitle (documentStatus: DocumentStatus) {
  switch (documentStatus) {
    case DocumentStatus.OPEN:
      return I18n.t('myAccountDocuments.status.openAndPartlyCompleted')
    default:
      return getDocumentStatusTitle(documentStatus)
  }
}

export function getDocumentTimespanTitle (documentTimespan: DocumentTimespan) {
  switch (documentTimespan) {
    case DocumentTimespan.LAST_30_DAYS:
      return I18n.t('myAccountDocuments.timespan.last30Days')
    case DocumentTimespan.LAST_QUARTER:
      return I18n.t('myAccountDocuments.timespan.lastQuarter')
    case DocumentTimespan.LAST_HALF_YEAR:
      return I18n.t('myAccountDocuments.timespan.lastHalfYear')
    case DocumentTimespan.LAST_WEEK:
      return I18n.t('myAccountDocuments.timespan.lastWeek')
    case DocumentTimespan.LAST_YEAR:
      return I18n.t('myAccountDocuments.timespan.lastYear')
    case DocumentTimespan.UNLIMITED:
      return I18n.t('myAccountDocuments.timespan.unlimited')
    case DocumentTimespan.CUSTOM:
      return I18n.t('myAccountDocuments.timespan.custom')
  }
}

export function getDocumentReferenceLink (documentType: DocumentType, documentId: string) {
  if (!documentType || !documentId) {
    return void 0
  }

  return 'my-account-documents-detail' +
    `?doctype=${encodeURIComponent(documentType.toString())}` +
    `&docid=${encodeURIComponent(documentId)}`
}
