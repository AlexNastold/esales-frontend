import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'
import { numberToSapNumber } from '@scripts/helper/sapFormat'

/**
 * Gibt die Downloads zurück
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getDownloads (): Promise<{ url: string, name: string, ext: string }[]> {
  const data: any = await axiosBackend.get('webservices/service.ws', { params: {
    event: 'GET_DOWNLOADS',
  }})

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

export enum MailToClerkFieldErrors {
  EMAIL = 'email',
  SUBJECT= 'subject',
  MESSAGE = 'message',
}

/**
 * Sendet eine E-Mail an den Sachbearbeiter
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function sendMailToClerk (
  email: string, phone: string, subject: string, message: string, sendCopy: boolean = false): Promise<void> {
  const data: any = await axiosBackend.post('webservices/service.ws', {
    event: 'CONTACT',
    gv_email: email,
    gv_mailcopy: sendCopy ? 'X' : void 0,
    gv_mailsubject: subject,
    gv_mailtext: message,
    gv_phone: phone,
  })

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status === 'WARNING') {
    if (data.use_validator === 'X') {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export enum NotListedProductsFieldErrors {
  ORDERNUMBER= 'ordernumber',
  MESSAGE = 'message',
}

/**
 * Sendet eine E-Mail an den Sachbearbeiter um nicht gelistete Produkte zu bestellen
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.NO_DATA}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function sendMailUnlistedArticles (
  orderNumber: string,
  message: string,
  products: { matnr: string, supplier: string, supplierName: string, amount: number }[] = [],
  file?: File,
) {
  const formData = new FormData()
  if (file) {
    formData.append('fileUpload', file, file.name)
  }
  formData.append('event', 'SEND_FORM_UNLISTED_ARTICLES')
  formData.append('iv_message', message)
  formData.append('iv_order_number', orderNumber)

  products.forEach((product, index) => {
    formData.append(`it_new[${index + 1}]-matnr`, product.matnr)
    formData.append(`it_new[${index + 1}]-herst`, product.supplier)
    formData.append(`it_new[${index + 1}]-herst_bez`, product.supplierName)
    formData.append(`it_new[${index + 1}]-menge`, numberToSapNumber(product.amount))
  })

  const data: any = await axiosBackend.post('webservices/service.ws', formData)

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    if (data.code === 'NO_DATA') {
      throw new ShopError(ErrorCode.NO_DATA, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status === 'WARNING') {
    if (data.use_validator === 'X') {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}
