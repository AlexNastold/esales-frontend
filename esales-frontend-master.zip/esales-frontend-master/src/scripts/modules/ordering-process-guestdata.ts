import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'

interface IGuestOrderData {
  contact: {
    email: string,
    phone: string,
  },
  companyAddress: {
    customerId: string,
    title: string,
    firstname: string,
    lastname: string,
    street: string,
    zipcode: string,
    city: string,
    country: string,
  },
  deliveryAddress: {
    title: string,
    firstname: string,
    lastname: string,
    street: string,
    zipcode: string,
    city: string,
    country: string,
  },
  deviantDeliveryAddress: boolean,
  privacyStatement: boolean,
}

export enum OrderDataErrorFields {
  // Kontakt
  CONTACT_EMAIL_ADDRESS = 'contact-email',
  CONTACT_PHONE = 'contact-phone',

  // Firmenanschrift
  COMPANY_ADDRESS_LASTNAME = 'company-address-lastname',
  COMPANY_ADDRESS_STREET = 'company-address-street',
  COMPANY_ADDRESS_ZIPCODE = 'company-address-zipcode',
  COMPANY_ADDRESS_CITY = 'company-address-city',
  COMPANY_ADDRESS_COUNTRY = 'company-address-country',

  // Lieferanschrifft
  DELIVERY_ADDRESS_LASTNAME = 'delivery-address-lastname',
  DELIVERY_ADDRESS_STREET = 'delivery-address-street',
  DELIVERY_ADDRESS_ZIPCODE = 'delivery-address-zipcode',
  DELIVERY_ADDRESS_CITY = 'delivery-address-city',
  DELIVERY_ADDRESS_COUNTRY = 'delivery-address-country',

  // Datenschutzerklärung
  PRIVACY_STATEMENT = 'privacy-statement'
}

export async function getOrderData (): Promise<IGuestOrderData> {
  const data: any = await axiosBackend.get('webservices/basket.ws', { params: { event: 'GET_GUEST_ORDER_DATA' } })

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
  return data.result
}

export async function saveOrderData (orderData: IGuestOrderData): Promise<void> {
  const data: any = await axiosBackend.post('webservices/basket.ws', {
    event: 'SAVE_GUEST_ORDER_DATA',
    gs_guest_order: {
      company_address: orderData.companyAddress,
      contact: orderData.contact,
      delivery_address: orderData.deliveryAddress,
      deviant_delivery_address: orderData.deviantDeliveryAddress ? 'X' : '',
      privacy_statement: orderData.privacyStatement ? 'X' : '',
    },
  })
  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status === 'WARNING') {
    if (data.use_validator === 'X' && !data.use_multiple_errors) {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export async function checkOrderData (): Promise<void> {
  const data: any = await axiosBackend.get('webservices/basket.ws', { params: { event: 'CHECK_GUEST_ORDER_DATA' } })

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status === 'WARNING') {
    if (data.code === 'INVALID_OR_MISSING_PARAMS') {
      throw new ShopError(ErrorCode.INVALID_OR_MISSING_PARAMS, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }
}
