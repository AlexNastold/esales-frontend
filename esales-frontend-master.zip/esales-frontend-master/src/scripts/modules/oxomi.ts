import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { IArticleDetails, getArticleDetails } from '@scripts/modules/article-details'
import { numberToSapCurrency, numberToSapNumber, sapNumberToNumber } from '@scripts/helper/sapFormat'
import { AvailabilityFlag } from '@scripts/modules/additional-article-data'
import I18n from '@scripts/modules/i18n'
import { addPositionToBasket } from '@scripts/modules/basket'
import { axiosBackend } from '@scripts/core/axios'
import { detailLink } from '@scripts/helper/generateLink'
import { getArticleImageUrl } from '@scripts/modules/images'
import { getCurrencySign } from '@scripts/helper/currencySign'
import merge from 'deepmerge'

// Documentation of differend possibilities to customize the styling of rendered Oxomi content:
// https://oxomi.com/help/de/integration/javascript-fortgeschrittene-themen/darstellung-anpassen
const defaultCSSClassMapping = {
  '.oxomi-h1': 'fis-oxomi-h1 h4 headline-text text-uppercase border-bottom pb-2 mb-3',
  '.oxomi-h2': 'fis-oxomi-h2 h5 headline-text text-uppercase mb-1 mt-4',
  '.oxomi-masterdata-field': 'pt-1',
  '.oxomi-masterdata-value': 'float-right',
  '.oxomi-shopping-cart-icon': 'd-none',
  '.oxomi-short-text': 'd-none',
}

export interface IOxomiConfiguration {
  active: boolean,
  server?: string,
  user?: string,
  token?: string,
  portal?: string,
  roles?: string,
  lang?: string,
  langsCatalogue?: string,
  langsDetail?: string,
  options?: {
    portal: boolean,
    detail: boolean,
    masterdata: boolean,
    texts: boolean,
    documents: boolean,
    images: boolean,
    videos: boolean,
    catalogues: boolean,
  },
  classMap?: object,
  catalogueCompletionHandler?: (context) => void,
  render?: OxomiType[],
}

interface IOptions {
  render?: boolean,
}

interface IItemNumber {
  matnr: string,
  supplierItemNumber?: string,
  supplierNumber?: string,
}

const defaultOptions: IOptions = {
  render: false,
}

export enum OxomiType {
  TEXTS = 'texts',
  IMAGES = 'images',
  MASTERDATA = 'masterdata',
  DOCUMENTS = 'documents',
  VIDEOS = 'videos',
  CATALOGUE_PAGES = 'cataloguePages',
  BRAND_CATALOGUES = 'brandCatalogues',
}

export interface IOxomiResponse {
  type: OxomiType,
  items: object[],
  rendered?: string,
}

const oxomiRequestTimeout = 5000

let config = void 0
let oxomi = void 0
let oxomiLoading = void 0
let oxomiReady = false

export function setOxomiConfiguration (conf: IOxomiConfiguration): void {
  config = conf

  if (!config.server || !config.portal || !config.user || !config.token) {
    throw new Error('Oxomi configuration is incomplete')
  }

  if (!config.classMap) {
    config.classMap = defaultCSSClassMapping
  }

  if (!config.render) {
    config.render = []
  }
}

export async function addOxomiDataToArticle (article: IArticleDetails) {

  const partNumber = article.matnrDisplay
  let supplierPartNumber = void 0
  let supplierId = void 0

  if (Array.isArray(article.factoryNumbers) && article.factoryNumbers.length) {
    supplierPartNumber = article.factoryNumbers[0].supplierMatnr
    supplierId = article.factoryNumbers[0].supplierNumber
  }

  const renderTexts = config.render.indexOf(OxomiType.TEXTS) >= 0
  const renderMasterdata = config.render.indexOf(OxomiType.MASTERDATA) >= 0
  const renderVideos = config.render.indexOf(OxomiType.VIDEOS) >= 0
  const renderCataloguePages = config.render.indexOf(OxomiType.CATALOGUE_PAGES) >= 0

  // Send all Requests in parallel
  const promises = []

  // Fetch Oxomi texts
  if (config.options.texts) {
    promises.push(getItemTexts(partNumber, void 0, {render: renderTexts}))
    if (supplierPartNumber && supplierId) {
      promises.push(getItemTexts(supplierPartNumber, supplierId, {render: renderTexts}))
    }
  }

  // Fetch Oxomi images
  if (config.options.images) {
    promises.push(getItemImages(partNumber, void 0))
    if (supplierPartNumber && supplierId) {
      promises.push(getItemImages(supplierPartNumber, supplierId))
    }
  }

  // Fetch Oxomi masterdata
  if (config.options.masterdata) {
    promises.push(getItemMasterdata(partNumber, void 0, {render: renderMasterdata}))
    if (supplierPartNumber && supplierId) {
      promises.push(getItemMasterdata(supplierPartNumber, supplierId, {render: renderMasterdata}))
    }
  }

  // Fetch Oxomi documents and files
  if (config.options.documents) {
    promises.push(getItemDocuments(partNumber, void 0))
    if (supplierPartNumber && supplierId) {
      promises.push(getItemDocuments(supplierPartNumber, supplierId))
    }
  }

  // Fetch Oxomi videos
  if (config.options.videos) {
    promises.push(getItemVideos(partNumber, void 0, true, {render: renderVideos}))
    if (supplierPartNumber && supplierId) {
      promises.push(getItemVideos(supplierPartNumber, supplierId, void 0, {render: renderVideos}))
    }
  }

  // Oxomi-Katalogseiten holen
  if (config.options.catalogues) {
    if (supplierPartNumber && supplierId) {
      promises.push(getItemCataloguePages(
        partNumber, supplierPartNumber, supplierId, void 0, {render: renderCataloguePages}),
      )
    } else {
      promises.push(getItemCataloguePages(partNumber, void 0, void 0, true, {render: renderCataloguePages}))
    }
  }

  try {

    // Wait until all requests have finished and add results to article object
    const results = await Promise.all(promises)
    article.oxomi = article.oxomi || {}
    results

      // Skip failed requests and empty results
      .filter((result) => {
        if (!result || !Array.isArray(result.items)) {
          console.error(`Oxomi request failed: ${result}`)
          return false
        }
        return result.items.length
      })

      .forEach((result: IOxomiResponse) => {
        switch (result.type) {
          case OxomiType.TEXTS:
            article.oxomi.texts = merge(article.oxomi.texts || {}, result)
            result.items.forEach((text: any, index) => {
              if (index === 0) {
                article.description = ''
              } else {
                article.description += '<br>'
              }
              article.description += text.text
            })
            break

          case OxomiType.IMAGES:
            article.oxomi.images = merge(article.oxomi.images || {}, result)
            result.items.forEach((image: any) => {
              article.images.push(image.large)
            })
            break

          case OxomiType.MASTERDATA:
            article.oxomi.masterdata = merge(article.oxomi.masterdata || {}, result)
            break

          case OxomiType.DOCUMENTS:
            article.oxomi.documents = merge(article.oxomi.documents || {}, result)
            result.items.forEach((document: any) => {
              article.documents.push({
                filename: document.filename,
                label: document.description,
                type: 'DOC',
                url: document.url,
              })
            })
            break

          case OxomiType.VIDEOS:
            article.oxomi.videos = merge(article.oxomi.videos || {}, result)
            break

          case OxomiType.CATALOGUE_PAGES:
            article.oxomi.cataloguePages = merge(article.oxomi.cataloguePages || {}, result)
            break

          default:
            throw new Error(`Type "${result.type}" is not yet implemented`)
        }
      })
  } catch (err) {
    throw new Error(err)
  }
}

export async function getItemTexts (
  itemNo: string, supplierNo?: string, _options: IOptions = defaultOptions): Promise<IOxomiResponse> {

  await ensureOxomiReady()

  const element = _options.render ? createTargetElement() : void 0
  let rendered = void 0

  return promiseTimeout(
    new Promise((resolve: (value: IOxomiResponse) => void, reject) => {
      try {

        // See http://oxomi.com/help/de/integration/javascript-artikelbezogene-daten#einbinden-artikel-langtext
        oxomi.itemText({
          alwaysShowTarget: false,
          completionHandler: (context) => {
            if (_options.render) {
              mapCSSClasses(config.classMap, element, true)
              rendered = element.innerHTML
              removeTargetElement(element)
            }
            resolve({
              items: context.json.texts,
              rendered,
              type: OxomiType.TEXTS,
            })
          },
          emptyResultHandler: (context) => {
            if (context.json.error) {
              reject(context.json.message)
            } else {
              resolve({
                items: [],
                type: OxomiType.TEXTS,
              })
            }
          },
          lang: config.langsDetail,
          supplierItemNumber: itemNo,
          supplierNumber: supplierNo,
          target: element,
          type: 'description',
        })
      } catch (err) {
        reject(err)
      }
    }),
  )
}

export async function getItemImages (
  itemNo: string, supplierNo?: string): Promise<IOxomiResponse> {

  await ensureOxomiReady()

  return promiseTimeout(
    new Promise((resolve: (value: IOxomiResponse) => void, reject) => {
      try {

        // See http://oxomi.com/help/de/integration/javascript-artikelbezogene-daten#einbinden-artikel-bilder
        oxomi.itemImages({
          interceptor: (data) => {
            if (data.error) {
              reject(data.message)
            } else {
              let images = []
              if (data.mainImage) {
                images.push(data.mainImage)
              }
              if (data.additionalImages && data.additionalImages.length) {
                images = images.concat(data.additionalImages)
              }
              resolve({
                items: images,
                type: OxomiType.IMAGES,
              })
            }
          },
          lang: config.langsDetail,
          supplierItemNumber: itemNo,
          supplierNumber: supplierNo,
        })
      } catch (err) {
        reject(err)
      }
    }),
  )
}

export async function getItemMasterdata (
  itemNo: string, supplierNo?: string, _options: IOptions = defaultOptions): Promise<IOxomiResponse> {

  await ensureOxomiReady()

  const element = _options.render ? createTargetElement() : void 0
  let rendered = void 0

  return promiseTimeout(
    new Promise((resolve: (value: IOxomiResponse) => void, reject) => {
      try {

        // See ?
        oxomi.itemMasterdata({
          alwaysShowTarget: false,
          completionHandler: (context) => {
            if (_options.render) {
              mapCSSClasses(config.classMap, element, true)
              rendered = element.innerHTML
              removeTargetElement(element)
            }
            resolve({
              items: context.json.items,
              rendered,
              type: OxomiType.MASTERDATA,
            })
          },
          emptyResultHandler: (context) => {
            if (context.json.error) {
              reject(context.json.message)
            } else {
              resolve({
                items: [],
                type: OxomiType.MASTERDATA,
              })
            }
          },
          lang: config.langsDetail,
          supplierItemNumber: itemNo,
          supplierNumber: supplierNo,
          target: element,
        })
      } catch (err) {
        reject(err)
      }
    }),
  )
}

export async function getItemDocuments (
  itemNo: string, supplierNo?: string): Promise<IOxomiResponse> {

  await ensureOxomiReady()

  return promiseTimeout(
    new Promise((resolve: (value: IOxomiResponse) => void, reject) => {
      try {

        // See http://oxomi.com/help/de/integration/javascript-artikelbezogene-daten#einbinden-artikel-dateien
        oxomi.itemAttachments({
          completionHandler: (context) => {
            resolve({
              items: context.json.attachments,
              type: OxomiType.DOCUMENTS,
            })
          },
          emptyResultHandler: (context) => {
            if (context.json.error) {
              reject(context.json.message)
            } else {
              resolve({
                items: [],
                type: OxomiType.DOCUMENTS,
              })
            }
          },
          lang: config.langsDetail,
          supplierItemNumber: itemNo,
          supplierNumber: supplierNo,
        })
      } catch (err) {
        reject(err)
      }
    }),
  )
}

export async function getItemVideos (
  itemNo: string, supplierNo?: string, own: boolean = void 0, _options: IOptions = defaultOptions)
  : Promise<IOxomiResponse> {

  await ensureOxomiReady()

  const element = _options.render ? createTargetElement() : void 0
  let rendered = void 0

  return promiseTimeout(
    new Promise((resolve: (value: IOxomiResponse) => void, reject) => {
      try {

        // See http://oxomi.com/help/de/integration/javascript-videos#videos-artikel-anzeigen
        oxomi.itemVideos({
          alwaysShowTarget: false,
          completionHandler: (context) => {
            if (_options.render) {
              mapCSSClasses(config.classMap, element, true)
              rendered = element.innerHTML
              removeTargetElement(element)
            }
            resolve({
              items: context.json.videos,
              rendered,
              type: OxomiType.VIDEOS,
            })
          },
          emptyResultHandler: (context) => {
            if (context.json.error) {
              reject(context.json.message)
            } else {
              resolve({
                items: [],
                type: OxomiType.VIDEOS,
              })
            }
          },
          lang: config.langsDetail,
          mode: 'in-place',
          own,
          showDetails: true,
          size: 'medium',
          supplierItemNumber: itemNo,
          supplierNumber: supplierNo,
          target: element,
        })
      } catch (err) {
        reject(err)
      }
    }),
  )
}

export async function getItemCataloguePages (
  itemNo: string,
  supplierItemNo?: string,
  supplierNo?: string,
  own: boolean = void 0,
  _options: IOptions = defaultOptions,
): Promise<IOxomiResponse> {

  await ensureOxomiReady()

  const element = _options.render ? createTargetElement() : void 0
  let rendered = void 0

  return promiseTimeout(
    new Promise((resolve: (value: IOxomiResponse) => void, reject) => {
      try {

        // See http://oxomi.com/help/de/integration/javascript-dokumente#dokument-seiten-artikel
        oxomi.itemPages({
          alwaysShowTarget: false,
          completionHandler: (context) => {
            if (_options.render) {
              mapCSSClasses(config.classMap, element, true)
              rendered = element.innerHTML
              removeTargetElement(element)
            }
            resolve({
              items: context.json.pages,
              rendered,
              type: OxomiType.CATALOGUE_PAGES,
            })
          },
          emptyResultHandler: (context) => {
            if (context.json.error) {
              reject(context.json.message)
            } else {
              resolve({
                items: [],
                type: OxomiType.CATALOGUE_PAGES,
              })
            }
          },
          itemNumber: itemNo,
          lang: config.langsDetail,
          own,
          showDetails: true,
          supplierItemNumber: supplierItemNo,
          supplierNumber: supplierNo,
          target: element,
        })
      } catch (err) {
        reject(err)
      }
    }),
  )
}

export async function getBrandCatalogues (
  own: boolean = void 0, _options: IOptions = defaultOptions): Promise<IOxomiResponse> {

  await ensureOxomiReady()

  const element = _options.render ? createTargetElement() : void 0
  let rendered = void 0

  return promiseTimeout(
    new Promise((resolve: (value: IOxomiResponse) => void, reject) => {
      try {

        // See http://oxomi.com/help/de/integration/javascript-dokumente#markenuebersicht
        oxomi.catalogBrands({
          brandSearch: false,
          brandSortBy: 'priority',
          completionHandler: (context) => {
            if (_options.render) {
              mapCSSClasses(config.classMap, element, true)
              rendered = element.innerHTML
              removeTargetElement(element)
            }
            resolve({
              items: context.json.brands,
              rendered,
              type: OxomiType.BRAND_CATALOGUES,
            })
          },
          emptyResultHandler: (context) => {
            if (context.json.error) {
              reject(context.json.message)
            } else {
              resolve({
                items: [],
                type: OxomiType.BRAND_CATALOGUES,
              })
            }
          },
          groupBy: 'type',
          includeOutdated: false,
          lang: config.langsDetail,
          own,
          search: true,
          showDetails: true,
          target: element,
          withLanguages: true,
        })
      } catch (err) {
        reject(err)
      }
    }),
  )
}

export async function openPortal (): Promise<void> {

  await ensureOxomiReady()

  oxomi.openPortal({
    withMenu: false,
  })
}

export async function isArticle (itemNo: string, supplierNo?: string | string[]): Promise<IItemNumber> {

  let supplierNumbers = void 0
  if (typeof supplierNo === 'string') {
    supplierNumbers = [supplierNo]
  }
  if (Array.isArray(supplierNo)) {
    supplierNumbers = supplierNo
  }

  const data: any = await axiosBackend.get('webservices/oxomi.ws', { params: {
    event: 'CHECK_IF_ARTICLE',
    item_number: itemNo || void 0,
    supplier_numbers: supplierNumbers,
  }})

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

async function ensureOxomiReady (): Promise<any> {
  if (oxomiReady) {
    return
  }

  await initOxomi()
}

interface ICustomWindow extends Window {
  oxomi_ready: () => void | void,
  oxomi: object | void,
}

const customWindow = window as any as ICustomWindow

async function initOxomi (): Promise<void> {

  if (!config) {
    throw new Error('Confguration is missing')
  }

  // Wait until Oxomi script is ready
  if (oxomiLoading) {
    await new Promise((resolve) => {
      const id = setInterval(() => {
        if (!oxomiLoading) {
          clearTimeout(id)
          resolve(void 0)
        }
      }, 50)
    })
    return
  }

  return new Promise((resolve, reject) => {
    oxomiLoading = true

    // Declare Oxomi Ready callback
    customWindow.oxomi_ready = () => {
      oxomi = customWindow.oxomi

      try {
        oxomi.init({
          accessToken: config.token,
          disableOverlayHistory: false,
          errorHandler: (obj) => {
            reject(obj.json.message)
          },

          // @see http://oxomi.com/help/de/integration/infoplay-2#warenkorbuebergabe
          infoplayBasketHandler: async (infoplayObj, nextFunc) => {
            try {
              await addPositionToBasket(
                infoplayObj.items[0].itemNumber, sapNumberToNumber(infoplayObj.quantity), 'oxomi')
              nextFunc(infoplayObj)
            } catch (e) {
              nextFunc({
                ...infoplayObj,
                basketMessage: I18n.t('oxomi.infoPlay.errorMessageBasket'),
              })
            }
          },

          // @see http://oxomi.com/help/de/integration/infoplay-2#infoplay-anpassen
          infoplayEmptyResultHandler: (infoplayObj, nextFunc) => {
            infoplayObj.items = [{
              sections: [
                {
                  fields: [
                    {
                      name: '',
                      span: true,
                      value: I18n.t('oxomi.infoPlay.notFoundMessage'),
                    },
                    {
                      name: '',
                      span: true,
                      value: `
                        <a href="search?q=${encodeURIComponent(infoplayObj.itemNumber)}">
                          <i class="fas fa-search" />
                          ${I18n.t('oxomi.infoPlay.notFoundLinkTitle', { query: infoplayObj.itemNumber })}
                        </a>
                      `,
                    },
                  ],
                  title: I18n.t('oxomi.infoPlay.notFoundTitle'),
                },
              ],
            }]

            nextFunc(infoplayObj)
          },

          // @see http://oxomi.com/help/de/integration/infoplay-2#infoplay-anpassen
          infoplayItemLookup: async (infoplayObj, nextFunc) => {

            // Verhindern, dass Daten von OXOMI angezeigt werden
            infoplayObj.externalLookupEnabled = false

            // Eigene Daten holen und anzeigen
            try {
              const item = await isArticle(
                infoplayObj.itemNumber || infoplayObj.compactSelection || infoplayObj.selectionText,
                infoplayObj.supplierNumbers,
              )

              if (item.matnr) {
                const articleData = await getArticleDetails(item.matnr)

                const fields = []

                const priceToString = (price?) => {
                  if (!price) {
                    return ''
                  }
                  if (price.price === 0) {
                    return I18n.t('oxomi.infoPlay.price0')
                  }
                  return numberToSapCurrency(price.price) + ' ' +
                    getCurrencySign(price.currency) +
                    ' / ' + numberToSapNumber(price.costUnit) +
                    ' ' + price.volumeUnit
                }

                // Bruttopreis
                if (articleData.retailPrice) {
                  fields.push({
                    name: articleData.netPrice ? I18n.t('oxomi.infoPlay.priceBrutto') : I18n.t('oxomi.infoPlay.price'),
                    value: priceToString(articleData.retailPrice),
                  })
                }

                // Nettopreis
                if (articleData.netPrice) {
                  fields.push({
                    name: I18n.t('oxomi.infoPlay.price'),
                    value: priceToString(articleData.netPrice),
                  })
                }

                // Verfügbarkeit
                if (articleData.availability) {
                  let availablityText = ''

                  switch (articleData.availability.availabilityFlag) {
                    case AvailabilityFlag.AVAILABLE:
                      availablityText = I18n.t('article.isAvailable')
                      break
                    case AvailabilityFlag.SHORTLY_AVAILABLE:
                      availablityText = I18n.t('article.shortlyAvailable')
                      break
                    case AvailabilityFlag.NOT_AVAILABLE:
                      availablityText = I18n.t('article.notAvailable')
                      break
                  }

                  fields.push({
                    name: I18n.t('oxomi.infoPlay.availability'),
                    value: availablityText,
                  })
                }

                infoplayObj.items = [{
                  features: [{ fields }],
                  itemNumber: articleData.matnrDisplay,
                  itemUrl: detailLink(articleData.matnr, articleData.maktx, articleData.maktx2),
                  previewImageUrl: getArticleImageUrl(articleData.image),
                  shortText: articleData.maktx + (articleData.maktx2 ? ' ' + articleData.maktx2 : ''),
                  supplierName: articleData.factoryNumbers.length ? articleData.factoryNumbers[0].supplierName : void 0,
                }]
              }

            } catch (e) {
              // Nichts tun -> OXOMI wertet den Fehler aus, da "infoplayObj.items" leer ist
            }

            nextFunc(infoplayObj)
          },
          lang: config.lang,
          portal: config.portal,
          roles: config.roles,
          server: '//' + config.server,
          user: config.user,
        })
      } catch (err) {
        oxomiLoading = false
        reject(err)
      }

      oxomiLoading = false
      oxomiReady = true
      resolve()
    }

    // Load Oxomi script
    const scriptTag = document.createElement('script')
    scriptTag.setAttribute('type', 'text/javascript')
    scriptTag.setAttribute('src', 'https://' + config.server + '/assets/frontend/oxomi.js')
    scriptTag.addEventListener('error', (err) => {
      oxomiLoading = false
      reject(err)
    })
    document.body.appendChild(scriptTag)
  })
}

function createTargetElement (): Element {
  const id = Math.floor(Math.random() * 1000000).toString()
  const targetElement = document.createElement('div')
  targetElement.setAttribute('id', id)
  targetElement.className = 'd-none'
  document.body.appendChild(targetElement)
  return targetElement
}

function removeTargetElement (element: Element): void {
  document.body.removeChild(element)
}

/**
 * Executes a class mapping either provided in the settings or the arguments.
 *
 * Adds a css class to a given selector. This can be used  to map from OXOMI css classes
 * to framework classes like bootstrap etc.
 */
function mapCSSClasses (classMap: object, element: Element | string, replace: boolean = false) {
  if (!classMap) {
    return
  }

  for (const oxomiClass in classMap) {
    // eslint-disable-next-line no-prototype-builtins
    if (!classMap.hasOwnProperty(oxomiClass)) {
      continue
    }

    $(oxomiClass, element)
      .removeClass(() => {
        return replace ? oxomiClass.replace(/^\./, '') : void 0
      })
      .addClass(classMap[oxomiClass])
  }
}

function promiseTimeout (promise, timeout = oxomiRequestTimeout) {
  let id
  const timeoutPromise = new Promise((_resolve, reject) => {
    id = setTimeout(() => {
      reject(`Timed out after ${timeout}ms`)
    }, timeout)
  })

  return Promise.race([
    promise,
    timeoutPromise,
  ]).then((result) => {
    clearTimeout(id)
    return result
  })
}
