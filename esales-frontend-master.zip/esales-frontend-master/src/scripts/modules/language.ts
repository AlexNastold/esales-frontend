import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'

/**
 * Ändert die Sprache
 *
 * @throws {ErrorCode.INVALID_LANGUAGE}
 * @throws Request error
 */
export async function changeLanguage (language: string) {
  const data: any = await axiosBackend.post('webservices/misc.ws', {
    event: 'CHANGE_LANGUAGE',
    'sap-language': language,
  })

  if (data.result.language !== language) {
    throw new ShopError(ErrorCode.INVALID_LANGUAGE, `Invalid language: "${language}"`)
  }
}

export function getLanguageIconClassAffix (language: string) {
  const languageLower = language.toLowerCase()
  switch (languageLower) {
    case 'en': return 'gb'
    default: return languageLower
  }
}
