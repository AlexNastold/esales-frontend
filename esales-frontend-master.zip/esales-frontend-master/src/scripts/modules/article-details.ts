import { ErrorCode, ShopError} from '@scripts/modules/errors'
import { IAdditionalMaterialCategory } from '@scripts/modules/interfaces'
import { IArticleEEKItem } from '@scripts/modules/eek'
import { IOxomiResponse } from '@scripts/modules/oxomi'
import { axiosBackend } from '@scripts/core/axios'

export enum AvailabilityFlag {
  AVAILABLE = 'available',
  SHORTLY_AVAILABLE = 'shortly-available',
  NOT_AVAILABLE = 'not-available',
}

export interface IArticleEEK {
  detailLabelsEnabled: boolean,
  supplierId: string,
  supplierMatnr: string,
  hasSupplierData: boolean,
  verb: string,
  classes: {
    id: string,
    class: string,
    text: string,
  }[],
  labels: {
    name: string,
    hasData: boolean,
  }[],
}

export interface IArticleDetails {
  errors?: string[],
  matnr: string,
  matnrDisplay: string,
  customerMatnr: string,
  bismt: string,
  quantity: number,
  maktx: string,
  maktx2: string,
  description: string,
  image?: string,
  supplierLogo?: string,
  unit: string,
  unitFormatted: string,
  stepsize: number,
  basisVolumneUnit: string,
  orderQuantityUnit: string,
  availability?: {
    unit: string,
    directly?: number,
    shortly?: number,
    replenishmentDate?: Date,
    availabilityFlag: AvailabilityFlag,
  },
  minimumOrderQuantity?: {
    quantity: number,
    unit: string,
  },
  quantityInBasket: number,
  lastPurchase?: {
    date: Date,
    documentType: string,
    documentId: string,
    documentIdDisplay: string,
    documentPosnr: string,
  },
  weightUnit?: string,
  weightGross?: number,
  weightNet?: number,
  images: string[],
  documentInformations?: {
    documentType: number,
    documentTypeText: string,
    documentId: string,
    documentIdDisplay: string,
    documentPosnr: string,
    documentPosnrDisplay: string,
    price: {
      price?: number,
      currency: string,
      costUnit: number,
      volumeUnit: string,
    },
  },
  retailPrice?: {
    price: number,
    currency: string,
    costUnit: number,
    volumeUnit: string,
  },
  retailScalePrices: {
    quantity: string,
    price: number,
    currency: string,
    costUnit: number,
    volumeUnit: string,
  }[],
  netPrice?: {
    price: number,
    currency: string,
    costUnit: number,
    volumeUnit: string,
  },
  netScalePrices?: {
    quantity: number,
    price: number,
    currency: string,
    costUnit: number,
    volumeUnit: string,
  }[],
  factoryNumbers: {
    matnr: string,
    supplierMatnr: string,
    supplierNumber: string,
    supplierName: string,
  }[],
  conversionFactors: {
    to: {
      quantity: number,
      unit: string,
    },
    from: {
      quantity: number,
      unit: string,
    },
  }[],
  documents: {
    url: string,
    type: string,
    label: string,
    filename: string,
  }[],
  eek?: IArticleEEK,
  cataloguePath: {
    catalogueId: string,
    catalogueName: string,
    hierarchyLevel: number,
    categoryId: string,
    categoryName: string,
    categoryIndex: string,
  }[],
  additionalMaterials: {
    type: string,
    label: string,
    articles: {
      matnr: string,
      matnrDisplay: string,
      customerMatnr: string,
      bismt: string,
      quantity: string,
      maktx: string,
      maktx2: string,
      description: string,
      image?: string,
      unit: string,
      stepsize: number,
      unitFormatted: string,
      basisVolumneUnit: string,
      orderQuantityUnit: string,
      // weightUnit?: string,
      // weightGross?: number,
      // weightNet?: number,
      additionalMaterialCategories: IAdditionalMaterialCategory[],
      retailPrice?: {
        price: number,
        currency: string,
        costUnit: number,
        volumeUnit: string,
      },
      eek?: IArticleEEKItem[],
    }[],
  }[],
  oxomi?: {
    texts?: IOxomiResponse,
    images?: IOxomiResponse,
    masterdata?: IOxomiResponse,
    documents?: IOxomiResponse,
    videos?: IOxomiResponse,
    cataloguePages?: IOxomiResponse,
  },
}

/**
 * Returns the details of an article
 *
 * @param matnr - Artical number
 * @param amount - Amount
 * @param docType - Document type
 * @param docId - Document number
 * @param docPosNumber - Document position number
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.NOT_FOUND}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 */
export async function getArticleDetails (
  matnr: string,
  amount: number = 1,
  docType?: number,
  docId?: string,
  docPosNumber?: string,
): Promise<IArticleDetails> {

  const data: any = await axiosBackend.get('webservices/article.ws', { params: {
    docid: docId,
    doctype: docType,
    event: 'GET_DETAILS',
    matnr,
    menge: amount,
    posnr: docPosNumber,
  } })

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    if (data.code === 'NOT_FOUND') {
      throw new ShopError(ErrorCode.NOT_FOUND, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if  (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

/**
 * Factory availablity
 */
export interface IFactoryAvailability {
  factory: string,
  factoryName: string,
  factoryAddress?: {
    street: string,
    postalCode: string,
    city: string,
    country: string,
    poBox: string,
  },
  availability: {
    unit: string,
    directly?: string,
    shortly?: string,
    availabilityFlag: AvailabilityFlag,
  },
  lon: number,
  lat: number,
}

/**
 * Returns the availability of an article for all factories
 *
 * @param matnr - Article number
 * @param volumeUnit - The volume unit (e.g. ST)
 */
export async function getFactoryAvailability (matnr: string, volumeUnit: string): Promise<IFactoryAvailability[]> {

  const params = {
    event: 'GET_WERKS_AVAILABILITY',
    matnr,
    meins: volumeUnit,
  }

  const data: any = await axiosBackend.get('webservices/materialmaster.ws', { params })

  return data.results
}
