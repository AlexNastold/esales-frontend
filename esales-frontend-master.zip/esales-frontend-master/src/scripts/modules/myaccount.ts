import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { IAddress } from '@scripts/modules/delivery-addresses'
import { IListListItem } from '@scripts/modules/lists'
import { axiosBackend } from '@scripts/core/axios'

export interface IDashboardInfos {
  orders?: {
    documendId: string,
    documentIdDisplay: string,
    status: OrderStatus,
    statusText: string,
    createDate: Date,
  }[],
  budgetOrders?: {
    documendId: string,
    documentIdDisplay: string,
    netPrice?: number,
    currency: string,
    createDate: Date,
    createdBy: string,
  }[],
  lists: IListListItem[],
  baskets?: {
    id: number,
    name: string,
    active; boolean,
    createDate: Date,
    positionsAmount: number,
  }[],
  addresses?: IAddress[],
  users?: {
    userId: string,
    surname: string,
    forename: string,
    createdAt: Date,
  }[],
}

export enum OrderStatus {
  OPEN = 'A',
  PARTLY_COMPLETED = 'B',
  COMPLETED = 'C',
  CANCELED = 'X',
}

/**
 * Returns the informations for the dashboard of myaccount
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getDashboardInfos (): Promise<IDashboardInfos> {

  const data: any = await axiosBackend.get('webservices/myaccount.ws', { params: { event: 'GET_DASHBOARD_INFOS' }})

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.result.orders) {
    data.result.orders = data.result.orders.map((order) => {
      order.createDate = new Date(order.createDate)
      return order
    })
  }

  if (data.result.budgetOrders) {
    data.result.budgetOrders = data.result.budgetOrders.map((budgetOrder) => {
      budgetOrder.createDate = new Date(budgetOrder.createDate)
      return budgetOrder
    })
  }

  if (data.result.lists) {
    data.result.lists = data.result.lists.map((list) => {
      list.createdAt = new Date(list.createdAt)
      return list
    })
  }

  if (data.result.baskets) {
    data.result.baskets = data.result.baskets.map((basket) => {
      basket.createDate = new Date(basket.createDate)
      return basket
    })
  }

  if (data.result.users) {
    data.result.users = data.result.users.map((user) => {
      user.createDate = new Date(user.createdAt)
      return user
    })
  }

  return data.result
}
