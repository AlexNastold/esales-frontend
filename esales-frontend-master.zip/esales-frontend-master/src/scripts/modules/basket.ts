
import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { IListArticle, IMaterialsInComponentState } from '@scripts/modules/interfaces'
import { Permission, default as user } from '@scripts/app/user'
import { dateToSapDate, numberToSapNumber } from '@scripts/helper/sapFormat'
import { axiosBackend } from '@scripts/core/axios'
import { redirect } from '@scripts/helper/redirect'
import { serverPath } from '@scripts/core/paths'
import { store } from '@scripts/core/setup/vuex'

import { applicationSettings } from '@scripts/app/settings'

import { gtagSaveOrder, gtagTrackOrder } from '@scripts/modules/gtag'

import { gtmSaveOrder, gtmTrackOrder } from '@scripts/modules/gtm'

import { showWarningMessage } from '@scripts/modules/dialogs'

export enum AvailabilityFlag {
  AVAILABLE = 'available',
  SHORTLY_AVAILABLE = 'shortly-available',
  NOT_AVAILABLE = 'not-available',
}

export enum PredefinedFilters {
  FILTER_ERROR = 'SPECIAL:ERROR',
  FILTER_SUBSTITUTION = 'SPECIAL:SUBSTITUTION',
  FILTER_STL = 'SPECIAL:STL',
  FILTER_SMARTCONFIG = 'SPECIAL:SMARTCONFIG',
}

export enum CSVdelimiter {
  COMMA = ',',
  SEMICOLON = ';',
  TAB = '\t',
  SPACE = ' ',
  OTHER = 'OTHER',
}

export interface IAdditionalPositionData {
  posnr: string,
  posnrDisplay: string,
  matnr: string,
  matnrDisplay: string,
  retailPrice: {
    price: string,
    currency: string,
    costUnit: string,
    volumeUnit: string,
  },
  retailPriceSingle: {
    price: string,
    currency: string,
    costUnit: string,
    volumeUnit: string,
  },
  netPrice?: {
    formattedPrice: string,
    currency: string,
    costUnit: string,
    volumeUnit: string,
  },
  availability?: {
    unit: string,
    directly?: number,
    shortly?: number,
    replenishmentDate?: Date,
    availabilityFlag: AvailabilityFlag,
  }
}

export async function getInstantAdditionalPositionData (posnrs: string[]): Promise<IAdditionalPositionData[]>  {

  const data: any = await axiosBackend.post('webservices/materialmaster.ws', {
    event: 'GET_AVAILABILITIES_AND_PRICES_FOR_BASKET',
    positions: posnrs.map((posnr) => ({ posnr })),
  })

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if  (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.results
}

export async function getInstantSingleAdditionalPositionData (posnr: string) {
  const data: any = await getInstantAdditionalPositionData([posnr])
  return data[0]
}

let queue = []
const QUEUE_MAX_LENGTH = 10
const QUEUE_MAX_WAIT = 100
let queueTimer = void 0

export function getAdditionalPositionData (posnrs: string[]) {
  const promises = posnrs.map(getSingleAdditionalPositionData)
  return Promise.all(promises)
}

export function getSingleAdditionalPositionData (posnr: string) {
  return new Promise((resolve) => {
    if (queue.length === 0) {
      queueTimer = setTimeout(executeQueue, QUEUE_MAX_WAIT)
    }

    queue.push({ callback: resolve, posnr })

    if (queue.length === QUEUE_MAX_LENGTH) {
      executeQueue()
    }
  })
}

async function executeQueue () {
  clearTimeout(queueTimer)

  const positions = queue
  queue = []

  if (positions.length) {
    const data = await getInstantAdditionalPositionData(positions.map((position) => position.posnr))

    data.forEach((additionalPositionData, index) => {
      positions[index].callback(additionalPositionData)
    })
  }
}

export async function getBasketOverview (): Promise<any> {

  const data: any = await axiosBackend.get('webservices/basket.ws', { params: { event: 'GET_OVERVIEW' }})

  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

export async function getBaskets (): Promise<any> {

  const data: any = await axiosBackend.get('webservices/basket.ws', {params: {event: 'MULTIBASKET_LIST'}})

  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

export async function addBasket (
  name: string = '',
  orderText: string = '',
  activate: boolean = false,
): Promise<void> {

  const params = {
    event: 'MULTIBASKET_ADD_BASKET',
    mbcheckboxactivate: activate === true ? activate : void 0,
    mbinputkommi: orderText,
    mbinputname: name,
  }

  const data: any = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status === 'ERROR') {
    if (data.code === 'INSUFFICIENT_PARAMS') {
      throw new ShopError(ErrorCode.INVALID_NAME, data.message)
    }
    if (data.code === 'NAME_ALREADY_TAKEN') {
      throw new ShopError(ErrorCode.NAME_ALREADY_TAKEN, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Changes a basket (name and/or custom order number)
 *
 * @throws {ErrorCode.NOT_FOUND}
 * @throws {ErrorCode.INVALID_NAME}
 * @throws {ErrorCode.NAME_ALREADY_TAKEN}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request Error
 */
export async function editBasket (
  oldName: string,
  newName: string,
  customOrderNumber: string,
): Promise<void> {

  const data: any = await axiosBackend.post('webservices/basket.ws', {
    event: 'MULTIBASKET_CHANGE_BASKET',
    mbinputkommi: customOrderNumber,
    mbinputname: newName,
    mbinputnameold: oldName,
  })

  if (data.status === 'ERROR') {
    if (data.code === 'NOT_FOUND') {
      throw new ShopError(ErrorCode.NOT_FOUND, data.message)
    }
    if (data.code === 'INSUFFICIENT_PARAMS') {
      throw new ShopError(ErrorCode.INVALID_NAME, data.message)
    }
    if (data.code === 'NAME_ALREADY_TAKEN') {
      throw new ShopError(ErrorCode.NAME_ALREADY_TAKEN, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export async function setBasketActive (name: string): Promise<void> {
  const data: any = await axiosBackend.post('webservices/basket.ws', {
    event: 'MULTIBASKET_SET_ACTIVE',
    mbinputname: name,
  })

  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  store.dispatch('updateBasket')
}

export async function deleteBasket (name: string = ''): Promise<any> {

  const params = {
    event: 'MULTIBASKET_DEL_BASKET',
    mbinputname: name,
  }

  const data: any = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export async function requestOffer (): Promise<any> {

  const params = {
    event: 'INQUIRY',
  }

  const data: any = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}
export enum ShipmentType {
  PICKUP = 'P',
  DELIVERY = 'D',
}

export enum ShipmentCondition {
  PICKUP = '01',
  DELIVERY_IMMEDIATE = '02',
  DELIVERY = '03',
}

export interface IShipmentData {
  errors?: {
    field: string,
    error: string,
  }[],
  additionalInfos: {
    projectLabel1: string,
    projectLabel2: string,
    customOrderNumber: string,
  },
  shipment: {
    condition: ShipmentCondition,
    type: ShipmentType,
    address: {
      isDifferent: boolean,
      isValidated?: boolean,
      id: string,
      name1?: string,
      name2?: string,
      street?: string,
      postalCode?: string,
      city?: string,
      country?: string,
    },
  },
  texts: {
    id: string,
    label: string,
    text: string,
    filled: boolean,
    language: string,
  }[],
  shipmentTypes: {
    '01': {
      available: boolean,
      label: string,
      type: ShipmentType,
      pickupDate?: Date,
      isWerkChangeable: boolean,
      vkorgs: {
        vkorg: string,
        vkorgText: string,
        vtweg: string,
        vtwegText: string,
        vwerk: string,
        sparte: string,
        sparteText: string,
        active: boolean,
      }[],
    },
    '02': {
      available: boolean,
      label: string,
      type: ShipmentType,
    },
    '03': {
      available: boolean,
      label: string,
      type: ShipmentType,
      deliveryDate?: Date,
    },
  },
  countries: {
    key: string,
    label: string,
  }[],
  addresses: {
    id: string,
    name1: string,
    name2: string,
    street: string,
    postalCode: string,
    city: string,
    country: string,
    isDefaultAddress: boolean,
    isEditable: boolean,
  }[],
}

export async function getShipmentData (): Promise<IShipmentData> {

  const data: any = await axiosBackend.get('webservices/basket.ws', { params: { event: 'GET_HEAD_DATA' }})

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  const deliveryData = data.result

  // ISO-Datum-Strings konvertieren
  if (deliveryData.shipmentTypes[ShipmentCondition.PICKUP].pickupDate) {
    deliveryData.shipmentTypes[ShipmentCondition.PICKUP].pickupDate
      = new Date(deliveryData.shipmentTypes[ShipmentCondition.PICKUP].pickupDate)
  }

  if (deliveryData.shipmentTypes[ShipmentCondition.DELIVERY].deliveryDate) {
    deliveryData.shipmentTypes[ShipmentCondition.DELIVERY].deliveryDate
      = new Date(deliveryData.shipmentTypes[ShipmentCondition.DELIVERY].deliveryDate)
  }

  return deliveryData
}

export interface ISaveShipmentData {
  werk?: string,
  desiredDeliveryDate?: string,
  desiredPickupDate?: string,
  addressName1?: string,
  addressName2?: string,
  addressStreet?: string,
  addressPostalCode?: string,
  addressCity?: string,
  addressCountry?: string,
  addressId?: string,
  deliverWhenComplete?: boolean,
}

export enum SaveShipmentDataErrorFields {
  DELIVERY_DATE = 'gs_upd_head-desired_delivery_date',
  PICKUP_DATE = 'gs_upd_head-desired_pickup_date',
  WERK = 'gs_upd_head-vwerk',
  ADDRESS_NAME1 = 'gs_upd_head-differ_name1',
  ADDRESS_STREET = 'gs_upd_head-differ_stras',
  ADDRESS_POSTAL_CODE = 'gs_upd_head-differ_pstlz',
  ADDRESS_CITY = 'gs_upd_head-differ_ort01',
  ADDRESS_COUNTRY = 'gs_upd_head-differ_land1',
}

export async function saveShipmentData (deliveryType, {
  werk,
  desiredDeliveryDate,
  desiredPickupDate,
  addressName1,
  addressName2,
  addressStreet,
  addressPostalCode,
  addressCity,
  addressCountry,
  addressId,
  deliverWhenComplete,
}: ISaveShipmentData): Promise<{
  deliveryDate?: {
    hasToBeCheckedAgainstPositions: boolean,
    newDeliveryDate?: Date,
    positions?: {
      posnr: string,
      posnrDisplay: string,
      matnr: string,
      matnrDisplay: string,
      bismt: string,
      amount: string,
      volumeUnit: string,
      maktx1: string,
      maktx2: string,
      deliveryDate: Date,
    }[],
  },
}> {

  const params = {
    event: 'SAVE_HEAD_DATA',
    gs_shipping_data: {
      complete_flag: deliverWhenComplete ? 'X' : void 0,
      desired_delivery_date: desiredDeliveryDate,
      desired_pickup_date: desiredPickupDate,
      differ_address: {
        city: addressCity,
        country: addressCountry,
        first_name: addressName2,
        last_name: addressName1,
        postal_code: addressPostalCode,
        ship_to_party: addressId,
        street: addressStreet,
      },
      pickup_plant: werk,
      ship_cond: deliveryType,
    },
  }

  const data: any  = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status === 'WARNING') {
    if (data.use_validator === 'X' && !data.use_multiple_errors) {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }

    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return {
    deliveryDate: {
      hasToBeCheckedAgainstPositions: data.result.poslevelDateChanged,
      newDeliveryDate: new Date(data.result.poslevelDateNew),
      positions: data.result.positions,
    },
  }
}

export async function saveAdditionalOrderData (
  orderNumber: string,
  projectLabel1: string,
  projectLabel2: string,
): Promise<void> {

  const params = {
    event: 'SAVE_ADDITIONAL_DATA',
    gs_further_infos: {
      order_nbr: orderNumber,
      project1: projectLabel1,
      project2: projectLabel2,
    },
  }

  const data: any  = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export async function adoptDeliveryDateOnPositions (posnrs: string[]): Promise<void> {

  const params = {
    event: 'UPDATE_POSITIONS_DATE',
    it_list: posnrs,
  }

  const data: any  = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export async function setPosText (posnr: string, text: string): Promise<any> {

  const params = {
    event: 'SET_POS_TEXTS',
    it_pos_txt: [{
      posnr,
      text_line: text,
    }],
  }

  const data: any  = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Returns the last order
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getLastOrder (): Promise<{ isInquiry: boolean, number: number }> {
  const data: any = await axiosBackend.get('webservices/ordersummary.ws', { params: { event: 'GET_LAST_ORDER' }})

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (applicationSettings.gtmActive && applicationSettings.gtmEcommerceActive) {
    gtmTrackOrder()
  }

  if (applicationSettings.gtagActive && applicationSettings.gtagEcommerceActive) {
    gtagTrackOrder()
  }

  return data.result
}

/**
 * Downloads the pdf of the last order
 *
 * @param  withNetPrices - Print netprices in the pdf
 */
export function downloadLastOrderAsPdf (withNetPrices: boolean = false): void {
  redirect(getLastOrderDownloadUri(withNetPrices))
}

/**
 * Returns the download url to download the pdf of the last order
 *
 * @param  withNetPrices - Print netprices in the pdf
 */
export function getLastOrderDownloadUri (withNetPrices: boolean = false): string {
  return `${serverPath}webservices/basket.ws?event=DOWNLOAD_PDF${withNetPrices ? '&iv_netto=X' : ''}`
}

export async function order () {
  const data: any = await axiosBackend.post('webservices/basket.ws', { event: 'ORDER' })

  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.status === 'OK' && data.message !== '') {
    showWarningMessage(data.message)
  }

  if (applicationSettings.gtagActive && data.result.tracking) {
    gtagSaveOrder(data.result.tracking)
  }

  if (applicationSettings.gtmActive && data.result.tracking) {
    gtmSaveOrder(data.result.tracking)
  }

  return data.result

}

export async function orderIds () {
  const data: any = await axiosBackend.post('webservices/basket.ws', { event: 'ORDER_IDS' })
  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
  if (data.status === 'OK' && data.message !== '') {
    showWarningMessage(data.message)
  }

  if (applicationSettings.gtagActive && data.result.tracking) {
    gtagSaveOrder(data.result.tracking)
  }

  if (applicationSettings.gtmActive && data.result.tracking) {
    gtmSaveOrder(data.result.tracking)
  }

  return data.result
}

export async function getIdsData () {
  const data: any = await axiosBackend.post('webservices/basket.ws', { event: 'GET_IDS_DATA' })

  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

export async function getOciData () {
  const data: any = await axiosBackend.post('webservices/basket.ws', { event: 'GET_OCI_DATA' })

  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

export function generateParamsForOciOrSap (ociData) {
  const fields = {}

  ociData.oci_hook_params.forEach((param) => fields[param.name] = param.value)

  ociData.oci_datas.forEach((field) => {
    if (field.field.toUpperCase() === 'LONGTEXT') {
      fields['NEW_ITEM-' + field.field + '_' + field.index + ':132[]'] = field.val
    } else {
      fields['NEW_ITEM-' + field.field + '[' + field.index + ']'] = field.val
    }
  })

  return {
    action: ociData.oci_url,
    fields,
    target: ociData.oci_target,
  }
}

export async function addPositionToBasket (
  matnr: string,
  amount: number = 1,
  pitcher: string,
  {
    bismt,
    volumeUnit,
    docType,
    docId,
    docPosnr,
    basketName,
    asZHA = false,
  }: {
    bismt?: string,
    volumeUnit?: string,
    docType?: number,
    docId?: string,
    docPosnr?: string,
    basketName?: string,
    asZHA?: boolean,
  } = {},
) {

  const params = {
    event: asZHA ? 'OFFER_TO_ZHA' : 'ADD_TO_BASKET',
    it_addto: [{
      bismt: bismt || matnr,
      doc_itm_number: docPosnr,
      doc_number: docId,
      doc_type: docType,
      matnr,
      meins: volumeUnit,
      menge: numberToSapNumber(amount),
    }],
    pitcher,
    receiver: basketName,
  }

  const data: any = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status !== 'OK') {
    throw new Error(data.message)
  }

  store.dispatch('updateBasket')
}

export async function addPositionsToBasket (
  articles: {
    matnr: string,
    amount: number,
    bismt?: string,
    volumeUnit?: string,
    docType?: number,
    docId?: string,
    docPosnr?: string,
    asZHA?: boolean,
  }[],
  pitcher?: string,
  {
    basketName,
    asZHA = false,
  }: {
    basketName?: string,
    asZHA?: boolean,
  } = {},
) {

  const params = {
    event: asZHA ? 'OFFER_TO_ZHA' : 'ADD_TO_BASKET',
    it_addto: articles.map((article) => ({
      bismt: article.bismt || article.matnr,
      doc_itm_number: article.docPosnr,
      doc_number: article.docId,
      doc_type: article.docType,
      matnr: article.matnr,
      meins: article.volumeUnit,
      menge: numberToSapNumber(article.amount),
    })),
    pitcher,
    receiver: basketName,
  }

  const data: any = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status !== 'OK') {
    throw new Error(data.message)
  }

  store.dispatch('updateBasket')
}

interface IBasketPositionId {
  posnr: string,
  matnr: string,
  matnr_d: string,
  revenue: number,
  flag: string,
}

export async function deletePositionsFromBasket (positions: IBasketPositionId[]) {

  const params = {
    event: 'DELETE_POSITIONS',
    it_addto: positions.map((position) => {
      return {
        checked: 'X',
        doc_itm_number: position.posnr, // Hier muss die posnr ohne führende Nullen übergeben werden!
        matnr: position.matnr,
      }
    }),
  }

  const data: any = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status !== 'OK') {
    throw new Error(data.message)
  }

  store.dispatch('updateBasket')
}

export async function deleteFaultyPositionsFromBasket () {

  const params = {
    event: 'DELETE_ERRORS',
  }

  const data: any = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status !== 'OK') {
    throw new Error(data.message)
  }

  store.dispatch('updateBasket')
}

export async function deleteAllPositionsFromBasket () {

  const params = {
    event: 'DELETE_ALL',
  }

  const data: any = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status !== 'OK') {
    throw new Error(data.message)
  }

  store.dispatch('updateBasket')
}

export interface IBasketPosition {
  matStatus: string,
  hasError: boolean,
  error?: string,
  article: IListArticle,
  position: {
    posnr: string,
    posnrDisplay: string,
    amount: number,
    nextAmount: number,
    referenceDocument?: {
      documentType: number,
      documentTypeText: string,
      documentId: string,
      documentIdDisplay: string,
      documentPosnr: string,
      documentPosnrDisplay: string,
    },
    customerText?: string,
    desiredDeliveryDate: Date,
    partList: {
      isPartListArticle: boolean,
      isHead: boolean,
      headPosnr?: string,
      type: string,
    },
  },
}

export interface IBasketPositions {
  positions: IBasketPosition[],
  positionsAmount: {
    all: {
      all: number,
      uepos: number,
      upos: number,
      faulty: number,
    },
    filtered: {
      all: number,
      uepos: number,
      upos: number,
      faulty: number,
    },
  },
  filter: {
    from: number,
    to: number,
    filter: string,
    sort: string,
  }
  hasErrors: boolean,
  lastCommission: string,
  missingZhaLdat: boolean,
  numberOfErrors: number,
  showNewlines: boolean,
  sum: {
    retailPrice: {
      sum: number,
      mwst: number,
      sumInclMwst: number,
      currency: string,
    },
    netPrice: {
      sum: number,
      mwst: number,
      sumInclMwst: number,
      currency: string,
    },
  },
}

export async function getBasketPositions (from?: number, to?: number, filter?: string): Promise<IBasketPositions> {

  const params = {
    event: 'GET_POSITIONS',
    iv_filter: filter ? filter : void 0,
    iv_from: from ? from : void 0,
    iv_to: to ? to : void 0,
  }

  const data: any = await axiosBackend.get('webservices/basket.ws', { params })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

export async function getMaterialsInBasket (): Promise<IMaterialsInComponentState> {
  const data: any = await axiosBackend.get('webservices/basket.ws', {params: {event: 'GET_ARTICLES_STATE'}})

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

export async function updateBasketPositions (positions: IBasketPosition[]): Promise<void> {

  const params = {
    event: 'UPDATE',
    it_pos: positions.map((position) => {
      return {
        '/fis/kommi': '',
        ldat: position.position.desiredDeliveryDate,
        matnr: position.article.matnr,
        matnr_d: position.article.matnrDisplay,
        menge: numberToSapNumber(position.position.amount),
        posnr: position.position.posnrDisplay,
      }
    }),
    it_pos_txt: [],
  }

  if (user.hasPermission(Permission.BASKET_POSITION_TEXT)) {
    params.it_pos_txt = positions.map((position) => {
      return {
        posnr: position.position.posnrDisplay,
        text_line: position.position.customerText,
      }
    })
  }

  const data: any = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  if (data.result.positions_changed) {
    store.dispatch('updateBasket')
  }

  return data.result.positions_changed
}

export async function setDesiredDeliveryDate (posnr: string, date: Date): Promise<void> {

  const params = {
    event: 'SET_DESIRED_DELIVERY_DATE_FOR_POS',
    iv_delivery_date: dateToSapDate(date),
    iv_posnr: posnr,
  }

  const data: any = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status === 'ERROR') {
    if (data.has_data_ref && Array.isArray(data.data_ref_as_json)
      && data.data_ref_as_json.length && data.data_ref_as_json[0].NAME === 'nextPossibleDeliveryDate') {
      throw new ShopError(ErrorCode.DATE_NOT_POSSIBLE, data.message, {
        nextPossibleDeliveryDate: new Date(data.data_ref_as_json[0].VALUE),
      })
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export async function substitutePosition (posnr: string, substitutionType: number): Promise<void> {

  const params = {
    event: 'SUBSTITUTION',
    iv_posnr: posnr,
    iv_type: substitutionType,
  }

  const data: any = await axiosBackend.post('webservices/basket.ws', params)

  if (data.status === 'ERROR') {
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export enum OrderVariant {
  NONE = 'NONE',
  NORMAL = 'NORMAL',
  IDS = 'IDS',
  OCI = 'OCI',
  SAP = 'SAP',
}

export interface IOrderSummary {
  hasErrors: boolean,
  order: {
    type: string,
    typeText: string,
    createdAt: Date,
    createdBy: string,
  },
  additionalInfos: {
    projectLabel1: string,
    projectLabel2: string,
    customOrderNumber: string,
  },
  payment: {
    paymentMethod: string,
    paymentMethodText: string,
  },
  delivery: {
    type: string,
    typeText: string,
    place?: string,
    date?: Date,
    address?: {
      name1: string,
      name2: string,
      street: string,
      postalCode: string,
      city: string,
      contry: string,
    },
  },
  texts: {
    id: string,
    label: string,
    filled: boolean,
    text: string,
  }[],
  positions: {
    matStatus: string,
    hasError: boolean,
    error?: string,
    article: IListArticle,
    position: {
      posnr: string,
      posnrDisplay: string,
      amount: number,
      referenceDocument?: {
        documentType: string,
        documentTypeText: string,
        documentId: string,
        documentIdDisplay: string,
        documentPosnr: string,
        documentPosnrDisplay: string,
      },
      customerText?: string,
      desiredDeliveryDate: Date,
      partList: {
        isPartListArticle: boolean,
        isHead: boolean,
        headPosnr?: string,
        type: string,
      },
    },
    flags: {
      canHaveDesiredDeliveryDate: boolean,
      canHaveCustomerText: boolean,
      canHavePrices: boolean,
      canHaveAvailablity: boolean,
      canBeDeleted: boolean,
    },
  }[],
  sum: {
    retailPrice: {
      sum: number,
      taxes: number,
      sumInclTaxes: number,
      currency: string,
      taxRate: number,
    },
    netPrice: {
      sum: number,
      taxes: number,
      sumInclTaxes: number,
      currency: string,
      taxRate: number,
    },
  },
}

/**
 * Returns the order summary
 *
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getOrderSummary (): Promise<IOrderSummary> {

  const params = {
    event: 'GET_SUMMARY',
  }

  const data: any = await axiosBackend.get('webservices/ordersummary.ws', { params })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

export enum UpDownloadFormat {
  CSV = 'CSV',
  UGS = 'UGS',
}

export function getDownloadUri (format: UpDownloadFormat | 'BASKETPDF'): string {
  return `${serverPath}webservices/basket.ws?event=DOWNLOAD_BASKET&iv_format=${encodeURIComponent(format)}`
}

export async function upload (format: UpDownloadFormat, file): Promise<any> {

  const params =  {
    event: 'UPLOAD_BASKET',
    iv_format: format,
  }

  const formData = new FormData()
  // formData.append('fileUpload', new Blob(['test payload'], { type: 'text/csv' }))
  formData.append('fileUpload', file, file.name)

  // Daten zu posten funktioniert wohl nur so.
  const data: any = await axiosBackend.post('webservices/basket.ws', formData, {params})

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  store.dispatch('updateBasket')

  return data.result.lines
}

/**
 * Returns the order payment method
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getOrderPaymentMethod (): Promise<{ paymentMethod: string, preferredPaymentMethod: string }> {

  const params = {
    event: 'GET_ORDER_PAYMENT',
  }

  const data: any = await axiosBackend.get('webservices/payment.ws', { params })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'PAYMENT_NOT_ACTIVE':
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

/**
 * Sets the order payment method
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function setOrderPaymentMethod (paymentMethod: string): Promise<void> {

  const params = {
    event: 'SET_ORDER_PAYMENT',
    iv_payment_method: paymentMethod,
  }

  const data: any = await axiosBackend.post('webservices/payment.ws', params)

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      case 'PAYMENT_NOT_ACTIVE':
      case 'INVALID_PAYMENT_METHOD':
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export interface IText {
  id: string,
  label: string,
  text: string,
}

/**
 * Gibt die Texte zurück
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getTexts (): Promise<IText[]> {
  const data: any = await axiosBackend.get('webservices/basket.ws', { params: { event: 'GET_TEXTS' }})

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}

/**
 * Speichert Texte
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function saveTexts (texts: { id: string, text: string }[]): Promise<void> {
  const data: any = await axiosBackend.post('webservices/basket.ws', {
    event: 'SAVE_TEXTS',
    it_texts: texts.map((text) => ({
      text_id: text.id,
      text_line: text.text,
    })),
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export interface ITrackingAddToBasket {
  netSum: number,
  grossSum: number,
  items: {
    partno: string,
    texts: string,
    netPrice: number,
    grossPrice: number,
    quantity: number,
  }[]
}

export interface ITrackingOrder {
  docId: string,
  currency: string,
  netSum: number,
  netTax: number,
  netSumTax: number,
  grossSum: number,
  grossTax: number,
  grossSumTax,
  items: {
    partno: string,
    pitcher: string,
    texts: string,
    brand: string,
    category: string,
    netPrice: number,
    grossPrice: number,
    quantity: number,
  }[]
}

/**
 * Returns the amount of an matnr in basket
 *
 * @throws {ErrorCode.NO_AUTHORIZATION} No authorization
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE} Unexpected webservice response
 * @throws {ErrorCode.UNSPECIFIED} Unspecified error
 * @throws Request error
 */
export async function getArticleQuantityInBasket (matnr: string): Promise<number> {
  const data: any = await axiosBackend.post('webservices/basket.ws', {
    event: 'GET_AMOUNT_IN_BASKET',
    iv_matnr: matnr,
  })

  if (data.status === 'ERROR') {
    switch (data.code) {
      case 'NO_AUTHORIZATION':
        throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result.amountInBasket
}
