import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { IListArticle } from '@scripts/modules/interfaces'
import { axiosBackend } from '@scripts/core/axios'

/**
 * Returns the last seen articles for the logged in user
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getLastSeenArticles (): Promise<IListArticle[]> {

  const data: any = await axiosBackend.get('webservices/lastseen.ws', { params: {
    event: 'GET_LAST_SEEN_ARTICLES',
  }})

  if (data.status === 'ERROR') {
    if (data.coe === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}
