/* eslint-disable no-useless-escape */
import Article from '@scripts/modules/article'
import I18n from '@scripts/modules/i18n'
import { applicationSettings } from '@scripts/app/settings'
import { axiosBackend } from '@scripts/core/axios'
import { getEEKIconUrl } from '@scripts/modules/eek'
import { store } from '@scripts/core/setup/vuex'
import { tryParseFloat } from '@scripts/helper/formatNumber'
import user from '@scripts/app/user'


const categoryImageBasePath   = applicationSettings.categoryImageBasePath
const categorySortKeyLength   = 6
let categoryNameSliceLength   = 0

const jsonFacetLabels = {}
let categoryHeaderImages: ICategoryImage[] = []
let categoryTileImages: ICategoryImage[] = []

categoryNameSliceLength += categorySortKeyLength

export enum FilterType {
  FIELD_FILTER = 'FIELD_FILTER',
  RANGE_FILTER = 'RANGE_FILTER',
  PIVOT_FILTER = 'PIVOT_FILTER',
  QUERY_FILTER = 'QUERY_FILTER',
}

export interface ICategoryImage {
  level: number,
  index: string,
  image: string,
}

export interface IParsedFacets {
  fields: IParsedFacetField[]
  ranges: IParsedFacetField[]
  pivots: IParsedFacetField[]
  queries: IParsedFacetField[]
}

export interface IParsedFacetField {
  id: string
  type: FilterType
  field: string
  label: string
  stats?: object | void
  values: IParsedFacetValue[]
}

interface IParsedFacetQuery extends IParsedFacetField {
  query: string
  hits: number
}

interface IParsedFacetValue {
  id: string
  type: FilterType
  field: string
  value: string
  label: string
  image?: string | void
  hits: number
  isActive: boolean
  markedForActivation: boolean
}

interface IParsedFacetRangeValue extends IParsedFacetValue {
  from: number | string
  to: number | string
}

export interface IParsedFacetPivotValue extends IParsedFacetValue {
  level: number
  constraints: string
  sub: IParsedFacetPivotValue[]
  parent?: IParsedFacetPivotValue
  headerImage?: string
}

export interface IActiveFilter {
  field: string
  label: string
  type?: FilterType
  values: string[]
}

export interface IActiveFilterFlat {
  id: string
  field: string
  label: string
  type?: FilterType
  value: string
  valueLabel?: string
}

export interface ISearchOptions {
  queryFields?: string
  start?: number
  rows?: number
  sort?: string
  fuzzy?: boolean
  categoriesOnly?: boolean
  userCatalogue?: boolean
}

export interface IActiveCatalogueCategory {
  filterQuery: string,
  label: string,
}

export async function getParsedResponse (query: string, activeFilters: IActiveFilter[], searchOptions?: ISearchOptions):
  Promise<any> {

  // Wurde der Filter über das Dropdown (FormInputProductSearchGlobal.vue)
  // geändert, müssen die activeFilters angepasst werden

  let selectedCategory = ''
  let filterChanged = false
  const storeActiveCategory = store.getters.getActiveCategory

  // prüfen ob es Kategorie-Filter gibt
  const hierarchyLvl0Filter = activeFilters.find((filter) => {
    if (filter.field === 'hierarchy_lvl_0') {
      // bisherige Kategorie merken
      selectedCategory = getLabelFromFacetFieldValue(filter.values[0])
      if (storeActiveCategory.manuallyChanged === true &&
        filter.field + ':(' + filter.values[0] + ')' !== storeActiveCategory.filterQuery) {
        filter.values = [getFilterLabelFromFilterQuery(storeActiveCategory.filterQuery)]
        selectedCategory = storeActiveCategory.label
        filterChanged = true
      }
    }
    return filter.field === 'hierarchy_lvl_0'
  })

  // Wurde die erste Kategorie geändert, müssen alle vorhanden Unterkategorien aus den
  // aktiven Filtern gelöscht werden
  if (filterChanged) {
    activeFilters = activeFilters.filter((filter) => {
      return !(filter.field.substring(0, 14) !== 'hierarchy_lvl_') ||
      (filter.field.substring(0, 14) === 'hierarchy_lvl_0' && filter.values[0] !== '')
    })
  }

  // Wenn es keine Kategorien in den aktiven Filtern gibt, aber über das Dropdown eine Kategorie
  // ausgewählt wurde muss diese den aktiven Filtern hinzugefügt werden
  if (!hierarchyLvl0Filter && storeActiveCategory.filterQuery !== '' && storeActiveCategory.manuallyChanged === true) {
    selectedCategory = storeActiveCategory.label
    activeFilters.push({
      field: 'hierarchy_lvl_0',
      label: 'hierarchy_lvl_0',
      type: FilterType.PIVOT_FILTER,
      values: [getFilterLabelFromFilterQuery(storeActiveCategory.filterQuery)],
    })
  }

  // Suchen
  let rawResponse = await getRawResponse(query, activeFilters, searchOptions)

  // Wurde bei der Suche keine Artikel gefunden und es ist eine Kategorie über das Dropdown gewählt,
  // Kategorie aus den aktiven Filtern löschen und nochmal suchen
  // die ursprüngliche Kategorie wird im Attribut selectedCategory im Return zurückgegeben,
  // um im Layout eine entsprechende Meldung anzeigen zu können
  if (rawResponse.response.numFound === 0) {
    const activeFilterLength = activeFilters.length
    activeFilters = activeFilters.filter((filter) => {
      return !(filter.field.substring(0, 14) === 'hierarchy_lvl_')
    })
    // Hat sich an den aktiven Filtern nichts geändert, war kein Kategorie-Filter vorhanden
    if (activeFilterLength !== activeFilters.length) {
      setActiveCatalogueCategoryToStore(false, {
        filterQuery: '',
        label: I18n.t('components.formInputProductSearch.allCategories'),
      })
      rawResponse = await getRawResponse(query, activeFilters, searchOptions)
    }
  }

  // manuallyChanged auf false setzen
  setActiveCatalogueCategoryToStore(false, store.getters.getActiveCategory)

  const numberOfHits = rawResponse.response.numFound
  const start = rawResponse.response.start
  const rows = parseInt(rawResponse.responseHeader.params.rows, 10) || 0
  const numberOfPages = rows ? (Math.ceil(numberOfHits / rows)) : 0
  const currentPage = rows ? Math.floor(start / rows) : 0
  const solrOffline = rawResponse.response.solrOffline ? true : false

  return {
    currentPage,
    filters: parseFacets(rawResponse),
    numberOfHits,
    numberOfPages,
    rows,
    searchResults: rawResponse.response.docs,
    selectedCategory,
    solrOffline,
    start: rawResponse.response.start,
  }
}

export function setActiveCatalogueCategoryToStore (manuallyChanged: boolean, category ?: IActiveCatalogueCategory) {
  store.dispatch('updateActiveCategory', {
    filterQuery: category ? category.filterQuery : '',
    label: category ? category.label : I18n.t('components.formInputProductSearch.allCategories'),
    manuallyChanged,
  })
}

function getFilterLabelFromFilterQuery (filterQuery) {
  return filterQuery.replace('hierarchy_lvl_0:(', '').replace(')', '')
}

async function getRawResponse (query: string, activeFilters: IActiveFilter[], searchOptions?: ISearchOptions):
  Promise<any> {

  const params =  {
    event: searchOptions.categoriesOnly ? 'GETCATEGORYHIERARCHY' : 'SEARCH',
    fq: serializeActiveFilters(activeFilters) || void 0,
    fuzzy: searchOptions.fuzzy || void 0,
    pitcher: searchOptions.categoriesOnly ? void 0 : 'search',
    qf: searchOptions.queryFields || void 0,
    query: query || void 0,
    rows: searchOptions.rows || void 0,
    sort: searchOptions.sort || void 0,
    start: searchOptions.start || void 0,
    user_catalogue: searchOptions.userCatalogue ? 'X' : void 0,
  }

  const data: any = await axiosBackend.post('webservices/search.ws', params)
  return data
}

function parseFacets (rawResponse: any): IParsedFacets {

  // Siehe Funktion parseFacetsToObject in V17

  const activeFilters = parseFilterString(rawResponse.responseHeader.params.fq)

  addFieldLabelsFromJSONFacets(rawResponse)

  // To-Do: Evtl alle Filter in ein großes Array schmeißen?
  // Besser sortierbar. Es kann leichter geprüft werden, ob es Filter gibt
  const parsedFacets: IParsedFacets = {
    fields: parseFacetFields(rawResponse, activeFilters),
    pivots: parseFacetPivots(rawResponse, activeFilters),
    queries: parseFacetQueries(rawResponse, activeFilters),
    ranges: parseFacetRanges(rawResponse, activeFilters),
  }
  return parsedFacets
}

function parseFacetFields (rawResponse, activeFilters: IActiveFilter[]): IParsedFacetField[] {

  let facetFields: IParsedFacetField[] = []
  const rawFacetFields = (rawResponse && rawResponse.facet_counts && rawResponse.facet_counts.facet_fields)
    ? rawResponse.facet_counts.facet_fields
    : {}
  const rawJSONFacetFields = (rawResponse && rawResponse.facets) ? rawResponse.facets : {}

  facetFields = Object.keys(rawFacetFields).reduce((fieldsWithValues: IParsedFacetField[], fieldName) => {

    // Felder, für die es keine Werte gibt, herausfiltern
    const values = parseFacetFieldValues(fieldName, rawFacetFields[fieldName], activeFilters)
    if (values.length) {
      fieldsWithValues.push({
        field: fieldName,
        id: `field-filter-${fieldName}`,
        label: getFilterLabel(fieldName),
        type: FilterType.FIELD_FILTER,
        values,
      })
    }
    return fieldsWithValues
  }, [])

  categoryHeaderImages = []
  categoryTileImages = []

  // Siehe Funktion parseJSONFacetsToObject in V17
  Object.keys(rawJSONFacetFields).forEach((fieldName) => {
    if (fieldName === 'count') {
      return
    }

    // Keys, die mit "hidden_" beginnen, nicht anzeigen aber ausgewählte verarbeiten
    if (fieldName.indexOf('hidden_') === 0) {
      switch (fieldName) {
        case 'hidden_category_head_images':
        case 'hidden_category_tile_images':
          // eslint-disable-next-line no-case-declarations
          const imageFilters = parseJSONFacetFieldValues(
            fieldName,
            rawJSONFacetFields[fieldName].buckets,
            activeFilters,
          )
          imageFilters.forEach((imageFilter) => {
            const imageObject = parseCategoryImageName(imageFilter.value)
            imageObject.image = imageObject.image ? (categoryImageBasePath + imageObject.image) : imageObject.image
            if (fieldName === 'hidden_category_head_images') {
              categoryHeaderImages.push(imageObject)
            }
            if (fieldName === 'hidden_category_tile_images') {
              categoryTileImages.push(imageObject)
            }
          })
          break
      }
      return
    }

    if (!Array.isArray(rawJSONFacetFields[fieldName].buckets) || rawJSONFacetFields[fieldName].buckets.length === 0) {
      return
    }

    facetFields.push({
      field: fieldName,
      id: `field-filter-${fieldName}`,
      label: getFilterLabel(fieldName),
      type: FilterType.FIELD_FILTER,
      values: parseJSONFacetFieldValues(fieldName, rawJSONFacetFields[fieldName].buckets, activeFilters),
    })
  })

  if (applicationSettings.sortFiltersBy === 'alpha') {
    facetFields.sort((a, b) => (a.label > b.label) ? 1 : ((b.label > a.label) ? -1 : 0))
  }

  return facetFields
}

function parseFacetRanges (rawResponse, activeFilters: IActiveFilter[]): IParsedFacetField[] {

  let facetRanges: IParsedFacetField[] = []
  const rawFacetRanges = (rawResponse && rawResponse.facet_counts && rawResponse.facet_counts.facet_ranges)
    ? rawResponse.facet_counts.facet_ranges
    : {}
  const currency = getCurrency(rawResponse)

  facetRanges = Object.keys(rawFacetRanges).map((fieldName) => {
    return {
      field: fieldName,
      id: `range-filter-${fieldName}`,
      label: getFilterLabel(fieldName),
      stats: getStatsForField(rawResponse, fieldName),
      type: FilterType.RANGE_FILTER,
      values: parseFacetRangeValues(fieldName, rawFacetRanges[fieldName], currency, activeFilters),
    }
  })
  return facetRanges
}

function parseFacetPivots (rawResponse, activeFilters: IActiveFilter[]): IParsedFacetField[] {

  let facetPivots: IParsedFacetField[] = []
  const rawFacetPivots = (rawResponse && rawResponse.facet_counts && rawResponse.facet_counts.facet_pivot)
    ? rawResponse.facet_counts.facet_pivot
    : {}

  facetPivots = Object.keys(rawFacetPivots).map((fieldName) => {
    return {
      field: fieldName,
      id: `pivot-filter-${fieldName}`,
      label: getFilterLabel(fieldName),
      type: FilterType.PIVOT_FILTER,
      values: parseFacetPivotValues(fieldName, rawFacetPivots[fieldName], activeFilters),
    }
  })

  if (applicationSettings.sortFiltersBy === 'alpha') {
    facetPivots.sort((a, b) => (a.label > b.label) ? 1 : ((b.label > a.label) ? -1 : 0))
  }

  return facetPivots
}

function parseFacetQueries (rawResponse, activeFilters: IActiveFilter[]): IParsedFacetQuery[] {

  let facetQueries: IParsedFacetQuery[] = []
  const rawFacetQueries = (rawResponse && rawResponse.facet_counts && rawResponse.facet_counts.facet_queries)
    ? rawResponse.facet_counts.facet_queries
    : {}

  facetQueries = Object.keys(rawFacetQueries).reduce((parsedFacetQueries: IParsedFacetQuery[], query) => {

    // Facet-Queries sind in der "normalen" Query-Syntax geschrieben.
    // Deshalb können Sie mit dem Parser, der auch für den fq-Parameter
    // verwendet wird, geparst werden.
    const parsedQueryFilters = parseFilterString(query, FilterType.QUERY_FILTER)
    parsedQueryFilters.forEach((filter) => {
      if (filter.values.length) {
        const label = getFilterLabel(filter.field)
        parsedFacetQueries.push({
          field: filter.field,
          hits: rawFacetQueries[query],
          id: `query-filter-${filter.field}`,
          label,
          query: normalizeFilterQuery(query),
          type: FilterType.QUERY_FILTER,
          values: filter.values.map((val: string) => {
            const isActive = isFilterActive(filter.field, val, activeFilters)
            return {
              field: filter.field,
              hits: rawFacetQueries[query],
              id: `query-filter-${filter.field}-${val}`,
              image: getValueImage(filter.field, val),
              isActive,
              label: val,
              markedForActivation: isActive,
              type: FilterType.QUERY_FILTER,
              value: val,
            }
          }),
        })
      }
    })
    return parsedFacetQueries
  }, [])
  return facetQueries
}

function parseFacetFieldValues (fieldName: string, array: any[], activeFilters: IActiveFilter[]): IParsedFacetValue[] {

  const parsedFacetFieldValues = array.reduce((fieldValues: IParsedFacetValue[], value, index, arr) => {

    // In gerade Indizes, stehen die Werte,
    // in ungeraden die Anzahl der Treffer
    // Leere Felder überspringen
    if (index % 2 === 0 && value.trim().length) {
      const isActive = isFilterActive(fieldName, value, activeFilters)
      fieldValues.push({
        field: fieldName,
        hits: arr[index + 1],
        id: `field-filter-${fieldName}-${value}`,
        image: getValueImage(fieldName, value),
        isActive,
        label: value,
        markedForActivation: isActive,
        type: FilterType.FIELD_FILTER,
        value,
      })
    }
    return fieldValues
  }, [])

  return parsedFacetFieldValues
}

function parseJSONFacetFieldValues (fieldName: string, array, activeFilters: IActiveFilter[]): IParsedFacetValue[] {

  array.sort((a: any, b: any) => (tryParseFloat(a.val) > tryParseFloat(b.val)) ? 1 : ((tryParseFloat(b.val) > tryParseFloat(a.val)) ? -1 : 0))
  return array.map((bucket) => {
    const isActive = isFilterActive(fieldName, bucket.val, activeFilters)
    return {
      field: fieldName,
      hits: bucket.count,
      id: `field-filter-${fieldName}-${bucket.val}`,
      image: getValueImage(fieldName, bucket.val),
      isActive,
      label: bucket.val,
      markedForActivation: isActive,
      type: FilterType.FIELD_FILTER,
      value: bucket.val,
    }
  })
}

function parseFacetRangeValues (fieldName: string, rangeFacet, currency: string, activeFilters: IActiveFilter[]):
  IParsedFacetRangeValue[] {

  const parsedFacetRanges: IParsedFacetRangeValue[] = []

  if (rangeFacet.before > 0) {
    const value = `[* TO ${rangeFacet.start}]`
    const isActive = isFilterActive(fieldName, value, activeFilters)
    parsedFacetRanges.push({
      field: fieldName,
      from: '*',
      hits: rangeFacet.before,
      id: `range-filter-${fieldName}-${value}`,
      image: getValueImage(fieldName, value),
      isActive,
      label: `${I18n.t('search.components.searchFilters.lessThen')} ${rangeFacet.end} ${currency}`,
      markedForActivation: isActive,
      to: rangeFacet.start,
      type: FilterType.RANGE_FILTER,
      value,
    })
  }

  rangeFacet.counts.forEach((val, index, array) => {
    if (index % 2 === 0) {
      const startValue = parseFloat(val)
      const endValue = startValue + rangeFacet.gap
      const value = `[${startValue} TO ${endValue}]`
      const isActive = isFilterActive(fieldName, value, activeFilters)
      parsedFacetRanges.push({
        field: fieldName,
        from: startValue,
        hits: array[index + 1],
        id: `range-filter-${fieldName}-${value}`,
        image: getValueImage(fieldName, value),
        isActive,
        label: `${val} - ${endValue} ${currency}`,
        markedForActivation: isActive,
        to: endValue,
        type: FilterType.RANGE_FILTER,
        value,
      })
    }
  })

  if (rangeFacet.after) {
    const value = `[${rangeFacet.end} TO *]`
    const isActive = isFilterActive(fieldName, value, activeFilters)
    parsedFacetRanges.push({
      field: fieldName,
      from: rangeFacet.end,
      hits: rangeFacet.after,
      id: `range-filter-${fieldName}-${value}`,
      image: getValueImage(fieldName, value),
      isActive,
      label: `${I18n.t('search.components.searchFilters.moreThen')} ${rangeFacet.end} ${currency}`,
      markedForActivation: isActive,
      to: '*',
      type: FilterType.RANGE_FILTER,
      value,
    })
  }

  // Optional Value für Slider hinzufügen
  const newValue = findActiveFilterMissingInArray(activeFilters, fieldName, parsedFacetRanges)
  if (newValue) {
    const values = newValue.match(/\[(\d+)\sTO\s(\d+)\]/)
    const startValue = parseFloat(values[1])
    const endValue = parseFloat(values[2])
    const value = `[${startValue} TO ${endValue}]`
    parsedFacetRanges.push({
      field: fieldName,
      from: startValue,
      hits: 1,
      id: `range-filter-${fieldName}-${value}`,
      image: getValueImage(fieldName, value),
      isActive: true,
      label: `${startValue} - ${endValue} ${currency}`,
      markedForActivation: true,
      to: endValue,
      type: FilterType.RANGE_FILTER,
      value,
    })
  }

  return parsedFacetRanges
}

function findActiveFilterMissingInArray (
  activeFilters: IActiveFilter[], fieldName: string, parsedValues: IParsedFacetValue[]): string | void {

  let newValue = void 0

  // Prüfen ob es einen Wert gibt, der nicht
  // im Array vorhanden ist
  activeFilters.find((filter) => {
    if (filter.field === fieldName) {
      filter.values.find((val) => {
        const index = parsedValues.map((parsedValue) => {
          return parsedValue.value
        }).indexOf(val)
        if (index < 0) {
          newValue = val
          return true
        }
        return false
      })
      return true
    }
    return false
  })

  return newValue
}

function parseFacetPivotValues (_fieldName: string, pivotFacets: any[], activeFilters: IActiveFilter[]):
  IParsedFacetPivotValue[] {
  const parsedFacetPivots = pivotFacets.reduce((parsedFacets: IParsedFacetPivotValue[], pivotObject) => {
    const parsedPivotHierarchy = parsePivotHierarchy(pivotObject, activeFilters)
    if (parsedPivotHierarchy) {
      setParentForPivotHierarchy(parsedPivotHierarchy.sub, parsedPivotHierarchy)
      parsedFacets.push(parsedPivotHierarchy)
    }
    return parsedFacets
  }, [])
  if (applicationSettings.sortFiltersBy === 'alpha') {
    parsedFacetPivots.sort((a, b) => (a.label > b.label) ? 1 : ((b.label > a.label) ? -1 : 0))
  }
  return parsedFacetPivots
}

function setParentForPivotHierarchy (subs: IParsedFacetPivotValue[], parent: IParsedFacetPivotValue): void {
  subs.forEach((sub) => {
    sub.parent = parent
    setParentForPivotHierarchy(sub.sub, sub)
  })
}

function parsePivotHierarchy (pivotObject, activeFilters: IActiveFilter[], parentObject?):
  IParsedFacetPivotValue | undefined {

  if (pivotObject.value == null || typeof pivotObject.value === 'string' && !pivotObject.value.length) {
    return
  }

  pivotObject.constraints = constructHierarchyConstraintsString(
    pivotObject.field, pivotObject.value, (parentObject ? parentObject.constraints : void 0),
  )

  const subPivots = (pivotObject.pivot || []).reduce((parsedSubPivots: IParsedFacetPivotValue[], subPivotObject) => {
    const parsedSubPivotObject = parsePivotHierarchy(subPivotObject, activeFilters, pivotObject)
    if (parsedSubPivotObject) {
      parsedSubPivots.push(parsedSubPivotObject)
    }
    return parsedSubPivots
  }, [])

  if (applicationSettings.sortFiltersBy === 'alpha') {
    subPivots.sort((a: IParsedFacetField, b: IParsedFacetField) => (a.label > b.label) ? 1 : ((b.label > a.label) ? -1 : 0))
  }

  const isActive = isFilterActive(pivotObject.field, pivotObject.value, activeFilters)

  if (isActive && pivotObject.field === 'hierarchy_lvl_0') {
    setActiveCatalogueCategoryToStore(false, {
      filterQuery: pivotObject.constraints,
      label: getLabelFromFacetFieldValue(pivotObject.value),
    })
  }

  return {
    constraints: pivotObject.constraints,
    field: pivotObject.field,
    headerImage: getHeaderImageFromJSONFacets(pivotObject.field, pivotObject.value),
    hits: pivotObject.count,
    id: `pivot-filter-${pivotObject.field}-${pivotObject.value}`,
    image: getTileImageFromJSONFacets(pivotObject.field, pivotObject.value),
    isActive,
    label: getLabelFromFacetFieldValue(pivotObject.value),
    level: getHierarchyLevelFromFieldname(pivotObject.field),
    markedForActivation: isActive,
    parent: void 0,
    sub: subPivots,
    type: FilterType.PIVOT_FILTER,
    value: pivotObject.value,
  }
}

function getHierarchyLevelFromFieldname (fieldName: string): number {
  const match = /^hierarchy_lvl_(\d+)$/.exec(`${fieldName}`)
  if (!match) {
    return -1
  }
  return parseInt(match[1], 10)
}

function parseCategoryImageName (imageNameWithPrefix: string): ICategoryImage {
  const match = /^hierarchy_lvl_(\d+)\$(\d{6})\$(.*)$/.exec(`${imageNameWithPrefix}`)
  if (!match) {
    return {
      image: '',
      index: '000000',
      level: -1,
    }
  }
  return {
    image: match[3],
    index: match[2],
    level: parseInt(match[1], 10),
  }
}

function constructHierarchyConstraintsString (fieldName: string, fieldValue: string, parentConstraints?: string):
  string {

  let valueEncapsulator = ''
  if (/[\s+\-&|!(){}[\]^~*?:\\\/]/.test(fieldValue)) {
    valueEncapsulator = '"'
  }

  return (parentConstraints ? `${parentConstraints} AND ` : '') +
    `${fieldName}:${valueEncapsulator}${fieldValue}${valueEncapsulator}`
}

function getLabelFromFacetFieldValue (fieldValue: string): string {
  if (typeof fieldValue !== 'string') {
    return ''
  }
  return fieldValue.slice(categoryNameSliceLength)
}

function parseHiearchyFieldValue (fieldValue: string): {index: string, payload: string } {
  if (typeof fieldValue !== 'string') {
    return {
      index: void 0,
      payload: fieldValue,
    }
  }

  const match = /^(\d{6})(.*)$/.exec(`${fieldValue}`)
  if (!match) {
    return {
      index: void 0,
      payload: fieldValue,
    }
  }

  return {
    index: match[1],
    payload: match[2],
  }
}

function addFieldLabelsFromJSONFacets (rawResponse: any): void {
  if (rawResponse && rawResponse.responseHeader && rawResponse.responseHeader.params
    && rawResponse.responseHeader.params['json.facet']) {
    try {
      const facetDefinitions = JSON.parse(rawResponse.responseHeader.params['json.facet'])
      for (const fieldName in facetDefinitions) {
        if (fieldName && facetDefinitions[fieldName].field && facetDefinitions[fieldName].label) {
          jsonFacetLabels[facetDefinitions[fieldName].field] = facetDefinitions[fieldName].label
        }
      }
    } catch (err) {
      console.error('Could not parse json facets: "' + err + '"')
    }
  }
}

function getHeaderImageFromJSONFacets (fieldName: string, fieldValue: string): string {
  if (typeof fieldValue !== 'string') {
    return ''
  }

  const data  = parseHiearchyFieldValue(fieldValue)
  const level = getHierarchyLevelFromFieldname(fieldName)
  let image = ''

  categoryHeaderImages
    .some((img) => {
      if (img.level === level && img.index === data.index) {
        image = img.image
        return true
      }
    })

  return image
}

function getTileImageFromJSONFacets (fieldName: string, fieldValue: string): string {
  if (typeof fieldValue !== 'string') {
    return ''
  }

  const data  = parseHiearchyFieldValue(fieldValue)
  const level = getHierarchyLevelFromFieldname(fieldName)
  let image = ''

  categoryTileImages
    .some((img) => {
      if (img.level === level && img.index === data.index) {
        image = img.image
        return true
      }
    })

  return image
}

function getCurrency (rawResponse): string {
  const doc = rawResponse.response && Array.isArray(rawResponse.response.docs) && rawResponse.response.docs.length
    ? rawResponse.response.docs[0]
    : void 0

  if (doc && doc.price_c) {
    return doc.price_c.slice(doc.price_c.lastIndexOf(',') + 1)
  }
  if (doc && doc.currency) {
    return doc.currency
  }
  return user.currency
}

function getStatsForField (rawResponse, fieldName: string): object | void {
  const stats = rawResponse.stats && rawResponse.stats.stats_fields && rawResponse.stats.stats_fields[fieldName]
    ? rawResponse.stats.stats_fields[fieldName]
    : void 0

  return stats
}

function getFilterLabel (fieldName: string): string {
  switch (fieldName) {
    case 'matkl':
    case 'supplier':
    case 'price':
    case 'mvgr2':
    case 'color_s':
    case 'mvgr3':
    case 'mvgr4':
    case 'material_s':
    case 'power_s':
    case 'eek_classes':
      return I18n.t(`search.filterLabels.${fieldName}`)
    default:

      // Bezeichnung für dynamische Filter aus SAP Klassifizierung ("prop_[atnam]_s")
      // eslint-disable-next-line no-prototype-builtins
      if (jsonFacetLabels.hasOwnProperty(fieldName)) {
        return jsonFacetLabels[fieldName]
      }

      // Bezeichnung für Kategoriebaum
      if (fieldName.substring(0, 16) === 'hierarchy_lvl_0,') {
        return I18n.t('search.filterLabels.hierarchy')
      }

      // Default
      return fieldName
  }
}

function getValueLabel (fieldName: string, value: string, filters: IParsedFacets, filterType?: FilterType): string {

  let valueLabel = value

  flattenFilters(filters).some((filter) => {
    if ((filterType ? filter.type === filterType : true)
      && filter.field === fieldName && filter.value === value) {
      valueLabel = filter.label
      return true
    }
  })
  return valueLabel
}

function getValueImage (fieldName: string, value: string): string | void {
  switch (fieldName) {
    case 'eek_classes':
    case 'prop_energieeffizienz_klasse_s':
      return getEEKIconUrl(value)
    default:
      return void 0
  }
}

export function parseFilterString (filterQuery: string | string[], filterType?: FilterType):
  IActiveFilter[] {

  const activeFilters: IActiveFilter[] = []
  const filterQueryString = normalizeFilterQuery(filterQuery)

  if (!filterQueryString) {
    return activeFilters
  }

  /**
   * Die einzelnen Felder sind im fq-Parameters durch AND / OR getrennt.
   * Siehe http://wiki.apache.org/solr/CommonQueryParameters#fq
   */

  /*
  '
    ( supplier:"Testlieferant MS" OR supplier:"Kermi MD_1" OR supplier:"Testlieferant AR-Grohe1" )
    AND ( matkl:"Test WG ZFIS" ) AND ( category:TEST )
  '
  */
  filterQueryString.split(/\s+AND\s+/g).forEach((fieldString) => {

    /*
    [
      '( supplier:"Testlieferant MS" OR supplier:"Kermi MD_1" OR supplier:"Testlieferant AR-Grohe1" )',
      '( matkl:"Test WG ZFIS" )',
      '( category:TEST )'
    ]
    */

    fieldString = fieldString.replace(/^\s*\(\s*|\s*\)\s*$/g, '')

    /*
    [
      'supplier:"Testlieferant MS" OR supplier:"Kermi MD_1" OR supplier:"Testlieferant AR-Grohe1"',
      'matkl:"Test WG ZFIS"',
      'category:TEST'
    ]
    */

    const fieldName = fieldString.trim().slice(0, fieldString.indexOf(':'))
    const fieldNameRegex = new RegExp('^\\\s*' + fieldName + '\\\s*:\\\s*', 'g')

    fieldString = fieldString.replace(fieldNameRegex, '')
    fieldString = fieldString.replace(/^\s*\(\s*/g, '')
    const filterValues = fieldString.split(/\s+OR\s+/g)

    /*
    [
      'supplier:"Testlieferant MS"',
      'supplier:"Kermi MD_1"',
      'supplier:"Testlieferant AR-Grohe1"'
    ]
    */

    filterValues.forEach((filterValue, index) => {
      filterValues[index] = filterValue.replace(fieldNameRegex, '')

      /*
      [
        '"Testlieferant MS"',
        '"Kermi MD_1"',
        '"Testlieferant AR-Grohe1"'
      ]
      */

      filterValues[index] = filterValue.replace(/^"(.+)"$/g, '$1')

      /*
      [
        'Testlieferant MS',
        'Kermi MD_1',
        'Testlieferant AR-Grohe1'
      ]
      */
    })

    activeFilters.push({
      field: fieldName,
      label: getFilterLabel(fieldName),
      type: filterType || void 0,
      values: filterValues,
    })

    /*
    [
      {field: 'supplier', values: ['Apple']},
      {field: 'mvgr2', values: ['blau', 'weiß']},
    ]
    */
  })
  return activeFilters
}

function normalizeFilterQuery (filterQuery: string | string[]): string {

  let queryFilterString = ''
  const findFilterTagsRegex = /\s*\{\s*!tag\s*=\s*[\u00C0-\u017Fa-zA-Z0-9_-]+\s*\}\s*/g

  if (typeof filterQuery === 'string') {
    queryFilterString = filterQuery.replace(findFilterTagsRegex, '')
  } else if (Array.isArray(filterQuery)) {
    queryFilterString = filterQuery.map((fieldFilter) => {
      return fieldFilter.replace(findFilterTagsRegex, '')
    }).join(' AND ')
  }

  return queryFilterString
}

export function activateFilter (filter: IParsedFacetValue): void {

  if (!filter) {
    return
  }

  if (filter.type === FilterType.PIVOT_FILTER) {

    // Übergeordneten Kategorien aktivieren
    getParentFilters(filter as IParsedFacetPivotValue).forEach((pivotFilter) => {
      pivotFilter.isActive = true
    })

    // Geschwister-Kategorien deaktivieren
    getSiblingFilters(filter as IParsedFacetPivotValue).forEach((pivotFilter) => {
      pivotFilter.isActive = false
    })

    // Untergeordnete Kategorien deaktivieren
    getChildFilters(filter as IParsedFacetPivotValue).forEach((pivotFilter) => {
      pivotFilter.isActive = false
    })
  }

  filter.isActive = true
}

export function deactivateFilter (filter: IParsedFacetValue): void {

  if (!filter) {
    return
  }

  if (filter.type === FilterType.PIVOT_FILTER) {

    // Untergeordnete Kategorien deaktivieren
    getChildFilters(filter as IParsedFacetPivotValue).forEach((pivotFilter) => {
      pivotFilter.isActive = false
    })
  }

  filter.isActive = false
}

export function toggleFilter (id: string, filters: IParsedFacets): void {

  const filter = getFilterById(id, filters)

  if (!filter) {
    return
  }

  if (filter.isActive) {
    deactivateFilter(filter)
  } else {
    activateFilter(filter)
  }
}

export function activateMarkedFilters (filters: IParsedFacets): void {
  flattenFilters(filters).forEach((filter) => {
    if (filter.markedForActivation) {
      filter.isActive = true
      filter.markedForActivation = false
    } else {
      filter.isActive = false
    }
  })
}

export function resetFilter (fieldName: string, value: string, filters: IParsedFacets): void {
  flattenFilters(filters)
    .some((filter) => {
      if (filter.field === fieldName && filter.value === value) {
        if (filter.type === FilterType.PIVOT_FILTER) {
          toggleFilter(filter.id, filters)
          return true
        }
        filter.isActive = false
        return true
      }
    })
}

export function resetAllFilters (filters: IParsedFacets, keepCategory: boolean = true): void {
  flattenFilters(filters).forEach((filter) => {
    if (keepCategory && filter.type === FilterType.PIVOT_FILTER) {
      return
    }
    filter.isActive = false
  })
}

export function getParentFilters (filter: IParsedFacetPivotValue): IParsedFacetPivotValue[] {

  const parentFilters = []

  if (!filter || !filter.parent) {
    return parentFilters
  }

  let currentFilter = filter.parent
  do {
    parentFilters.unshift(currentFilter)
    currentFilter = currentFilter.parent
  } while (currentFilter)

  return parentFilters
}

export function getChildFilters (filter: IParsedFacetPivotValue): IParsedFacetPivotValue[] {
  if (!filter || !filter.sub.length) {
    return []
  }

  return flattenPivotFilters(filter.sub)
}

export function getSiblingFilters (filter: IParsedFacetPivotValue): IParsedFacetPivotValue[] {
  if (!filter.parent) {
    return []
  }

  // Die Kategorie selbst herausfiltern
  const siblingFilters = filter.parent.sub.filter((pivotFilter) => {
    return pivotFilter !== filter
  })

  return flattenPivotFilters(siblingFilters)
}

function flattenActiveFilters (activeFilters: IActiveFilter[], filters?: IParsedFacets): IActiveFilterFlat[] {

  const flattenedActiveFilters = activeFilters.reduce((flattenedFilters, filter) => {
    filter.values.forEach((value) => {
      flattenedFilters.push({
        field: filter.field,
        id: `active-filter-${filter.field}-${value}`,
        label: filter.label,
        type: filter.type,
        value,
        valueLabel: getValueLabel(filter.field, value, filters, filter.type),
      })
    })
    return flattenedFilters
  }, [] as IActiveFilterFlat[])

  return flattenedActiveFilters
}

function flattenFilters (filters: IParsedFacets): IParsedFacetValue[] {

  let flattenedFilters = []

  Object.keys(filters).forEach((filterType) => {
    filters[filterType].forEach((filter: IParsedFacetField) => {
      if (filter.type === FilterType.PIVOT_FILTER) {
        flattenedFilters = flattenedFilters.concat(flattenPivotFilters(filter.values as IParsedFacetPivotValue[]))
      } else {
        flattenedFilters = flattenedFilters.concat(filter.values)
      }
    })
  })

  return flattenedFilters
}

function flattenPivotFilters (pivotFilters: IParsedFacetPivotValue[]): IParsedFacetPivotValue[] {
  if (!pivotFilters.length) {
    return []
  }

  const flattenedPivotFilters = pivotFilters.reduce((flattenedFilters: IParsedFacetPivotValue[], filter) => {
    flattenedFilters.push(filter)
    flattenPivotFilters(filter.sub).forEach((fltr) => {
      flattenedFilters.push(fltr)
    })
    return flattenedFilters
  }, [])

  return flattenedPivotFilters
}

export function resetHierarchyFilters (filters: IParsedFacets): void {
  store.dispatch('updateActiveCategory', {
    filterQuery: '',
    label: I18n.t('components.formInputProductSearch.allCategories'),
    manuallyChanged: false,
  })
  flattenFilters(filters)
    .filter((filter) => {
      return filter.type === FilterType.PIVOT_FILTER && filter.field.substring(0, 14) === 'hierarchy_lvl_'
    })
    .forEach((hierarchyFilter) => {
      hierarchyFilter.isActive = false
    })
}

export function getDeepestActiveHierarchyFilter (pivotFilter: IParsedFacetPivotValue): IParsedFacetPivotValue {

  let currentDeepest = pivotFilter

  if (pivotFilter.isActive) {
    getChildFilters(pivotFilter)
      .filter((filter) => {
        return filter.isActive
      })
      .forEach((filter) => {
        if (filter.level > currentDeepest.level) {
          currentDeepest = filter
        }
      })
  }
  return currentDeepest
}

export function getDeepestActiveHierarchyFilterWithSubs (pivotFilter: IParsedFacetPivotValue): IParsedFacetPivotValue {

  let deepestWithSubs = getDeepestActiveHierarchyFilter(pivotFilter)

  while (!deepestWithSubs.sub.length && deepestWithSubs.parent) {
    deepestWithSubs = deepestWithSubs.parent
  }
  return deepestWithSubs
}

export function getActiveFilters (filters: IParsedFacets): IActiveFilter[] {

  const activeFilters = []

  flattenFilters(filters)
    .filter((filter) => {
      return filter.isActive
    })
    .forEach((activeFilter) => {

      // Prüfen, ob es schon ein Filter-Objekt für dieses Feld gibt
      // Sonst erzeugen
      let existingActiveFilter = activeFilters.find((object) => {
        return object.field === activeFilter.field
      })
      if (!existingActiveFilter) {
        existingActiveFilter = {
          field: activeFilter.field,
          label: getFilterLabel(activeFilter.field),
          type: activeFilter.type,
          values: [],
        }
        activeFilters.push(existingActiveFilter)
      }
      existingActiveFilter.values.push(activeFilter.value)
    })

  return activeFilters
}

export function getActiveFiltersFlat (filters: IParsedFacets): IActiveFilterFlat[] {
  return flattenActiveFilters(getActiveFilters(filters), filters)
}

function isFilterActive (fieldName: string, value: string, activeFilters: IActiveFilter[]): boolean {
  if (!activeFilters || !activeFilters.length) {
    return false
  }

  // Gibt true zurück, wenn ein Filter für dem übergebenen Feldnamen
  // mit dem entsprechenden Wert gefunden wird
  return activeFilters.some((filter) => {
    return filter.field === fieldName && filter.values.indexOf(value) >= 0
  })
}

export function constructFilterQuery (fieldName: string, fieldValue: string | string[]): string {

  const values = Array.isArray(fieldValue) ? fieldValue : [fieldValue]
  const valueArray = []

  values.forEach((value) => {
    if (typeof value === 'string') {
      let valueEncapsulator = ''

      /* Filterwert nur durch Gänsefüsschen einfassen, wenn es sich nicht um einen Range-Filter handelt. */
      const matchResult = value.match(/\S+/g)
      if (value.length === 0
        || matchResult && (matchResult.length > 1 || /[\s+\-&|!(){}[\]^~*?:\\\/]/.test(value))
          && !value.match(/^\[\s*(\d+\.?\d*|\*)\s+TO\s+(\d\.?\d*|\*)\s*\]$/)) {
        valueEncapsulator = '"'
      }
      valueArray.push(valueEncapsulator + value + valueEncapsulator)
    }
  })
  const fieldString = fieldName + ':(' + valueArray.join(' OR ') + ')'
  return fieldString
}

export function serializeActiveFilters (activeFilters: IActiveFilter[]): string {
  // return 'mvgr2:(gold OR weiß) AND supplier:(Apple)'

  const filterArray = []

  activeFilters.forEach((filter) => {
    filterArray.push(constructFilterQuery(filter.field, filter.values))
  })
  return filterArray.join(' AND ')
}

export function getFilterById (id: string, filters: IParsedFacets): IParsedFacetValue {

  let requestedFilter

  flattenFilters(filters).some((filter) => {
    if (filter.id === id) {
      requestedFilter = filter
      return true
    }
    return false
  })

  return requestedFilter
}

export function findFilter (field: string, value: string, filters: IParsedFacets, type?: FilterType)
  : IParsedFacetValue {

  let requestedFilter

  flattenFilters(filters).some((filter) => {
    if (filter.field === field && filter.value === value && (type ? filter.type === type : true)) {
      requestedFilter = filter
      return true
    }
    return false
  })

  return requestedFilter
}

export function generateArticleFromSearchResult (searchResult) {
  return new Article(searchResult.matnr, searchResult.bismt, {
    cross: searchResult.cross,
    currency: searchResult.currency,
    eekClasses: searchResult.eek_classes,
    imagePath: searchResult.picture,
    maktx1: searchResult.maktx1,
    maktx2: searchResult.maktx2,
    maktx3: searchResult.maktx3,
    maktx4: searchResult.maktx4,
    priceGross: searchResult.price,
    priceGrossQuantityUnit: searchResult.kpein,
    priceGrossUnit: searchResult.kmein,
    quantity: searchResult.qty_stepsize,
    stepsize: searchResult.qty_stepsize,
    unit: searchResult.meins,
    unitFormatted: searchResult.mseh3,
  })
}
