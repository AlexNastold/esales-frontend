export function isGeolocationSupported () {
  return 'geolocation' in navigator
}

export async function getLocation () {
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(resolve, reject)
  })
}
