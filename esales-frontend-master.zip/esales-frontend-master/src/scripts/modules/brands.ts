import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'

export interface IBrandLogo {
  supplierId: string,
  supplierName: string,
  logo: string,
}

/**
 * Returns brands
 *
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getBrands (): Promise<IBrandLogo[]> {
  const data: any = await axiosBackend.get('webservices/misc.ws', { params: {
    event: 'GET_BRANDS',
  }})

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return data.result
}
