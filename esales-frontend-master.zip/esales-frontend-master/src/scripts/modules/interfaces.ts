import { IArticleEEKItem} from '@scripts/modules/eek'

export interface IListArticle {
  matnr: string,
  matnrDisplay: string,
  maktx?: string,
  maktx2?: string,
  image?: string,
  retailPrice?: {
    price?: number,
    currency?: string,
    costUnit?: number,
    volumeUnit?: string,
  },
  unit: string,
  unitFormatted: string,
  stepsize: number,
  eek?: IArticleEEKItem[],
  additionalMaterialCategories: IAdditionalMaterialCategory[],
}

export interface IAdditionalMaterialCategory {
  type: string,
  label: string,
}

export interface IMaterialsInComponentState {
  materials: [string],
  numberOfArticles: number,
}
