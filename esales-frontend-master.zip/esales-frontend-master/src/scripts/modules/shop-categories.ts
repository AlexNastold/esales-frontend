import { ErrorCode, ShopError } from '@scripts/modules/errors'
import { applicationSettings } from '@scripts/app/settings'
import { axiosBackend } from '@scripts/core/axios'

/**
 * Gibt die Toplevel Katalogkategorien zurück
 *
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getShopCategories (limit?: number): Promise<{
  amountAll: number,
  categories: {
    label: string,
    image: string,
    filterQuery: string,
    articleAmount: number,
  }[],
}> {
  const data: any = await axiosBackend.get('webservices/misc.ws', { params: {
    event: 'GET_SHOP_CATEGORIES',
    iv_limit: limit,
  }})

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE)
  }

  if (applicationSettings.sortFiltersBy === 'alpha') {
    data.result.categories.sort((a, b) => (a.label > b.label) ? 1 : ((b.label > a.label) ? -1 : 0))
  }

  return data.result
}
