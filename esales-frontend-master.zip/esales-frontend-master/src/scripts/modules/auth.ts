import { ErrorCode, ShopError} from '@scripts/modules/errors'
import { axiosBackend } from '@scripts/core/axios'

export enum LoginMode {
  IDS = 'IDS',
  OCI = 'OCI',
  SHK = 'SHK',
  NORMAL = '',
}

/**
 * Login as a normal user
 *
 * @throws {ErrorCode.SHOP_LOCKED}
 * @throws {ErrorCode.LOGIN_INVALID_CREDENTIALS}
 * @throws {ErrorCode.USER_LOCKED}
 * @throws {ErrorCode.DEBITOR_LOCKED}
 * @throws {ErrorCode.USER_INITIAL}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function login (
  username,
  password,
  {
    mode = LoginMode.NORMAL,
    ramId,
    sessionId,
  }: {
    mode?: LoginMode,
    ramId?: string,
    sessionId?: string,
  } = {},
): Promise<{
  showAdmaLogin?: boolean,
  hasToAcceptTerms?: boolean,
}> {

  await closeSession()

  const data: any = await axiosBackend.post('webservices/auth.ws', {
    event: 'LOGIN',
    iv_cmd: mode,
    iv_ignore_old_session: 'X',
    iv_password: password,
    iv_ram: ramId,
    iv_username: username,
    s: sessionId,
  })

  // status:
  // OK
  // ERROR

  // status: ERROR, message:
  // OLD_SESSION: Es gibt bereits eine Session für diesen User (wird zukünftig ignoriert)
  // NO_GUEST: Gast-Login nicht verfügbar (nur bei event=LOGIN_GUEST)
  // NO_NEW_PWD: Passwort ist initial, es wurde kein neues Passwort mitgegeben (nur bei event=LOGIN_INIT)
  // GUEST_ERROR: Fehler beim Gastlogin (nur bei event=LOGIN_GUEST)

  // Rückgabe:
  // showAdmaLogin: true/false (nur bei event LOGIN oder LOGIN_INIT)

  if (data.status === 'ERROR') {
    switch (data.code) {

      // CLOSE oder SHOP_LOCK: Shop im Wartungsmodus und User nicht in Ausnahmetabelle
      case 'CLOSE':
      case 'SHOP_LOCK':
        throw new ShopError(ErrorCode.SHOP_LOCKED, data.message)

      // FALSE:
      //  - Keine Benutzerkennung übergeben
      //  - User-Id nicht gefunden
      //  - Keine Berechtigung für diesen Shop
      //  - OCI-User will sich beim normalen Login anmelden
      // BLOCK: Falsches Passwort, weitere Versuche erlaubt
      // NOOCI: Nicht-OCI-User will sich per OCI einloggen
      case 'FALSE':
      case 'BLOCK':
      case 'NOOCI':
        throw new ShopError(ErrorCode.LOGIN_INVALID_CREDENTIALS, data.message)

      // LOCK: Zu oft falsch eingegeben
      // LOCK3: Letzer Versuch verspielt
      case 'LOCK':
      case 'LOCK3':
        throw new ShopError(ErrorCode.USER_LOCKED, data.message)

      // LOCK4: Debitorstammsatz ist gesperrt
      // KNA1: Kein KNA1-Satz zur Kundennummer vorhanden
      case 'LOCK4':
      case 'KNA1':
        throw new ShopError(ErrorCode.DEBITOR_LOCKED, data.message)

      // INIT: Passwort ist noch initial
      case 'INIT':
        throw new ShopError(ErrorCode.USER_INITIAL, data.message)

      // I_EXP: Passwort ist noch initial, aber abgelaufen
      case 'I_EXP':
        throw new ShopError(ErrorCode.USER_INITIAL_EXPIRED, data.message)

      // NOKAT: Kein Katalog zugeordnet
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return {
    hasToAcceptTerms: data.result.hasToAcceptTerms,
    showAdmaLogin: data.result.showAdmaLogin,
  }
}

/**
 * Login as an initial user
 *
 * @throws {ErrorCode.SHOP_LOCKED}
 * @throws {ErrorCode.LOGIN_INVALID_CREDENTIALS}
 * @throws {ErrorCode.USER_LOCKED}
 * @throws {ErrorCode.DEBITOR_LOCKED}
 * @throws {ErrorCode.LOGIN_PASSWORD_ALREADY_USED}
 * @throws {ErrorCode.LOGIN_MISSING_NEW_PASSWORD}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function loginInitial (
  username: string,
  password: string,
  passwordNew: string,
  passwordNewConfirm: string,
  {
    mode = LoginMode.NORMAL,
    ramId,
  }: {
    mode?: LoginMode,
    ramId?: string,
  } = {},
): Promise<{
  showAdmaLogin?: boolean,
  hasToAcceptTerms?: boolean,
}> {

  await closeSession()

  const data: any = await axiosBackend.post('webservices/auth.ws', {
    event: 'LOGIN_INIT',
    iv_cmd: mode,
    iv_password: password,
    iv_password_new1: passwordNew,
    iv_password_new2: passwordNewConfirm,
    iv_ram: ramId,
    iv_username: username,
  })

  // Rückgabe:
  // showAdmaLogin: true/false (nur bei event LOGIN oder LOGIN_INIT)

  if (data.status === 'ERROR') {
    switch (data.code) {

      // CLOSE oder SHOP_LOCK: Shop im Wartungsmodus und User nicht in Ausnahmetabelle
      case 'CLOSE':
      case 'SHOP_LOCK':
        throw new ShopError(ErrorCode.SHOP_LOCKED, data.message)

      // FALSE:
      //  - Keine Benutzerkennung übergeben
      //  - User-Id nicht gefunden
      //  - Keine Berechtigung für diesen Shop
      //  - OCI-User will sich beim normalen Login anmelden
      // BLOCK: Falsches Passwort, weitere Versuche erlaubt
      // NOOCI: Nicht-OCI-User will sich per OCI einloggen
      case 'FALSE':
      case 'BLOCK':
      case 'NOOCI':
        throw new ShopError(ErrorCode.LOGIN_INVALID_CREDENTIALS, data.message)

      // LOCK: Zu oft falsch eingegeben
      // LOCK3: Letzer Versuch verspielt
      case 'LOCK':
      case 'LOCK3':
        throw new ShopError(ErrorCode.USER_LOCKED, data.message)

      // LOCK4: Debitorstammsatz ist gesperrt
      case 'LOCK4':
        throw new ShopError(ErrorCode.DEBITOR_LOCKED, data.message)

      // HIST: Passwort wurde in letzter Zeit bereits benutzt
      case 'HIST':
        throw new ShopError(ErrorCode.LOGIN_PASSWORD_ALREADY_USED, data.message)

      // NO_NEW_PWD: Es wurde kein neues Passwort mitgegeben
      case 'NO_NEW_PWD':
        throw new ShopError(ErrorCode.LOGIN_MISSING_NEW_PASSWORD, data.message)

      // NOKAT: Kein Katalog zugeordnet
      // KNA1: Kein KNA1-Satz zur Kundennummer vorhanden
      default:
        throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
    }
  }

  if (data.status === 'WARNING') {
    if (data.use_validator === 'X') {
      throw new ShopError(ErrorCode.INVALID_FIELDS, data.message, {
        fieldErrors: data.data_ref_as_json,
      })
    }
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  return {
    hasToAcceptTerms: data.result.hasToAcceptTerms,
    showAdmaLogin: data.result.showAdmaLogin,
  }
}

/**
 * Login as Adma
 *
 * @param userId - ID of the user to login with
 *
 * @throws {ErrorCode.NO_AUTHORIZATION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function loginAdma (userId: string): Promise<void> {
  const data: any = await axiosBackend.post('webservices/auth.ws', {
    event: 'LOGIN_ADMA',
    iv_user_id: userId,
  })

  if (data.status === 'ERROR') {
    if (data.code === 'NO_AUTHORIZATION') {
      throw new ShopError(ErrorCode.NO_AUTHORIZATION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export interface IAdmaCustomer {
  kunnr: string,
  name1: string,
  name2: string,
  street: string,
  postalCode: string,
  city: string,
  country: string,
  vkorg: string,
  vtweg: string,
  sparte: string,
  userId: string,
}

/**
 * Get the customer list for an adma user
 *
 * @throws {ErrorCode.NO_SESSION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function getAdmaCustomerList ({
  filter,
  start = 0,
  amount = 10,
}: {
  filter?: string,
  start?: number,
  amount?: number,
} = {}): Promise<{
  paging: {
    pages: number,
    currentPage: number,
    amountPerPage: number,
  },
  customers: IAdmaCustomer[],
}> {
  const data: any = await axiosBackend.get('webservices/auth.ws', { params: {
    event: 'GET_ADMA_LIST',
    iv_filter: filter,
    iv_rows: amount,
    iv_start: start,
  }})

  if (data.status === 'ERROR') {
    if (data.code === 'NOSESSION') {
      throw new ShopError(ErrorCode.NO_SESSION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }

  const pages = Math.ceil(data.result.amount / data.result.rows)
  const currentPage = Math.floor(data.result.start / data.result.rows)

  return {
    customers: data.result.customers,
    paging: {
      amountPerPage: amount,
      currentPage,
      pages,
    },
  }
}

/**
 * Logout
 *
 * @throws {ErrorCode.NO_SESSION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function logout ({ saveBasket = true }: { saveBasket?: boolean } = {}): Promise<void> {
  const data: any = await axiosBackend.post('webservices/auth.ws', {
    event: 'LOGOUT',
    iv_save_basket: saveBasket ? 'X' : void 0,
  })

  if (data.status === 'ERROR') {
    if (data.code === 'NOSESSION') {
      throw new ShopError(ErrorCode.NO_SESSION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Close the session
 *
 * @throws Request error
 */
export async function closeSession (): Promise<void> {
  await axiosBackend.post('webservices/auth.ws', { event: 'EXIT_SESSION' })
}

/**
 * Accept the terms (after first login)
 *
 * @throws {ErrorCode.NO_SESSION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function acceptTerms (): Promise<void> {
  const data: any = await axiosBackend.post('webservices/auth.ws', { event: 'ACCEPT_TERMS' })

  if (data.status === 'ERROR') {
    if (data.code === 'NOSESSION') {
      throw new ShopError(ErrorCode.NO_SESSION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

/**
 * Deny the terms (after first login)
 *
 * @throws {ErrorCode.NO_SESSION}
 * @throws {ErrorCode.UNSPECIFIED}
 * @throws {ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE}
 * @throws Request error
 */
export async function denyTerms (): Promise<void> {
  const data: any = await axiosBackend.post('webservices/auth.ws', { event: 'DENY_TERMS' })

  if (data.status === 'ERROR') {
    if (data.code === 'NOSESSION') {
      throw new ShopError(ErrorCode.NO_SESSION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }

  if (data.status !== 'OK') {
    throw new ShopError(ErrorCode.UNEXPECTED_WEBSERVICE_RESPONSE, data.message)
  }
}

export async function pinCustomer (customerId: string, isCustomerPinned: boolean, vkorg: string, sparte: string, vtweg: string):
  Promise<void> {
  const data: any = await axiosBackend.post('webservices/auth.ws', {
    GV_IS_CUSTOMER_PINNED: isCustomerPinned,
    GV_KUNNR: customerId,
    GV_SPART: sparte,
    GV_VKORG: vkorg,
    GV_VTWEG: vtweg,
    event: 'TOGGLE_PIN_CUSTOMER',
  })

  if (data.status === 'ERROR') {
    if (data.code === 'NOSESSION') {
      throw new ShopError(ErrorCode.NO_SESSION, data.message)
    }
    throw new ShopError(ErrorCode.UNSPECIFIED, data.message)
  }
}
