import { applicationSettings } from '@scripts/app/settings'

interface IArticleInputAttributes {
  maktx1: string
  maktx2: string
  maktx3?: string
  maktx4?: string
  priceGross: number
  priceGrossQuantityUnit: number
  priceGrossUnit: string
  currency: string
  imagePath?: string
  eekClasses?: string[]
  quantity?: number
  stepsize?: number
  unit?: string,
  unitFormatted?: string,
  cross: string[],
}

interface IRetailPrice {
  price: number
  currency: string
  costUnit: number
  volumeUnit: string
}

interface IEEKClass {
  id: string,
  class: string,
  text: string
}

interface IAdditionalMaterialCategory {
  type: string,
  label: string,
}

export default class Article {

  public readonly matnr: string
  public readonly matnrDisplay: string
  public readonly bismt: string
  public readonly maktx: string
  public readonly maktx2: string
  public readonly maktx3: string
  public readonly maktx4: string
  public readonly image: string
  public readonly retailPrice: IRetailPrice
  public readonly eek: IEEKClass[]
  public readonly quantity: number
  public readonly stepsize: number
  public readonly unit: string
  public readonly unitFormatted: string
  public readonly additionalMaterialCategories: IAdditionalMaterialCategory[]

  constructor (matnr: string, bismt: string, attributes: IArticleInputAttributes) {
    this.matnr                  = matnr
    this.matnrDisplay           = bismt
    this.bismt                  = bismt
    // this.name                = [attributes.maktx1, attributes.maktx2, attributes.maktx3, attributes.maktx4].join(' ')
    this.maktx                  = attributes.maktx1
    this.maktx2                 = attributes.maktx2
    this.maktx3                 = attributes.maktx3
    this.maktx4                 = attributes.maktx4
    /*
    this.priceGross             = typeof attributes.priceGross === 'string'
      ? parseFloat(attributes.priceGross)
      : attributes.priceGross
    this.priceGrossQuantityUnit = attributes.priceGrossQuantityUnit
    this.priceGrossUnit         = attributes.priceGrossUnit
    this.currency               = attributes.currency
    */
    this.image                  = attributes.imagePath
    const retailPrice = typeof attributes.priceGross === 'string'
      ? parseFloat(attributes.priceGross)
      : attributes.priceGross
    const costUnit = typeof attributes.priceGrossQuantityUnit === 'string'
      ? parseFloat(attributes.priceGrossQuantityUnit)
      : attributes.priceGrossQuantityUnit
    this.retailPrice            = {
      costUnit,
      currency: attributes.currency,
      price: retailPrice,
      volumeUnit: attributes.priceGrossUnit,
    }

    // this.eekClasses             = attributes.eekClasses
    if (Array.isArray(attributes.eekClasses)) {
      this.eek                    = attributes.eekClasses.map((eekClass) => {
        return {
          class: eekClass,
          id: '', // To-Do
          text: '', // To-Do
        }
      })
    }
    this.quantity               = attributes.quantity
    this.stepsize               = attributes.stepsize
    this.unit                   = attributes.unit
    this.unitFormatted          = attributes.unitFormatted

    if (attributes.cross) {
      this.additionalMaterialCategories = attributes.cross.filter((c) => c).map((c) => {
        return {
          label: (applicationSettings.accessories[c] || c),
          type: c,
        }
      })
    } else {
      this.additionalMaterialCategories = []
    }
  }
}
