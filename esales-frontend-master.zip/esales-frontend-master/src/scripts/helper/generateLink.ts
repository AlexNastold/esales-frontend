export function detailLink (matnr: string, maktx: string, maktx2: string): string {
  if (!matnr || !maktx || matnr === '' || maktx === '') {
    return 'article'
  } else {
    return 'article-' + encodeURIComponent(maktx.replace(/\s/g, '-')) + '-' + encodeURIComponent(maktx2.replace(/\s/g, '-')) + (maktx2 !== '' ? '-' : '') + encodeURIComponent(matnr.replace(/^0+/, ''))
  }
}
