import { serverOrigin } from '@scripts/core/paths'

export function getExternalUrl (url: string): string {
  if (typeof url === 'string' && url.indexOf('/') === 0) {
    return `${serverOrigin}${url}`
  }
  return url
}
