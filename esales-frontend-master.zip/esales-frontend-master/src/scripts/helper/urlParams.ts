import qs from 'querystringify'

export const getQueryParameters = (except: string[] = []) => {
  const queryParameters = {...qs.parse(location.search)}

  // Parameter herausfiltern, die nicht zurückgegeben werden sollen
  Object.keys(queryParameters).forEach((key) => {
    if (except.indexOf(key) >= 0) {
      delete queryParameters[key]
    }
  })
  return queryParameters
}

export const getQueryParameter = (parameter) => getQueryParameters()[parameter]
