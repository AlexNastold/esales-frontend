import qs from 'querystringify'

export function updateUrlQueryString (params = {}, {
  ignoreFalsyValues = true,
  onlyWhenChanged = true,
  pushState = false,
}: {
  ignoreFalsyValues?: boolean,
  onlyWhenChanged?: boolean,
  pushState?: boolean,
} = {}) {

  const modifiedParams = {}

  // Optionally remove falsy values
  Object.keys(params).forEach((key) => {
    if (params[key] || ignoreFalsyValues === false) {
      modifiedParams[key] = params[key]
    }
  }, {})

  let urlQueryString = qs.stringify(modifiedParams)

  if (urlQueryString.length) {
    urlQueryString = '?' + urlQueryString
  }

  // Optionally update state only when it was changed
  // ToDo: nur die übergebenen Parameter vergleichen!?
  if (onlyWhenChanged && (urlQueryString === location.search)) {
    return
  }

  // Hack to allow removal of query parameter
  urlQueryString = urlQueryString || location.pathname

  if (pushState) {
    window.history.pushState(void 0, '', urlQueryString)
  } else {
    window.history.replaceState(void 0, '', urlQueryString)
  }
}

export function setUrlChangeHandler (handler) {
  window.addEventListener('popstate', handler)
}
