import moment from 'moment'

import { formatNumber, parseNumber } from '@scripts/helper/formatNumber'
import { applicationSettings } from '@scripts/app/settings'

/**
 * Returns a sap formatted currency value
 *
 * @param value - The number to format
 * @param [omitUnnecessaryDecimals=false] - Omit unnecessary decimals
 */
export function numberToSapCurrency (value: number, omitUnnecessaryDecimals: boolean = false): string {
  return formatNumber(value, {
    decimalPlaces: applicationSettings.decimalPlacesMoney,
    decimalSeparator: applicationSettings.decimalSeparator,
    omitUnnecessaryDecimals,
    thousandsSeparator: applicationSettings.thousandsSeparator,
  })
}

/**
 * Returns a sap formatted number
 *
 * @param value - The number to format
 * @param [omitUnnecessaryDecimals=false] - Omit unnecessary decimals
 */
export function numberToSapNumber (value: number, {
  omitUnnecessaryDecimals = false,
  negativeSignAtEnd = false,
}: {
  omitUnnecessaryDecimals?: boolean,
  negativeSignAtEnd?: boolean,
} = {}): string {
  return formatNumber(value, {
    decimalPlaces: applicationSettings.decimalPlaces,
    decimalSeparator: applicationSettings.decimalSeparator,
    negativeSignAtEnd,
    omitUnnecessaryDecimals,
    thousandsSeparator: applicationSettings.thousandsSeparator,
  })
}

/**
 * Returns a number from a sap formatted number
 *
 * @param value - The number to parse
 * @param [fallback] - Fallback, if the number cannot be parsed
 */
export function sapNumberToNumber<T> (value: string, fallback?: T): number | T
export function sapNumberToNumber (value: string, fallback: any = void 0): number {
  if (typeof value !== 'string') {
    return fallback
  }

  const parsedNumber = parseNumber(value, {
    decimalSeparator: applicationSettings.decimalSeparator,
    negativeSignAtEnd: true,
    thousandsSeparator: applicationSettings.thousandsSeparator,
  })

  if (!Number.isNaN(parsedNumber)) {
    return parsedNumber
  }

  return fallback
}

/**
 * Returns a sap formatted date
 *
 * @param value - The Date object to format
 */
export function dateToSapDate (value: Date) {
  return moment(value).format(applicationSettings.dateFormat)
}
