export function matches (queryText: string, text: string | string[]) {
  if (Array.isArray(text)) {
    text = text.join(' ')
  }
  const queries = queryText.split(' ')
  for (const query of queries) {
    if (text.toLowerCase().indexOf(query.toLowerCase()) === -1) {
      return false
    }
  }
  return true
}
