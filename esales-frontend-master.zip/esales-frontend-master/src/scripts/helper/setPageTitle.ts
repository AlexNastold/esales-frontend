export function setPageTitle (title: string, omitShopTitle = false) {
  const titleEl = document.head.querySelector('title')

  if (omitShopTitle) {
    titleEl.innerText = title
    return
  }

  if (title) {
    titleEl.innerText = `${title} - FIS/eSales dev`
    return
  }

  titleEl.innerText = 'FIS/eSales dev'
}
