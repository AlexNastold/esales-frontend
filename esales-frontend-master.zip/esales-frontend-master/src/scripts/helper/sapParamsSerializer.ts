import { isArrayBuffer, isBlob, isBuffer, isFile, isFormData, isStream } from 'axios/lib/utils'

export const sapParamsSerializer = (params, options?) => {
  const _defaults = {
    encode: true,
    encodeValuesOnly: false,
  }
  const _options = Object.assign({}, _defaults, options)

  const serializeArray = (prefix, array) => {
    const arr = []
    array.forEach((val, idx) => {
      arr.push(`${serialize(`${prefix}[${++idx}]`, val)}`)
    })
    return arr.join('&')
  }

  const serializeObject = (prefix, object) => {
    const arr = []
    Object.keys(object).forEach((key) => {
      arr.push(`${serialize(`${prefix}-${key}`, object[key])}`)
    })
    return arr.join('&')
  }

  const serializeElementary = (prefix, value) => {
    const key = _options.encode && !_options.encodeValuesOnly ? encodeURIComponent(`${prefix}`) : `${prefix}`
    value = (value === undefined) ? '' : value
    const val = _options.encode ? encodeURIComponent(`${value}`) : `${value}`
    return `${key}=${val}`
  }

  const serialize = (prefix, any) => {
    if (any instanceof Array) {
      return serializeArray(prefix, any)
    }
    if (any instanceof Object) {
      return serializeObject(prefix, any)
    }
    return serializeElementary(prefix, any)
  }

  if (params instanceof Object) {
    const arr = []

    // Ignore data passed as a second argument to axios
    // See https://github.com/axios/axios/blob/master/dist/axios.js#L590
    if (isFormData(params) ||
      isArrayBuffer(params) ||
      isBuffer(params) ||
      isStream(params) ||
      isFile(params) ||
      isBlob(params)
    ) {
      return params
    }

    Object.keys(params).forEach((key) => {
      if (typeof params[key] !== 'undefined') {
        arr.push(serialize(key, params[key]))
      }
    })
    return arr.join('&')
  }
  if (typeof params === 'string') {
    return params
  }
  if (!params) {
    return params
  }
  throw new Error('Only objects and strings supported')
}
