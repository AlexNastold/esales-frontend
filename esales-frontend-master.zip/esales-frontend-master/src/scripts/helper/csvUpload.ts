import { axiosBackend } from '@scripts/core/axios'
import i18next from 'i18next'
import { store } from '@scripts/core/setup/vuex'
// tslint:disable: max-classes-per-file
// tslint:disable: class-name
export class BasketCSV {
  private _csvData: []
  private _delimiter: string
  private _articleIndex: number
  private _amountIndex: number
  private _hasColumnHeadings: boolean

  get hasColumnHeadings (): boolean {
    return this._hasColumnHeadings
  }
  set hasColumnHeadings (hasColumnHeadings: boolean) {
    this._hasColumnHeadings = hasColumnHeadings
  }
  get delimiter (): string {
    return this._delimiter
  }

  set delimiter (delimiter: string) {
    this._delimiter = delimiter
  }

  get csvData (): [] {
    return this._csvData
  }
  set csvData (csvData: []) {
    this._csvData = csvData
  }

  get articleIndex (): number {
    return this._articleIndex
  }
  set articleIndex (articleIndex: number) {
    this._articleIndex = articleIndex
  }

  get amountIndex (): number {
    return this._amountIndex
  }
  set amountIndex (amountIndex: number) {
    this._amountIndex = amountIndex
  }

  get splittedCSVData (): string[][] {
    if (!this.csvData) {
      return null
    }
    return this.csvData.map((row: string) => {
      return row.split(this.delimiter)
    })
  }

  get rowsWithoutHeadline (): string[][] {
    if (!this.splittedCSVData) {
      return null
    }
    if (this.hasColumnHeadings) {
      return this.splittedCSVData.splice(1, this.splittedCSVData.length)
    } else {
      return this.splittedCSVData.splice(0, this.splittedCSVData.length)
    }
  }
  get positions (): object[] {
    if (!this.rowsWithoutHeadline) {
      return null
    }
    const positions = this.rowsWithoutHeadline.map((row: string[]) => {
      return {
        bismt: row[this.articleIndex],
        broken: (row[this.articleIndex] && row[this.amountIndex]) ? false : true,
        menge: row[this.amountIndex],
      }
    })
    return positions
  }

  get columns (): object[] {
    let selectOption = []

    if (!this.splittedCSVData) {
      return null
    }

    selectOption = this.splittedCSVData[0].map((_position, index) => {
      return {
        text: `${i18next.t('basket.components.csvUploadDialog.column')} ${index + 1} (${_position})`,
        value: index,
      }
    })

    selectOption.unshift({text: `${i18next.t('basket.components.csvUploadDialog.chooseColumn')}`, value: null})

    return selectOption
  }

  get amountBrokenColumns (): number {
    if (this.positions && this.positions.length >= 1 && this.articleIndex !== undefined && this.amountIndex !== undefined) {
      return this.positions.filter((position: any) => {
        return position.broken
      }).length
    }
    return 0
  }

  get amountColumns (): number {
    if (!this.rowsWithoutHeadline) {
      return null
    }
    return this.rowsWithoutHeadline.length
  }

  get body (): string[][] {
    if (!this.splittedCSVData) {
      return null
    }
    if (this.hasColumnHeadings) {
      return this.rowsWithoutHeadline.splice(0, 4)
    } else {
      return this.rowsWithoutHeadline.splice(0, 5)
    }

  }
  get headline (): string[] {
    if (this.hasColumnHeadings) {
      return this.splittedCSVData[0]
    } else {
      return null
    }
  }

  public async upload (): Promise<{}> {
    // eslint-disable-next-line no-async-promise-executor
    return new Promise(async (resolve, reject) => {
      const params = {
        event: 'ADD_CSV_TO_BASKET',
        it_addto: this.positions,
      }
      try {
        const response = await axiosBackend.post('webservices/basket.ws', params)
        resolve(response)
        store.dispatch('updateBasket')
      } catch (e) {
        reject(e)
      }
    })
  }
}
