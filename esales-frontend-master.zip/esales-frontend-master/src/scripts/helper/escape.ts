export function escapeHtml (html: string): string {
  const text = document.createTextNode(html)
  const div = document.createElement('div')
  div.appendChild(text)
  return div.innerHTML
}
