export enum RedirectMethod {
  POST = 'post',
  GET = 'get',
}

/**
 * Redirects to another page
 *
 * @param url           The url
 * @param [params]      The parameters as object
 * @param [method]      The method (get, post)
 * @param [attributes]  The form-attributes for POST requests
 * @param [options]
 */
export function redirect (
  url: string,
  params?: { [key: string]: string | number | void },
  method: RedirectMethod = RedirectMethod.GET,
  attributes?: any,
  { omitUndefined = true, openInNewTab = false }: { omitUndefined?: boolean, openInNewTab?: boolean } = {},
) {
  if (method && method === RedirectMethod.POST) {
    const form = document.createElement('form')
    form.action = url
    form.method = 'post'

    if (openInNewTab) {
      form.setAttribute('target', '_blank')
    }

    if (attributes && typeof attributes === 'object' && attributes !== null) {
      Object.keys(attributes).forEach((key) => form.setAttribute(key, attributes[key]))
    }

    if (params) {
      Object.keys(params).forEach((key) => {
        if (omitUndefined && typeof params[key] === 'undefined') {
          return
        }

        const formInput = document.createElement('input')
        formInput.type = 'hidden'
        formInput.name = key
        formInput.value = String(params[key])
        form.appendChild(formInput)
      })
    }
    document.body.appendChild(form)
    form.submit()
    document.body.removeChild(form)
    return
  }

  let urlParams = ''

  if (params) {
    const serializedParams = Object.entries(params)
      .filter(([, val]) => {
        if (omitUndefined && typeof val === 'undefined') {
          return false
        }
        return true
      })
      .map(([key, val]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(val))}`)
      .join('&')

    urlParams = `?${serializedParams}`
  }

  const newUrl = `${url}${urlParams}`

  if (openInNewTab) {
    window.open(newUrl)
  } else {
    window.location.href = newUrl
    if (newUrl.indexOf('#') !== -1) {
      location.reload()
    }
  }
}

export function reload () {
  location.reload()
}
