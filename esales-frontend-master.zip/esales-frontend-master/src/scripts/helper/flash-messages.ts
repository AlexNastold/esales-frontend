import browserStore from '@scripts/core/browserStore'

// Eindeutige Request-ID setzen
const requestId = Math.floor(Math.random() * 1000000)

// Initialwert setzen, falls es noch keinen gibt
if (!Array.isArray(browserStore.get('flashMessages'))) {
  browserStore.set('flashMessages', [])
}

/**
 * Setzt eine Flash-Message
 */
export function createFlashMessage (message: string, type: string = 'info', icon?: string) {
  browserStore.push('flashMessages', { icon, message, requestId, type})
}

/**
 * Gibt zurück, ob es Flash-Messages gibt
 */
export function hasFlashMessages () {
  const flashMessages = browserStore.get('flashMessages')
  if (Array.isArray(flashMessages)) {
    // Prüfen, ob es Flash-Messages von einem vorherigen Request gibt
    return flashMessages.some((flashMessage) => flashMessage.requestId !== requestId)
  }
}

/**
 * Gibt Flash-Messages zurück und löscht diese
 */
export function getFlashMessages () {
  const flashMessages = browserStore.get('flashMessages')
  if (Array.isArray(flashMessages)) {
    // Nur Flash-Messages von einem vorherigen Request zurückgeben und löschen
    const flashMessagesFromOtherRequests = flashMessages.filter((flashMessage) => flashMessage.requestId !== requestId)
    browserStore.set('flashMessages', flashMessages.filter((flashMessage) => flashMessage.requestId === requestId))
    return flashMessagesFromOtherRequests
  }
  return []
}
