/* eslint-disable no-useless-escape */
export function formatNumber (value: number, {
  decimalPlaces = 2,
  decimalSeparator,
  thousandsSeparator,
  omitUnnecessaryDecimals = false,
  negativeSignAtEnd = false,
}: {
  decimalPlaces?: number
  decimalSeparator?: string
  thousandsSeparator?: string,
  omitUnnecessaryDecimals?: boolean,
  negativeSignAtEnd?: boolean,
} = {}): string {

  if (typeof value !== 'number') {
    return void 0
  }

  let valueAbsolute = value
  let negative = false

  if (value < 0) {
    valueAbsolute = Math.abs(valueAbsolute)
    negative = true
  }
  // let pow
  // const valueWithDecimals = (Math.ceil(valueAbsolute *
  //  (pow = Math.pow(10,decimalPlaces || 0))) / pow).toFixed(decimalPlaces)
  const valueWithDecimals = valueAbsolute.toFixed(decimalPlaces)
  const valueWithDecimalsSplitted = valueWithDecimals.split('.')
  const hasFractional = valueWithDecimalsSplitted.length === 2
  const integerPart = valueWithDecimalsSplitted[0]
  const fractionalPart = valueWithDecimalsSplitted[1]

  let integerPartFormatted
  if (typeof thousandsSeparator !== 'undefined') {
    integerPartFormatted = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, thousandsSeparator)
  } else {
    integerPartFormatted = integerPart
  }

  let numberFormatted = integerPartFormatted

  if (!omitUnnecessaryDecimals && hasFractional) {
    numberFormatted += `${decimalSeparator}${fractionalPart}`
  }

  if (negative) {
    if (negativeSignAtEnd) {
      numberFormatted += '-'
    } else {
      numberFormatted = `-${numberFormatted}`
    }
  }

  return numberFormatted
}

export function parseNumber (value: string, {
  decimalSeparator,
  thousandsSeparator,
  negativeSignAtEnd = false,
}: {
  decimalSeparator?: string,
  thousandsSeparator?: string,
  negativeSignAtEnd?: boolean,
} = {}): number {

  let cleanValue = value
  let negative = false

  if (negativeSignAtEnd && cleanValue[cleanValue.length - 1] === '-') {
    cleanValue = cleanValue.slice(0, -1)
    negative = true
  }

  if (typeof thousandsSeparator !== 'undefined') {
    const thousandsSeparatorRegex = new RegExp(thousandsSeparator.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'g')
    cleanValue = cleanValue.replace(thousandsSeparatorRegex, '')
  }
  if (typeof decimalSeparator !== 'undefined') {
    const decimalSeparatorRegex = new RegExp(decimalSeparator.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'g')
    cleanValue = cleanValue.replace(decimalSeparatorRegex, '.')
  }

  // No need to check a negative sign at position 0, because parseFloat can parse it
  const parsedNumber = parseFloat(cleanValue)
  const finalNumber = parsedNumber * (negative ? -1 : 1)
  return finalNumber
}

export function getSignificantDigitCount (number: number): number {

  // Remove decimals and make positive
  let n = Math.abs(parseInt(String(number).replace('.', ''), 10))

  if (n === 0) {
    return 0
  }

  // Kill the 0s at the end of n
  while (n !== 0 && n % 10 === 0) {
    n /= 10
  }

  // get number of digits
  return Math.floor(Math.log(n) / Math.log(10)) + 1
}

export function tryParseFloat (value: string) {
  if (!isNaN(parseFloat(value.replace(',', '.')))) {
    return parseFloat(value.replace(',', '.'))
  } else {
    return value
  }
}
