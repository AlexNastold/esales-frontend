/* eslint-disable no-useless-escape */
import { characterRangeFromCharcode } from '@scripts/helper/characterRange'

export function validateEmailAddress (emailAddress): { success: boolean } {
  // tslint:disable-next-line max-line-length
  const regex = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/
  return { success: regex.test(emailAddress) }
}

/**
 * Prüft alle Materialnummern, ob diese von dem Barcodetyp unterstützt werden
 */
export function validateBarcode (
  barcodeType: string,
  text: string = '',
): {
  success: boolean,
  invalidCharacters?: string[],
} {
  const invalidCharacters = []
  const barcodes = {
    C39: /^[0-9A-Z\-\. \$\/+%]$/,
    'C39+': /^[0-9A-Z\-\. \$\/+%]$/,
    C39E: [...characterRangeFromCharcode(0, 127)],
    'C39E+': [...characterRangeFromCharcode(0, 127)],
    C93: [...characterRangeFromCharcode(0, 127)],
    C128: [...characterRangeFromCharcode(0, 127)],
  }

  const check = barcodes[barcodeType]
  if (check) {
    for (const char of text) {
      if (Array.isArray(check)) {
        if (check.indexOf(char) === -1) {
          invalidCharacters.push(char)
        }
      } else if (check instanceof RegExp) {
        if (!check.test(char)) {
          invalidCharacters.push(char)
        }
      }
    }
  }

  if (invalidCharacters.length) {
    return { invalidCharacters, success: false }
  }
  return { success: true }
}
