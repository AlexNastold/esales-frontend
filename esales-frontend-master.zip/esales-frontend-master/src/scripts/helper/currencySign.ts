const currencies = [
  { sign: '€', text: 'EUR' },
  { sign: '$', text: 'USD' },
]

export function getCurrencySign (input: string): string {
  const matchedCurrency = currencies.find((currency) => currency.text === input)
  if (matchedCurrency) {
    return matchedCurrency.sign
  }
  return input
}

export function replaceCurrencyWithSign (input: string): string {
  let replacedInput = input

  currencies.forEach((currency) => {
    const currencyRegex = new RegExp(`(^|\\s)${currency.text}($|\\s)`, 'g')
    replacedInput = replacedInput.replace(currencyRegex, `${currency.sign}`)
  })

  return replacedInput
}
