import urlParse from 'url-parse'

interface IParsedUrl {
  protocol: string,
  slashes: boolean,
  hostname: string,
  port: number,
  username: string,
  pathname: string,
  hash: string,
  href: string,
  query: { [key: string]: string },
}

const allowedPathNames = [
  /^.*article$/,
  /^.*basket$/,
  /^.*campaign$/,
  /^.*campaigns$/,
  /^.*catalogue$/,
  /^.*checkout$/,
  /^.*consent-declaration$/,
  /^.*imprint$/,
  /^.*index$/,
  /^.*labels$/,
  /^.*my-account(-.+)?$/,
  /^.*news$/,
  /^.*ordermatrix$/,
  /^.*privacy$/,
  /^.*product-comparison$/,
  /^.*search$/,
  /^.*service(-.+)?$/,
  /^.*terms$/,
  /^.*terms-of-use$/,
  /^.*topsellers$/,
]

const excludeParams = [
  'redirectMessage',
  'redirectMessageType',
]

function isPathAllowed (path: string): boolean {
  return (allowedPathNames.some((allowedPathName) => {
    return allowedPathName.test(path)
  }))
}

export function filterParameters (url: string): any {
  const parsedUrl: IParsedUrl = urlParse(url, true)

  const query = Object.keys(parsedUrl.query).reduce((acc, paramName) => {
    if (!excludeParams.includes(paramName)) {
      acc[paramName] = parsedUrl.query[paramName]
    }
    return acc
  }, {})

  const queryString = Object.keys(query).length
    ? '?' + Object.keys(query)
      .map((paramName) => `${encodeURIComponent(paramName)}=${encodeURIComponent(query[paramName])}`)
      .join('&')
    : ''

  const isAbsolute = /^https?:\/\//i.test(url)

  if (isAbsolute) {
    return parsedUrl.protocol + '//' +
      parsedUrl.hostname +
      (parsedUrl.port ? ':' + parsedUrl.port : '') +
      (parsedUrl.pathname === '/' ? '' :  parsedUrl.pathname) +
      queryString +
      (parsedUrl.hash ? '#' + parsedUrl.hash : '')
  } else {
    return (parsedUrl.pathname === '/' ? '' :  parsedUrl.pathname) +
      queryString +
      (parsedUrl.hash ? '#' + parsedUrl.hash : '')
  }
}

(window as any).filterParameters = filterParameters

export function getNextShopPageAfterLogin (
  redirectUrl: string,
  currentUrl: string = location.href,
  fallback: string = 'index',
): string {
  // Fallback zurückgeben, falls redirectUrl leer ist
  if (!redirectUrl) {
    return fallback
  }

  // Prüfen, ob redirectUrl bereits erlaubt ist
  if (isPathAllowed(redirectUrl)) {
    return filterParameters(redirectUrl)
  }

  const currentUrlParsed: IParsedUrl = urlParse(currentUrl, true)
  const redirectUrlParsed: IParsedUrl = urlParse(redirectUrl, true)

  // Hosts vergleichen
  if (currentUrlParsed.hostname !== redirectUrlParsed.hostname) {
    return fallback
  }

  // Pfadname aus Url holen (ohne führenden Slash)
  const pathName = redirectUrlParsed.pathname.toLowerCase().substring(1)

  // Prüfen, ob Pfadname erlaubt ist
  if (isPathAllowed(pathName)) {
    return filterParameters(redirectUrl)
  }

  // Fallback zurückgeben, falls nichts gepasst hast
  return fallback
}
