import { serverOrigin } from '@scripts/core/paths'

export function rewriteUrlsInText (text: string): string {
  if (!text) {
    return ''
  }
  let textReplaced = text

  // Absolute Bilderpfade ersetzen
  textReplaced = textReplaced.replace(/src="\/([^"]+)"/g, `src="${serverOrigin}/$1"`)

  // Absolute Linkpfade ersetzen
  textReplaced = textReplaced.replace(/href="\/([^"]+)"/g, `href="${serverOrigin}/$1"`)

  return textReplaced
}
