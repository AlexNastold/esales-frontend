export function characterRange (start: string, end: string) {
  const charCodeStart = start.charCodeAt(0)
  const charCodeEnd = end.charCodeAt(0)
  const characters = []
  for (let i = charCodeStart; i < charCodeEnd; i++) {
    characters.push(String.fromCharCode(i))
  }
  return characters
}

export function characterRangeFromCharcode (charCodeStart, charCodeEnd) {
  const characters = []
  for (let i = charCodeStart; i < charCodeEnd; i++) {
    characters.push(String.fromCharCode(i))
  }
  return characters
}
